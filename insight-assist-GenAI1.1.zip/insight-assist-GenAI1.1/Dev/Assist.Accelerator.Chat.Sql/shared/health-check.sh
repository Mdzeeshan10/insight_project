#!/bin/bash

/opt/mssql-tools/bin/sqlcmd -Usa -P${SA_PASSWORD} -Q "select 1"
