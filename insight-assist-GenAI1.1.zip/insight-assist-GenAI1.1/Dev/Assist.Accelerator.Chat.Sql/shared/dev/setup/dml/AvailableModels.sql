/*
COST-RELATED INFO:

ChatGPT4 model info
   https://azure.microsoft.com/en-us/blog/introducing-gpt4-in-azure-openai-service/
   8k context	$0.03 per 1,000 tokens	$0.06 per 1,000 tokens
   32k context	$0.06 per 1,000 tokens	$0.12 per 1,000 tokens
Database has CostPerPromptToken=3000 and CostPerCompletionToken=6000 and CostUnit=2 for this model
This is $30 and $60 per million tokens (in and out respectively)
That's 3000 and 6000 "tenths of a cent per million tokens", which is in the DB

Bison-Chat model info
  https://cloud.google.com/vertex-ai/pricing#vertex-ai-pricing
  Price per 1000 *CHARACTERS* is $0.0010 in and out
This is $1 per million CHARACTERS in and out, each
That's 100 "tenths of a cent per million characters", which is in the DB

Amazon Bedrock Model info
  https://us-east-1.console.aws.amazon.com/bedrock/home?region=us-east-1#/providers?model=titan-large



NOTES FROM THE CODE

// The amount spent by the user for this API call, in millionths of a cent
CostUsed = CalculateCost(ChatResponse response) =
{
        return response.InputTokens * CostPerPromptToken +
               response.OutputTokens * CostPerCompletionToken;
}
CostUnit: Token = 1, Character = 2

*/



/* Replace providers for Provider=2 -> ModelProvider=GoogleVertexAIProvider */
BEGIN TRAN;

DELETE FROM ctl.AvailableModels WHERE Provider=2;

/* Provider=2 -> ModelProvider=GoogleVertexAi */
INSERT INTO ctl.AvailableModels (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, IsActive)
VALUES (2, N'chat-bison@001', N'chat-bison', N'001', 100, 100, 2, N'VertexAI', 0);

COMMIT TRAN;

SELECT TRIM(ModelVersion) as ModelVersion FROM ctl.AvailableModels WHERE Provider=2;




/* Replace providers for Provider=3 -> ModelProvider=AmazonBedrock
*/
BEGIN TRAN;

DELETE FROM ctl.AvailableModels WHERE Provider=3;

-- Pricing is TBD
INSERT INTO ctl.AvailableModels (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, IsActive)
VALUES (3, N'Amazon', N'Titan-Large', N'amazon.titan-tg1-large', 1100, 1100, 1, N'BedrockAI', 0);

-- Input tokens: $11.02 per million tokens Output tokens: $32.68 per million tokens
INSERT INTO ctl.AvailableModels (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, IsActive)
VALUES (3, N'Anthropic', N'Claude-V2', N'anthropic.claude-v2', 1102, 3268, 1, N'BedrockAI', 0);

-- Input tokens: $11.02 per million tokens, Output tokens: $32.68 per million tokens
INSERT INTO ctl.AvailableModels (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, IsActive)
VALUES (3, N'Anthropic', N'Claude-V1', N'anthropic.claude-v1', 1102, 3268, 1, N'BedrockAI', 0);

-- Input tokens: $1.63 per million tokens, Output tokens: $5.51 per million tokens
INSERT INTO ctl.AvailableModels (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, IsActive)
VALUES (3, N'Anthropic', N'Claude-V1-Instant', N'anthropic.claude-instant-v1', 163, 551, 1, N'BedrockAI', 0);

-- Input tokens: $18.80 per million tokens, Output tokens: $18.80 per million tokens
INSERT INTO ctl.AvailableModels (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, IsActive)
VALUES (3, N'AI21', N'J2 Ultra', N'ai21.j2-ultra', 1880, 1880, 1, N'BedrockAI', 0);

-- Input tokens: $12.50 per million tokens, Output tokens: $12.50 per million tokens
INSERT INTO ctl.AvailableModels (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, IsActive)
VALUES (3, N'AI21', N'J2 Mid', N'ai21.j2-mid', 1250, 1250, 1, N'BedrockAI', 0);

COMMIT TRAN;

SELECT TRIM(ModelVersion) as ModelVersion FROM ctl.AvailableModels WHERE Provider=3;
