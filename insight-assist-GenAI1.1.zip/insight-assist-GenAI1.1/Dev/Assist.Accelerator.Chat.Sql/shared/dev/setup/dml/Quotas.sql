SET IDENTITY_INSERT ctl.Quotas ON

INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (1, null, 0, 100000000000, N'2023-06', 115149800, 6, 6363, 33422);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (2, 1, null, 2000000000, N'2023-06', 27681800, 2, 2204, 12584);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (3, null, 0, 100000000000, N'2023-01', 0, 0, 0, 0);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (4, null, 0, 100000000000, N'2023-01', 0, 0, 0, 0);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (5, null, 0, 100000000000, N'2023-02', 0, 0, 0, 0);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (6, null, 0, 100000000000, N'2023-03', 0, 0, 0, 0);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (7, null, 0, 100000000000, N'2023-04', 0, 0, 0, 0);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (8, null, 0, 100000000000, N'2023-05', 0, 0, 0, 0);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (9, 2, null, 2000000000, N'2023-06', 94602000, 3, 4153, 23228);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (10, 3, null, 2000000000, N'2023-06', 1164000, 1, 24, 340);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (11, null, 0, 2000000000, N'2023-07', 1254344000, 202, 75513, 394877);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (12, 2, null, 2000000000, N'2023-07', 498724400, 58, 24602, 139611);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (13, 1, null, 2000000000, N'2023-07', 10662000, 3, 598, 2358);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (14, 3, null, 2000000000, N'2023-07', 243952300, 68, 11905, 72733);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (15, 8, null, 2000000000, N'2023-07', 7548000, 1, 712, 1092);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (16, 9, null, 2000000000, N'2023-07', 4724600, 4, 2375, 4237);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (17, 14, null, 2000000000, N'2023-07', 6498000, 2, 995, 176);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (18, 16, null, 2000000000, N'2023-07', 137333500, 11, 6774, 35823);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (19, 5, null, 2000000000, N'2023-07', 29052800, 3, 1287, 8037);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (20, 19, null, 2000000000, N'2023-07', 1158000, 1, 153, 80);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (21, 23, null, 2000000000, N'2023-07', 53349000, 4, 4401, 8981);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (22, 18, null, 2000000000, N'2023-07', 746800, 1, 873, 2861);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (23, 15, null, 2000000000, N'2023-07', 116600, 1, 482, 101);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (24, 24, null, 2000000000, N'2023-07', 23646400, 3, 1411, 7443);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (25, 11, null, 2000000000, N'2023-07', 8484000, 3, 872, 1084);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (26, 13, null, 2000000000, N'2023-07', 10815000, 2, 958, 1689);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (27, 28, null, 2000000000, N'2023-07', 63603000, 5, 2671, 15859);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (28, 27, null, 2000000000, N'2023-07', 119641800, 29, 10388, 83085);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (29, 20, null, 2000000000, N'2023-07', 981800, 1, 1728, 3181);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (30, 7, null, 2000000000, N'2023-07', 37350000, 2, 2644, 7162);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (31, null, 0, 2000000000, N'2023-08', 96296800, 14, 5475, 34590);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (32, 27, null, 2000000000, N'2023-08', 939000, 0, 48, 217);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (33, 2, null, 2000000000, N'2023-08', 1764000, 4, 1364, 7456);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (34, 23, null, 2000000000, N'2023-08', 161000, 2, 591, 214);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (35, 7, null, 2000000000, N'2023-08', 356800, 0, 154, 1630);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (36, 12, null, 2000000000, N'2023-08', 82000, 1, 301, 109);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (37, 16, null, 2000000000, N'2023-08', 12429000, 2, 606, 2931);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (38, 28, null, 2000000000, N'2023-08', 29055000, 2, 1506, 6673);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (39, 24, null, 2000000000, N'2023-08', 69690000, 3, 1771, 19688);
INSERT INTO ctl.Quotas (Id, UserId, TeamId, CostLimit, Period, CostUsed, ConversationCount, CompletionTokenCount, PromptTokenCount) VALUES (40, 30, null, 2000000000, N'2023-08', 3150000, 1, 472, 106);

SET IDENTITY_INSERT ctl.Quotas OFF
