# GOAL

Create a local instance of MS SQL Server,
populated with data for local development of this project.

# DESCRIPTION

This container runs without maintaining permanent storage
so that no cleanup is necessary, and setup is always done
from an empty database.

The container exposes the DB on the localhost at port 1433.

# APP-SPECIFIC SETUP

This will:
- Create the dev database
- Run a copy of scripts taken from the repo's Database directory
- Run some additional dev setup scripts to populate data that is not
  created above.

# REQUIREMENTS

This should run on any system with:
- Bash
- Make
- Docker and Docker-Compose

## Special Note for Windows users

Docker is mandatory for this setup, but depending on your permissions, getting it running can
be painful due to permission issues, and may require an assist from your helpdesk. 

Due to licensing, Rancher Desktop or Podman is recommended for running containers, and should 
be nearly transparently compatible to Docker.

`Make` can be installed via chocolatey. If you installed node.js through the Windows installer,
there is a good chance you already have chocolatey installed. You can test this by running 
`choco -v` and seeing if you get a version number back.

Either way, once chocolatey is available, run `choco install make` in an admin-elevated console
to install make.

If you are running this on Windows, you must run this in a bash environment. It will not
function under Powershell. Running it in `git bash` will work. If you are using Windows Terminal
(the default for Windows 11), it is possible to add git bash to your available shells for a 
better developer experience, please see [this blog for details](https://www.timschaeps.be/post/adding-git-bash-to-windows-terminal/).

# SETUP

Optionally, create a custom config file ```./sqlserverdb.env```

If this file exists, it will be used.
If this file does not exist, it will be created from ```./sqlserverdb.env.example```

# RUNNING THE CODE

```make```

# CONFIGURING YOUR USER

- Note that your login account needs to be part of the Insight Engineering tenant. Please see the [UI documentation](../../Documentation/InsightAssist/UI/README.md) for more information on this.

Once you are part of the Insight Engineering tenant, add your user to the database:

- Connect to the database using SQL Server Management Studio or Azure Data Studio; this connection string should work for the default setup: `Server=localhost,1433;Database=InsightAssist;User Id=sa;Password=test123!;Connection Timeout=5;TrustServerCertificate=True;`

- Run the `dbo.CreateUser` stored procedure to create your entry in the users table.

- Search the `ctl.UserRoles` table to find your entry and note the userId value.

- Run the following sql:

```sql
if not exists (select *
from ctl.[UserRoles]
where userId = @userId)
begin
    insert into ctl.[UserRoles]
        (userId, roleId)
    values
        (@userId, 1)
end
```
