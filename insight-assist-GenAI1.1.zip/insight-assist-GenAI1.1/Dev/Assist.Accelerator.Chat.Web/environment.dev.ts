export const environment = {
  production: false,
  defaultauth: 'aad',
  chatApi: 'https://localhost:7295/chat',
  chatSignalR: 'https://localhost:7295/messageHub',
  statsApi: 'https://localhost:7295/stats',
  usersApi: 'https://localhost:7295/users',
  aadConfig: {
    apiBase: 'https://localhost:7295',
    clientId: '68e74e21-0923-492c-b9a7-ba5578ae1565',
    tenantId: 'ada8b199-c07c-4596-ba92-bbcea977b591',
  },
  appInsightsConfig: {
    instrumentationKey: 'bd2e4dc7-2773-48b0-97fb-f6bbceb7d9e6',
  },
};
