# GOAL

Support running some or all components locally.

# DESCRIPTION

This automates some dev setup tasks so that we can develop locally.
This also implicitly documents some steps or constraints around dev.

This is useful for development and maybe as a step to containerizing
the app so that it can run in another environment (e.g. locally).

Given that we shouldn't keep secrets in code, this uses a pattern
of keeping example files in version control with secrets marked out.

See the sub-folders for details.

# INSTRUCTIONS

Each dir under ./Dev has a README and Makefile

In short, this allows you to have all components running locally. It also lets us store config files away from the code and makes it more feasible to use some sort of vault and templating for the files if we want to do that.

```
cd Assist.Accelerator.Chat.Sql
make
```

```
cd Assist.Accelerator.Chat.Api
cp ./examples/appsettings.development.json.example ./appsettings.development.json edit and replace secrets
make
```

```
cd Assist.Accelerator.Chat.Web
cp examples/environment.dev.ts.example ./environment.dev.ts edit and replace secrets (if any are added)
make
```
