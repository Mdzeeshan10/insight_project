using Insight.Assist.Api.Models;
using Insight.Assist.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Security.Claims;
using Assist.Accelerator.Chat.Api.Util.Exceptions;

namespace Insight.Assist.Api.Controllers;

[Authorize]
[ApiController]
[Route("[controller]")]
[Produces("application/json")]
public class UsersController : ControllerBase
{
    private readonly UsersService _usersService;

    public UsersController(
        UsersService usersService)
    {
        _usersService = usersService;
    }

    [HttpGet("me")]
    public async Task<IActionResult> GetMe()
    {
        var result = await _usersService.GetCurrentUserDetails();
        return Ok(result);
    }

    [HttpPost]
    public async Task<IActionResult> InviteGuestUser([FromBody] UserInvite invitation)
    {
        await _usersService.InviteGuestUser(invitation);
        return Ok();
    }

    [HttpGet("GetADUsers")]
    public async Task<IActionResult> GetADUsers(string filter)
    {
        var result = await _usersService.GetADUsers(filter);
        return Ok(result);
    }

    //[HttpGet("GetADGroupMembers")]
    //public async Task<IActionResult> GetADGroupUsers(string groupName)
    //{
    //    var result = await _usersService.GetGroupMembers(groupName);
    //    return Ok(result);
    //}

    [HttpGet("GetRoles")]
    public async Task<IActionResult> GetRoles()
    {
        var result = await _usersService.GetRoles();
        return Ok(result);
    }

    //[HttpGet("AddAllAdUsersToApplication")]
    //public async Task<IActionResult> AddAllAdUsersToApplication()
    //{
    //    try
    //    {
    //        await _usersService.AddAllAdUsersToApplication();
    //        return Ok();
    //    }
    //    catch (Exception ex)
    //    {
    //        _logger.LogError(ex, ex.Message);
    //        return NotFound();
    //    }
    //}

    [HttpGet("GetApplicationUsers")]
    public Task<UserResponse> GetApplicationUsers(string? filter, int pageNumber, int pageSize, int groupId)
    {
        var result = _usersService.GetApplicationUsers(filter, pageNumber, pageSize, groupId);
        return result;
    }

    [HttpPost("AddUsers")]
    [Authorize(Roles = Policy.Admin)]
    public async Task<IActionResult> AddUsers([FromBody] List<Models.User> user, int userRoleId)
    {
        await _usersService.AddUsers(user, userRoleId);
        return Ok();
    }

    [HttpPost("DeleteUsers")]
    [Authorize(Roles = Policy.Admin)]
    public async Task<IActionResult> DeleteUsers(string userIds, bool status)
    {
        await _usersService.DeleteUsers(userIds, status);
        return Ok();
    }

    [HttpPost("UpdateAppUserRole")]
    [Authorize(Roles = Policy.Admin)]
    public async Task<IActionResult> UpdateAppUserRole(int UserId, int RoleId)
    {
        var adminCount = await _usersService.GetAdminCount();

        if (RoleId == (int)UsersService.UserRole.User && adminCount <= 1)
        {
            return StatusCode(500, "There must be atleast one administrator.");
        }

        await _usersService.UpdateAppUserRole(UserId, RoleId);
        return Ok();
    }

    [HttpPost("UpdateAutoRegisterFlag")]
    public async Task<IActionResult> UpdateAutoRegisterFlag(bool flag)
    {
        await _usersService.UpdateAutoRegisterFlag(flag);
        return Ok();
    }

    [HttpGet("GetAutoRegisterFlag")]
    public async Task<IActionResult> GetAutoRegisterFlag()
    {
        var result = await _usersService.GetAutoRegisterFlag();
        return Ok(result);
    }

    [HttpPost("ToggleModelControl")]
    public async Task<IActionResult> ToggleModelControl(int Id, bool status, bool isGroup)
    {
        await _usersService.ToggleModelControl(Id, status, isGroup);
        return Ok();
    }

    [HttpPost("ToggleKnowledgeBase")]
    public async Task<IActionResult> ToggleKnowledgeBase(int indexId, int userId, bool status)
    {
        var res = await _usersService.ToggleKnowledgeBase(indexId, userId, status);
        return Ok(res);
    }

    // ###########################################################################

    [HttpGet("SearchADGroups")]
    public async Task<IActionResult> SearchADGroups(string initials)
    {
        var result = await _usersService.SearchGroupsByInitials(initials);
        return Ok(result);
    }

    [HttpPost("AddADGroups")]
    public async Task<IActionResult> AddADGroups([FromBody] List<Group> groups, int groupRoleId)
    {
        await _usersService.AddGroup(groups, groupRoleId);
        return Ok();
    }

    [HttpGet("GetGroupsForMember")]
    public async Task<IActionResult> GetGroupsForMember(string memberADId)
    {
        var result = await _usersService.GroupsForMember(memberADId);
        return Ok(result);
    }

    [HttpGet("GetApplicationGroups")]
    public Task<GroupResponse> GetApplicationGroups(string? filter, int pageNumber, int pageSize)
    {
        var result = _usersService.GetApplicationGroups(filter, pageNumber, pageSize);
        return result;
    }

    [HttpPost("ApplicationGroupStatus")]
    public async Task<IActionResult> DeleteApplicationGroup(int userId, bool status)
    {
        await _usersService.DeleteApplicationGroup(userId, status);
        return Ok();
    }

    [HttpPost("UpdateGroupRole")]
    public async Task<IActionResult> UpdateGroupRole(int GroupId, int RoleId)
    {
        await _usersService.UpdateGroupRole(GroupId, RoleId);
        return Ok();
    }

    [HttpGet("GetGroupNamesForUser")]
    public async Task<IActionResult> GetGroupNamesForUser(int userId, string? filter, int pageNumber, int pageSize)
    {
        var res = await _usersService.GetGroupNamesForUser(userId, filter, pageNumber, pageSize);
        return Ok(res);
    }

    [HttpGet("GetKnowledgeBaseForUser")]
    public async Task<IActionResult> GetKnowledgeBaseForUser(int userId, string? filter, int pageNumber, int pageSize)
    {
        var res = await _usersService.GetKnowledgeBaseForUser(userId, filter, pageNumber, pageSize);
        return Ok(res);
    }


    // ###########################################################################

    [HttpPost("GetIndexes")]
    public async Task<IActionResult> GetIndexFromURL([FromBody] IndexRequest request)
    {
        var res = await _usersService.GetAzureIndexes(request);
        return Ok(res);
        

    }

    [HttpGet("GetInfo")]
    public Task<IndexInfoResponse> GetIndexInfo(string? filter, int pageNumber, int pageSize)
    {

        var indexes = _usersService.GetIndexInfo(filter, pageNumber, pageSize);
        return indexes;

    }

    [HttpPost("DisplayName")]
    public async Task<IActionResult> UpdateDisplayName(int indexId, string displayName)
    {

        //Check if the display name already exists in the database
        bool isDisplayNameExists = await _usersService.IsDisplayNameExists(indexId, displayName);
        if (isDisplayNameExists)
        {
            return Conflict("Display name already exists. Please choose a different name.");
        }

        await _usersService.UpdateDisplayName(indexId, displayName);
        return Ok();

    }

    [HttpPost("DeleteKnowledgeBase")]
    public IActionResult UpdateIndexStatus(int indexId, bool status)
    {
        var response = _usersService.UpdateIndexStatus(indexId, status);
        return Ok(response);

    }

    [HttpGet("GetActiveKnowledgeBases")]
    public async Task<IActionResult> GetActiveKnowledgeBases()
    {

        var res = await _usersService.ActiveIndexList();
        return Ok(res);

    }

    // ###########################################################################
    // Role Policy Testing
    // ###########################################################################

    [HttpGet("me/is-admin")]
    [Authorize(Roles = Policy.Admin)]
    public IActionResult CheckAdmin()
    {
        return Ok("You have passed the policy check on the Admin role.");
    }

    [HttpGet("me/is-user")]
    [Authorize(Roles = Policy.User)]
    public IActionResult CheckUser()
    {
        return Ok("You have passed the policy check on the User role.");
    }

    [HttpGet("me/roles")]
    public IActionResult ExtractRole()
    {
        var roles = this.HttpContext.User.Claims
            .Where(c => c.Type == ClaimTypes.Role)
            .Select(r => r.Value)
            .ToList();
        return Ok(roles);
    }

    // ###########################################################################
    // ###########################################################################
}