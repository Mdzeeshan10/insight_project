using Assist.Accelerator.Chat.Api.Models;
using Assist.Accelerator.Chat.Api.Models.MapExtensions;
using Assist.Accelerator.Chat.Api.Models.Exceptions;
using Assist.Accelerator.Chat.Api.Services;
using Assist.Accelerator.Chat.Api.Util;
using Assist.Accelerator.Chat.CopilotSupport;
using Insight.Assist.Api.Models;
using Insight.Assist.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Insight.Assist.Api.Controllers;

[Authorize]
[ApiController]
[Route("[controller]")]
public class ChatController : ControllerBase
{
    private readonly ChatService _chatService;
    private readonly FileService _fileService;
    private readonly KernelService _kernelService;
    private readonly ICopilotSupport _copilotSupport;

    private readonly long _maxFileSize;

    public ChatController(
        ChatService chatService,
        FileService fileService,
        KernelService kernelService,
        ICopilotSupport copilotSupport,
        IConfiguration configuration)
    {
        _chatService = chatService;
        _fileService = fileService;
        _kernelService = kernelService;
        _copilotSupport = copilotSupport;

        var maxFileSize = configuration.GetValue<long>("FileStorage:MaxFileSize");
        _maxFileSize = maxFileSize > 0 ? maxFileSize : 100000000;
    }

    [HttpGet] // TODO: needs pagination
    public IActionResult Get()
    {
        var chats = _chatService.Get();
        return Ok(chats);
    }

    [HttpGet("{id}")]
    public IActionResult Get(string id)
    {
        if (!Guid.TryParse(id, out var guid))
        {
            return NotFound(id);
        }

        var chat = _chatService.Get(guid);
        return Ok(chat);
    }

    [HttpPost]
    public async Task<IActionResult> Post(
        [FromBody] ChatBody body)
    {
        var chat = await _kernelService.GetChatCompletionAsync(body);
        if (chat == null)
        {
            throw new Exception("Invalid chat result.");
        }
        return Ok(chat);
    }

    [HttpGet("copilots")]
    public IActionResult GetCopilots()
    {
        CopilotPredicate isActiveCheck = new CopilotPredicate(nameof(CopilotRegistration.IsActive), true);
        IEnumerable<CopilotRegistration> matchedCopilots = _copilotSupport.FilterCopilots(new CopilotPredicate[] { isActiveCheck });
        IEnumerable<Copilot> copilots = matchedCopilots.AsCopilots();
        
        return Ok(copilots);
    }

    [HttpGet("file")]
    public async Task<IActionResult> GetFile(
        [FromQuery] string fileName)
    {
        if (string.IsNullOrEmpty(fileName)) return BadRequest("Request must include fileName in query.");

        using var chatFile = await _fileService.DownloadFileAsync(fileName);
        using var mem = new MemoryStream();
        chatFile.Stream.CopyTo(mem);

        return new FileContentResult(mem.ToArray(), "text/plain");
    }

    [HttpGet("file/check")]
    public async Task<IActionResult> GetFileCheck(
        [FromQuery] string fileName)
    {
        if (string.IsNullOrEmpty(fileName)) return BadRequest("Request must include fileName in query.");

        var exists = await _fileService.FileExistsAsync(fileName);
        var extensions = _fileService.GetSupportedFileExtensions();
        var isSupported = extensions
            .Contains(new ChatFile { FileName = fileName }.FileExtension);

        return Ok(new FileCheckResponse
        {
            FileName = fileName,
            Exists = exists,
            IsSupported = isSupported
        });
    }

    [HttpGet("file/supported")]
    public async Task<IActionResult> GetSupportedFileExtensions()
    {
        var extensions = _fileService.GetSupportedFileExtensions();

        return Ok(new FileSupport
        {
            Extensions = extensions,
            MaxFileSize = _maxFileSize
        });
    }

    [HttpPut("file")]
    public async Task<IActionResult> PutFile(
        [FromForm] IList<IFormFile> files)
    {
        if (files == null || !files.Any())
        {
            return BadRequest($"Request must include exactly 1 file.");
        }

        var file = files[0];

        if (file.Length > _maxFileSize)
        {
            return BadRequest($"Attached file ({FileUtils.GetFileSizeString(file.Length)}) exceeds maximum size ({FileUtils.GetFileSizeString(_maxFileSize)}).");
        }

        await _fileService.UploadFileAsync(file.FileName, file.OpenReadStream(), HttpContext.RequestAborted);

        return NoContent();
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Put(
        [FromRoute] string id,
        [FromBody] ChatBody body)
    {
        if (!Guid.TryParse(id, out var guid))
        {
            throw new ChatApiException();
        }

        var chat = await _kernelService.GetChatCompletionAsync(body, guid);

        if (chat == null)
        {
            throw new Exception("Invalid chat result.");
        }

        return Ok(chat);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        if (!Guid.TryParse(id, out var guid))
        {
            return NotFound(id);
        }

        await _chatService.Delete(guid);
        return Ok();
    }

    [HttpPut("Rename/{id}")]
    public async Task<IActionResult> Rename(string newTitle, string id)
    {
        if (!Guid.TryParse(id, out var guid))
        {
            return NotFound(id);
        }

        var chat = await _chatService.Rename(newTitle, guid);
        return Ok(chat);
    }

    [HttpGet("ActiveIndex")]
    public async Task<IActionResult> GetActiveIndexes()
    {
        var activeIndexes = await _chatService.GetActiveIndexes();
        return Ok(activeIndexes);
    }

    [HttpPost("DeleteIndex")]
    public IActionResult UpdateIndexStatus(int indexId, bool status)
    {
        var response = _chatService.UpdateIndexStatus(indexId, status);
        return Ok(response);

    }

    [HttpGet("GetInfo")]
    public Task<IndexInfoResponse> GetIndexInfo(string? filter, int pageNumber, int pageSize)
    {
        var indexes = _chatService.GetIndexInfo(filter, pageNumber, pageSize);
        return indexes;

    }

    [HttpPost("CognitiveSearchWithOpenAI")]
    public async Task<IActionResult> AzureCognitiveSearchWithOpenAI(string message, List<int> indexIds)
    {
        var azureResponse = await _chatService.GetAzureResultWIthOpenAI(message, indexIds);
        return Ok(new { result = azureResponse });
    }

    [HttpPost("DisplayName")]
    public async Task<IActionResult> UpdateDisplayName(int indexId, string displayName)
    {
        //Chexk if the display name already exists in the database
        bool isDisplayNameExists = await _chatService.IsDisplayNameExists(indexId, displayName);
        if (isDisplayNameExists)
        {
            return Conflict("Display name already exists. Please choose a different name.");
        }

        await _chatService.UpdateDisplayName(indexId, displayName);
        return Ok();
    }
}