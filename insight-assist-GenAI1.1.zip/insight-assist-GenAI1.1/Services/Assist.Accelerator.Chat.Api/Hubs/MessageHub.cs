﻿using Microsoft.AspNetCore.SignalR;

namespace Assist.Accelerator.Chat.Api.Hubs
{
    public class MessageHub : Hub
    {
        public override Task OnConnectedAsync()
        {
            Console.WriteLine("User connected: " + Context.ConnectionId);

            return base.OnConnectedAsync();
        }

        public async Task SendMessageToAllClients(string user, string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", user, message);
        }

        public async Task AddUserToGroup(string groupName)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, groupName.ToLower());
        }
    }
}
