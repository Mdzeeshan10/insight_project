using Assist.Accelerator.Chat.Api.Models.Usage;
using Assist.Accelerator.Chat.Api.Util;
using Insight.Assist.Api.Services;
using Polly;
using Polly.Retry;
using System.Reflection;

namespace Assist.Accelerator.Chat.Api.HostedServices;

public abstract class HistoricalStatsService : CronJobService
{
    private readonly HistoricalStatSpan _span;
    private readonly IServiceScopeFactory _serviceScopeFactory;
    private readonly AsyncRetryPolicy _concurrencyRetryPolicy;
    private readonly ILogger<HistoricalStatsService> _logger;

    public HistoricalStatsService(
        string cronExpression,
        HistoricalStatSpan span,
        IServiceScopeFactory serviceScopeFactory,
        ILogger<HistoricalStatsService> logger)
        : base(cronExpression)
    {
        _span = span;
        _serviceScopeFactory = serviceScopeFactory;
        _concurrencyRetryPolicy = Policy
            .Handle<Exception>()
            .WaitAndRetryAsync(3, _ => TimeSpan.FromSeconds(5));
        _logger = logger;
    }

    public override async Task DoWork(CancellationToken cancellationToken)
    {
        await _concurrencyRetryPolicy.ExecuteAsync(async () =>
        {
            using var scope = _serviceScopeFactory.CreateScope();
            var statsService = scope.ServiceProvider.GetService<StatsService>();

            try
            {
                if (statsService == null) { throw new NullReferenceException(); }

                var now = DateTime.UtcNow;
                var prevSpanDateTime = _span.PreviousStartDate(now);
                var startDateTime = _span.PeriodDateTimeForSpan(prevSpanDateTime);
                var stats = await statsService.ComputeHistoricalStats(prevSpanDateTime, _span);

                // Iterate over each property so we can create a new row for each stat
                var properties = typeof(StatsService.AdminStats).GetProperties();
                foreach (var property in properties)
                {
                    var statAttr = property.GetCustomAttributes(typeof(StatsService.HistoricalStatAttribute)).FirstOrDefault() as StatsService.HistoricalStatAttribute;
                    if (statAttr == null) continue;

                    var stat = statsService.GetHistoricalStat(statAttr.Index, _span, startDateTime) ?? new HistoricalStat
                    {
                        Index = statAttr.Index,
                        StartDateTime = startDateTime,
                        Span = _span,
                        Name = statAttr.Name,
                        Data = new Dictionary<int, object>()
                    };

                    var value = property.GetValue(stats);
                    if (value == null) continue;

                    stat.Data[GetXAxisPoint(prevSpanDateTime, _span)] = value;

                    statsService.SaveHistoricalStat(stat, save: false);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
            finally
            {
                await statsService.SaveHistoricalStats(true);
            }
        });
    }

    private int GetXAxisPoint(DateTime dateTime, HistoricalStatSpan span)
    {
        return span switch
        {
            HistoricalStatSpan.Year => dateTime.Year,
            HistoricalStatSpan.Month => dateTime.Month,
            HistoricalStatSpan.Day => dateTime.Day,
            HistoricalStatSpan.Hour => dateTime.Hour,
            _ => dateTime.Minute
        };
    }
}

public class MinutelyHistoricalStatsService : HistoricalStatsService
{
    public MinutelyHistoricalStatsService(IServiceScopeFactory serviceScopeFactory, ILogger<HistoricalStatsService> logger)
        : base("* * * * *", HistoricalStatSpan.Minute, serviceScopeFactory, logger)
    {
    }
}

public class HourlyHistoricalStatsService : HistoricalStatsService
{
    public HourlyHistoricalStatsService(IServiceScopeFactory serviceScopeFactory, ILogger<HistoricalStatsService> logger)
        : base("0 * * * *", HistoricalStatSpan.Hour, serviceScopeFactory, logger)
    {
    }
}

public class DailyHistoricalStatsService : HistoricalStatsService
{
    public DailyHistoricalStatsService(IServiceScopeFactory serviceScopeFactory, ILogger<HistoricalStatsService> logger)
        : base("0 0 * * *", HistoricalStatSpan.Day, serviceScopeFactory, logger)
    {
    }
}

public class MonthlyHistoricalStatsService : HistoricalStatsService
{
    public MonthlyHistoricalStatsService(IServiceScopeFactory serviceScopeFactory, ILogger<HistoricalStatsService> logger)
        : base("0 0 1 * *", HistoricalStatSpan.Month, serviceScopeFactory, logger)
    {
    }
}