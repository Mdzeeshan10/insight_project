namespace Assist.Accelerator.Chat.Api.Util;

public class Date
{
    // TODO: design decisions still need to be made about time zones, so just
    // pulling this out so that if we ever wanna change how dates are stored we can do it in one place.
    public static DateTime Now => DateTime.UtcNow;
}