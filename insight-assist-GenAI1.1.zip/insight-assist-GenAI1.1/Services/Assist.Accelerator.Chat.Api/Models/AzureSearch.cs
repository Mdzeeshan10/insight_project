﻿using System.ComponentModel.DataAnnotations;

namespace Insight.Assist.Api.Models;

public partial class AzureSearch
{
    [Key]
    public int AzureSearchId { get; set; }

    public string SearchUrl { get; set; } = null!;

    public string AzureKey { get; set; } = null!;

    public virtual ICollection<AzureSearchIndex> AzureSearchIndices { get; set; } = new List<AzureSearchIndex>();
}

