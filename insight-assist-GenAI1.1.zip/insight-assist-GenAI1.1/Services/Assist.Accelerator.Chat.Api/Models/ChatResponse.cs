using Azure.AI.OpenAI;

namespace Insight.Assist.Api.Models;

public class ChatResponse
{
    public string Message { get; set; }
    public int InputTokens { get; set; }
    public int OutputTokens { get; set; }

    public int TotalTokens => InputTokens + OutputTokens;

    public ChatMessage ChatMessage => new(ChatRole.Assistant, Message);
}