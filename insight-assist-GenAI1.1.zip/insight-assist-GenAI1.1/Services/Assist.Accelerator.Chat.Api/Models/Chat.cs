using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Azure.AI.OpenAI;

namespace Insight.Assist.Api.Models;

public class Chat
{
    public Chat()
    {
        Messages = new List<ChatMessage>();
        CreatedAt = DateTime.UtcNow;
        SQLChat = new List<ChatMessage>();
    }
    
    [Key]
    public Guid Id { get; set; }
    public IEnumerable<ChatMessage> Messages { get; set; }
    public IEnumerable<ChatMessage> SQLChat { get; set; }
    public string Title { get; set; }
    public int UserId { get; set; }
    public int TokenCount { get; set; }
    public int? CopilotId { get; set; }
    public int IndexId { get; set; }
    public DateTime? CreatedAt { get; set; }
    
    [NotMapped]
    public Quota Quota { get; set; }
}