namespace Insight.Assist.Api.Models;

public class ChatBody
{
    public string Input { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
    public int? Copilot { get; set; } = null;
    public int IndexId { get; set; } = 0;
    public string ModelName { get; set; } = string.Empty;
}