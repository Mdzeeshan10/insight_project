using System.ComponentModel.DataAnnotations;
using System.Runtime.InteropServices;

namespace Insight.Assist.Api.Models;

public class UserInvite
{
    // required
    public string? EmailAddress { get; set; } 

    // optional - if not provided the email address will be parsed
    public string? FirstName { get; set; }

    // optional - if not provided the email address will be parsed
    public string? LastName { get; set; }

    // optional - if not provided the email address will be parsed
    public string? DisplayName { get; set; }

    // optional - if not provided the user will be returned to the host address
    public string? ReturnUrl { get; set; }

    // optional - if not provided the invitation will use default active directory messaging
    public string? Message { get; set; }

    // todo - add roles, permissions, etc.
}