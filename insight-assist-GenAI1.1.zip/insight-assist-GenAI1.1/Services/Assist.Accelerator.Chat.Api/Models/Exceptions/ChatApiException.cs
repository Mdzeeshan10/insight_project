﻿using Google.Rpc;
using Grpc.Core;
using Microsoft.AspNetCore.Http;
using System.Net;

namespace Assist.Accelerator.Chat.Api.Models.Exceptions
{
    public class ChatApiException: Exception
    {
        public HttpStatusCode StatusCode = HttpStatusCode.InternalServerError;

        public ChatApiException()
        {
        }

        public ChatApiException(string message)
            : base(message)
        {
        }

        public ChatApiException(string message, Exception inner)
            : base(message, inner)
        {
        }
        public ChatApiException(HttpStatusCode statusCode)
            : base(statusCode.ToString())
        {
            StatusCode = statusCode;
        }

        public ChatApiException(HttpStatusCode statusCode, string message)
            : base(message)
        {
            StatusCode = statusCode;
        }

        public ChatApiException(HttpStatusCode statusCode, string message, Exception inner)
            : base(message, inner)
        {
            StatusCode = statusCode;
        }
    }
}
