﻿using Microsoft.EntityFrameworkCore;

namespace Insight.Assist.Api.Models
{

    public class GroupUsers
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int GroupId { get; set; }
    }
}
