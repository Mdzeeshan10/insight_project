using System.ComponentModel.DataAnnotations;

namespace Assist.Accelerator.Chat.Api.Models;

public class Copilot
{
    [Key]
    public int Id { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public string IntroMessage { get; set; }
    public bool IsActive { get; set; }
    public string FileTypes { get; set; }
}