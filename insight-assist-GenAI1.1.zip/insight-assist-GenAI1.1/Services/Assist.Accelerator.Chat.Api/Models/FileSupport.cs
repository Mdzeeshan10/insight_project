﻿namespace Assist.Accelerator.Chat.Api.Models
{
    public class FileSupport
    {
        public List<string> Extensions { get; set; }
        public long MaxFileSize { get; set; }
    }
}
