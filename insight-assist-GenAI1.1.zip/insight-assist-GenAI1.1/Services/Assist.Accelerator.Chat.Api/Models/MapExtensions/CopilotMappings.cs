﻿using Assist.Accelerator.Chat.CopilotSupport;

namespace Assist.Accelerator.Chat.Api.Models.MapExtensions
{
    public static class CopilotMappings
    {
        public static Copilot AsCopilot(this CopilotRegistration regEntry)
        {
            return new Copilot
            {
                Id = regEntry.Id,
                Name = regEntry.DisplayName,
                Description = regEntry.Description,
                IntroMessage = regEntry.IntroMessage,
                IsActive = regEntry.IsActive,
                FileTypes = regEntry.FileTypes
            };
        }

        public static IEnumerable<Copilot> AsCopilots(this IEnumerable<CopilotRegistration> regEntries)
        {
            return regEntries.Select(AsCopilot);
        }

        public static CopilotSettings AsCopilotSettings(this CopilotRegistration regEntry)
        {
            CopilotAuthProvider? authProvider = (CopilotAuthProvider?)regEntry.AuthProviderId;
            
            return new CopilotSettings
            {
                CopilotId = regEntry.Id,
                Endpoint = regEntry.Endpoint??string.Empty,
                AuthProvider = authProvider??CopilotAuthProvider.NoAuth,
                CredentialData = regEntry.CredentialData??string.Empty,
                Pipeline = regEntry.Pipeline
            };
        }

        public static IEnumerable<CopilotSettings> AsCopilotSettings(this IEnumerable<CopilotRegistration> regEntries)
        {
            return regEntries.Select(AsCopilotSettings);
        }
    }
}
