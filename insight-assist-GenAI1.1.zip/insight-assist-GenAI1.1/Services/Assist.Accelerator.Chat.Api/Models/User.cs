using System.ComponentModel.DataAnnotations;

namespace Insight.Assist.Api.Models;

public class User
{
    [Key]
    public int UserId { get; set; }
    public string Name { get; set; }
    public string LastName { get; set; }
    public string EmailAddress { get; set; }
    public bool IsActive { get; set; }
    public bool? model_control { get; set; }

    //public  byte[] EncryptedUserAPIKey { get; set; }
    public bool OwnsChat(Chat chat)
    {
        return UserId == chat.UserId;
    }

    /*public int RoleId { get; set; }*/
}
public class UserResponse
{
    public List<UserWithRoleMapped> Users { get; set; }
    public int PageCount { get; set; }
}

public class UserWithRoleMapped
{
   
    public int RoleId { get; set; }

    public int UserId { get; set; }
    public string Name { get; set; }
    public string LastName { get; set; }
    public string EmailAddress { get; set; }
    public bool IsActive { get; set; }
    public bool? model_control { get; set;}
}