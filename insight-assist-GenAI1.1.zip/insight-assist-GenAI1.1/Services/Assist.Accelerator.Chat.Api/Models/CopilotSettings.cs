using System.ComponentModel.DataAnnotations;
using Google.Cloud.AIPlatform.V1;
using Newtonsoft.Json;

namespace Assist.Accelerator.Chat.Api.Models;

public class CopilotSettings
{
    [Key]
    public int CopilotId { get; set; }
    public string Endpoint { get; set; }
    public CopilotAuthProvider AuthProvider { get; set; }
    public string CredentialData { get; set; }
    
    public string Pipeline { get; set; }

    public CopilotPipeline Plan => JsonConvert.DeserializeObject<CopilotPipeline>(Pipeline)!;
}