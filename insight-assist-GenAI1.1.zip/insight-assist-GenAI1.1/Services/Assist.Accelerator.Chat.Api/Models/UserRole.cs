using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Insight.Assist.Api.Models;

[PrimaryKey(nameof(UserId), nameof(RoleId))]
public class UserRole
{
    public int UserId { get; set; }
    public int RoleId { get; set; }
}