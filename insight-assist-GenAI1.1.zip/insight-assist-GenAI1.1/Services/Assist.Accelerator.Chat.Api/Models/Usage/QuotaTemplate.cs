using System.ComponentModel.DataAnnotations;

namespace Insight.Assist.Api.Models;

public class QuotaTemplate
{
    /// <summary>
    /// ID of the default quota template, which is used for users who have no quota assignment
    /// </summary>
    public const int DefaultId = 1;
    
    /// <summary>
    /// ID of the default quota template, which is used for the organization (which doesn't have a QuotaAssignment)
    /// </summary>
    public const int OrgDefaultId = 2;
    
    /// <summary>
    /// ID of the quota template
    /// </summary>
    [Key]
    public int Id { get; set; }
    
    /// <summary>
    /// Name of the template
    /// </summary>
    public string? Name { get; set; }
    
    /// <summary>
    /// CostLimit is the max a user can spend in the quota time period, in millionths of a cent
    /// </summary>
    public Int64 CostLimit { get; set; }
}