namespace Assist.Accelerator.Chat.Api.Models.Usage;

public enum ModelProvider
{
    AzureOpenAiService = 1,
    GoogleVertexAi,
    AmazonBedrockAi
}