using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Assist.Accelerator.Chat.Api.Util;
using Azure.AI.OpenAI;

namespace Insight.Assist.Api.Models;

public class Quota
{
    /// <summary>
    /// C# date format used to store the quota's time period (currently only implemented as monthly) 
    /// </summary>
    public const string PeriodDateFormat = "yyyy-MM";

    /// <summary>
    /// The team ID used to identify all users in the system
    /// </summary>
    public const int AllUsersTeamId = 0;
    
    /// <summary>
    /// ID of this quota
    /// </summary>
    [Key]
    public int Id { get; set; }
    
    /// <summary>
    /// User ID assigned this quota
    /// </summary>
    public int? UserId { get; set; }

    /// <summary>
    /// User assigned this quota
    /// </summary>
    public User? User { get; init; }
    
    /// <summary>
    /// Team ID assigned this quota
    /// TODO: Teams not yet implemented, but using TeamID = 0 to refer to all users
    /// </summary>
    public int? TeamId { get; set; }
    
    /// <summary>
    /// The max a user can spend in the quota time period, in millionths of a cent
    /// </summary>
    public Int64 CostLimit { get; set; }
    
    /// <summary>
    /// Monthly period for when this quota is in effect
    /// </summary>
    public string Period { get; set; }
    
    /// <summary>
    /// The amount spent by the user in the quota time period, in millionths of a cent
    /// </summary>
    public Int64 CostUsed { get; set; }
    
    /// <summary>
    /// Number of conversations started during this quota period
    /// </summary>
    public int ConversationCount { get; set; }
    
    /// <summary>
    /// Number of completion tokens used during this quota period
    /// </summary>
    public int CompletionTokenCount { get; set; }
    
    /// <summary>
    /// Number of prompt tokens used during this quota period
    /// </summary>
    public int PromptTokenCount { get; set; }

    /// <summary>
    /// Whether or not the user has exceeded their quota during this time period
    /// </summary>
    [NotMapped]
    public bool HasBeenExceeded => CostUsed >= CostLimit;

    /// <summary>
    /// Gets the period string for the current moment, in the format used to track periods in quotas
    /// </summary>
    public static string CurrentPeriodString => GetPeriodStringForDate(DateTime.UtcNow);

    public void IncreaseQuota(ApiCall apiCall)
    {
        PromptTokenCount += apiCall.PromptTokenCount ?? 0;
        CompletionTokenCount += apiCall.CompletionTokenCount ?? 0;
        CostUsed += apiCall.CostUsed ?? 0;

        // Increment conversation count if this is a new user conversation (e.g. has no assistant messages/responses)
        // initiated by a user (e.g. not system action like naming the conversation) 
        if (apiCall.IsSystemAction == false
            && apiCall.RequestOptions.Messages.All(m => m.Role != ChatRole.Assistant))
        {
            ConversationCount++;
        }
    }

    public static Quota FromTemplate(QuotaTemplate template, int? userId = null, int? teamId = null, string? period = null)
    {
        // TODO: should not set both userId and teamId
        var quota = new Quota
        {
            UserId = userId,
            TeamId = teamId,
            CostLimit = template.CostLimit,
            Period = period ?? GetPeriodStringForDate(DateTime.UtcNow)
        };
        
        return quota;
    }

    public static string GetPeriodStringForDate(DateTime month)
    {
        return month.ToString(PeriodDateFormat);
    }
}