namespace Assist.Accelerator.Chat.Api.Models;

public enum CopilotAuthProvider
{
  NoAuth = 0,
  GoogleCloudServiceAccount = 1  
}