using System.ComponentModel.DataAnnotations;

namespace Insight.Assist.Api.Models;

public class UserDetails
{
    public int UserId { get; set; }
    public string EmailAddress { get; set; } = string.Empty;
    public List<string> Roles { get; set; } = new List<string>();
}