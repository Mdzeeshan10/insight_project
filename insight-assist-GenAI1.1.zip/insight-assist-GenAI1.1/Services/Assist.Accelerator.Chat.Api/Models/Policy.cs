using System.ComponentModel.DataAnnotations;

namespace Insight.Assist.Api.Models;

// For each supported authorization policy, define a list of roles
//  that should pass a policy check.
public static class Policy
{

    public const string Admin = $"{Role.Admin}";
    public const string User = $"{Role.Admin},{Role.User}";
    
}