using System.ComponentModel.DataAnnotations;

namespace Insight.Assist.Api.Models;

public class Usage
{
    [Key]
    public int UserId { get; set; }
    // Quota is in thousandths of a cent
    public int Quota { get; set; }
    // Quota is in thousandths of a cent
    public int Used { get; set; }
    public int ConversationCount { get; set; }
    public int EmailUsageCount { get; set; }
    public int SqlUsageCount { get; set; }
}