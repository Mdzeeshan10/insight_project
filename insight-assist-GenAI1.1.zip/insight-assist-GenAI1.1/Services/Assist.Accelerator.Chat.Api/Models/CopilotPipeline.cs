namespace Assist.Accelerator.Chat.Api.Models;

public class CopilotPipeline
{
    public Dictionary<string, string> ContextVariables { get; set; }
    
    public List<string> Plugins { get; set; }
}