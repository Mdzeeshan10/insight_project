﻿using Microsoft.SemanticKernel.Orchestration;
using Microsoft.SemanticKernel.SkillDefinition;
using SharpToken;
using System.ComponentModel;
using Microsoft.SemanticKernel;

namespace Assist.Accelerator.Chat.Api.SemanticKernel.Plugins
{
    public class MemoryPlugin
    {
        private readonly int _totalPromptTokens = 12228;
        private readonly int _chunkSize = 2048;
        private readonly int _chunkOverlap = 256;
        
        private readonly GptEncoding _encoding;

        public MemoryPlugin() 
        {
            _encoding = GptEncoding.GetEncoding("r50k_base");
        }

        /// <summary>
        /// Turns user input, file contents and chat history into memories and engineers
        /// the prompt 
        /// </summary>
        [SKFunction, Description("Refines prompt and chat history to most relevant parts")]
        public async Task GetMemories(
            [Description("The chat's ID")] string chatId,
            [Description("The chat history as a string")] string chatHistory,
            [Description("The parsed text of the attached file")] string fileText,
            [Description("The message sent by the user")] string userInput,
            SKContext context)
        {
            var chunks = new List<string>();
            var userInputChunks = SplitText(userInput);
            var fileTextChunks = SplitText($"Attached file contents: {fileText}");
            var prompt = context.Variables.TryGetValue("userIntent", out var userIntent)
                ? userIntent : userInput;

            chunks.AddRange(fileTextChunks);
            chunks.AddRange(SplitText(chatHistory));
            chunks.AddRange(userInputChunks);

            if (userInputChunks.Count > 1 && context.Variables.ContainsKey("userIntent"))
            {
                prompt = userIntent;
            }

            await context.Memory.SaveInformationAsync(chatId, chunks[0], "0");

            await Task.WhenAll(chunks.Skip(1).Select((str, i) =>
                context.Memory.SaveInformationAsync(chatId, str, (i+1).ToString())));

            var totalMemories = (_totalPromptTokens / _chunkSize) - 1;
            var memories = context.Memory.SearchAsync(chatId, prompt, totalMemories, 0.0);
            var memoriesText = new List<string>();

            var e = memories.GetAsyncEnumerator();
            
            while (await e.MoveNextAsync())
            {
                memoriesText.Add(e.Current.Metadata.Text);
            }

            if (memoriesText.Count == 0 && fileTextChunks.Count > 0)
            {
                memoriesText.AddRange(fileTextChunks.Take(totalMemories));
            }

            context.Variables.Set("prompt", prompt);
            context.Variables.Set("chatHistory", memoriesText.Any()
                ? string.Join(" ", memoriesText)
                : "No chat history");
        }
        
        [SKFunction, Description("Retrieves memories from a cognitive search index")]
        public async Task GetCognitiveSearchMemories(
            [Description("The message sent by the user")] string userInput,
            [Description("The URL of the ACS instance to connect to")] string cognitiveSearchUrl,
            [Description("The collection to query in ACS")] string cognitiveSearchCollection,
            [Description("The key to connect to ACS")] string cognitiveSearchKey,
            [Description("The limit of results returned from ACS")] string cognitiveSearchLimit,
            SKContext context)
        {
            var acsKernel = Kernel.Builder
                .WithLogger(context.Log)
                .WithAzureCognitiveSearchMemory(cognitiveSearchUrl, cognitiveSearchKey)
                .Build();
            
            var queryResult = acsKernel.Memory
                .SearchAsync(cognitiveSearchCollection, userInput, int.Parse(cognitiveSearchLimit));
            
            var memoriesText = new List<string>();
            var e = queryResult.GetAsyncEnumerator();
            while (await e.MoveNextAsync())
            {
                memoriesText.Add(e.Current.Metadata.Text);
            }

            context.Variables.Set("searchResults", memoriesText.Any()
                ? string.Join(" ", memoriesText)
                : "No search results");
        }

        private List<string> SplitText(string text)
        {
            var splits = new List<string>();
            var tokens = _encoding.Encode(text);
            
            while (tokens.Any())
            {
                splits.Add(_encoding.Decode(tokens.Take(_chunkSize).ToList()));

                if (tokens.Count < _chunkSize)
                {
                    tokens.Clear();
                }
                else
                {
                    tokens.RemoveRange(0, _chunkSize - _chunkOverlap);
                }
                Console.WriteLine(splits.Last());
            }

            return splits;
        }
    }
}
