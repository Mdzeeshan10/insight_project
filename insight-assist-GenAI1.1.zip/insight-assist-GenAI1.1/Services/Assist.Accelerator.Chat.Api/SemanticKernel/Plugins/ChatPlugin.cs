﻿using Assist.Accelerator.Chat.Api.Hubs;
using Assist.Accelerator.Chat.Api.Util;
using Azure.AI.OpenAI;
using Google.Api.Gax.Grpc;
using Insight.Assist.Api;
using Insight.Assist.Api.Models;
using Insight.Assist.Api.Services;
using Microsoft.AspNetCore.SignalR;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.AI.ChatCompletion;
using Microsoft.SemanticKernel.AI.TextCompletion;
using Microsoft.SemanticKernel.Connectors.AI.OpenAI.Tokenizers;
using Microsoft.SemanticKernel.Orchestration;
using Microsoft.SemanticKernel.SemanticFunctions;
using Microsoft.SemanticKernel.SkillDefinition;
using Newtonsoft.Json;
using System.ComponentModel;
using Assist.Accelerator.Chat.Api.Providers;
using Assist.Accelerator.Chat.Api.Services;
using Tavis.UriTemplates;
using static System.Runtime.InteropServices.JavaScript.JSType;
//using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Assist.Accelerator.Chat.Api.SemanticKernel.Plugins
{
    public class ChatPlugin
    {
        private readonly PromptTemplateConfig _promptConfig = new()
        {
            Completion =
            {
                MaxTokens = 2048,
                Temperature = 0.9,
                TopP = 0.0,
                PresencePenalty = 0.0,
                FrequencyPenalty = 0.0
            }
        };

        private const string _systemPrompt = @"You are a friendly and helpful assistant. 
                Respond to the user's inquiry with a useful answer.
                Use information from the chat history and search results where appropriate.";

        private const string _completionPrompt = @"
You are a friendly and helpful assistant. 
Respond to the user's inquiry with a useful answer.
Use information from the chat history and search results where appropriate.

HISTORY
+++++
{{$chatHistory}}
+++++

SEARCH RESULTS
+++++
{{$searchResults}}
+++++

USER: {{$prompt}}
ASSISTANT: 
";

        private readonly IKernel _kernel;
        private readonly UsageService _usageService;
        private readonly UsersService _usersService;
        private readonly LlmService _llmService;
        private readonly ChatService _chatService;
        private readonly ResponseStreamingService _responseStreamingService;
        private readonly ISKFunction _getChatCompletion;
        private readonly ISKFunction _getChatTitle;
        private readonly ISKFunction _getUserIntent;
        private readonly User _user;
        private readonly AvailableModel _model;

        /// <summary>
        /// Plugin containing functions that prompt the LLM for a response.
        /// </summary>
        public ChatPlugin(IKernel kernel, UsageService usageService, UsersService usersService, LlmService llmService, ChatService chatService, ResponseStreamingService responseStreamingService)
        {
            _kernel = kernel;
            _usageService = usageService;
            _usersService = usersService;
            _llmService = llmService;
            _chatService = chatService;
            _responseStreamingService = responseStreamingService;

            _getChatCompletion = RegisterFunction(nameof(GetChatCompletion), @"
                You are a friendly and helpful assistant. 
                Respond to the user's inquiry with a useful answer.
                Use information from the chat history and search results where appropriate.

                HISTORY
                +++++
                {{$chatHistory}}
                +++++

                SEARCH RESULTS
                +++++
                {{$searchResults}}
                +++++

                USER: {{$prompt}}
                ASSISTANT: 
                ");

            _getChatTitle = RegisterFunction(nameof(GetChatTitle), @"
                You are a friendly and helpful assistant. 
                Create a title that is 6 words or less and summarizes the topic of the following conversation.

                USER: {{$userInput}}
                ASSISTANT: {{$llmOutput}}
                TITLE: 
                ");

            _getUserIntent = RegisterFunction(nameof(GetUserIntent), @"
                Repeat the user's request from the following message. Speak as if you are the user clarifying their intent. Include only what the user is requesting, and leave out any background information they may have included.

                USER: {{$userInput}}
                SUMMARY: 
                ");

            _user = _usersService.GetCurrentUserOrThrow();
            _model = _usageService.GetCurrentModel();
            _chatService = chatService;
        }

        /// <summary>
        /// Gets a response for an existing chat.
        /// </summary>
        [SKFunction, Description("Gets chat completion from a prompt")]
        public async Task GetChatCompletion(
            [Description("The chat's ID")] string chatId,
            [Description("The user's input")] string userInput,
            SKContext context)
        {
            if (!context.Variables.ContainsKey("prompt"))
            {
                context.Variables.Set("prompt", userInput);
            }

            context.Variables.TryGetValue("userEmail", out string userEmail);
            context.Variables.TryGetValue("searchResults", out string searchResults);

            if (!context.Variables.TryGetValue("chatHistory", out string chatHistoryString))
            {
                chatHistoryString = string.Empty;
            }

            var quotas = await GetRequestQuotas();

            int modelId = Convert.ToInt32(context["modelId"]);
            var model = _usageService.GetModelFromDatabase(modelId);

            var apiCall = CreateApiCall(context, nameof(GetChatCompletion), true);

            var chatCompletion = this._kernel.GetService<IChatCompletion>();

            string botInstructions = _completionPrompt
                .Replace("{{$chatHistory}}", chatHistoryString)
                .Replace("{{$searchResults}}", searchResults)
                .Replace("{{$prompt}}", userInput);
            
            try
            {
                var chatRequestSettings = this.CreateChatRequestSettings();
                var chatHistory = chatCompletion.CreateNewChat(botInstructions);
                var stream = chatCompletion.GenerateMessageStreamAsync(chatHistory, chatRequestSettings);

                var responseStream = _responseStreamingService.Bind(userEmail);
                await responseStream.BeginResponseStream();
                await responseStream.UpdateResponseStatus("Generating response");

                string resultMessage = string.Empty;

                var alreadySentReceivingResponseStatus = false;
                await foreach (string contentPiece in stream)
                {
                    if (!alreadySentReceivingResponseStatus)
                    {
                        await responseStream.UpdateResponseStatus("Receiving response");
                        alreadySentReceivingResponseStatus = true;
                    }

                    resultMessage += contentPiece;
                    await responseStream.SendPartialResponse(resultMessage);
                }

                await responseStream.EndResponseStream();

                var promptTokens = GPT3Tokenizer.Encode(userInput).Count;
                var completionTokens = GPT3Tokenizer.Encode(resultMessage).Count;

                UpdateApiCallOnResponse(apiCall, context, resultMessage, model, promptTokens, completionTokens);
                
                context.Variables.Set("llmOutput", resultMessage);
            }
            catch (Exception ex)
            {
                await UpdateApiCallOnExceptionAsync(apiCall, ex);
                throw;
            }

            await UpdateUsageOnSuccess(apiCall, context, model, quotas);
        }

        private ChatRequestSettings CreateChatRequestSettings()
        {
            return new ChatRequestSettings
            {
                MaxTokens = _promptConfig.Completion.MaxTokens,
                Temperature = (float)_promptConfig.Completion.Temperature,
                PresencePenalty = (float)_promptConfig.Completion.PresencePenalty,
                FrequencyPenalty = (float)_promptConfig.Completion.FrequencyPenalty,
            };
        }

        /// <summary>
        /// Gets a response for an existing chat using a knowledge base.
        /// </summary>
        [SKFunction, Description("Gets the intent of a long user input.")]
        public async Task GetKbChatCompletion(
            [Description("The user's input")] string userInput,
            [Description("The knowledge base index to query")] string indexId,
            SKContext context)
        {
            if (!context.Variables.ContainsKey("prompt"))
            {
                context.Variables.Set("prompt", userInput);
            }

            var apiCall = CreateApiCall(context, nameof(GetKbChatCompletion), true);
            var response = await InvokeLlmServiceAsync(context, apiCall);

            context.Variables.Set("llmOutput", response);
        }

        /// <summary>
        /// Gets a title for a chat.
        /// </summary>
        [SKFunction, Description("Gets a title for a chat if one is not already set")]
        public async Task GetChatTitle(
            [Description("The chat's title")] string chatTitle,
            SKContext context)
        {
            if (string.IsNullOrEmpty(chatTitle))
            {
                var apiCall = CreateApiCall(context, nameof(GetChatTitle), true);
                var response = await InvokeFunctionAsync(_getChatTitle, context, apiCall);
                chatTitle = response;
            }

            context.Variables.Set("chatTitle", chatTitle);
        }

        /// <summary>
        /// If the user's input is too long to add to the prompt in one piece, extracts the
        /// intent 
        /// </summary>
        [SKFunction, Description("Gets the intent of a long user input.")]
        public async Task GetUserIntent(
            [Description("The user's input")] string userInput,
            SKContext context)
        {
            var tokens = GPT3Tokenizer.Encode(userInput).Count;

            if (tokens > 2048)
            {
                var apiCall = CreateApiCall(context, nameof(GetUserIntent), true);
                var response = await InvokeFunctionAsync(_getUserIntent, context, apiCall);
                var userIntent = response;

                context.Variables.Set("userIntent", userIntent);
            }
        }

        private ISKFunction RegisterFunction(string name, string prompt)
        {
            var promptTemplate = new PromptTemplate(prompt, _promptConfig, _kernel);
            var functionConfig = new SemanticFunctionConfig(_promptConfig, promptTemplate);

            var function = _kernel.RegisterSemanticFunction(nameof(ChatPlugin), name, functionConfig);

            return function;
        }

        private async Task<string> InvokeFunctionAsync(ISKFunction function, SKContext context, ApiCall apiCall)
        {
            var quotas = await GetRequestQuotas();

            int modelId = Convert.ToInt32(context["modelId"]);

            var model = _usageService.GetModelFromDatabase(modelId);

            string response;

            try
            {
                var result = await function.InvokeAsync(context);
                response = result.Result;
                UpdateApiCallOnResponse(apiCall, context, response, model);
            }
            catch (Exception ex)
            {
                await UpdateApiCallOnExceptionAsync(apiCall, ex);
                throw;
            }

            await UpdateUsageOnSuccess(apiCall, context, model, quotas);

            return response;
        }

        private async Task<string> InvokeLlmServiceAsync(SKContext context, ApiCall apiCall)
        {
            var quotas = await GetRequestQuotas();

            int modelId = Convert.ToInt32(context["modelId"]);
            
            var history = new List<ChatMessage>();

            if (context.Variables.ContainsKey("chatJson"))
            {
                var chat = JsonConvert.DeserializeObject<Insight.Assist.Api.Models.Chat>(context.Variables["chatJson"]);
                history = chat.Messages.ToList();
            }

            var model = _usageService.GetModelFromDatabase(modelId);
            var embedModel = _usageService.GetCurrentModel(ModelPurpose.Embedding);
            var prompt = context.Variables["prompt"];
            var indexId = int.Parse(context.Variables["indexId"]);
            /*var dataSources = await _chatService.GetDataSourceFromDatabase(indexId);
            string response;*/
            string dataSources = await _chatService.GetDataFromCogSearch(indexId, model, embedModel, prompt);//added prompt too and changed var to string
            string response;

            try
            {
                response = await _llmService.GetChatCompletion(model, dataSources, prompt, history);
                UpdateApiCallOnResponse(apiCall, context, response, model);
            }
            catch (Exception ex)
            {
                await UpdateApiCallOnExceptionAsync(apiCall, ex);
                throw;
            }

            await UpdateUsageOnSuccess(apiCall, context, model, quotas);

            return response;
        }

        private ApiCall CreateApiCall(SKContext context, string methodName, bool isSystemAction)
        {
            var user = _usersService.GetCurrentUser() ?? throw new Exception("User must be logged in.");

            //var model = _usageService.GetCurrentModel();
            int modelId = Convert.ToInt32(context["modelId"]);

            var model = _usageService.GetModelFromDatabase(modelId);

            var requestOptions = new ChatCompletionsOptions
            {
                MaxTokens = _promptConfig.Completion.MaxTokens,
                Temperature = (float)_promptConfig.Completion.Temperature,
                PresencePenalty = (float)_promptConfig.Completion.PresencePenalty,
                FrequencyPenalty = (float)_promptConfig.Completion.FrequencyPenalty,
            };

            context.Variables.TryGetValue("chatId", out var chatId);
            Guid.TryParse(chatId, out var chatGuid);

            var apiCall = new ApiCall
            {
                UserId = user.UserId,
                MethodName = methodName,
                ModelId = model.Id,
                DeploymentName = model.DeploymentName,
                ChatId = chatGuid,
                IsSystemAction = isSystemAction,
                RequestOptions = requestOptions,
                RequestedAt = DateTime.UtcNow,
                CostUsed = 0,
                //Tags = tags
            };

            return apiCall;
        }

        private async Task<RequestQuotas> GetRequestQuotas()
        {
            var currentUser = _usersService.GetCurrentUser() ?? throw new Exception("User must be logged in.");

            var quota = (await _usageService.GetQuota(userId: currentUser.UserId, month: DateTime.UtcNow))!;
            // TODO: individual user quota checks have been disabled - uncomment the if statement below to enable them
            //if (quota.HasBeenExceeded)
            //{
            //    throw new Exception($"User's quota for period {quota.Period} has been exceeded.");
            //}

            // TODO: right now, org quota is hardcoded; should revisit when teams are implemented to make it dynamic
            var orgQuota = (await _usageService.GetQuota(
                teamId: Insight.Assist.Api.Models.Quota.AllUsersTeamId,
                month: DateTime.UtcNow))!;

            if (orgQuota.HasBeenExceeded)
            {
                throw new Exception($"Organization's quota for period {quota.Period} has been exceeded.");
            }

            return new RequestQuotas
            {
                OrgQuota = orgQuota,
                UserQuota = quota
            };
        }

        private void UpdateApiCallOnResponse(ApiCall apiCall, SKContext context, string response, AvailableModel model, int promptTokens, int completionTokens)
        {
            apiCall.MarkResponseReceived();
            apiCall.ResponseMessage = new ChatMessage(ChatRole.Assistant, response);
            apiCall.PromptTokenCount = promptTokens;
            apiCall.CompletionTokenCount = completionTokens;
            apiCall.TotalTokenCount = promptTokens + completionTokens;
            apiCall.CostUsed = 
                promptTokens * model.CostPerPromptToken +
                completionTokens * model.CostPerCompletionToken;
        }

        private void UpdateApiCallOnResponse(ApiCall apiCall, SKContext context, string response, AvailableModel model)
        {
            var promptTokens = 0;
            var completionTokens = 0;

            foreach (var modelResult in context.ModelResults)
            {
                var usage = modelResult.GetUsage();

                promptTokens += usage.PromptTokens;
                completionTokens += usage.CompletionTokens;
            }

            UpdateApiCallOnResponse(apiCall, context, response, model, promptTokens, completionTokens);
        }

        private void UpdateApiCallOnResponse(ApiCall apiCall, SKContext context, string prompt, string response, AvailableModel model)
        {
            var promptTokens = 0;
            var completionTokens = 0;
            
            foreach (var modelResult in context.ModelResults)
            {
                var usage = modelResult.GetUsage();

                promptTokens += usage.PromptTokens;
                completionTokens += usage.CompletionTokens;
            }

            UpdateApiCallOnResponse(apiCall, context, response, model, promptTokens, completionTokens);
        }

        private async Task UpdateApiCallOnExceptionAsync(ApiCall apiCall, Exception ex)
        {
            apiCall.MarkResponseReceived();
            apiCall.ResponseError = ex.ToString();
            await _usageService.SaveApiCall(apiCall);
        }

        private async Task UpdateUsageOnSuccess(ApiCall apiCall, SKContext context, AvailableModel model, RequestQuotas quotas)
        {
            foreach (var modelResult in context.ModelResults)
            {
                var usage = modelResult.GetUsage();

                apiCall.CostUsed +=
                    usage.PromptTokens * model.CostPerPromptToken +
                    usage.CompletionTokens * model.CostPerCompletionToken;
            }

            await _usageService.IncreaseQuota(quotas.UserQuota!, apiCall);
            await _usageService.IncreaseQuota(quotas.OrgQuota!, apiCall);

            await _usageService.SaveApiCall(apiCall);
        }
    }
}
