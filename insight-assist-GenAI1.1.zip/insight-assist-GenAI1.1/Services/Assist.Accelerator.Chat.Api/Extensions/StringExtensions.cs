﻿using System.Text.RegularExpressions;

namespace Assist.Accelerator.Chat.Api.Extensions
{
    public static partial class StringExtensions
    {
        [GeneratedRegex("(\\s)\\s+")]
        private static partial Regex RemoveDuplicateWhitespaceRegex();

        public static string RemoveDuplicateWhitespace(this string str)
        {
            return RemoveDuplicateWhitespaceRegex().Replace(str, "$1");
        }
    }
}
