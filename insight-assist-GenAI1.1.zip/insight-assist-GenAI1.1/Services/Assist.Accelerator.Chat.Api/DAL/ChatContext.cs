using Assist.Accelerator.Chat.Api.Models;
using Azure.AI.OpenAI;
using Insight.Assist.Api.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace Insight.Assist.Api.DAL;

public class ChatContext : DbContext
{
    private readonly string _connectionString;

    public ChatContext(IConfiguration configuration) : base()
    {
        _connectionString = configuration.GetConnectionString("ControlDb")!;
    }

    public DbSet<Models.Chat> Chats { get; set; }
    public DbSet<User> Users { get; set; }
    //public DbSet<Copilot> Copilots { get; set; }
    //public DbSet<CopilotSettings> CopilotSettings { get; set; }
    public DbSet<Usage> Usage { get; set; }
    public DbSet<AzureSearch> AzureSearches { get; set; }

    public DbSet<AzureSearchIndex> AzureSearchIndices { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer(_connectionString);
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<User>().ToTable("User", "ctl");
        //modelBuilder.Entity<Copilot>().ToTable("Copilots", "ctl");
        //modelBuilder.Entity<CopilotSettings>().ToTable("CopilotSettings", "ctl");
        
        modelBuilder.Entity<ChatMessage>(
                eb =>
                {
                    eb.HasNoKey();
                    eb.Property(p => p.Role)
                        .HasConversion(v => v.ToString(),
                            v => Enum.Parse<ChatRole>(v));
                });

        modelBuilder.Entity<Models.Chat>(
            eb =>
            {
                eb.Property(p => p.Messages)
                    .HasConversion(v => JsonConvert.SerializeObject(v, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                        v => JsonConvert.DeserializeObject<IList<ChatMessage>>(v, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }));

                eb.Property(p => p.SQLChat)
                    .HasConversion(v => JsonConvert.SerializeObject(v, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                        v => JsonConvert.DeserializeObject<IList<ChatMessage>>(v, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }));
            });

        modelBuilder.Entity<AzureSearch>(entity =>
        {
            entity.HasKey(e => e.AzureSearchId).HasName("PK_AzureSearch");

            entity.ToTable("AzureSearch");

            entity.Property(e => e.AzureSearchId).HasColumnName("AzureSearchID");
            entity.Property(e => e.AzureKey)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.SearchUrl)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("SearchURL");
        });

        modelBuilder.Entity<AzureSearchIndex>(entity =>
        {
            entity.HasKey(e => e.IndexId).HasName("PK_AzureSearchIndex");

            entity.ToTable("AzureSearchIndex");

            entity.Property(e => e.IndexId).HasColumnName("IndexID");
            entity.Property(e => e.AzureSearchId).HasColumnName("AzureSearchID");
            entity.Property(e => e.DisplayName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.IndexName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.IsActive)
                .IsRequired()
                .HasDefaultValueSql("((0))")
                .HasColumnName("isActive");
            entity.Property(e => e.SemanticName)
                .HasMaxLength(255)
                .IsUnicode(false);

            entity.HasOne(d => d.AzureSearch).WithMany(p => p.AzureSearchIndices)
                .HasForeignKey(d => d.AzureSearchId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AzureSearch");
        });
    }
}