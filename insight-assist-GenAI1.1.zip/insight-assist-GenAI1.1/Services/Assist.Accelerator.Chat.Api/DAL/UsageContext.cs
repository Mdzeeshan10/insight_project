using Assist.Accelerator.Chat.Api.Models.Usage;
using Azure.AI.OpenAI;
using Insight.Assist.Api.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace Insight.Assist.Api.DAL;

public class UsageContext : DbContext
{
    private readonly string _connectionString;

    public UsageContext(IConfiguration configuration) : base()
    {
        _connectionString = configuration.GetConnectionString("ControlDb")!;
    }

    public DbSet<QuotaTemplate> QuotaTemplates { get; set; }
    public DbSet<QuotaAssignment> QuotaAssignments { get; set; }
    public DbSet<Quota> Quotas { get; set; }
    public DbSet<ApiCall> ApiCalls { get; set; }
    public DbSet<AvailableModel> AvailableModels { get; set; }
    public DbSet<HistoricalStat> HistoricalStats { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer(_connectionString);
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<QuotaTemplate>().ToTable("QuotaTemplates", "ctl");
        modelBuilder.Entity<QuotaAssignment>().ToTable("QuotaAssignments", "ctl");
        modelBuilder.Entity<Quota>().ToTable("Quotas", "ctl");
        modelBuilder.Entity<ApiCall>().ToTable("ApiCalls", "ctl");
        modelBuilder.Entity<AvailableModel>().ToTable("AvailableModels", "ctl");
        modelBuilder.Entity<HistoricalStat>().ToTable("HistoricalStats", "ctl");
        modelBuilder.Entity<User>().ToTable("User", "ctl");

        modelBuilder.Entity<ChatMessage>(
            eb =>
            {
                eb.HasNoKey();
                eb.Property(p => p.Role)
                    .HasConversion(v => v.ToString(),
                        v => Enum.Parse<ChatRole>(v));
            });

        modelBuilder.Entity<HistoricalStat>(
            eb =>
            {
                eb.Property(p => p.Data)
                    .HasConversion(
                        v => JsonConvert.SerializeObject(v,
                            new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                        v => JsonConvert.DeserializeObject<Dictionary<int, object>>(v,
                            new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }));
            });

        modelBuilder.Entity<ApiCall>(
            eb =>
            {
                eb.Property(p => p.RequestOptions)
                    .HasConversion(
                        v => JsonConvert.SerializeObject(v,
                            new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                        v => JsonConvert.DeserializeObject<ChatCompletionsOptions>(v,
                            new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }));
                
                eb.Property(p => p.ResponseMessage)
                    .HasConversion(
                        v => JsonConvert.SerializeObject(v,
                            new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                        v => JsonConvert.DeserializeObject<ChatMessage>(v,
                            new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }));
                
                eb.Property(p => p.Tags)
                    .HasConversion(
                        v => JsonConvert.SerializeObject(v,
                            new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                        v => JsonConvert.DeserializeObject<IEnumerable<string>>(v,
                            new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }));
            });
    }
}