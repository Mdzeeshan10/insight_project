using Insight.Assist.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Insight.Assist.Api.DAL;

public class UsersContext : DbContext
{
    private readonly string _connectionString;


    public UsersContext(IConfiguration configuration) : base()
    {
        _connectionString = configuration.GetConnectionString("ControlDb")!;
    }

    public DbSet<User> Users { get; set; }
    public DbSet<Role> Roles { get; set; }
    public DbSet<UserRole> UserRoles { get; set; }
    public DbSet<GlobalFlags> GlobalFlags { get; set; }
    public DbSet<Group> Groups { get; set; }
    public DbSet<GroupUsers> GroupUsers { get; set; }
    public DbSet<GroupRole> GroupRoles { get; set; }
    public DbSet<AzureSearch> AzureSearches { get; set; }
    public DbSet<AzureSearchIndex> AzureSearchIndexes { get; set; }
    public DbSet<AzureSearchIndexUsers> AzureSearchUsers { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer(_connectionString);
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<User>().ToTable("User", "ctl");
        modelBuilder.Entity<Role>().ToTable("Roles", "ctl");
        modelBuilder.Entity<UserRole>().ToTable("UserRoles", "ctl");
        modelBuilder.Entity<GlobalFlags>().ToTable("GlobalFlags", "ctl");
        modelBuilder.Entity<Group>().ToTable("Group", "dbo");
        modelBuilder.Entity<GroupUsers>().ToTable("GroupUsers", "dbo");
        modelBuilder.Entity<GroupRole>().ToTable("GroupRoles", "dbo");
        modelBuilder.Entity<AzureSearch>().ToTable("AzureSearch", "dbo");
        modelBuilder.Entity<AzureSearchIndex>().ToTable("AzureSearchIndex", "dbo");
        modelBuilder.Entity<AzureSearchIndexUsers>().ToTable("AzureSearchIndexUsers", "dbo");

    }
}