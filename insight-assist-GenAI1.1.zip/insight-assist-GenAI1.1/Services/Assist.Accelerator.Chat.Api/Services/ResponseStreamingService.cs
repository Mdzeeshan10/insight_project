using Assist.Accelerator.Chat.Api.Hubs;
using Azure.AI.OpenAI;
using Microsoft.AspNetCore.SignalR;

namespace Assist.Accelerator.Chat.Api.Services;

public static class StreamMessageTypes
{
    public const string BeginChatStream = "BeginChatStream";
    public const string ReceiveChatMessage = "ReceiveChatMessage";
    public const string EndChatStream = "EndChatStream";
    public const string UpdateStatus = "UpdateStatus";
}

public class BoundResponseStreamingService
{
    private readonly ResponseStreamingService _responseStreamingService;
    private readonly string _groupName;

    public BoundResponseStreamingService(ResponseStreamingService responseStreamingService, string groupName)
    {
        _responseStreamingService = responseStreamingService;
        _groupName = groupName;
    }
    
    public async Task BeginResponseStream()
    {
        await _responseStreamingService.BeginResponseStream(_groupName);
    }

    public async Task SendPartialResponse(string message)
    {
        await _responseStreamingService.SendPartialResponse(_groupName, message);
    }

    public async Task EndResponseStream()
    {
        await _responseStreamingService.EndResponseStream(_groupName);
    }

    public async Task UpdateResponseStatus(string updatedStatus)
    {
        await _responseStreamingService.UpdateResponseStatus(_groupName, updatedStatus);
    }
}

public class ResponseStreamingService 
{
    private readonly IHubContext<MessageHub> _messageHubContext;

    public ResponseStreamingService(IHubContext<MessageHub> messageHubContext)
    {
        _messageHubContext = messageHubContext;
    }

    public BoundResponseStreamingService Bind(string groupName)
    {
        return new BoundResponseStreamingService(this, groupName);
    }

    public async Task BeginResponseStream(string groupName)
    {
        await SendMessageToClientInternal(
            StreamMessageTypes.BeginChatStream, 
            string.Empty, 
            ChatRole.User,
            groupName);
    }

    public async Task SendPartialResponse(string groupName, string message)
    {
        await SendMessageToClientInternal(
            StreamMessageTypes.ReceiveChatMessage, 
            message, 
            ChatRole.Assistant,
            groupName);
    }

    public async Task EndResponseStream(string groupName)
    {
        await SendMessageToClientInternal(
            StreamMessageTypes.EndChatStream, 
            string.Empty, 
            ChatRole.User,
            groupName);
    }

    public async Task UpdateResponseStatus(string groupName, string updatedStatus)
    {
        await SendMessageToClientInternal(
            StreamMessageTypes.UpdateStatus, 
            updatedStatus, 
            ChatRole.Assistant,
            groupName);
    }

    private async Task SendMessageToClientInternal(string method, string message, ChatRole role, string groupName)
    {
        try
        {
            await _messageHubContext.Clients.Groups(groupName).SendAsync(method, role, message);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Received SignalR error: " + ex.Message);
        }
    }
}