﻿using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Text.Json;
using Assist.Accelerator.Chat.Api.Models.Exceptions;
using Assist.Accelerator.Chat.Api.Util.Exceptions;

namespace Assist.Accelerator.Chat.Api.Services.Middleware
{
    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;

        public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (ChatApiException ex)
            {
                await HandleExceptionAsync(context, ex, ex.StatusCode);
            }
            catch (Azure.RequestFailedException ex)
            {
                var message = ex.Message.Substring(0, ex.Message.IndexOf("\n"));
                await HandleExceptionAsync(context, ex, (HttpStatusCode)ex.Status, message);
            }
            catch (ValidationException ex)
            {
                await HandleExceptionAsync(context, ex, HttpStatusCode.BadRequest);
            }
            catch (UnauthorizedAccessException ex)
            {
                await HandleExceptionAsync(context, ex, HttpStatusCode.Unauthorized);
            }
            catch (NullReferenceException ex)
            {
                await HandleExceptionAsync(context, ex, HttpStatusCode.NotFound);
            }
            catch (UserConflictException ex)
            {
                await HandleExceptionAsync(context, ex, HttpStatusCode.Conflict);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex, HttpStatusCode.InternalServerError);
            }
        }

        private Task HandleExceptionAsync(HttpContext context, Exception exception, HttpStatusCode statusCode, string message = null)
        {
            context.Response.StatusCode = (int)statusCode;
            context.Response.ContentType = "application/json";

            var errorResponse = new
            {
                error = message ?? exception.Message ?? statusCode.ToString()
            };

            var jsonResponse = JsonSerializer.Serialize(errorResponse);

            _logger.LogError(exception, exception.Message);

            return context.Response.WriteAsync(jsonResponse);
        }
    }
}