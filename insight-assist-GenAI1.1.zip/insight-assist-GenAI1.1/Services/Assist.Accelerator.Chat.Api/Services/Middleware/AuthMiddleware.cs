using Assist.Accelerator.Chat.Api.Models.Exceptions;
using Microsoft.AspNetCore.Authentication;
using System.Net;
using System.Security.Claims;

namespace Insight.Assist.Api.Services.Middleware;

public class AuthMiddleware : IMiddleware
{
    private readonly ILogger<AuthMiddleware> _logger;
    private readonly UsersService _usersService;

    public AuthMiddleware(
        ILogger<AuthMiddleware> logger,
        UsersService usersService)
    {
        _logger = logger;
        _usersService = usersService;
    }

    public async Task InvokeAsync(HttpContext context, RequestDelegate next)
    {
        var path = context.Request.Path.Value ?? string.Empty;

        if (context.User.Identity != null
            && context.User.Identity.IsAuthenticated)
        {
            var userRoles = await _usersService.GetCurrentUserRoles();
            if (userRoles.Count > 0)
            {
                var identity = new ClaimsIdentity();
                foreach (var userRole in userRoles)
                {
                    identity.AddClaim(new Claim(identity.RoleClaimType, userRole.RoleName));
                }
                context.User.AddIdentity(identity); // add custom claims for roles/permissions in the
                                                    //   auth pipeline
            }
            else
            {
                throw new ChatApiException(HttpStatusCode.Forbidden);
            }
        }
        else
        {
            // TODO: this needs to be replaced with proper authentication for the endpoint...
            if (!path.Contains("messageHub"))
            {
                throw new ChatApiException(HttpStatusCode.Unauthorized);
            }
        }

        await next(context);
    }
}