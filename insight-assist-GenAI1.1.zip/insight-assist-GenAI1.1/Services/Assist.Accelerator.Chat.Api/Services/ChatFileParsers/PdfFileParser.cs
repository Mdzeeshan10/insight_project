﻿using Assist.Accelerator.Chat.Api.Extensions;
using Assist.Accelerator.Chat.Api.Models;
using System.Text;
using UglyToad.PdfPig;

namespace Assist.Accelerator.Chat.Api.Services.ChatFileParsers
{
    public class PdfFileParser : IChatFileParser
    {
        private static readonly List<string> _supportedFileExtensions = new() { ".pdf" };

        /// <inheritdoc />
        public List<string> SupportedFileExtensions => _supportedFileExtensions;

        /// <inheritdoc />
        public async Task<string> ParseFileAsync(ChatFile chatFile)
        {
            return await Task.Run(() =>
            {
                var sb = new StringBuilder();

                using var ms = new MemoryStream();
                chatFile.Stream.CopyTo(ms);

                var doc = PdfDocument.Open(ms.ToArray(), new ParsingOptions
                {
                    SkipMissingFonts = true
                });

                foreach (var page in doc.GetPages())
                {
                    if (!string.IsNullOrEmpty(page.Text))
                    {
                        sb.Append($" {page.Text} ");
                    };
                }

                var text = sb.ToString();
                return text;
            });
        }
    }
}
