﻿using Assist.Accelerator.Chat.Api.Models;

namespace Assist.Accelerator.Chat.Api.Services.ChatFileParsers
{
    public interface IChatFileParser
    {
        /// <summary>
        ///     List of supported file extensions.
        /// </summary>
        List<string> SupportedFileExtensions { get; }

        /// <summary>
        ///     Reads the text content of a ChatFile.
        /// </summary>
        /// <param name="chatFile"></param>
        /// <returns>The text contained in the ChatFile.</returns>
        Task<string> ParseFileAsync(ChatFile chatFile);
    }
}
