﻿using Assist.Accelerator.Chat.Api.Extensions;
using Assist.Accelerator.Chat.Api.Models;

namespace Assist.Accelerator.Chat.Api.Services.ChatFileParsers
{
    public class PlainTextFileParser : IChatFileParser
    {
        private static readonly List<string> _supportedFileExtensions = new() { ".txt", ".vtt" };

        /// <inheritdoc />
        public List<string> SupportedFileExtensions => _supportedFileExtensions;

        /// <inheritdoc />
        public async Task<string> ParseFileAsync(ChatFile chatFile)
        {
            using var reader = new StreamReader(chatFile.Stream);

            var text = (await reader.ReadToEndAsync());

            return text;
        }
    }
}
