using Assist.Accelerator.Chat.Api.Models.Exceptions;
using Assist.Accelerator.Chat.Api.Util.Exceptions;
using Azure.Identity;
using Insight.Assist.Api.DAL;
using Insight.Assist.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Graph;
using Microsoft.Graph.Models;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.Data;

using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Net;

namespace Insight.Assist.Api.Services;

public class UsersService
{
    private readonly IHttpContextAccessor _contextAccessor;
    private readonly IConfiguration _configuration;
    private readonly ILogger<UsersService> _logger;
    private readonly HttpClient _httpClient;

    private readonly UsersContext _db;

    public enum UserRole
    {
        Admin = 1,
        User = 2
    }


    /// <summary>
    /// Constructor
    /// </summary>
    public UsersService(
        IHttpContextAccessor contextAccessor,
        IConfiguration configuration,
        ILogger<UsersService> logger,
        UsersContext usersContext,
        IHttpClientFactory httpClientFactory)
    {
        _contextAccessor = contextAccessor;
        _configuration = configuration;
        _logger = logger;
        _httpClient = httpClientFactory.CreateClient();

        _db = usersContext;
    }

    /// <summary>
    /// Invites a guest user to the application's database and host active directory.
    /// </summary>
    public async Task InviteGuestUser([FromBody] UserInvite invitation)
    {
        if (string.IsNullOrEmpty(invitation.EmailAddress))
        {
            throw new Exception("Invalid email in InviteGuestUser");
        }

        var inviter = this.GetCurrentUser();
        var invitee = this.GetUser(invitation.EmailAddress);
        var inviteeName = UserNameDetails.FromInvitation(invitation);

        if (inviter == null)
        {
            throw new Exception("Cannot find inviter in InviteGuestUser");
        }

        _logger.LogInformation($"Inviting {invitation.EmailAddress} on behalf of {inviter.EmailAddress}");

        // note - we should check inviter role here to enforce admin
        // note - we should support invitee role (and modification of role)

        // put the invitee in the application database first (and update invitee record)
        if (invitee == null)
        {
            invitee = await this.InviteUserToApplication(invitation, inviteeName);
        }
        else
        {
            _logger.LogInformation($"User {invitation.EmailAddress} already exists in app. Inviting anyway.");
        }

        // access azure ad on behalf of the current user
        /* var graphClient = GetOboGraphClient();
         try
         {
             var result = await this.InviteUserToDirectory(graphClient, invitation, inviteeName);
             return result;
         }
         catch (Exception ex)
         {
             _logger.LogError(ex, "Failed to obtain MS Graph client. Check app registration.");
             throw new Exception(ex.Message);
         }
         finally
         {
             graphClient.Dispose();
         }*/
    }


    public async Task<Insight.Assist.Api.Models.User?> GetCurrentUserFromAD()
    {
        var email = _contextAccessor.HttpContext?.User?.Identity?.Name;
        if (email == null) return null;

        var user = _db.Users.FirstOrDefault(u => u.EmailAddress == email);

        if (user is not null)
        {
            return user;
        }

        var autoRegisterFlag =
            Convert.ToBoolean(_db.GlobalFlags.SingleOrDefault(x => x.FlagName == "AutoRegister")!.Value);

        if (autoRegisterFlag.Equals(false) && user is null)
        {
            // Auto register off and user do not exist 
            return null;
        }
        else if (autoRegisterFlag.Equals(true) && user is null)
        {
            // Auto register on but user do not exist
            var graphClient = GetOboGraphClient();
            var userCollection = new Microsoft.Graph.Models.UserCollectionResponse();

            userCollection = await graphClient.Users.GetAsync((cfg) =>
            {
                cfg.QueryParameters.Count = true;
                cfg.QueryParameters.Filter = $"mail eq '{email}'";
                cfg.Headers.Add("ConsistencyLevel", "eventual");
            });

            #region Alternative approach to fetch logged in user name if AD is not avaiable

            //var name = email.Contains("@") ? email.Split("@")[0].ToString() : email;

            //var firstName = string.Empty;
            //var lastName = string.Empty;

            //if (name.Contains("."))
            //{
            //    firstName = name.Contains(".") ? name.Split(".")[0].ToString() : name;
            //    lastName = name.Contains(".") ? name.Split(".")[1].ToString() : name;
            //}

            #endregion Alternative approach to fetch logged in user name if AD is not avaiable

            if (userCollection is not null)
            {
                Models.User newUser = new Models.User();
                newUser.EmailAddress = userCollection.Value[0].Mail;

                if (userCollection.Value[0].GivenName is null)
                {
                    var name = userCollection.Value[0].DisplayName.Split(',');
                    if (name.Count() == 2)
                    {
                        newUser.LastName = name[0];
                        newUser.Name = name[1];
                    }
                    else
                    {
                        newUser.Name = userCollection.Value[0].DisplayName;
                        newUser.LastName = "";
                    }
                }
                else
                {
                    newUser.LastName = userCollection.Value[0].Surname;
                    newUser.Name = userCollection.Value[0].GivenName;
                }

                await _db.SaveChangesAsync();

                Models.UserRole userRole = new Models.UserRole();
                userRole.UserId = _db.Users.SingleOrDefault(x => x.EmailAddress == email)!.UserId;
                userRole.RoleId = Convert.ToInt16(UserRole.User);
                _db.UserRoles.Add(userRole);
                await _db.SaveChangesAsync();
            }
        }

        return await _db.Users.FirstAsync(u => u.EmailAddress == email);
    }

    /// <summary>
    /// Returns the current (logged in) application user.
    /// </summary>
    public Insight.Assist.Api.Models.User? GetCurrentUser()
    {
        var email = _contextAccessor.HttpContext?.User?.Identity?.Name;
        if (email == null) return null;

        var user = _db.Users.FirstOrDefault(u => u.EmailAddress == email);

        return user is not null ? user : null;
    }

    /// <summary>
    /// Returns the current (logged in) application user.
    /// Throws an exception if the user is null.
    /// </summary>
    public Insight.Assist.Api.Models.User GetCurrentUserOrThrow()
    {
        return GetCurrentUser() ?? throw new ChatApiException(HttpStatusCode.Unauthorized);
    }
    
    /// <summary>
    /// Returns the current (logged in) active directory user.
    /// </summary>
    public async Task<Microsoft.Graph.Models.User?> GetCurrentUser(GraphServiceClient graphClient)
    {
        return await graphClient.Me.GetAsync();
    }

    /// <summary>
    /// Returns a list of Roles assigned to the current (logged in) user
    /// </summary>
    public async Task<List<Role>> GetCurrentUserRoles()
    {
        var user = this.GetCurrentUser();
        if (user == null)
        {
            throw new UnauthorizedAccessException();
        }

        var userRoles = await _db.UserRoles
            .Where(p => p.UserId == user.UserId)
            .Join(_db.Roles, u => u.RoleId, r => r.RoleId, (u, r) => new Role()
            {
                RoleId = r.RoleId,
                RoleName = r.RoleName,
                RoleDescription = r.RoleDescription
            })
            .ToListAsync();

        return userRoles;
    }

    /// <summary>
    /// Returns the current user's detailed information including roles and permissions
    /// </summary>
    /// <returns></returns>
    public async Task<UserDetails> GetCurrentUserDetails()
    {
        var user = await this.GetCurrentUserFromAD();
        var roles = await this.GetCurrentUserRoles();

        if (user == null)
        {
            throw new NullReferenceException();
        }

        if (roles == null)
        {
            throw new NullReferenceException();
        }

        return new UserDetails()
        {
            UserId = user.UserId,
            EmailAddress = user.EmailAddress,
            Roles = roles.Select(r => r.RoleName).ToList()
        };
    }

    /// <summary>
    /// Invites (adds) a user to the application database. Returns the invited application user.
    /// </summary>
    private async Task<Insight.Assist.Api.Models.User> InviteUserToApplication(
        UserInvite invitation,
        UserNameDetails nameDetails)
    {
        await _db.Database.ExecuteSqlInterpolatedAsync(
            $"CreateUser {nameDetails.First}, {nameDetails.Last}, {invitation.EmailAddress}, {nameDetails.Display}");

        var invitee = await _db.Users.FirstOrDefaultAsync(x => x.EmailAddress == invitation.EmailAddress);
        if (invitee == null)
        {
            throw new Exception($"Failed to add {invitation.EmailAddress} to application db");
        }

        return invitee;
    }

    /// <summary>
    /// Invites (adds and sends invitation) a user to the backing active directory. Returns the invitation 
    /// information sent to the user.
    /// </summary>
    private async Task<Invitation> InviteUserToDirectory(
        GraphServiceClient graphClient,
        UserInvite invitation,
        UserNameDetails nameDetails)
    {
        if (string.IsNullOrEmpty(invitation.EmailAddress))
        {
            throw new Exception("Invalid email in InviteGuestUser");
        }

        var adInviter = await GetCurrentUser(graphClient);
        var adInvitee = await GetUser(graphClient, invitation.EmailAddress);

        if (adInvitee != null)
        {
            _logger.LogInformation($"User {invitation.EmailAddress} already exists in directory. Inviting anyway.");
        }

        // send the invitation always
        var requestBody = new Invitation
        {
            InvitedUserEmailAddress = invitation.EmailAddress,
            InvitedUserDisplayName = nameDetails.Display,
            InviteRedirectUrl = this.GetInvitationRedirectUrl(invitation),
            SendInvitationMessage = true
        };

        if (!string.IsNullOrEmpty(invitation.Message))
        {
            requestBody.InvitedUserMessageInfo = new InvitedUserMessageInfo()
            {
                CustomizedMessageBody = invitation.Message
            };
        }

        var result = await graphClient.Invitations.PostAsync(requestBody);
        if (result == null)
        {
            throw new Exception("Failed to send invitation in InviteGuestUser");
        }

        // fetch the added user and make sure we have relevant display information captured
        if (result.InvitedUser != null && result.InvitedUser.Id != null)
        {
            // patch the invited user to set 
            var patchbody = new Microsoft.Graph.Models.User()
            {
                GivenName = nameDetails.First,
                Surname = nameDetails.Last,
                DisplayName = nameDetails.Display
            };
            await graphClient.Users[result.InvitedUser.Id].PatchAsync(patchbody);
        }

        return result;
    }

    /// <summary>
    /// Creates a new instance of the Microsoft Graph Client. The instance is created via an on-behalf-of
    /// flow, meaning the authenticated user's directory role directly applies to the role of the returned
    /// graph client. Instance must be disposed.
    /// </summary>
    private GraphServiceClient GetOboGraphClient()
    {
        var scopes = new[] { "User.Read" };
        var tenantId = _configuration.GetSection("AzureAd")["TenantId"];
        var clientId = _configuration.GetSection("AzureAd")["ClientId"];
        var clientSecret = _configuration.GetSection("AzureAd")["ClientSecret"];

        var authHeader = _contextAccessor.HttpContext?.Request.Headers["Authorization"];
        if (!authHeader.HasValue)
        {
            throw new Exception("Invalid authorization in GetOboGraphClient()");
        }

        var auth = authHeader.Value;
        if (auth.Count == 0)
        {
            throw new Exception("Invalid auth header in GetOboGraphClient()");
        }

        var jwt = auth[0];
        jwt = jwt?.Substring("Bearer ".Length);

        if (string.IsNullOrEmpty(jwt))
        {
            throw new Exception("Invalid jwt in GetOboGraphClient()");
        }

        var options = new OnBehalfOfCredentialOptions
        {
            AuthorityHost = AzureAuthorityHosts.AzurePublicCloud
        };

        var onBehalfOfCredential = new OnBehalfOfCredential(tenantId, clientId, clientSecret, jwt, options);
        var graphClient = new GraphServiceClient(onBehalfOfCredential, scopes);

        return graphClient;
    }

    /// <summary>
    /// Returns the application redirect to which users can be sent after accepting
    /// an invitation. The value can be provided explicitly, or inferred by the host.
    /// </summary>
    private string? GetInvitationRedirectUrl(UserInvite invitation)
    {
        if (!string.IsNullOrEmpty(invitation.ReturnUrl))
        {
            return invitation.ReturnUrl;
        }

        // route back to host if caller has not provided a redirect
        return _contextAccessor.HttpContext?.Request.Host.ToString();
    }

    /// <summary>
    /// Gets an application user by email. Returns null for users that do not exist.
    /// </summary>
    private Insight.Assist.Api.Models.User? GetUser(string email)
    {
        return _db.Users.FirstOrDefault(u => u.EmailAddress == email);
    }

    /// <summary>
    /// Gets an active directory user by email. Returns null for users that do not exist.
    /// </summary>
    private async Task<Microsoft.Graph.Models.User?> GetUser(GraphServiceClient graphClient, string email)
    {
        try
        {
            var filter = await graphClient.Users.GetAsync((cfg) =>
            {
                cfg.QueryParameters.Count = true;
                cfg.QueryParameters.Filter = $"mail eq '{email}'";
                cfg.Headers.Add("ConsistencyLevel", "eventual");
            });

            if (filter == null || filter.Value == null || filter.Value.Count == 0)
            {
                return null;
            }

            return filter.Value[0];
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    /// <summary>
    /// Fetching users from active director based filter criteria 
    /// </summary>
    /// <param name="filter"></param>
    /// <returns>User Model</returns>
    public async Task<List<Models.User?>> GetADUsers(string filter, bool byEmail = false)
    {

        var graphClient = GetOboGraphClient();
        var userCollection = new Microsoft.Graph.Models.UserCollectionResponse();
        if (!byEmail)
        {
            userCollection = await graphClient.Users.GetAsync((cfg) =>
            {
                cfg.QueryParameters.Count = true;
                cfg.QueryParameters.Search = $"\"displayName:{filter}\"";
                cfg.Headers.Add("ConsistencyLevel", "eventual");
            });
        }
        else
        {
            userCollection = await graphClient.Users.GetAsync((cfg) =>
            {
                cfg.QueryParameters.Count = true;
                cfg.QueryParameters.Filter = $"mail eq '{filter}')";
                cfg.Headers.Add("ConsistencyLevel", "eventual");
            });
        }

        if (userCollection == null || userCollection.Value == null || userCollection.Value.Count == 0)
        {
            return null;
        }

        List<Models.User> usersList = new List<Models.User>();

        for (int i = 0; i < userCollection.Value.Count; i++)
        {
            var adUser = userCollection.Value[i];
            var (firstName, lastName) = GetFullName(adUser);
            Models.User user = new Models.User();

            user.EmailAddress = adUser.Mail;
            user.LastName = lastName;
            user.Name = firstName;

            usersList.Add(user);
        }

        return usersList!;
    }

    /// <summary>
    /// Gets all application users based on filter criteria
    /// </summary>
    /// <param name="filter"></param>
    /// <returns></returns>
    internal async Task<UserResponse> GetApplicationUsers(string filter, int pageNumber, int pageSize, int groupId)
    {
        var usersList = _db.Users.Join(_db.UserRoles, u => u.UserId, uir => uir.UserId, (u, uir) => new { u, uir })
            .ToList();

        if (!string.IsNullOrEmpty(filter))
        {
            filter = filter.ToLower();
            usersList = usersList.Where(x =>
                x.u.Name.ToLower().StartsWith(filter) || x.u.LastName.ToLower().StartsWith(filter) ||
                x.u.EmailAddress.ToLower().StartsWith(filter)).ToList();
        }

        if (groupId > 0)
        {
            usersList = usersList.Where(x => _db.GroupUsers.Any(gu => gu.UserId == x.u.UserId && gu.GroupId == groupId))
                .ToList();
        }

        int pageCount = usersList.Count;

        usersList = usersList.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();
        
        List<Models.UserWithRoleMapped> users = new List<Models.UserWithRoleMapped>();
        foreach (var obj in usersList)
        {
            Models.UserWithRoleMapped user = new Models.UserWithRoleMapped();

            user.UserId = obj.u.UserId;
            user.Name = obj.u.Name;
            user.LastName = obj.u.LastName;
            user.model_control = obj.u.model_control;
            user.IsActive = obj.u.IsActive;
            user.EmailAddress = obj.u.EmailAddress;
            user.RoleId = obj.uir.RoleId;
            users.Add(user);
        }

        return new UserResponse { Users = users, PageCount = pageCount };
    }

    /// <summary>
    /// Add all users from AD to the application database
    /// </summary>
    /// <returns></returns>
    //internal async Task AddAllAdUsersToApplication()
    //{

    //    var graphClient = GetOboGraphClient();
    //    var userCollection = new Microsoft.Graph.Models.UserCollectionResponse();
    //    userCollection = await graphClient.Users.GetAsync((cfg) =>
    //    {
    //        cfg.QueryParameters.Count = true;
    //        //cfg.QueryParameters.Filter = $"startswith(displayName, '{filter}')";
    //        cfg.Headers.Add("ConsistencyLevel", "eventual");
    //    });          

    //    if (userCollection == null || userCollection.Value == null || userCollection.Value.Count == 0)
    //    {
    //        return;
    //    }

    //    List<Models.User> usersList = new List<Models.User>();

    //    for (int i = 0; i < userCollection.OdataCount; i++)
    //    {
    //        var appUser = _db.Users.SingleOrDefault(x => x.EmailAddress == userCollection.Value[i].Mail);
    //        if (appUser is null)
    //        {
    //            await _db.Database.ExecuteSqlInterpolatedAsync(
    //            $"CreateUser {userCollection.Value[i].DisplayName!}, {userCollection.Value[i].Surname!}, {userCollection.Value[i].Mail!}, ''");

    //            Models.UserRole userRole = new Models.UserRole();
    //            userRole.UserId = _db.Users.SingleOrDefault(x => x.EmailAddress == userCollection.Value[i].Mail)!.UserId;
    //            userRole.RoleId = Convert.ToInt16(UserRole.User);
    //            _db.UserRoles.Add(userRole);
    //            _db.SaveChanges();
    //        }
    //    }

    //}

    /// <summary>
    /// Adds user to the application database
    /// </summary>
    /// <param name="userList"></param>
    /// <returns></returns>
    internal async Task AddUsers([FromBody] List<Models.User> userList, int userRoleId)
    {
        if (userList == null || userList.Count == 0)
        {
            throw new ArgumentException("User list cannot be empty.");
        }

        if (userRoleId <= 0)
        {
            throw new ArgumentException("Invalid user role ID.");
        }

        foreach (var data in userList)
        {
            var appUserExists = _db.Users.Any(x => x.EmailAddress == data.EmailAddress);
            if (!appUserExists)
            {
                var newUser = new Models.User
                {
                    Name = data.Name,
                    LastName = data.LastName,
                    EmailAddress = data.EmailAddress
                };
                _db.Users.Add(newUser);
                await _db.SaveChangesAsync();

                var userId = newUser.UserId;

                var userRole = new Models.UserRole
                {
                    UserId = userId,
                    RoleId = userRoleId == 0 ? Convert.ToInt16(UserRole.User) : userRoleId
                };
                _db.UserRoles.Add(userRole);
                await _db.SaveChangesAsync();

                var indexes = await _db.AzureSearchIndexes.ToListAsync();
                foreach (var index in indexes)
                {
                    var newIndexUser = new AzureSearchIndexUsers
                    {
                        IndexID = index.IndexId,
                        UserId = userId,
                        isActive = false
                    };
                    _db.AzureSearchUsers.Add(newIndexUser);
                }

                await _db.SaveChangesAsync();
            }
            else
            {
                throw new UserConflictException();
            }
        }
    }

    /// <summary>
    ///  Deletes user from the application database
    /// </summary>
    /// <param name="userIds"></param>
    /// <returns></returns>
    internal async Task DeleteUsers(string userIds, bool status)
    {
        var userIdList = userIds.Split(',').ToList();
        foreach (var userId in userIdList)
        {
            await this.DeleteApplicationUser(Convert.ToInt16(userId), status);
        }
    }

    /// <summary>
    /// Deletes a user to the application database.  
    /// </summary>
    internal async Task DeleteApplicationUser(int id, bool status)
    {
        var itemTobeDeactivated = _db.Users.SingleOrDefault(x => x.UserId == id);
        if (itemTobeDeactivated is not null)
        {
            itemTobeDeactivated.IsActive = status;
            await _db.SaveChangesAsync();
        }
    }

    internal async Task<List<Models.Role?>> GetRoles()
    {
        List<Models.Role> roleList = await _db.Roles.ToListAsync();
        return roleList!;
    }

    internal async Task UpdateAppUserRole(int UserId, int RoleId)
    {
        var item = await _db.UserRoles.FirstOrDefaultAsync(x => x.UserId == UserId);

        if (item is not null)
        {
            _db.UserRoles.Remove(item);
            await _db.SaveChangesAsync();
        }

        Models.UserRole userRole = new Models.UserRole();
        userRole.UserId = UserId;
        userRole.RoleId = RoleId;
        _db.UserRoles.Add(userRole);
        await _db.SaveChangesAsync();
    }

    public async Task<int> GetAdminCount()
    {
        return await _db.UserRoles.CountAsync(ur => ur.RoleId == (int)UserRole.Admin);
    }

    internal async Task UpdateAutoRegisterFlag(bool flag)
    {
        var itemTobeUpdate = _db.GlobalFlags.SingleOrDefault(x => x.FlagName == "AutoRegister");

        if (itemTobeUpdate is not null)
        {
            itemTobeUpdate.Value = flag == false ? "false" : "true";
        }

        await _db.SaveChangesAsync();
    }

    internal async Task<bool> GetAutoRegisterFlag()
    {
        var flag = _db.GlobalFlags.SingleOrDefault(x => x.FlagName == "AutoRegister")!.Value;
        var result = flag == "false" ? false : true;
        return result;
    }

    /// <summary>
    /// Utility class for generating user object fields from one or more invtation specifications.
    /// </summary>
    private class UserNameDetails
    {
        public string? First { get; set; }

        public string? Last { get; set; }

        public string? Display { get; set; }

        public static UserNameDetails FromInvitation(UserInvite invitation)
        {
            var email = invitation.EmailAddress ?? throw new NullReferenceException();
            var domain = email.Substring(email.IndexOf('@'));
            var userid = email.Substring(0, email.IndexOf('@'));

            if (domain.IsNullOrEmpty())
            {
                throw new Exception($"Invalid email address {email}");
            }

            if (userid.IsNullOrEmpty())
            {
                throw new Exception($"Invalid email address {email}");
            }

            var userleft = userid.IndexOf('.') >= 0
                ? userid.Substring(0, userid.IndexOf('.'))
                : userid;
            var userright = userid.IndexOf('.') >= 0
                ? userid.Substring(userid.LastIndexOf('.') + 1)
                : string.Empty;

            string first = invitation.FirstName ?? ToTitleCase(userleft); // guaranteed to have some length
            string last = invitation.LastName ?? ToTitleCase(userright); // could be empty string if no '.'
            string display = invitation.DisplayName ?? $"{last}, {first}";

            if (display.TrimEnd().EndsWith(','))
            {
                display = display.Substring(0, display.IndexOf(','));
            }

            return new UserNameDetails()
            {
                First = first,
                Last = last,
                Display = display
            };
        }

        private static string ToTitleCase(string s)
        {
            return System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(s);
        }
    }

    private (string, string) GetFullName(Microsoft.Graph.Models.User user)
    {
        if (user?.DisplayName != null && user.DisplayName.Contains(", "))
        {
            var splitName = user.DisplayName.Split(", ");
            return (user.GivenName ?? splitName[1], user.Surname ?? splitName[0]);
        }
        else
        {
            return (user.GivenName, user.Surname);
        }
    }

    // Add Azure AD group Members


    public async Task<List<Models.User>> GetGroupMembers(string groupName)
    {
        var graphClient = GetOboGraphClient();
        List<Models.User> membersList = new List<Models.User>();

        var groupCollection = await graphClient.Groups.GetAsync((cfg) =>
        {
            cfg.QueryParameters.Count = true;
            cfg.QueryParameters.Filter = $"displayName eq '{groupName}'";
            cfg.Headers.Add("ConsistencyLevel", "eventual");
        });

        var group = groupCollection.Value.FirstOrDefault();
        if (group != null)
        {
            var members = await graphClient.Groups[group?.Id].Members.GetAsync();
            var membersCollection = members?.Value;
            if (membersCollection != null || membersCollection!.Count != 0)
            {
                foreach (var member in membersCollection)
                {
                    if (member is Microsoft.Graph.Models.User user)
                    {
                        var (firstName, lastName) = GetFullName(user);
                        membersList.Add(new Models.User
                        {
                            EmailAddress = user.Mail!,
                            LastName = lastName,
                            Name = firstName
                        });

                    }
                    // Add group name, GroupId(if needed).
                }
            }
        }

        return membersList;
    }

    public async Task<List<Models.Group>> SearchGroupsByInitials(string initials)
    {
        var graphClient = GetOboGraphClient();
        List<Models.Group> matchingGroupNames = new List<Models.Group>();

        var groupCollection = await graphClient.Groups.GetAsync((cfg) =>
        {
            cfg.QueryParameters.Count = true;
            cfg.QueryParameters.Search = $"\"displayName:{initials}\"";
            cfg.Headers.Add("ConsistencyLevel", "eventual");
        });

        foreach (var group in groupCollection.Value)
        {
            matchingGroupNames.Add(new Models.Group
            {
                GroupName = group.DisplayName,
                ObjectId = group.Id
            });
        }

        // No need to save anything in database.
        return matchingGroupNames;
    }

    public async Task AddGroup(List<Models.Group> groups, int groupRoleId)
    {
        if (groups == null || groups.Count == 0)
        {
            throw new ArgumentException("Group list cannot be empty.");
        }

        if (groupRoleId <= 0)
        {
            throw new ArgumentException("Invalid user role ID.");
        }

        foreach (var group in groups)
        {
            var existing_group = _db.Groups.FirstOrDefault(x => x.GroupName == group.GroupName);
            if (existing_group == null)
            {
                _db.Groups.Add(group);
            }

            await _db.SaveChangesAsync();

            var existingGroup = _db.Groups.FirstOrDefault(x => x.ObjectId == group.ObjectId);
            if (existingGroup != null)
            {
                group.GroupId = existingGroup.GroupId;

                List<Models.User> users = await GetGroupMembers(group.GroupName!);
                foreach (var user in users)
                {
                    var existing_user = _db.Users.FirstOrDefault(x => x.EmailAddress == user.EmailAddress);
                    if (existing_user == null)
                    {
                        _db.Users.Add(user);
                        await _db.SaveChangesAsync();

                        // Fetch the user again to get the generated UserId
                        existing_user = _db.Users.FirstOrDefault(x => x.EmailAddress == user.EmailAddress);
                    }

                    if (existing_user != null)
                    {
                        var existingUserRole = _db.UserRoles.FirstOrDefault(x => x.UserId == existing_user.UserId);
                        if (existingUserRole != null)
                        {
                            _db.UserRoles.Remove(existingUserRole);
                            await _db.SaveChangesAsync();
                        }

                        Models.UserRole role = new Models.UserRole
                        {
                            UserId = existing_user.UserId,
                            RoleId = groupRoleId
                        };
                        await _db.AddAsync(role);

                        var existing_GroupUsers = _db.GroupUsers.FirstOrDefault(x =>
                            x.UserId == existing_user.UserId && x.GroupId == group.GroupId);

                        if (existing_GroupUsers == null)
                        {
                            GroupUsers groupUsers = new GroupUsers();
                            groupUsers.UserId = existing_user.UserId;
                            groupUsers.GroupId = existingGroup.GroupId;
                            await _db.GroupUsers.AddAsync(groupUsers);
                        }
                    }
                }

                var existing_groupRole = _db.GroupRoles.FirstOrDefault(x => x.GroupId == existingGroup.GroupId);
                if (existing_groupRole != null)
                {
                    _db.GroupRoles.Remove(existing_groupRole);
                    await _db.SaveChangesAsync();
                }

                GroupRole groupRole = new GroupRole
                {
                    RoleId = groupRoleId,
                    GroupId = existingGroup.GroupId
                };
                await _db.AddAsync(groupRole);
            }

            await _db.SaveChangesAsync(); // Save changes for user roles and group roles
        }
    }

    public async Task<List<string>> GroupsForMember(string memberId)
    {
        var graphClient = GetOboGraphClient();
        List<string> groupsForMember = new List<string>();
        var groupCollection = await graphClient.Users[memberId].MemberOf.GetAsync();

        foreach (var group in groupCollection.Value)
        {
            if (group is Microsoft.Graph.Models.Group groupInfo)
            {
                groupsForMember.Add(groupInfo.DisplayName);
            }

        }

        return groupsForMember;
    }


    /// <summary>
    /// Gets all application groups based on filter criteria
    /// </summary>
    /// <param name="filter"></param>
    /// <returns></returns>
    internal async Task<GroupResponse> GetApplicationGroups(string filter, int pageNumber, int pageSize)
    {
        var groupsList = await _db.Groups.Join(_db.GroupRoles, u => u.GroupId, uir => uir.GroupId, (u, uir) => new { u, uir })
            .ToListAsync();

        int pageCount = groupsList.Count;

        if (!string.IsNullOrEmpty(filter))
        {
            filter = filter.ToLower();
            groupsList = groupsList
                .Where(x => x.u.GroupName!.ToLower().StartsWith(filter) || x.u.ObjectId!.ToLower().StartsWith(filter))
                .Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();
        }
        else
        {
            groupsList = groupsList.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();
        }

        List<GroupWithRoleMapped> groups = new List<GroupWithRoleMapped>();
        foreach (var obj in groupsList)
        {
            GroupWithRoleMapped group = new GroupWithRoleMapped();

            group.GroupId = obj.u.GroupId;
            group.GroupName = obj.u.GroupName;
            group.IsActive = obj.u.isActive;
            group.Model_Control = obj.u.Model_Control;
            group.RoleId = obj.uir.RoleId;
            groups.Add(group);
        }

        return new GroupResponse { Groups = groups, PageCount = pageCount };
    }

    internal async Task UpdateGroupRole(int groupId, int roleId)
    {
        await using var transaction = await _db.Database.BeginTransactionAsync();

        var groupRole = await _db.GroupRoles.FirstOrDefaultAsync(x => x.GroupId == groupId);
        if (groupRole != null)
        {
            _db.GroupRoles.Remove(groupRole);

            var newGroupRole = new GroupRole
            {
                GroupId = groupId,
                RoleId = roleId
            };

            await _db.GroupRoles.AddAsync(newGroupRole);

            await _db.SaveChangesAsync();

            var userIds = await _db.GroupUsers.Where(x => x.GroupId == groupId).Select(x => x.UserId).ToListAsync();

            var userRolesToRemove = await _db.UserRoles.Where(x => userIds.Contains(x.UserId)).ToListAsync();
            _db.UserRoles.RemoveRange(userRolesToRemove);

            var newUserRoles = userIds.Select(userId => new Models.UserRole
            {
                UserId = userId,
                RoleId = roleId
            });

            await _db.UserRoles.AddRangeAsync(newUserRoles);

            await _db.SaveChangesAsync();

            await transaction.CommitAsync();
        }
    }

    internal async Task DeleteApplicationGroup(int id, bool status)
    {
        var item = await _db.Groups.FirstOrDefaultAsync(x => x.GroupId == id);
        if (item is not null)
        {
            item.isActive = status;
            await _db.SaveChangesAsync();

            var userIds = await _db.GroupUsers.Where(x => x.GroupId == id).Select(x => x.UserId).ToListAsync();

            foreach (var userId in userIds)
            {
                var user = await _db.Users.FirstOrDefaultAsync(x => x.UserId == userId);
                if (user is not null)
                {
                    user.IsActive = status;
                }
            }

            await _db.SaveChangesAsync();
        }
    }

    internal async Task<bool> ToggleKnowledgeBase(int indexID, int userId, bool status)
    {
        var userIndex = await _db.AzureSearchUsers.FirstOrDefaultAsync(x => x.IndexID == indexID && x.UserId == userId);
        var index = await _db.AzureSearchIndexes.FirstOrDefaultAsync(x => x.IndexId == indexID);
        if (userIndex is not null && !string.IsNullOrEmpty(index!.DisplayName))
        {
            userIndex.isActive = status;
            await _db.SaveChangesAsync();
            return true;
        }

        return false;
    }

    internal async Task ToggleModelControl(int Id, bool status, bool isGroup)
    {
        if (isGroup)
        {
            var group = await _db.Groups.FirstOrDefaultAsync(x => x.GroupId == Id);
            if (group is not null)
            {
                group.Model_Control = status;
                await _db.SaveChangesAsync();

                var userIds = await _db.GroupUsers.Where(x => x.GroupId == Id).Select(x => x.UserId).ToListAsync();

                foreach (var userId in userIds)
                {
                    var user = await _db.Users.FirstOrDefaultAsync(x => x.UserId == userId);
                    if (user is not null)
                    {
                        user.model_control = status;
                    }
                }

                await _db.SaveChangesAsync();
            }
        }
        else
        {
            var user = await _db.Users.FirstOrDefaultAsync(x => x.UserId == Id);
            if (user is not null)
            {
                user.model_control = status;
                await _db.SaveChangesAsync();
            }
        }
    }

    internal async Task<GroupResponse> GetGroupNamesForUser(int userId, string filter, int pageNumber, int pageSize)
    {
        var groupIds = await _db.GroupUsers.Where(x => x.UserId == userId).Select(x => x.GroupId).ToListAsync();
        var groups = await _db.Groups.Where(x => groupIds.Contains(x.GroupId)).ToListAsync();
        int pageCount = groups.Count;

        if (!string.IsNullOrEmpty(filter))
        {
            filter = filter.ToLower();
            groups = groups.Where(x => x.GroupName!.ToLower().Contains(filter)).Skip((pageNumber - 1) * pageSize)
                .Take(pageSize).ToList();
        }
        else
        {
            groups = groups.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();
        }

        List<GroupWithRoleMapped> GroupToReturn = new List<GroupWithRoleMapped>();
        foreach (var obj in groups)
        {
            GroupWithRoleMapped group = new GroupWithRoleMapped();

            group.GroupId = obj.GroupId;
            group.GroupName = obj.GroupName;
            GroupToReturn.Add(group);
        }

        return new GroupResponse { Groups = GroupToReturn, PageCount = pageCount };
    }

    internal async Task<KnowledgeBaseResponse> GetKnowledgeBaseForUser(int userId, string filter, int pageNumber,
        int pageSize)
    {
        var indexIds = await _db.AzureSearchUsers.Where(x => x.UserId == userId).Select(x => x.IndexID).ToListAsync();
        var index = await _db.AzureSearchIndexes.Where(x => indexIds.Contains(x.IndexId)).ToListAsync();

        int pageCount = index.Count;

        if (!string.IsNullOrEmpty(filter))
        {
            filter = filter.ToLower();
            index = index.Where(x => x.IndexName!.ToLower().Contains(filter)).Skip((pageNumber - 1) * pageSize)
                .Take(pageSize).ToList();
        }
        else
        {
            index = index.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();
        }

        List<AzureSearchIndex> AzureSearchIndex = new List<AzureSearchIndex>();
        foreach (var obj in index)
        {
            AzureSearchIndex azureSearchIndex = new AzureSearchIndex();

            azureSearchIndex.IndexId = obj.IndexId;
            azureSearchIndex.IndexName = obj.IndexName;
            azureSearchIndex.DisplayName = obj.DisplayName;
            var azureSearchUser =
                await _db.AzureSearchUsers.FirstOrDefaultAsync(x => x.IndexID == obj.IndexId && x.UserId == userId);
            azureSearchIndex.IsActive = azureSearchUser!.isActive;
            AzureSearchIndex.Add(azureSearchIndex);
        }

        return new KnowledgeBaseResponse { KnowledgeBase = AzureSearchIndex, PageCount = pageCount };
    }

    public async Task<AzureSearchResult> GetAzureIndexes(IndexRequest request)
    {
        var uri = new Uri(new Uri(request.AzureSearchUrl), "indexes?api-version=2021-04-30-Preview");
        var req = new HttpRequestMessage(HttpMethod.Get, uri);
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        req.Headers.Add("api-key", request.AzureKey);

        using HttpResponseMessage response = await _httpClient.SendAsync(req);

        if (!response.IsSuccessStatusCode)
        {
            return new AzureSearchResult
            {
                IsSuccess = false,
                Message = $"Error: {response.ReasonPhrase}"
            };
        }

        var responseBody = await response.Content.ReadAsStringAsync();
        var responseObject = JsonConvert.DeserializeObject<dynamic>(responseBody);

        var existingAzureSearch = _db.AzureSearches.FirstOrDefault(a => a.SearchUrl == request.AzureSearchUrl);

        if (existingAzureSearch == null)
        {
            var azureSearch = new AzureSearch
            {
                SearchUrl = request.AzureSearchUrl,
                AzureKey = request.AzureKey
            };

            _db.AzureSearches.Add(azureSearch);
            await _db.SaveChangesAsync();

            var indexesToAdd = ((IEnumerable<dynamic>)responseObject!.value)
                .Select(item => new AzureSearchIndex
                {
                    IndexName = item.name.ToString(),
                    SemanticName = item.semantic?.configurations[0]?.name.ToString() ?? string.Empty,
                    AzureSearchId = azureSearch.AzureSearchId,
                    IsActive = false
                })
                .ToList();

            _db.AzureSearchIndexes.AddRange(indexesToAdd);
            await _db.SaveChangesAsync();
            foreach (var indexToAdd in indexesToAdd)
            {
                var userIds = await _db.Users.Select(u => u.UserId).ToListAsync();
                var indexUserEntries = userIds.Select(userId => new AzureSearchIndexUsers
                {
                    IndexID = indexToAdd.IndexId,
                    UserId = userId,
                    isActive = false
                });

                _db.AzureSearchUsers.AddRange(indexUserEntries);
            }

            await _db.SaveChangesAsync();

            return new AzureSearchResult
            {
                IsSuccess = true,
                Message = "New indexes retrieved and saved successfully."
            };
        }

        var existingIndexes = _db.AzureSearchIndexes
            .Where(i => i.AzureSearchId == existingAzureSearch.AzureSearchId)
            .ToList();

        var newIndexes = new List<AzureSearchIndex>();

        foreach (var item in responseObject!.value)
        {
            var indexName = item.name.ToString();
            var semanticName = string.Empty;

            if (item.semantic != null && item.semantic?.configurations != null &&
                item.semantic.configurations.Count > 0)
            {
                semanticName = item.semantic?.configurations[0]?.name.ToString();
            }

            else
            {
                semanticName = string.Empty;
            }

            var existingIndex = existingIndexes.FirstOrDefault(i => i.IndexName == indexName);

            if (existingIndex != null)
            {
                existingIndex.SemanticName = semanticName;
                existingIndex.IsActive = false;
                _db.AzureSearchIndexes.Update(existingIndex);
            }
            else
            {
                var newIndex = new AzureSearchIndex
                {
                    IndexName = indexName,
                    SemanticName = semanticName,
                    AzureSearchId = existingAzureSearch.AzureSearchId,
                    IsActive = false
                };
                existingIndexes.Add(newIndex);
                newIndexes.Add(newIndex);
            }
        }

        _db.AzureSearchIndexes.UpdateRange(existingIndexes);
        await _db.SaveChangesAsync();

        foreach (var newIndex in newIndexes)
        {
            // Get the saved IndexId from the database
            var savedIndex = _db.AzureSearchIndexes
                .FirstOrDefault(i => i.IndexName == newIndex.IndexName && i.AzureSearchId == newIndex.AzureSearchId);

            if (savedIndex != null)
            {
                var userIds = await _db.Users.Select(u => u.UserId).ToListAsync();
                var indexUserEntries = userIds.Select(userId => new AzureSearchIndexUsers
                {
                    IndexID = savedIndex.IndexId,
                    UserId = userId,
                    isActive = false
                });

                _db.AzureSearchUsers.AddRange(indexUserEntries);
            }
        }

        await _db.SaveChangesAsync();

        return new AzureSearchResult
        {
            IsSuccess = true,
            Message = "Indexes retrieved and saved successfully."
        };
    }

    internal async Task<IndexInfoResponse> GetIndexInfo(string filter, int pageNumber, int pageSize)
    {

        var query = await _db.AzureSearchIndexes.Include(a => a.AzureSearch).ToListAsync();

        int totalCount = query.Count();

        // Apply filter if provided
        if (!string.IsNullOrEmpty(filter))
        {
            filter = filter.ToLower();
            query = query
                .Where(x => x.IndexName.ToLower().StartsWith(filter) ||
                            (x.SemanticName != null && x.SemanticName.ToLower().StartsWith(filter)) ||
                            (x.DisplayName != null && x.DisplayName.ToLower().StartsWith(filter)))
                .Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();
        }

        else
        {
            query = query.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();
        }

        // Get the total count for pagination

        var indexList = query.Select(i => new IndexWithSearchUrl
        {
            IndexId = i.IndexId,
            IndexName = i.IndexName,
            SemanticName = i.SemanticName,
            AzureSearchId = i.AzureSearchId,
            IsActive = i.IsActive,
            DisplayName = i.DisplayName,
            SearchUrl = i.AzureSearch.SearchUrl
        }).ToList();

        // Create a response object with index list and pagination details
        return new IndexInfoResponse { IndexList = indexList, ItemCount = totalCount };
    }

    public async Task<bool> IsDisplayNameExists(int indexId, string displayName)
    {
        //Check if the display name already exists in the database
        bool isDisplayNameExists =
            await _db.AzureSearchIndexes.AnyAsync(x => x.IndexId != indexId && x.DisplayName == displayName);
        return isDisplayNameExists;
    }

    public async Task UpdateDisplayName(int indexId, string displayName)
    {
        var azureSearchIndex = await _db.AzureSearchIndexes.FirstOrDefaultAsync(i => i.IndexId == indexId);

        if (azureSearchIndex == null)
        {
            throw new ArgumentException($"AzureSearchIndex with {indexId} not found.");
        }

        azureSearchIndex.DisplayName = displayName;
        await _db.SaveChangesAsync();
    }

    public bool UpdateIndexStatus(int indexId, bool status)
    {
        var index = _db.AzureSearchIndexes.FirstOrDefault(i => i.IndexId == indexId);
        if (index != null && index.DisplayName != null)
        {
            index.IsActive = status;

            var userToUpdate = _db.AzureSearchUsers.Where(x => x.IndexID == indexId).ToList();

            foreach (var user in userToUpdate)
            {
                user.isActive = status;
            }

            _db.SaveChangesAsync();
            return true;
        }
        else
        {
            return false;
        }
    }

    public async Task<List<AzureSearchIndex>> ActiveIndexList()
    {
        var user = this.GetCurrentUser();
        List<AzureSearchIndex> result = new List<AzureSearchIndex>();
        var indexList = _db.AzureSearchUsers.Where(x => x.UserId == user!.UserId && x.isActive == true).ToList();
        foreach (var index in indexList)
        {
            var item = await _db.AzureSearchIndexes.FirstOrDefaultAsync(x => x.IndexId == index.IndexID);
            AzureSearchIndex index1 = new AzureSearchIndex
            {
                IndexId = item!.IndexId,
                DisplayName = item.DisplayName,
            };
            result.Add(index1);
        }

        return result;
    }
}