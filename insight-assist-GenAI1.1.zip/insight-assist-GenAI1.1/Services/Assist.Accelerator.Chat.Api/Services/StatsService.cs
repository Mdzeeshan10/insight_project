using System.Reflection;
using Assist.Accelerator.Chat.Api.Models.Usage;
using Insight.Assist.Api.DAL;
using Insight.Assist.Api.Models;
using Microsoft.EntityFrameworkCore;
using NuGet.Packaging;

namespace Insight.Assist.Api.Services;

public partial class StatsService
{
    private readonly UsageContext _usageContext;
    private readonly UsageService _usageService;

    public StatsService(UsageContext usageContext, UsageService usageService)
    {
        _usageContext = usageContext;
        _usageService = usageService;
    }
    public HistoricalStatSpan GetSpanFromDates(DateTime? startDate, DateTime? endDate)
    {
        if (startDate != null && endDate != null)
        {
            // Calculate the difference between the start and end dates
            TimeSpan span = endDate.Value - startDate.Value;

            if (span.TotalMinutes <= 60)
            {
                return HistoricalStatSpan.Minute;
            }
            else if (span.TotalHours <= 24)
            {
                return HistoricalStatSpan.Hour;
            }
            else if (span.TotalDays <= 31)
            {
                return HistoricalStatSpan.Day;
            }
            else if (span.TotalDays <= 365)
            {
                return HistoricalStatSpan.Month;
            }
            else
            {
                return HistoricalStatSpan.Year;
            }
        }
        else
        {
            // Default span if no start and end dates are provided
            return HistoricalStatSpan.Day;
        }
    }
    public async Task<AdminStats> ComputeHistoricalStats(DateTime dateTime, HistoricalStatSpan span)
    {
        var startDate = span.StartDateTimeForSpan(dateTime);
        var endDate = span.EndDateTimeForSpan(dateTime);
        var periodApiCalls = _usageContext.ApiCalls
            .Where(call => call.ReceivedResponseAt >= startDate && call.ReceivedResponseAt <= endDate);

        // TODO: switching to use org quota, but need more requirements to really figure out the proper logic of stats
        var orgQuota = (await _usageService.GetQuota(teamId: Quota.AllUsersTeamId, period: Quota.GetPeriodStringForDate(dateTime), createIfDoesntExist: true))!;

        var stats = new AdminStats
        {
            TotalUsers = periodApiCalls.GroupBy(call => call.UserId).Count(),
            TotalConversations = periodApiCalls.GroupBy(call => call.ChatId).Count(),
            TotalInteractions = periodApiCalls.Count(),
            QuotaLimit = orgQuota.CostLimit,
            QuotaUsed = periodApiCalls.Sum(call => call.CostUsed ?? 0),
            AverageResponseTimeInMs = periodApiCalls.Average(call => call.RequestDurationMs) ?? 0
        };

        return stats;
    }

    public async Task<AdminStats> ComputeHistoricalStatsRange(DateTime startDate, DateTime endDate, HistoricalStatSpan span)
    {
        /*var startDate = span.StartDateTimeForSpan(dateTime);
        var endDate = span.EndDateTimeForSpan(dateTime);*/
        var periodApiCalls = _usageContext.ApiCalls
            .Where(call => call.ReceivedResponseAt >= startDate && call.ReceivedResponseAt <= endDate);

        // TODO: switching to use org quota, but need more requirements to really figure out the proper logic of stats
        var orgQuota = (await _usageService.GetQuota(teamId: Quota.AllUsersTeamId, period: Quota.GetPeriodStringForDate(startDate), createIfDoesntExist: true))!;

        var stats = new AdminStats
        {
            TotalUsers = periodApiCalls.GroupBy(call => call.UserId).Count(),
            TotalConversations = periodApiCalls.GroupBy(call => call.ChatId).Count(),
            TotalInteractions = periodApiCalls.Count(),
            QuotaLimit = orgQuota.CostLimit,
            QuotaUsed = periodApiCalls.Sum(call => call.CostUsed ?? 0),
            AverageResponseTimeInMs = periodApiCalls.Average(call => call.RequestDurationMs) ?? 0
        };

        return stats;
    }

    public async Task<HistoricalStat?> ComputeHistoricalStatsForTimeWindow(int statIndex, DateTime dateTime, HistoricalStatSpan span)
    {
        var statProperties = typeof(AdminStats).GetProperties()
            .Select(p => new
            {
                Property = p,
                Attribute =
                    p.GetCustomAttributes(typeof(HistoricalStatAttribute)).FirstOrDefault() as
                        HistoricalStatAttribute
            });

        // Compute the stat on the fly
        var targetStartDate = dateTime;
        var workingDate = targetStartDate;
        var numDataPoints = span.NumDataPoints(targetStartDate);
        var data = new Dictionary<int, AdminStats>();
        var startingDataValue = span.StartingDataValue();
        for (var i = 0; i < numDataPoints; i++)
        {
            if (workingDate > DateTime.UtcNow) continue;

            data.Add(startingDataValue + i, await ComputeHistoricalStats(workingDate, span));
            workingDate = workingDate.Add(span.ToTimeSpan(workingDate));
        }

        var newStats = statProperties.Select(statProperty => new HistoricalStat
        {
            Index = statProperty.Attribute.Index,
            Name = statProperty.Attribute.Name,
            Span = span,
            StartDateTime = targetStartDate,
            Data = new Dictionary<int, object>(data.Select(kvp =>
                KeyValuePair.Create(kvp.Key, statProperty.Property.GetValue(kvp.Value)))!)
        });

        foreach (var stat in newStats)
        {
            await SaveHistoricalStat(stat, isNew: true, save: false);
        }

        await SaveHistoricalStats();

        return newStats.FirstOrDefault(stat => stat.Index == statIndex);
    }

    public IEnumerable<Quota> GetTopUsers(DateTime dateTime, HistoricalStatSpan span, int limit = 10)
    {
        var startDate = span.StartDateTimeForSpan(dateTime);
        var endDate = span.EndDateTimeForSpan(dateTime);
        var topUsers = _usageContext.ApiCalls
            .Where(call => call.ReceivedResponseAt >= startDate && call.ReceivedResponseAt <= endDate)
            .Include(call => call.User)
            .GroupBy(call => call.UserId)
            .Select(g => new Quota
            {
                UserId = g.Key,
                User = g.First().User,
                CostUsed = g.Sum(call => call.CostUsed) ?? 0,
                ConversationCount = g.Count() // This field is actually used to convey an interaction/query count, not a distinct chat/conversation count
            })
            .OrderByDescending(q => q.CostUsed)
            .Take(limit);

        return topUsers;
    }

    public IEnumerable<Quota> GetTopUsersRange(DateTime startDate, DateTime endDate, HistoricalStatSpan span, int limit = 10)
    {
        /*var startDate = span.StartDateTimeForSpan(dateTime);
        var endDate = span.EndDateTimeForSpan(dateTime);*/
        var topUsers = _usageContext.ApiCalls
            .Where(call => call.ReceivedResponseAt >= startDate && call.ReceivedResponseAt <= endDate)
            .Include(call => call.User)
            .GroupBy(call => call.UserId)
            .Select(g => new Quota
            {
                UserId = g.Key,
                User = g.First().User,
                CostUsed = g.Sum(call => call.CostUsed) ?? 0,
                ConversationCount = g.Count() // This field is actually used to convey an interaction/query count, not a distinct chat/conversation count
            })
            .OrderByDescending(q => q.CostUsed)
            .Take(limit);

        return topUsers;
    }

    public async Task<HistoricalStat?> GetHistoricalDashboardStatsRange(int statIndex, DateTime startDate, DateTime endDate)
    {
        var inclusiveEndDate = endDate.AddDays(1);
        var span = GetSpanFromDates(startDate, inclusiveEndDate);

        if (startDate == inclusiveEndDate)
        {
            span = HistoricalStatSpan.Hour;
        }
        var statData = new Dictionary<string, int>();
        if (span == HistoricalStatSpan.Month || span == HistoricalStatSpan.Hour)
        {
            string periodString = startDate.ToString(span.ToDateFormat());
            var stat = GetHistoricalStat(statIndex, span, span.DateTimeFromPeriod(periodString)) ?? new HistoricalStat
            {
                Index = statIndex,
                Span = span,
                StartDateTime = span.PeriodDateTimeForSpan(startDate),
                Data = new Dictionary<int, object>()
            };
            var date = stat.Data;
            stat.Name = "CombinedStats";
            return stat;
        }
        else
        {
            // Loop through the months between the start date and end date
            var currentDate = startDate;
            while (currentDate <= inclusiveEndDate)
            {
                string key = $"{currentDate.DayOfYear}";
                statData[key] = 0;
                currentDate = currentDate.AddDays(1);

            }
            currentDate = startDate;
            while (currentDate <= inclusiveEndDate)
            {
                string periodString = currentDate.ToString(span.ToDateFormat());
                var stat = GetHistoricalStat(statIndex, span, span.DateTimeFromPeriod(periodString)) ?? new HistoricalStat
                {
                    Index = statIndex,
                    Span = span,
                    StartDateTime = span.PeriodDateTimeForSpan(startDate),
                    Data = new Dictionary<int, object>()
                }; ;

                // If the stat is not found for the specific month, compute it and add it to the database
                if (stat == null)
                {
                    stat = await ComputeHistoricalStatsForTimeWindow(statIndex, span.DateTimeFromPeriod(periodString), span);
                }

                // Add the data for the current month to the response dictionary
                foreach (var kvp in stat.Data)
                {
                    int date = (int)kvp.Key;
                    DateTime currentDateTimeWithDay = new DateTime(currentDate.Year, currentDate.Month, date);

                    if (currentDateTimeWithDay >= startDate && currentDateTimeWithDay <= inclusiveEndDate)
                    {
                        int value = Convert.ToInt32(kvp.Value);
                        string key = $"{currentDateTimeWithDay.DayOfYear}"; // Converting DateTime to day of year
                        statData[key] = value;
                    }

                }

                // Move to the next month
                var lastDateOfMonth = currentDate.LastDayOfMonth();
                currentDate = lastDateOfMonth.AddDays(1);

            }
            var convertedData = statData.ToDictionary(kvp => int.Parse(kvp.Key), kvp => (object)kvp.Value);

            // Create the final HistoricalStat object
            var finalStat = new HistoricalStat
            {
                Index = statIndex,
                Name = "CombinedStats",
                Span = span,
                StartDateTime = startDate,
                Data = convertedData
            };

            return finalStat;
        }
    }

    /// <summary>
    /// Maps the property to the "StatIndex" column in the HistoricalStats table.
    /// This allows you to rename the property without losing the mapping.
    /// Indices SHOULD NOT be reused if a stat is removed and new one is added.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class HistoricalStatAttribute : Attribute
    {
        public int Index { get; }
        public string Name { get; }

        public HistoricalStatAttribute(int index, string name)
        {
            Index = index;
            Name = name;
        }
    }

    public class AdminStats
    {
        [HistoricalStat(0, "Active Users")]
        public int TotalUsers { get; init; }

        [HistoricalStat(1, "Total Conversations")]
        public int TotalConversations { get; set; }

        [HistoricalStat(8, "Total Interactions")]
        public int TotalInteractions { get; set; }

        [HistoricalStat(2, "Average Chats Per User")]
        public double AverageChatsPerUser => TotalUsers == 0 ? 0 : (double)TotalConversations / TotalUsers;

        [HistoricalStat(3, "Average Response Time (ms)")]
        public double AverageResponseTimeInMs { get; set; }

        [HistoricalStat(4, "Quota Used")]
        public long QuotaUsed { get; set; }

        [HistoricalStat(5, "Quota Limit")]
        public long QuotaLimit { get; set; }

        [HistoricalStat(6, "Average Cost Per User")]
        public long AverageCostPerUser => TotalUsers == 0 ? 0 : QuotaUsed / TotalUsers;

        [HistoricalStat(7, "Average Cost Per Chat")]
        public long AverageCostPerChat => TotalConversations == 0 ? 0 : QuotaUsed / TotalConversations;
    }

    public HistoricalStat GetHistoricalStat(int index, HistoricalStatSpan span, DateTime startDateTime)
    {
        var stat = _usageContext.HistoricalStats.FirstOrDefault(
            hs => hs.Index == index && hs.StartDateTime == startDateTime && hs.Span == span);

        var entries = Enumerable.Range(0, 24).Select(i => new KeyValuePair<int, object>(i, 0));
        var data = new Dictionary<int, object>();
        data.AddRange(entries);

        return stat;
    }

    public async Task SaveHistoricalStat(HistoricalStat stat, bool isNew = false, bool save = true)
    {
        if (stat.Data.Count() == 1 || isNew)
        {
            // Needs to be added to context; use having 1 stat as a proxy for it being a new entity
            _usageContext.HistoricalStats.Add(stat);
        }
        else
        {
            _usageContext.HistoricalStats.Entry(stat).State = EntityState.Modified;
        }

        await SaveHistoricalStats(save);
    }

    public async Task SaveHistoricalStats(bool save = true)
    {
        if (save)
        {
            try
            {
               await _usageContext.SaveChangesAsync();
            }
            catch (Exception ex)
            { 
                Console.WriteLine(ex.ToString());
            }
        }
    }
}