﻿using Assist.Accelerator.Chat.Api.Hubs;
using Assist.Accelerator.Chat.Api.Models.Exceptions;
using Assist.Accelerator.Chat.Api.SemanticKernel.Plugins;
using Insight.Assist.Api.Models;
using Insight.Assist.Api.Services;
using Microsoft.AspNetCore.SignalR;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Memory;
using Microsoft.SemanticKernel.Orchestration;
using System.Text.Json;
using Assist.Accelerator.Chat.Api.Providers;
using Microsoft.SemanticKernel.SkillDefinition;
using Insight.Assist.Api.DAL;
using Assist.Accelerator.Chat.CopilotSupport;
using Assist.Accelerator.Chat.Api.Models;
using Assist.Accelerator.Chat.Api.Models.MapExtensions;

namespace Assist.Accelerator.Chat.Api.Services
{
    public class KernelService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;
        private readonly UsageService _usageService;
        private readonly UsersService _usersService;
        private readonly LlmService _llmService;
        private readonly ChatService _chatService;
        private readonly FileService _fileService;
        private readonly FileParserService _fileParserService;
        private readonly ResponseStreamingService _responseStreamingService;
        private readonly ICopilotSupport _copilotSupport;

        public KernelService(
            IConfiguration configuration,
            ILogger<KernelService> logger,
            UsageService usageService,
            UsersService usersService,
            LlmService llmService,
            ChatService chatService,
            FileService fileService,
            FileParserService fileParserService,
            ResponseStreamingService responseStreamingService,
            ChatContext chatContext,
            ICopilotSupport copilotSupport)
        {
            _configuration = configuration;
            _logger = logger;
            _usageService = usageService;
            _usersService = usersService;
            _llmService = llmService;
            _chatService = chatService;
            _fileService = fileService;
            _fileParserService = fileParserService;
            _responseStreamingService = responseStreamingService;
            _copilotSupport = copilotSupport;

            //_coPilotRegistry = GetCopilotRegistry(chatContext);
        }

        public async Task<Insight.Assist.Api.Models.Chat> GetChatCompletionAsync(ChatBody body, Guid? chatId = null)
        {
            var user = _usersService.GetCurrentUserOrThrow()!;

            var model = body.ModelName == string.Empty ? _usageService.GetCurrentModel() : _usageService.GetModel(body.ModelName);
            var modelConfig = _configuration.GetSection(model.CredentialPath);

            var embeddingModel = _usageService.GetCurrentModel(ModelPurpose.Embedding);
            var embeddingModelConfig = _configuration.GetSection(embeddingModel.CredentialPath);
            
            var kernel = Kernel.Builder
                .WithLogger(_logger)
                .WithChatCompletionService(model, modelConfig)
                .WithTextEmbeddingGenerationService(embeddingModel, embeddingModelConfig)
                .WithMemoryStorage(new VolatileMemoryStore())
                .Build();

            var chatPlugin = kernel.ImportSkill(new ChatPlugin(kernel, _usageService, _usersService, _llmService, _chatService, _responseStreamingService));
            var chatHistoryPlugin = kernel.ImportSkill(new ChatHistoryPlugin(_chatService));
            var filePlugin = kernel.ImportSkill(new FilePlugin(_fileService, _fileParserService));
            var memoryPlugin = kernel.ImportSkill(new MemoryPlugin());
            var externalServicePlugin = kernel.ImportSkill(new ExternalServicePlugin(_chatService));

            var contextVars = new ContextVariables();
            contextVars.Set("userInput", body.Input);
            contextVars.Set("fileName", body.FileName);
            contextVars.Set("indexId", body.IndexId.ToString());
            contextVars.Set("chatId", chatId.ToString());
            contextVars.Set("userEmail", user.EmailAddress);
            contextVars.Set("userId", user.UserId.ToString());
            contextVars.Set("modelId", model.Id.ToString());

            var chatCompletionFn = body.IndexId == 0 
                ? chatPlugin["GetChatCompletion"] 
                : chatPlugin["GetKbChatCompletion"];

            var pipeline = new[]
            {
                chatHistoryPlugin["GetChatHistory"],
                chatPlugin["GetUserIntent"],
                filePlugin["GetFileContents"],
                memoryPlugin["GetMemories"],
                chatCompletionFn,
                chatPlugin["GetChatTitle"],
                chatHistoryPlugin["UpdateChatHistory"]
            };

            // Use the default pipeline unless we are requesting to use a copilot
            var copilotId = await GetCopilotId(body, chatId);
            if (copilotId != null)
            {
                contextVars.Set("copilotId", copilotId.ToString());
                
                // Create a dictionary of the Skills required by the CoPilot's Pipeline.
                var copilotContext = new Dictionary<string, IDictionary<string, ISKFunction>>
                {
                    { nameof(ChatPlugin), chatPlugin },
                    { nameof(ChatHistoryPlugin), chatHistoryPlugin },
                    { nameof(FilePlugin), filePlugin },
                    { nameof(MemoryPlugin), memoryPlugin },
                    { nameof(ExternalServicePlugin), externalServicePlugin }
                };

                // Read the CoPilot definition in from the database & return the pipeline.
                pipeline = GetCopilotPipeline(copilotId.Value, copilotContext, contextVars, kernel);
            }
            
            var result = await kernel.RunAsync(contextVars, pipeline);

            if (result.ErrorOccurred)
            {
                string errorMessage = "Something went wrong with Azure OpenAI service.";
                throw new ChatApiException(errorMessage);
            }

            if (!result.Variables.TryGetValue("chatJson", out var chatJson))
            {
                throw new NullReferenceException(nameof(chatJson));
            }

            var chat = JsonSerializer.Deserialize<Insight.Assist.Api.Models.Chat>(chatJson);

            return chat ?? throw new NullReferenceException(nameof(chat));
        }

        private ISKFunction[] GetCopilotPipeline(int copilotId, 
            Dictionary<string, IDictionary<string, ISKFunction>> context,
            ContextVariables contextVariables, 
            IKernel kernel)
        {
            CopilotSettings copilotSettings = _copilotSupport.GetCopilot(copilotId).AsCopilotSettings();
            CopilotPipeline plan = copilotSettings.Plan;
            
            // Add context vars
            foreach (var (variable, value) in plan.ContextVariables)
            {
                contextVariables.Set(variable, value);
            }

            // If the copilot has a code implementation...
            
            // If we can initialize that copilot implementation...
            ICopilot? copilot = _copilotSupport.LoadCopilot(copilotId, kernel);

            // Try to add its "private" plugins.  If the copilot is null, or the method returns null, don't update context.
            context = copilot?.AddCopilotSpecificPlugins(context)??context;
            

            // Construct pipeline
            var pipeline = plan.Plugins
                .Select(p => p.Split("."))
                .Select(p => context[p[0]][p[1]])
                .ToArray();

            return pipeline;
        }

        private async Task<int?> GetCopilotId(ChatBody body, Guid? chatId)
        {
            var copilotId = body.Copilot;
            
            // Copilot ID can't be changed once it's been used in a conversation
            if (chatId != null)
            {
                var existingChat = await _chatService.GetChatAsync(chatId);
                if (existingChat.CopilotId.HasValue)
                {
                    copilotId = existingChat.CopilotId;
                }
            }

            return copilotId;
        }

    }

    
}