using Assist.Accelerator.Chat.Api.Models;
using Azure.AI.OpenAI;

namespace Assist.Accelerator.Chat.Api.Services.Copilots.AuthProviders;

public interface ICopilotAuthProvider
{
    Task<string> GetCopilotResponse(
        string endpoint,
        string credentialData, 
        string input, 
        IEnumerable<ChatMessage> history);
}