using Assist.Accelerator.Chat.Api.Models;
using Azure.AI.OpenAI;
using Newtonsoft.Json.Linq;

namespace Assist.Accelerator.Chat.Api.Services.Copilots.AuthProviders;

/// <summary>
/// A provider for Google Cloud Platform Service Account signed web requests
/// </summary>
public class GCPSACopilotAuthProvider : ICopilotAuthProvider
{
    public async Task<string> GetCopilotResponse(
        string endpoint,
        string credentialData, 
        string input, 
        IEnumerable<ChatMessage> history)
    {
        var client = new GoogleAuthenticatedHttpClient(endpoint, credentialData).GetAuthenticatedClient();
        client.Timeout = TimeSpan.FromMinutes(10);
        // TODO: failure/retry logic
        var response = await client.PostAsJsonAsync(endpoint, new Dictionary<string, object>
        {
            { "input", input },
            { "messageHistory", history }
        });
        var responseString = await response.Content.ReadAsStringAsync();
        var data = JObject.Parse(responseString);
        return data["response"].ToString();
    }
}