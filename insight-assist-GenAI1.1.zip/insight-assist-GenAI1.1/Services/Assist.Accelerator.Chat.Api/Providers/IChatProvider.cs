using Azure.AI.OpenAI;
using Insight.Assist.Api.Models;

namespace Assist.Accelerator.Chat.Api.Providers;

public interface IChatProvider
{
    Task<ChatResponse> SendMessage(AvailableModel model, ChatCompletionsOptions chatCompletionsOptions, CancellationToken cancellationToken = new CancellationToken());
}