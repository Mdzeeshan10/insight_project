﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.CopilotSupport
{
    /// <summary>
    /// A simple class that wraps a predicate for filtering CopilotRegistrations.
    /// </summary>
    public class CopilotPredicate
    {
        public CopilotPredicate(string propertyName, object value)
        {
            PropertyName =  propertyName;
            RequiredValue = value;
        }

        public string PropertyName { get; private set; }

        public object RequiredValue { get; private set; }

        public Func<CopilotRegistration, bool> Predicate 
        { 
            get 
            { 
                return (copilot) =>
                {
                    var property = copilot.GetType().GetProperty(PropertyName);
                    if (property == null)
                    {
                        return false;
                    }

                    var value = property.GetValue(copilot);
                    if (value == null)
                    {
                        return false;
                    }

                    return value.Equals(RequiredValue);
                };
            } 
        }

    }
}
