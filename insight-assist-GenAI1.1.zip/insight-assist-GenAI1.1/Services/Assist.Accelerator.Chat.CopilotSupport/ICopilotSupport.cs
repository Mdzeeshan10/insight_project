﻿using Microsoft.SemanticKernel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.CopilotSupport
{
    public interface ICopilotSupport
    {
        int RegisterCopilot(CopilotRegistration copilot);

        ICopilot? LoadCopilot(int copilotId, IKernel kernel);

        IEnumerable<CopilotRegistration> FilterCopilots(CopilotPredicate[] predicates);

        CopilotRegistration GetCopilot(int copilotId);
    }
}
