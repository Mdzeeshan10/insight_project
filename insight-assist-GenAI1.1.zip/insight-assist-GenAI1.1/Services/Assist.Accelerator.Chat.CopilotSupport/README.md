﻿# Authoring Copilots for Insight-Assist  

A certain amount of our job when bringing the Insight Assistant system into a Client's environment will be the creation of specialized Copilots that meet specific business use cases.  To simplify this process, we have worked to make these Copilots as easy to author and plug in as possible.  

*This document assumes you're already familiar with the basics of working with Semantic Kernel and authoring custom Plugins; Copilot authoring builds on those skills.*

*Note:  Throughout this document, we refer to Plugins quite a bit.  In early versions of the Semantic Kernel, these were called Skills, and Microsoft has expressed a plan to rename the Skill concept to "Plugin".  If you're working with this before that rename has happened, just remember that Plugin == Skill.*

# Introduction  
Within the context of the insight-assist project, a Copilot is a pre-configured set of Semantic Plugins that
are executed sequentially to perform some well-defined process or task.  We currently support to kinds of Copilots within the
insight-assist system:  *Composed Copilots* and *Custom Copilots*.  Copilots of both kinds must be registered in the 
InsightAssist control database to be available on the User Interface.  

It is important to carefully consider the use case for the Copilot you're creating, and how best you can leverage existing plugins to perform the desired workload.  If you require capabilities that are provided in thw Semantic Kernel or the main API project already, use those, 
rather than building your own.  Inside your Copilot project, be sure to create only those Plugins that *should not* be exposed or imported into the Kernel during regular use.  

For example:  
The Meeting Summarizer Copilot has a plugin that accepts a large Transcript file, breaks it into a number of smaller pieces and processes those parts in parallel.  The Semantic Function that summarizes each chunk returns a fragment of JSON.  

Once all of the "chunks" have been summarized, these JSON fragments are passed to another method for consolidation, sorting, and formatting.  Finally, a second Semantic Function condenses the summary to a more reasonable length.  

All of the File Access, User Interaction, Chat History Retention parts of our process are provided by plugins that are built into either the Kernel package or the API, so we can leverage them in our Copilot's pipeline without having to write the code for those capabilities ourselves.  

We don't want those two semantic functions available outside of the context of the Copilot, as their inputs and outputs depend on each other for proper execution.  Should another copilot (or a Planner,) select one plugin without the other, or execute them in an incorrect order, the results would be... peculiar at best.

_**Remember:**  We don't code "Features" directly, but rather create the discrete capabilties required to provide the requested behavior, and then stitch those capabilities together to provide that behavior._

# Copilot Database Tables

**ctl.Copilots** 

| Column Name | Data Type | Description |  
| ----------- | --------- | ----------- |  
| Id | int | Unique identifier for the Copilot |  
| SystemName | varchar(MAX) | The immutable name of the Copilot, used for system identification |  
| DisplayName | varchar(MAX) | The display name of the Copilot, used on the UI |  
| Description | varchar(MAX) | A description of the Copilot, displayed in the UI |  
| IntroMessage | varchar(MX) | the message that is displayed when a new conversation with the copilot begins |  
| IsActive | bit | Indicates whether the Copilot is active or not |  

**ctl.CopilotSettings (1:1 relationship with ctl.Copilots)**  

| Column Name | Data Type | Description |  
| ----------- | --------- | ----------- |  
| CopilotId | int | Associates the Settings with a defined Copilot in the base table. |  
| Endpoint | varchar(MAX) | For external Copilots, the URL of the Copilot endpoint |  
| AuthProvider | int | For External Copilots, the Authentication provider (Currently 0 = No Auth, 1 = Google) |  
| CredentialData | varchar(MAX) | For External Copilots, the credential information to be sent to the AuthProvider |  
| Pipeline | varchar(MAX) | A JSON string containing any special Context Variables, as well as an ordered list of Plugins to be executed in performing the Copilot's workload |  


## Composed Copilots  
Composed copilots are made up of a sequence of plugins that are "native" to either the SemanticKernel itself, or are defined directly within the insight-assist chat api's code.  Adding a new Composed Copilot is a matter of creating new entries in the Copilot Tables.

These copilots are registered either with a custom installation script provided by the Copilot author, or manually into the database through some SQL UI.

## Custom Copilots  
Custom Copilots not only include built-in Sementic Kernel or API plugins, but also have Plugins that may not be suitable for use outside the context of the Copilot itself.  

These Copilots are coded in their own assembly, and then brought into the Accelerator application via project reference.  Any custom or private plugins that should be kept private to the copilot are defined within this assembly and injected into the current Kernel instance just before invocation.  

Custom Copilots are capable of self-registration in the database, and do so the first time the application starts after they've been added to the API's hosting environment.

# Creating a Custom Copilot
First, add a new Class Library Project to the solution, named appropriately for whatever convention has been established for your client project.

Next, you will install the Semantic Kernel packages into your Copilot project, and add a Project reference.

## Installing the Semantic Kernel packages
Look at the Semantic Kernel package references on the main API project, and take careful note of the package versions.  You'll need to make sure that the packages in your project match those imported by the API you're extending.

## Adding the project reference
`Assist.Accelerator.Chat.CopilotSupport` is already referenced by the main API; this project provides the infrastructure used by the API to support both Composed and Custom Copilots.  This package contains the dotNet Interface that all custom copilots must implement, along with a handful of data classes that are used to manage and invoke these Copilots.

## Create the Copilot class in your project
Create a new class in your project that implements the `ICopilot` interface.  Create the method stubs for that interface now.  

*Style Note*: Wrapping the Interface implementations, constants and other boilerplate code in regions can help when you're working in this class later.  It's not required, but it can help you and later developers focus on the parts of your copilot class that they care about.

Next, you'll add constants to your class that will be used during self-registration.  These constants will provide the initial values that will be added to the database, though most of them can be edited in that db entry later.

```csharp  
#region Registration Constants
        public const string SystemName = "Meeting Summarizer";  
        private const string defaultDisplayName = "Meeting Summarizer";  
        private const string defaultDescription = "Provides methods by which a meeting transcript can be summarized.";  
        private const string defaultIntroMessage = "I can summarize a meeting transcript for you.";  
        private const string defaultPipeline = "/{'ContextVariables':{},'Plugins':['ChatHistoryPlugin.GetChatHistory','FilePlugin.GetFileContents','TranscriptSummarizer.SummarizeTranscript','ChatPlugin.GetChatTitle','ChatHistoryPlugin.UpdateChatHistory']}";  
        private const string defaultEndpoint = "";  
        private const string defaultCredentialData = "";  
        private const int defaultAuthProviderId = 0;  
#endregion
```

You'll then define any other class-level constants or `private readonly` variables that you'd use when creating your Copilot-private plugins, and set up your class' constructor.

Add the methods to implement and expose the plugins, with the main "entry point" methods being marked as Semantic Functions.  (Use the `[SkFunction]` attribute as you normally would.)
For readability or maintainability's sake, you could choose to implement your inner plugins as discrete classes in separate files.  The decision to do this is up to you, and shoudl be based on the complexity of 
the workload you're implementing.

Now that you've created most of the functionality of your Copilot, let's revist those interface methods you stubbed out at the beginning.

### Implementing the ICopilot interface

**ICopilot**  

| Method Name | Parameters | Return Type | Description |  
| ----------- | ---------- | ----------- | ----------- |
| `Name` | None | `string` | Returns the SystemName of the Copilot |
| `AddCopilotSpecificPlugins` | `Dictionary<string, IDictionary<string, ISKFunction>>` | `Dictionary<string, IDictionary<string, ISKFunction>>` | Adds the Plugins defined by the Copilot and used in its Pipeline to the provided Dictionary and returns it. |  
| `RegisterSelf` | `Func<CopilotRegistration, int>` | `CopilotRegistration` | The Copilot uses the provided function to pass an instance of its `CopilotRegistration` built from the defined default values to the Copilot Storage component, receives its new Id and returns the completed Registration instance to the caller. |  

*`Name`* simply provides access to the SystemName constant defined above.  This is used by the API to help identify the Copilot when it's being used.  

*`AddCopilotSpecificPlugins`* is where you'll add the plugins dictionary you created in the constructor to the provided dictionary.  The Key of the outer Dictionary is the first part of the Plugin referenced in its Pipline entry.  The Value that you'll add is the IDictionary variable you created in the class constructor that holds the available plugins exposed by the Copilot.

For Example:  
In the Meeting Summarizer Copilot, the Pipeline value references `"TranscriptSummarizer.SummarizeTranscript"`.  
In the constructor for the Summarizer's Copilot class, we instantiated the local plugin dictionary (just like we do with custom plugins,) 
```csharp
  _publishedFunctions = _kernel.ImportSkill(this, nameof(TranscriptSummarizerCopilot));
```
In that Copilot's implementation of the AddCopilotSpecific... method, add an entry to that Dictionary of Dictionaries, keyed to the TranscriptSummarizerCopilot, like so:  
```csharp
  globalPlugins.Add("TranscriptSummarizer", _publishedFunctions);
  return globalPlugins;
```  

*`RegisterSelf`* is where you'll create a `CopilotRegistration` instance, and then send it to the database using the provided storage function.  The storage function will return the Id of the newly created Copilot, which you'll then add to the CopilotRegistration instance and return to the caller.

Here is the implementation of that method, from the `TranscriptSummarizerCopilot`:

```csharp
        public static CopilotRegistration RegisterSelf(Func<CopilotRegistration, int> registrationVisitor)
        {
            string pipeline = defaultPipeline;
            // Had to escape the { at the start of the defaultPipeline constant to avoid a compiler error.
            // that escape character cannot be sent to the database, or the pipeline won't be deserializable, so let's remove it now.
            if (pipeline.StartsWith("/")) 
            { 
                pipeline = pipeline.Substring(1);
            }

            CopilotRegistration registration = new CopilotRegistration
            {
                AuthProviderId = defaultAuthProviderId,
                SystemName = SystemName,
                DisplayName = defaultDisplayName,
                Description = defaultDescription,
                IntroMessage = defaultIntroMessage,
                Endpoint = defaultEndpoint,
                CredentialData = defaultCredentialData,
                Pipeline = pipeline,
                IsActive = true,
                Implementation = typeof(TranscriptSummarizerCopilot)
            };

            int copilotId = registrationVisitor( registration );

            registration.Id = copilotId;

            return registration;
        }
```

**Note**:  You may have had to escape the first curly brace in the defaultPipeline constant.  Make sure to remove that escape character from the string before sending it to the database, or it will fail to deserialize when the pipeline is requested later at invocation time.



