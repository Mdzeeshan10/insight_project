﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.CopilotSupport.DataAccess.SqlModels
{
    [Table("CopilotChatState", Schema ="ctl")]
    internal class CopilotChatStateSqlModel
    {
        [Key, Required]
        public string ChatId { get; set; }

        [Required]
        public string ChatState { get; set; }
    }
}
