﻿using Assist.Accelerator.Chat.CopilotSupport.DataAccess.SqlModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.CopilotSupport.DataAccess
{
    internal class CopilotAccess : ICopilotAccess
    {
        private readonly string _connectionString;
        
        public CopilotAccess(string cn)
        {
            _connectionString = cn;
        }

        public IEnumerable<CopilotRegistration> LoadRegisteredCopilots()
        {
            List<CopilotRegistration> copilots = new List<CopilotRegistration>();
                
            using(CopilotContext ctx = new CopilotContext(_connectionString))
            {
                var copilotRecords = ctx.Copilots;
                var copilotSettingsRecords = ctx.CopilotSettings;

                copilots = copilotRecords.Join(copilotSettingsRecords,
                        c => c.Id,
                        s => s.CopilotId,
                        (c, s) => new CopilotRegistration
                        {
                            Id = c.Id,
                            SystemName = c.SystemName,
                            DisplayName = (string.IsNullOrWhiteSpace(c.DisplayName) ? c.SystemName : c.DisplayName),
                            Description = c.Description,
                            IntroMessage = c.IntroMessage,
                            IsActive = c.IsActive,
                            Endpoint = s.Endpoint,
                            AuthProviderId = s.AuthProvider,
                            CredentialData = s.CredentialData,
                            Pipeline = s.Pipeline,
                            FileTypes = c.FileTypes
                        }).ToList();                    
            }

            return copilots;
        }

        public int SaveCopilot(CopilotRegistration copilot)
        {
            using(CopilotContext ctx = new CopilotContext(_connectionString))
            {
                var copilotRecord = ctx.Copilots.FirstOrDefault(c => c.Id == copilot.Id);
                var copilotSettingsRecord = ctx.CopilotSettings.FirstOrDefault(s => s.CopilotId == copilot.Id);

                if(copilotRecord == null)
                {
                    copilotRecord = new CopilotSqlModel
                    {
                        SystemName = copilot.SystemName,
                        DisplayName = copilot.DisplayName,
                        Description = copilot.Description,
                        IntroMessage = copilot.IntroMessage,
                        IsActive = copilot.IsActive,
                        FileTypes = copilot.FileTypes
                    };

                    ctx.Copilots.Add(copilotRecord);
                }
                else
                {
                    copilotRecord.SystemName = copilot.SystemName;
                    copilotRecord.DisplayName = copilot.DisplayName;
                    copilotRecord.Description = copilot.Description;
                    copilotRecord.IntroMessage = copilot.IntroMessage;
                    copilotRecord.IsActive = copilot.IsActive;
                    copilotRecord.FileTypes = copilot.FileTypes;
                }

                //Save changes now, to get the new copilotId.
                ctx.SaveChanges();

                if(copilotSettingsRecord == null)
                {
                    copilotSettingsRecord = new CopilotSettingsSqlModel
                    {
                        CopilotId = copilotRecord.Id,
                        Endpoint = copilot.Endpoint??string.Empty,
                        AuthProvider = copilot.AuthProviderId,
                        CredentialData = copilot.CredentialData ?? string.Empty,
                        Pipeline = copilot.Pipeline
                    };

                    ctx.CopilotSettings.Add(copilotSettingsRecord);
                }
                else
                {
                    copilotSettingsRecord.Endpoint = copilot.Endpoint ?? string.Empty;
                    copilotSettingsRecord.AuthProvider = copilot.AuthProviderId;
                    copilotSettingsRecord.CredentialData = copilot.CredentialData ?? string.Empty;
                    copilotSettingsRecord.Pipeline = copilot.Pipeline;
                }

                // Save changes to write the settings.
                ctx.SaveChanges();

                return copilotRecord.Id;
            }   
        }
    }
}
