﻿using Assist.Accelerator.Chat.CopilotSupport.DataAccess.SqlModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.CopilotSupport.DataAccess
{
    public class ChatStateAccess : IChatStateAccess
    {
        private readonly string _connectionString;

        public ChatStateAccess(string cn)
        {
            _connectionString = cn;
        }

        public async Task<string> GetCopilotChatStateAsync(string chatId)
        {
            string chatState = string.Empty;

            using (ChatStateDbContext ctx = new ChatStateDbContext(_connectionString))
            {
                CopilotChatStateSqlModel? stateRecord = null;

                stateRecord = await ctx.CopilotChatStates.FirstOrDefaultAsync(x => x.ChatId == chatId);

                chatState = stateRecord?.ChatState ?? string.Empty;
            }

            return chatState;
        }

        public async Task SaveCopilotChatAsync(string chatId, string stateJson)
        {
            

            using(ChatStateDbContext ctx = new ChatStateDbContext(_connectionString))
            {
                CopilotChatStateSqlModel? stateRecord = ctx.CopilotChatStates.FirstOrDefault(x => x.ChatId == chatId);
                if(stateRecord == null)
                {
                    stateRecord = new CopilotChatStateSqlModel();
                    stateRecord.ChatId = chatId;
                    stateRecord.ChatState = stateJson;
                    ctx.CopilotChatStates.Add(stateRecord);
                }
                else
                {
                    stateRecord.ChatState = stateJson;
                }

                await ctx.SaveChangesAsync();
            }

        }
    }
}
