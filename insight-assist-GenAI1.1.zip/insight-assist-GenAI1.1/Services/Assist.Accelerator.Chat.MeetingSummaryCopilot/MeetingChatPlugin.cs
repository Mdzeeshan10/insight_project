﻿using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Orchestration;
using Microsoft.SemanticKernel.SemanticFunctions;
using Microsoft.SemanticKernel.SkillDefinition;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.MeetingSummaryCopilot
{
    /// <summary>
    /// A version of the chat completion behavior that is customized to chatting about a summarized meeting.
    /// </summary>
    internal class MeetingChatPlugin
    {
        private readonly PromptTemplateConfig _promptConfig = new()
        {
            Completion =
            {
                MaxTokens = 2048,
                Temperature = 0.9,
                TopP = 0.0,
                PresencePenalty = 0.0,
                FrequencyPenalty = 0.0
            }
        };

        private readonly IKernel _kernel;
        private readonly ISKFunction _chatCompletionFunction;

        public MeetingChatPlugin(IKernel kernel)
        {
            _kernel = kernel;
            _chatCompletionFunction = kernel.CreateSemanticFunction(
                _completionPrompt,
                skillName: nameof(MeetingChatPlugin),
                description: "Chat about a meeting that has been summarized.",
                maxTokens: _promptConfig.Completion.MaxTokens,
                temperature: _promptConfig.Completion.Temperature,
                topP: _promptConfig.Completion.TopP,
                presencePenalty: _promptConfig.Completion.PresencePenalty,
                frequencyPenalty: _promptConfig.Completion.FrequencyPenalty
                );
        }

        [SKFunction, Description("Chat with the LLM about the summarized meeting content.")]
        public async Task<SKContext> ChatWithMeetingAsync(
            [Description("The unique identifier of this chat")]string chatId,
            [Description("The user's input")]string userInput,
            SKContext context)
        {
            
            context.Variables.Set("prompt", userInput);
            
            context.Variables.TryGetValue("userEmail", out string userEmail);
            context.Variables.TryGetValue("meetingData", out string meetingData);

            if(context.Variables.TryGetValue("chatHistory", out string chatHistory) == false)
            {
                chatHistory = string.Empty;
            }

            SKContext chatResult = await _kernel.RunAsync(context.Variables, _chatCompletionFunction);

            string chatResponse = chatResult.Result;

            context.Variables.Set("llmOutput", chatResponse);

            return context;
        }


        private const string _completionPrompt = @"
You are a friendly and helpful assistant. 
Respond to the user's inquiry with a useful answer.
Use information from the chat history and meeting information where appropriate.
If there is nothing in the chat history or meeting information, respond normally.

HISTORY
+++++
{{$chatHistory}}
+++++

MEETING INFORMATION
+++++
{{$meetingData}}
+++++

USER: {{$prompt}}
ASSISTANT: 
";
    }
}
