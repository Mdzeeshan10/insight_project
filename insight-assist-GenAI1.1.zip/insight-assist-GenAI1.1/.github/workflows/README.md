#gitHub
GitHub workflows, actions, and other policies related to the repo will live here. 
Actions are GitHub's version of CI / CD pipelines.  
The workflows and actions should be used to build and release IP artifacts into the artifact repository.

For an example of workflows in action, view the [InsightAppsAndData/MSTestAndBuildSample](https://github.com/InsightAppsAndData/MSTestAndBuildSample) project. 
This project is a sample of building on merging PRs into master, executing unit tests, and providing a test report.