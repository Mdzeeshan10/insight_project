function CreateDefaultSearchIndex (
    [Parameter(Mandatory = $true)]
    [pscustomobject]$tout
) 
{
    $key = az search admin-key show --resource-group $tout.resource_group_name --service-name $tout.search_service_name
    $key = $key | ConvertFrom-Json
    $pk = $key.primaryKey
    
    $headers = @{
        'api-key' = $pk
        'Content-Type' = 'application/json' 
        'Accept' = 'application/json' 
    }

    $serviceName = $tout.search_service_name
    $apiVersion = "2021-04-30-Preview"

    #---------------------------------------------------------------
    # Create Index
    #---------------------------------------------------------------
    
    $indexName = $tout.search_service_default_index_name

$body = @"
{
    "name": "$indexName",
    "fields": 
    [
        {
            "name": "DocumentName",
            "type": "Edm.String",
            "searchable": true,
            "filterable": true,
            "retrievable": true,
            "sortable": true,
            "facetable": false,
            "key": false,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": "standard.lucene",
            "normalizer": null,
            "synonymMaps": []
        },
        {
            "name": "PageNumber",
            "type": "Edm.String",
            "searchable": true,
            "filterable": true,
            "retrievable": true,
            "sortable": true,
            "facetable": false,
            "key": false,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": "standard.lucene",
            "normalizer": null,
            "synonymMaps": []
        },
        {
            "name": "Content",
            "type": "Edm.String",
            "searchable": true,
            "filterable": false,
            "retrievable": true,
            "sortable": false,
            "facetable": false,
            "key": false,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": "standard.lucene",
            "normalizer": null,
            "synonymMaps": []
        },
        {
            "name": "ChunkSize",
            "type": "Edm.String",
            "searchable": false,
            "filterable": false,
            "retrievable": false,
            "sortable": false,
            "facetable": false,
            "key": false,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": null,
            "normalizer": null,
            "synonymMaps": []
        },
        {
            "name": "AzureSearch_DocumentKey",
            "type": "Edm.String",
            "searchable": false,
            "filterable": false,
            "retrievable": true,
            "sortable": false,
            "facetable": false,
            "key": true,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": null,
            "normalizer": null,
            "synonymMaps": []
        },
        {
            "name": "metadata_storage_content_type",
            "type": "Edm.String",
            "searchable": false,
            "filterable": false,
            "retrievable": false,
            "sortable": false,
            "facetable": false,
            "key": false,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": null,
            "normalizer": null,
            "synonymMaps": []
        },
        {
            "name": "metadata_storage_size",
            "type": "Edm.Int64",
            "searchable": false,
            "filterable": false,
            "retrievable": false,
            "sortable": false,
            "facetable": false,
            "key": false,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": null,
            "normalizer": null,
            "synonymMaps": []
        },
        {
            "name": "metadata_storage_last_modified",
            "type": "Edm.DateTimeOffset",
            "searchable": false,
            "filterable": false,
            "retrievable": false,
            "sortable": false,
            "facetable": false,
            "key": false,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": null,
            "normalizer": null,
            "synonymMaps": []
        },
        {
            "name": "metadata_storage_content_md5",
            "type": "Edm.String",
            "searchable": false,
            "filterable": false,
            "retrievable": false,
            "sortable": false,
            "facetable": false,
            "key": false,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": null,
            "normalizer": null,
            "synonymMaps": []
        },
        {
            "name": "metadata_storage_name",
            "type": "Edm.String",
            "searchable": false,
            "filterable": false,
            "retrievable": false,
            "sortable": false,
            "facetable": false,
            "key": false,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": null,
            "normalizer": null,
            "synonymMaps": []
        },
        {
            "name": "metadata_storage_path",
            "type": "Edm.String",
            "searchable": false,
            "filterable": false,
            "retrievable": false,
            "sortable": false,
            "facetable": false,
            "key": false,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": null,
            "normalizer": null,
            "synonymMaps": []
        },
        {
            "name": "metadata_storage_file_extension",
            "type": "Edm.String",
            "searchable": false,
            "filterable": false,
            "retrievable": false,
            "sortable": false,
            "facetable": false,
            "key": false,
            "indexAnalyzer": null,
            "searchAnalyzer": null,
            "analyzer": null,
            "normalizer": null,
            "synonymMaps": []
        }
    ]
}
"@

    Write-Host "Adding index $indexName to $serviceName..."

    $uri = "https://${serviceName}.search.windows.net/indexes/${indexName}?api-version=$apiVersion"
    $request = Invoke-RestMethod -Method put -Uri $uri -Headers $headers -Body $body 
    
    Write-Host "  Added index $($request.name)"

    #---------------------------------------------------------------
    # Create Data Source
    #---------------------------------------------------------------

    $datasourceName = $tout.index_storage_account_name
    $datasourceAccountId = $tout.index_storage_account_id
    $datasourceContainerName = $tout.index_storage_account_container_name

$body = @"
{   
    "name" : "$datasourceName",
    "type" : "adlsgen2",
    "credentials" : { 
        "connectionString": "ResourceId=$datasourceAccountId;"
    },  
    "container" : { 
        "name" : "$datasourceContainerName" 
    }
}
"@

    Write-Host "Adding data source $datasourceName to $serviceName..."

    $uri = "https://${serviceName}.search.windows.net/datasources/${datasourceName}?api-version=$apiVersion"
    $request = Invoke-RestMethod -Method put -Uri $uri -Headers $headers -Body $body

    Write-Host "  Added $($request.name)"

    #---------------------------------------------------------------
    # Create Indexer
    #    "schedule" : {
    #        "interval" : "PT1H"
    #    },
    #   Above is if schedule property wanted later on
    #---------------------------------------------------------------

    $indexerName = $tout.search_service_default_indexer_name

$body = @"
{
    "name" : "$indexerName",
    "dataSourceName" : "$datasourceName",
    "targetIndexName" : "$indexName",
    "parameters" : {
        "configuration" : {
            "dataToExtract" : "contentAndMetadata",
            "parsingMode": "delimitedText",
            "firstLineContainsHeaders": true,
            "delimitedTextDelimiter": ",",
            "delimitedTextHeaders": ""
        }
    },
    "fieldMappings": [
        {
            "sourceFieldName": "AzureSearch_DocumentKey",
            "targetFieldName": "AzureSearch_DocumentKey",
            "mappingFunction": {
                "name": "base64Encode",
                "parameters": null
            }
        }
    ]
}
"@

    Write-Host "Adding indexer $indexerName on $indexName to $serviceName..."

    $uri = "https://${serviceName}.search.windows.net/indexers/${indexerName}?api-version=$apiVersion"
    $request = Invoke-WebRequest -Method put -Uri $uri -Headers $headers -Body $body
    $request = $request | ConvertFrom-Json

    Write-Host "  Added $($request.name)"
}