function TerraformOutputs (
    [Parameter(Mandatory = $true)]
    [String]$terraformFolderPath,
    [Parameter(Mandatory = $true)]
    [String]$pathToReturnTo
) {
    Set-Location $terraformFolderPath

    $myIp = (Invoke-WebRequest ifconfig.me/ip).Content

    $env:TF_VAR_ip_address = $myIp
    $env:TF_VAR_tf_backend_loc = "remote"

    #------------------------------------------------------------------------------------------------------------
    # Get all the outputs from terraform
    #------------------------------------------------------------------------------------------------------------
    Write-Debug "-------------------------------------------------------------------------------------------------"
    Write-Debug "Reading Terraform Outputs - Started"

    $tout = New-Object PSObject
    terragrunt init --terragrunt-config terragrunt/terragrunt.hcl -reconfigure
    $tout0 = (terragrunt output --terragrunt-config terragrunt/terragrunt.hcl -json | ConvertFrom-Json -Depth 10).PSObject.Properties 
    $tout0 | Foreach-Object {                    
        $tout | Add-Member  -MemberType NoteProperty -Name $_.Name -Value $_.Value.value
    }

    $rgid = (az group show -n $tout.resource_group_name | ConvertFrom-Json -Depth 10).id
    $tout | Add-Member  -MemberType NoteProperty -Name "resource_group_id" -Value $rgid

    Write-Debug "Reading Terraform Outputs - Finished"
    Write-Debug "-------------------------------------------------------------------------------------------------"

    Set-Location $pathToReturnTo
    return $tout
}