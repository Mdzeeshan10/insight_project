function DatabaseUsers (
    [Parameter(Mandatory = $true)]
    [String]$terraformFolderPath,
    [Parameter(Mandatory = $true)]
    [String]$pathToReturnTo,
    [Parameter(Mandatory = $true)]
    [pscustomobject]$tout
) {
    Set-Location $terraformFolderPath

    $myIp = (Invoke-WebRequest ifconfig.me/ip).Content

    $env:TF_VAR_ip_address = $myIp
    $env:TF_VAR_tf_backend_loc = "remote"

    $token=$(az account get-access-token --resource=https://database.windows.net --query accessToken --output tsv)

    $users =  @($tout.app_service_web_app_name,$tout.app_service_api_name)
    
    # Add build machine IP to firewall
    $result = az sql server update -n $tout.sql_server_name -g $tout.resource_group_name  --set publicNetworkAccess="Enabled" --only-show-errors
    if ($myIp -ne $null) {
        $result = az sql server firewall-rule create -g $tout.resource_group_name -s $tout.sql_server_name -n "CICDAgent" --start-ip-address $myIp --end-ip-address $myIp --only-show-errors
    }

    # Allow Azure services and resources to access this server
    $result = az sql server firewall-rule create -g $tout.resource_group_name -s $tout.sql_server_name -n "Azure" --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0 --only-show-errors

    # Add MSI as DB users
    foreach($user in $users)        
    {
        if (![string]::IsNullOrEmpty($user))
        {
            $sqlcommand = "

            IF NOT EXISTS (SELECT *
            FROM [sys].[database_principals]
            WHERE [type] = N'E' AND [name] = N'$user') 
            BEGIN
                CREATE USER [$user] FROM EXTERNAL PROVIDER;		
            END
            ALTER ROLE db_datareader ADD MEMBER [$user];
            ALTER ROLE db_datawriter ADD MEMBER [$user];
            GRANT EXECUTE ON SCHEMA::[dbo] TO [$user];
            GO
                    
            "
            
            write-host ("Granting MSI Privileges on Database: " + $tout.sql_database_name + " to " + $user)
            Invoke-Sqlcmd -ServerInstance "$($tout.sql_server_name).database.windows.net,1433" -Database $tout.sql_database_name -AccessToken $token -query $sqlcommand    
        }
    }
    Set-Location $pathToReturnTo

}
