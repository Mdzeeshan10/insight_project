/****** Object:  Table [ctl].[APIUser]    Script Date: 4/04/2023 9:12:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ctl].[APIUser](
	[APIUserId] [int] IDENTITY(1,1) NOT NULL,
	[Username] [varchar](100) NOT NULL,
	[EncryptedPassword] [varbinary](max) NOT NULL,
	[FailedLoginAttempCount] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_APIUserId] PRIMARY KEY CLUSTERED 
(
	[APIUserId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [ctl].[ChatHistory]    Script Date: 4/04/2023 9:12:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ctl].[ChatHistory](
	[ChatHistoryId] [bigint] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[Question] [varchar](8000) NOT NULL,
	[Answer] [varchar](max) NOT NULL,
	[CreateDateTime] [datetime] NOT NULL,
	[AcceptAnswer] [bit] NULL,
	[SQL] [varchar](max) NOT NULL,
	[ReturnJsonData] [varchar](max) NOT NULL,
	[ChatTypeId] [int] NOT NULL,
 CONSTRAINT [PK_ChatHistory] PRIMARY KEY CLUSTERED 
(
	[ChatHistoryId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [ctl].[ChatType]    Script Date: 4/04/2023 9:12:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ctl].[ChatType](
	[ChatTypeId] [int] NOT NULL,
	[ChatTypeName] [varchar](200) NOT NULL,
	[ImageRef] [varchar](200) NOT NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_ChatType] PRIMARY KEY CLUSTERED 
(
	[ChatTypeId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [ctl].[Log]    Script Date: 4/04/2023 9:12:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ctl].[Log](
	[LogId] [bigint] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[LogTypeId] [int] NOT NULL,
	[Message] [varchar](max) NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[IsFailure] [bit] NOT NULL,
 CONSTRAINT [PK_Log] PRIMARY KEY CLUSTERED 
(
	[LogId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [ctl].[LogType]    Script Date: 4/04/2023 9:12:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ctl].[LogType](
	[LogTypeId] [int] NOT NULL,
	[LogTypeDesc] [varchar](50) NOT NULL,
 CONSTRAINT [PK_LogType] PRIMARY KEY CLUSTERED 
(
	[LogTypeId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [ctl].[SourceObject]    Script Date: 4/04/2023 9:12:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ctl].[SourceObject](
	[SourceObjectId] [int] IDENTITY(1,1) NOT NULL,
	[SourceObjectName] [varchar](8000) NOT NULL,
	[SourceObjectGroupId] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_SourceObject] PRIMARY KEY CLUSTERED 
(
	[SourceObjectId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [ctl].[SourceObjectGroup]    Script Date: 4/04/2023 9:12:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ctl].[SourceObjectGroup](
	[SourceObjectGroupId] [int] IDENTITY(1,1) NOT NULL,
	[SourceObjectGroupName] [varchar](8000) NOT NULL,
 CONSTRAINT [PK_SourceObjectGroup] PRIMARY KEY CLUSTERED 
(
	[SourceObjectGroupId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [ctl].[User]    Script Date: 4/04/2023 9:12:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ctl].[User](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](200) NOT NULL,
	[LastName] [varchar](200) NOT NULL,
	[EmailAddress] [varchar](200) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[EncryptedUserAPIKey] [varbinary](max) NOT NULL,
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [ctl].[UserSourceObject]    Script Date: 4/04/2023 9:12:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ctl].[UserSourceObject](
	[UserSourceObjectId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[SourceObjectId] [int] NOT NULL,
 CONSTRAINT [PK_UserSourceObject] PRIMARY KEY CLUSTERED 
(
	[UserSourceObjectId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO