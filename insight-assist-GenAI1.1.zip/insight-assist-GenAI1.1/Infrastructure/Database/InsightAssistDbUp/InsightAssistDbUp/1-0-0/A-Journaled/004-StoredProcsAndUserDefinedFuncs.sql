/****** Object:  StoredProcedure [dbo].[CreateAPIUser]    Script Date: 4/04/2023 9:12:55 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CreateAPIUser]
@Username as varchar(200),
@Password as varchar(200)

AS
BEGIN

	SET NOCOUNT ON;

	set @Password = replace(@Password,',','')
	set @Password = replace(@Password,'''','')
	set @Password = replace(@Password,';','')

 declare @EncryptedPassword as varbinary(max)
 set @EncryptedPassword = HASHBYTES('SHA2_256', @Password)

    insert into [ctl].[APIUser]
	([UserName], [EncryptedPassword],[FailedLoginAttempCount] ,[IsActive])
	values
	(@UserName, @EncryptedPassword, 0,1)


	select @Password

END
GO
/****** Object:  StoredProcedure [dbo].[CreateUser]    Script Date: 4/04/2023 9:12:55 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CreateUser]
@Name as varchar(200),
@LastName as varchar(200),
@EmailAddress as varchar(200),
@UserAPIKey as varchar(100)
AS
BEGIN

	SET NOCOUNT ON;

    set @UserAPIKey = replace(@UserAPIKey,',','')
	set @UserAPIKey = replace(@UserAPIKey,'''','')
	set @UserAPIKey = replace(@UserAPIKey,';','')

 declare @EncryptedUserAPIKey as varbinary(max)
 set @EncryptedUserAPIKey = HASHBYTES('SHA2_256', @UserAPIKey)

    insert into [ctl].[User]
	([Name], [LastName], [EmailAddress],[IsActive],[CreateDate],[EncryptedUserAPIKey])
	values
	(@Name, @LastName, lower(@EmailAddress),1,getdate(),@EncryptedUserAPIKey)

	select @UserAPIKey
END
GO
