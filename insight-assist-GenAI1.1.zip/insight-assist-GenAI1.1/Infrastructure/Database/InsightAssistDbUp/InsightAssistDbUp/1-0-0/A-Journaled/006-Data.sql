INSERT [ctl].[ChatType] ([ChatTypeId], [ChatTypeName], [ImageRef], [IsActive]) VALUES (1, N'Data Lake', N'/assets/images/Datalake.png', 1)
GO
INSERT [ctl].[ChatType] ([ChatTypeId], [ChatTypeName], [ImageRef], [IsActive]) VALUES (2, N'Document Search', N'/assets/images/Search.png', 1)
GO
INSERT [ctl].[ChatType] ([ChatTypeId], [ChatTypeName], [ImageRef], [IsActive]) VALUES (3, N'Document Comparison', N'/assets/images/Document.png', 1)
GO
INSERT [ctl].[ChatType] ([ChatTypeId], [ChatTypeName], [ImageRef], [IsActive]) VALUES (4, N'Summary', N'/assets/images/Summary.png', 1)
GO


SET IDENTITY_INSERT [ctl].[SourceObjectGroup] ON 
GO
INSERT [ctl].[SourceObjectGroup] ([SourceObjectGroupId], [SourceObjectGroupName]) VALUES (1, N'General')
GO
SET IDENTITY_INSERT [ctl].[SourceObjectGroup] OFF
GO

ALTER TABLE [ctl].[Log] ADD  CONSTRAINT [DF_Log_CreateDate]  DEFAULT (getdate()) FOR [CreateDate]
GO
ALTER TABLE [ctl].[User] ADD  CONSTRAINT [DF_User_CreateDate]  DEFAULT (getdate()) FOR [CreateDate]
GO
ALTER TABLE [ctl].[ChatHistory]  WITH CHECK ADD  CONSTRAINT [FK_ChatHistory_ChatType] FOREIGN KEY([ChatTypeId])
REFERENCES [ctl].[ChatType] ([ChatTypeId])
GO
ALTER TABLE [ctl].[ChatHistory] CHECK CONSTRAINT [FK_ChatHistory_ChatType]
GO
ALTER TABLE [ctl].[ChatHistory]  WITH CHECK ADD  CONSTRAINT [FK_ChatHistory_User1] FOREIGN KEY([UserId])
REFERENCES [ctl].[User] ([UserId])
GO
ALTER TABLE [ctl].[ChatHistory] CHECK CONSTRAINT [FK_ChatHistory_User1]
GO
ALTER TABLE [ctl].[Log]  WITH CHECK ADD  CONSTRAINT [FK_Log_LogType] FOREIGN KEY([LogTypeId])
REFERENCES [ctl].[LogType] ([LogTypeId])
GO
ALTER TABLE [ctl].[Log] CHECK CONSTRAINT [FK_Log_LogType]
GO
ALTER TABLE [ctl].[Log]  WITH CHECK ADD  CONSTRAINT [FK_Log_User] FOREIGN KEY([UserId])
REFERENCES [ctl].[User] ([UserId])
GO
ALTER TABLE [ctl].[Log] CHECK CONSTRAINT [FK_Log_User]
GO
ALTER TABLE [ctl].[LogType]  WITH CHECK ADD  CONSTRAINT [FK_LogType_LogType] FOREIGN KEY([LogTypeId])
REFERENCES [ctl].[LogType] ([LogTypeId])
GO
ALTER TABLE [ctl].[LogType] CHECK CONSTRAINT [FK_LogType_LogType]
GO
ALTER TABLE [ctl].[SourceObject]  WITH CHECK ADD  CONSTRAINT [FK_SourceObject_SourceObjectGroup] FOREIGN KEY([SourceObjectGroupId])
REFERENCES [ctl].[SourceObjectGroup] ([SourceObjectGroupId])
GO
ALTER TABLE [ctl].[SourceObject] CHECK CONSTRAINT [FK_SourceObject_SourceObjectGroup]
GO
ALTER TABLE [ctl].[UserSourceObject]  WITH CHECK ADD  CONSTRAINT [FK_UserSourceObject_SourceObject] FOREIGN KEY([SourceObjectId])
REFERENCES [ctl].[SourceObject] ([SourceObjectId])
GO
ALTER TABLE [ctl].[UserSourceObject] CHECK CONSTRAINT [FK_UserSourceObject_SourceObject]
GO
ALTER TABLE [ctl].[UserSourceObject]  WITH CHECK ADD  CONSTRAINT [FK_UserSourceObject_User] FOREIGN KEY([UserId])
REFERENCES [ctl].[User] ([UserId])
GO
ALTER TABLE [ctl].[UserSourceObject] CHECK CONSTRAINT [FK_UserSourceObject_User]
GO
