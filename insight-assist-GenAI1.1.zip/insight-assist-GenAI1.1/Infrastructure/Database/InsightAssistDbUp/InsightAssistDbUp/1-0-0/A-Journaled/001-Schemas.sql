/****** Object:  Schema [ctl]    Script Date: 20/03/2023 8:10:17 AM ******/
CREATE SCHEMA [ctl]
GO
