﻿CREATE TABLE [dbo].[GroupRoles] (
    [GroupId] INT NOT NULL,
    [RoleId]  INT NOT NULL,
    PRIMARY KEY CLUSTERED ([GroupId] ASC, [RoleId] ASC),
    FOREIGN KEY ([GroupId]) REFERENCES [dbo].[Group] ([GroupId]),
    FOREIGN KEY ([RoleId]) REFERENCES [ctl].[Roles] ([RoleId])
);

