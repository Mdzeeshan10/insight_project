﻿CREATE TABLE [dbo].[AzureSearch] (
    [AzureSearchID] INT           IDENTITY (1, 1) NOT NULL,
    [SearchURL]     VARCHAR (255) NOT NULL,
    [AzureKey]      VARCHAR (255) NOT NULL,
    PRIMARY KEY CLUSTERED ([AzureSearchID] ASC)
);

