﻿CREATE TABLE [dbo].[Group] (
    [GroupId]       INT            IDENTITY (1, 1) NOT NULL,
    [GroupName]     VARCHAR (255)  NOT NULL,
    [isActive]      BIT            NOT NULL,
    [Model_Control] BIT            NOT NULL,
    [ObjectId]      NVARCHAR (255) NULL,
    PRIMARY KEY CLUSTERED ([GroupId] ASC)
);





