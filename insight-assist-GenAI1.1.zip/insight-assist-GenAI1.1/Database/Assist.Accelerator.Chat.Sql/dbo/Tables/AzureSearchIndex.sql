﻿CREATE TABLE [dbo].[AzureSearchIndex] (
    [IndexID]       INT           IDENTITY (1, 1) NOT NULL,
    [IndexName]     VARCHAR (255) NOT NULL,
    [SemanticName]  VARCHAR (255) NULL,
    [AzureSearchID] INT           NOT NULL,
    [isActive]      BIT           CONSTRAINT [DF__AzureSear__isAct__6AEFE058] DEFAULT ((0)) NOT NULL,
    [DisplayName]   VARCHAR (255) NULL,
    PRIMARY KEY CLUSTERED ([IndexID] ASC),
    FOREIGN KEY ([AzureSearchID]) REFERENCES [dbo].[AzureSearch] ([AzureSearchID])
);

