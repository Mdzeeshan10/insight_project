﻿CREATE TABLE [ctl].[UserRoles]
(
	[UserId] INT NOT NULL,
	[RoleId] INT NOT NULL,
	PRIMARY KEY([UserId],[RoleId]),
	FOREIGN KEY([UserId]) REFERENCES [ctl].[User](UserId),
	FOREIGN KEY([RoleId]) REFERENCES [ctl].[Roles](RoleId)
)
