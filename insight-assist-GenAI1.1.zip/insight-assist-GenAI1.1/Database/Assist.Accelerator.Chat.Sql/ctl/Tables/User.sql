﻿/****** Object:  Table [ctl].[User]    Script Date: 5/18/2023 9:43:32 PM ******/

CREATE TABLE [ctl].[User] (
    [UserId]              INT           IDENTITY (1, 1) NOT NULL,
    [Name]                VARCHAR (200) NOT NULL,
    [LastName]            VARCHAR (200) NOT NULL,
    [EmailAddress]        VARCHAR (200) NOT NULL,
    [IsActive]            BIT           NOT NULL,
    [CreateDate]          DATETIME      CONSTRAINT [DF_User_CreateDate] DEFAULT (getdate()) NOT NULL,
    [EncryptedUserAPIKey] VARCHAR (200) NULL,
    [model_control]       BIT           NULL,
    CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED ([UserId] ASC)
);


GO

GO
