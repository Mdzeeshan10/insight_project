﻿CREATE TABLE [ctl].[Quotas]
(
	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[UserId] INT NULL,
	[TeamId] INT NULL,
	[CostLimit] BIGINT NOT NULL,
	[Period] [varchar](200) NOT NULL,
	[CostUsed] BIGINT NOT NULL,
	[ConversationCount] INT NOT NULL,
	[CompletionTokenCount] INT NOT NULL,
	[PromptTokenCount] INT NOT NULL,
)
