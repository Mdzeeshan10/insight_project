﻿CREATE TABLE [ctl].[Copilots]
(
	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[SystemName] [varchar](max) NOT NULL,
	[DisplayName] [varchar](max) NOT NULL,
	[Description] [varchar](max) NOT NULL,
	[IntroMessage] [varchar](max) NOT NULL,
	[IsActive] BIT NOT NULL,
	[FileTypes] [varchar](max) NOT NULL DEFAULT ''
)
