﻿CREATE TABLE [ctl].[UserBusinessLines]
(
	[UserId] INT NOT NULL,
    [LobId] INT NOT NULL,
    PRIMARY KEY([UserId], [LobId]),
    FOREIGN KEY([UserId]) REFERENCES [ctl].[User]([UserId]),
    FOREIGN KEY([LobId]) REFERENCES [ctl].[BusinessLines]([LobId])
)
