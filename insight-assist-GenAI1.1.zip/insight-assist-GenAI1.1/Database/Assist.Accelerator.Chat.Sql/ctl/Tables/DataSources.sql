﻿CREATE TABLE [ctl].[DataSources]
(
	[SourceId] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[SourceName] NVARCHAR(64) NOT NULL,
	[Connection] NVARCHAR(255) NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[SourceDescription] NVARCHAR(255)
)
