﻿CREATE TABLE [ctl].[QuotaTemplates]
(
	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] [varchar](200) NOT NULL,
	[CostLimit] BIGINT NOT NULL
)
