﻿CREATE TABLE [ctl].[AvailableModels]
(
	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Provider] INT NULL,
	[DeploymentName] [varchar](200) NOT NULL,
	[ModelType] [varchar](200) NULL,
	[ModelVersion] [varchar](200) NULL,
	[CostPerPromptToken] INT NOT NULL,
	[CostPerCompletionToken] INT NOT NULL,
	[CostUnit] INT NULL,
	[CredentialPath] [varchar](200) NULL,
	[IsActive] BIT NULL,
	[Purpose] INT NOT NULL DEFAULT 0
)
