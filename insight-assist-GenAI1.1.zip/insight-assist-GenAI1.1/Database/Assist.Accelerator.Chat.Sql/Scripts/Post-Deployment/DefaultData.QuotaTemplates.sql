﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
BEGIN
    IF NOT EXISTS (SELECT * FROM [ctl].[QuotaTemplates]
                   WHERE Id = 1)
        BEGIN
            INSERT INTO [ctl].[QuotaTemplates]  (Name, CostLimit)
            VALUES ('Default', 2000000000)
        END
END

BEGIN
    IF NOT EXISTS (SELECT * FROM [ctl].[QuotaTemplates]
                   WHERE Id = 2)
        BEGIN
            INSERT INTO [ctl].[QuotaTemplates]  (Name, CostLimit)
            VALUES ('Org Limit', 100000000000)
        END
END