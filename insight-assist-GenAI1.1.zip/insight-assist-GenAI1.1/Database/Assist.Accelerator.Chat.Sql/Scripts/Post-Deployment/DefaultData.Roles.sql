﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

BEGIN
    IF NOT EXISTS (SELECT * FROM [ctl].[Roles] 
                   WHERE RoleName = 'Admin')
    BEGIN
        INSERT INTO [ctl].[Roles]  (RoleName, RoleDescription)
        VALUES ('Admin', 'Controls all aspects of the application')
    END
END
BEGIN
    IF NOT EXISTS (SELECT * FROM [ctl].[Roles] 
                   WHERE RoleName = 'User')
    BEGIN
        INSERT INTO [ctl].[Roles]  (RoleName, RoleDescription)
        VALUES ('User', 'Chat access only')
    END
END
