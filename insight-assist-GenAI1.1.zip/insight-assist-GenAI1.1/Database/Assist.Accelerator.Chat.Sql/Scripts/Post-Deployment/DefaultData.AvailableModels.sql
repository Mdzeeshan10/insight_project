﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
BEGIN
    IF NOT EXISTS (SELECT * FROM [ctl].[AvailableModels]
                   WHERE DeploymentName = 'gpt4')
        BEGIN
            INSERT INTO [ctl].[AvailableModels]  (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, Purpose, IsActive)
            VALUES (1, 'gpt4','gpt-4', '0314', 3000, 6000, 1, 'OpenAI', 0, 0)
        END
END

BEGIN
    IF NOT EXISTS (SELECT * FROM [ctl].[AvailableModels]
                   WHERE DeploymentName = 'gpt35')
        BEGIN
            INSERT INTO [ctl].[AvailableModels]  (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, Purpose, IsActive)
            VALUES (1, 'gpt35','gpt-35-turbo', '0301', 150, 200, 1, 'OpenAI', 0, 1)
        END
END

BEGIN
    IF NOT EXISTS (SELECT * FROM [ctl].[AvailableModels]
                   WHERE DeploymentName = 'ada-embedding')
        BEGIN
            INSERT INTO [ctl].[AvailableModels]  (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, Purpose, IsActive)
            VALUES (1, 'ada-embedding','text-embedding-ada-002', '2', 10, 10, 0, 'OpenAI', 1, 1)
        END
END

-- BEGIN
--     IF NOT EXISTS (SELECT * FROM [ctl].[AvailableModels]
--                    WHERE DeploymentName = 'chat-bison@001')
--         BEGIN
--             INSERT INTO [ctl].[AvailableModels]  (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, Purpose, IsActive)
--             VALUES (2, 'chat-bison@001','chat-bison', '2', 50, 50, 1, 'VertexAI', 0, 0)
--         END
-- END

-- BEGIN
--     IF NOT EXISTS (SELECT * FROM [ctl].[AvailableModels]
--                    WHERE DeploymentName = 'textembedding-gecko@001')
--         BEGIN
--             INSERT INTO [ctl].[AvailableModels]  (Provider, DeploymentName, ModelType, ModelVersion, CostPerPromptToken, CostPerCompletionToken, CostUnit, CredentialPath, Purpose, IsActive)
--             VALUES (2, 'textembedding-gecko@001','textembedding-gecko', '2', 10, 0, 1, 'VertexAI', 1, 0)
--         END
-- END