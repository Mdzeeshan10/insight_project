import { NgModule, isDevMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Overlay } from '@angular/cdk/overlay';
// search module
import { Ng2SearchPipeModule } from 'ng2-search-filter';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { PagesModule } from './pages/pages.module';

// Auth
import {
  HttpClientModule,
  HttpClient,
  HTTP_INTERCEPTORS,
} from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { environment } from '../environments/environment';

// Language
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';

// MSAL v2
import {
  MsalModule,
  MsalRedirectComponent,
  MsalGuard,
  MsalInterceptor,
} from '@azure/msal-angular';
import { PublicClientApplication, InteractionType } from '@azure/msal-browser';
import { StoreModule } from '@ngrx/store';
// import { reducers, metaReducers } from './reducers';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { CoreModule } from './core/core.module';
import { chatReducer } from './core/store/chat.reducer';
import { ErrorHandler } from '@angular/core';
import { GlobalErrorHandlerService } from './global-error-handler.service';
import { ToastrModule } from 'ngx-toastr';
import { ToastService } from './toast.service';
import { LoadingInterceptorService } from './loadingInterceptor.service';
import { AdminGuard } from './guards/admin.guard';
import {
  MAT_AUTOCOMPLETE_SCROLL_STRATEGY,
  MAT_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY,
} from '@angular/material/autocomplete';
import {
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
} from '@angular/material/select';
import { COMMA, SPACE } from '@angular/cdk/keycodes';
import { MAT_CHIPS_DEFAULT_OPTIONS } from '@angular/material/chips';
import { SpinnerComponent } from './spinner/spinner.component';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';

export function createTranslateLoader(http: HttpClient): any {
  return new TranslateHttpLoader(http, 'assets/i18n/', '.json');
}

@NgModule({
  declarations: [AppComponent, SpinnerComponent],
  imports: [
    CoreModule,
    TranslateModule.forRoot({
      defaultLanguage: 'en',
      loader: {
        provide: TranslateLoader,
        useFactory: createTranslateLoader,
        deps: [HttpClient],
      },
    }),
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    PagesModule,
    NgxPaginationModule,
    NgbModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    Ng2SearchPipeModule,
    MsalModule.forRoot(
      new PublicClientApplication({
        auth: {
          clientId: `${environment.aadConfig.clientId}`,
          authority: `https://login.microsoftonline.com/${environment.aadConfig.tenantId}`,
          redirectUri: location.origin,
          postLogoutRedirectUri: location.origin,
        },
        cache: {
          cacheLocation: 'localStorage',
          storeAuthStateInCookie: false,
        },
      }),
      {
        // MSALv2 Guard Configuration
        interactionType: InteractionType.Redirect,
        authRequest: {
          scopes: ['user.read'],
        },
      },
      {
        // MSALv2 Interceptor Configuration
        interactionType: InteractionType.Redirect,
        protectedResourceMap: new Map([
          ['https://graph.microsoft.com/v1.0/me', ['user.read']],
          [
            `${environment.aadConfig.apiBase}`,
            [`api://${environment.aadConfig.clientId}/access_as_user`],
          ],
        ]),
      }
    ),
    StoreModule.forRoot({ chat: chatReducer }),
    // StoreModule.forRoot({layout: layoutReducer}, {}),
    // StoreModule.forRoot(reducers, {
    //   metaReducers
    // }),
    StoreDevtoolsModule.instrument({ maxAge: 25, logOnly: !isDevMode() }),
  ],
  providers: [
    GlobalErrorHandlerService,
    SpinnerComponent,
    LoadingInterceptorService,
    { provide: ErrorHandler, useClass: GlobalErrorHandlerService },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoadingInterceptorService,
      multi: true,
    },
    MsalGuard,
    ToastService,
    AdminGuard,

    {
      provide: MAT_AUTOCOMPLETE_SCROLL_STRATEGY,
      useFactory: MAT_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY,
      deps: [Overlay],
    },
    {
      provide: MAT_SELECT_SCROLL_STRATEGY,
      useFactory: MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
      deps: [Overlay],
    },
    {
      provide: MAT_CHIPS_DEFAULT_OPTIONS,
      useValue: {
        separatorKeyCodes: [COMMA, SPACE],
      },
    },
  ],
  bootstrap: [AppComponent, MsalRedirectComponent],
})
export class AppModule {}
