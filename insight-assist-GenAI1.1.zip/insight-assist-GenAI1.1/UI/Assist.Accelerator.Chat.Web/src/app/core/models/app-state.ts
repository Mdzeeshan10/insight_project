import { ChatState } from '../store/chat-state';

export interface AppState {
  chat: ChatState;
}
