export interface ChatHistory {
  id: string;
  title: string;
  messages: any[];
  copilotId?: number;
  indexId?: number;
}
