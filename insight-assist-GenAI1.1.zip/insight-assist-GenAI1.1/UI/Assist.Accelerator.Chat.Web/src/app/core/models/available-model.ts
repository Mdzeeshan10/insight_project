export interface AvailableModel {
  id: number;
  deploymentName: string;
  modelType: string;
  modelVersion: string;
  costPerPromptToken: number;
  costPerCompletionToken: number;
  costUnit: number;
  isActive: boolean;
}
