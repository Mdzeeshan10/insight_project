import { MessageChunk } from "src/app/pages/apps/chat/chat.model";

export interface ChatStateMessage {
  id: string;
  from: string;
  text: string;
  time: string;
  chunks: MessageChunk[];
  file?: string;
  copilotId?: number;
  streaming?: boolean;
}
