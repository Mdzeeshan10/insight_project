export interface Copilot {
  id: number;
  name: string;
  description: string;
  introMessage: string;
  fileTypes: string;
}