import { createReducer, on } from '@ngrx/store';
import {
  showSidebar,
  hideSidebar,
  MessageActions,
  startTyping,
  endTyping,
  toggleMoblieMenu,
  hideSplashScreen,
  newChat,
  updateSeletedPeriod,
  showSplashScreen,
} from './chat.actons';
import { ChatState } from './chat-state';
import { ChatStateMessage } from '../models/chat-message';
import { ChatHistory } from '../models/chat-history';

export const chatFeatureKey = 'chat';

var initalChatMessage: ChatStateMessage = {
  id:'',
  from: 'OpenAI',
  text: `Welcome to Insight Lens for GenAI. How can I help you?`,
  time: '',
  chunks: [],
};
var chatHistory: ChatHistory = {
  id: '',
  title: '',
  messages: [],
  indexId: 0
};

export const initalChatState: ChatState = {
  sidebar: true,
  chatId: '',
  chatMessages: [initalChatMessage],
  typing: false,
  chatStreamingResponse: '',
  chatHistory: [],
  user: { name: '', imageUrl: '' },
  userRoles: [],
  splashScreen: false,
  moblieMenu: false,
  quota: null,
  deployment: null,
  availableModels: null,
  adminStats: null,
  adminTopUsers: null,
  adminGraph: null,
  selectedKpi: null,
  selectedKpiRange: null,
  selectedPeriod: null,
  selectedPeriodRange: [],
  selectedChatHistory: chatHistory,
  copilots: [],
  attachedFiles: [],
  replaceMessages: initalChatMessage,
};
export const messages: any[] = [];

export const chatReducer = createReducer(
  initalChatState,
  on(newChat, (state) => { 
    return {
      ...state,
      chatMessages: [initalChatMessage],
      splashScreen: true,
      chatId: '', // make sure this is a new conversation
      selectedChatHistory: chatHistory
    }
  }),
  on(MessageActions.newChatWithCopilot, (state, props) => {
    return {
      ...state,
      chatMessages: [initalChatMessage],
      splashScreen: true,
      chatId: '', // make sure this is a new conversation
      selectedChatHistory: {
        ...chatHistory,
        copilotId: props.copilotId
      }
    }
  }),
  on(showSidebar, (state) => ({ ...state, sidebar: true })),
  on(hideSidebar, (state) => ({ ...state, sidebar: false })),
  on(toggleMoblieMenu, (state) => ({
    ...state,
    moblieMenu: !state.moblieMenu,
  })),
  on(hideSplashScreen, (state) => ({ ...state, splashScreen: false })),
  on(showSplashScreen, (state) => ({ ...state, splashScreen: true })),
  on(startTyping, (state: ChatState) => ({ ...state, typing: true })),
  on(endTyping, (state: ChatState) => ({ ...state, typing: false })),
  on(MessageActions.addResponseStream, (state, props) => ({
    ...state,
    chatStreamingResponse: props.message,  
  })),
  on(MessageActions.addMessage, (state, props) => ({
    ...state,
    chatMessages: state.chatMessages.length > 0 && state.chatMessages[state.chatMessages.length-1].streaming ?
      [...state.chatMessages.slice(0, -1), {...state.chatMessages.slice(0, -1)[0], ...props.message}] :
      [...state.chatMessages, props.message],
    splashScreen: false,
  })),
  on(MessageActions.replaceMessages, (state, props) => ({
    ...state,
    chatMessages: [props.message],
    splashScreen: false,
  })),
  on(MessageActions.addId, (state, props) => ({
    ...state,
    chatId: props.id,
  })),
  on(MessageActions.loadHistory, (state, props) => ({
    ...state,
    chatHistory: props.chatHitory,
  })),
  on(MessageActions.selectHistory, (state, props) => {
    var chatHistoryMessages: ChatStateMessage[] = state.chatHistory.find(
      (v) => v.id == props.id
    )!.messages;
    return {
      ...state,
      chatMessages: chatHistoryMessages,
      splashScreen: false,
      moblieMenu: false,
    };
  }),
  on(MessageActions.addUser, (state, props) => ({
    ...state,
    user: props.user,
  })),
  on(MessageActions.addUserRoles, (state, props) => ({
    ...state,
    userRoles: props.roles,
  })),
  on(MessageActions.updateQuota, (state, props) => ({
    ...state,
    quota: props.quota,
  })),
  on(MessageActions.loadAdminStats, (state, props) => ({
    ...state,
    adminStats: props.stats,
    deployment: props.deployment,
    availableModels: props.availableModels
  })),
  on(MessageActions.loadAdminTopUsers, (state, props) => ({
    ...state,
    adminTopUsers: props.adminTopUsers
  })),
  on(MessageActions.loadAdminGraph, (state, props) => ({
    ...state,
    adminGraph: props.adminGraph
  })),
  on(MessageActions.selectKpi, (state, props) => ({
    ...state,
    selectedKpi: props.id
  })),
  on(MessageActions.selectKpiRange, (state, props) => ({
    ...state,
    selectedKpiRange: props.id
  })),
  on(MessageActions.selectPeriod, (state, props) => ({
    ...state,
    selectedPeriod: props.period
  })),
  on(MessageActions.selectPeriodRange, (state, props) => ({
    ...state,
    selectedPeriodRange: [props.startDate, props.endDate]
  })),
  on(MessageActions.setSelectedChatHistory, (state, props) => ({
    ...state,
    selectedChatHistory: props.history
  })),
  on(MessageActions.setChatIndex, (state, props) => {
    var selectedChatHistory = {...state.selectedChatHistory};
    selectedChatHistory.indexId = props.indexId;

    var allChatHistories = [...state.chatHistory];
    var index = -1;
    allChatHistories.find((h, i) => {
      if (h.id === selectedChatHistory.id) index = i;
    });
    allChatHistories[index] = selectedChatHistory;

    return {
      ...state,
      selectedChatHistory: selectedChatHistory,
      chatHistory: allChatHistories
    }
  }),
  on(updateSeletedPeriod, (state, props) => ({
    ...state,
    selectedPeriod: props.selectedPeriod
  })),
  on(MessageActions.getCopilots, (state, props) => ({
    ...state,
    copilots: props.copilots
  })),
  on(MessageActions.addAttachedFiles, (state, props) => ({
    ...state,
    attachedFiles: state.attachedFiles.concat(props.attachedFiles)
  })),
  on(MessageActions.removeAttachedFiles, (state, props) => ({
    ...state,
    attachedFiles: state.attachedFiles.filter(stateFile => 
      !props.attachedFiles
        .map(propFile => propFile.name)
        .includes(stateFile.name)
    )
  }))
);
