import { TestBed } from '@angular/core/testing';

import { ChatStateService } from './chat-state.service';
import { BehaviorSubject, of } from 'rxjs';
import { ChatStreamingService } from '../services/chat-streaming.service';
import { ToastService } from 'src/app/toast.service';

describe('ChatSateService', () => {
  let service: ChatStateService;
  let mockStreamingService: ChatStreamingService;
  let mockStore: any;
  let mockChatApiService: any;
  let mockMessageParserService: any;
  let mockUserProfileService: any;
  let mockStatsApiService: any;
  let mockRouter: any;
  let mockToaster: ToastService;

  mockStore = {
    select: jasmine.createSpy().and.returnValue(of({})),
    dispatch: jasmine.createSpy(),
    pipe: jasmine.createSpy().and.returnValue(of('success')),
  };

  beforeEach(() => {
    service = new ChatStateService(
      mockStore,
      mockChatApiService,
      mockStreamingService,
      mockMessageParserService,
      mockUserProfileService,
      mockStatsApiService,
      mockRouter,
      mockToaster
    );
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
