import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { ChatState } from './chat-state';
import { Subject } from 'rxjs';
import {
  MessageActions,
  endTyping,
  hideSplashScreen,
  newChat,
  showSidebar,
  showSplashScreen,
  startTyping,
  toggleMoblieMenu,
} from './chat.actons';
import {
  selectChatId,
  selectHistory,
  selectMessages,
  selectMoblieMenu,
  selectSidebar,
  selectSplashScreen,
  selectTyping,
  selectStreamingResponse,
  selectUser,
  selectUserRoles,
  selectAdminStats,
  selectQuota,
  selectDeployment,
  selectAdminTopUsers,
  selectAdminGraph,
  selectKpi,
  selectPeriod,
  selectAvailableModels,
  selectedChatHistory,
  getCopilots,
  getAttachedFiles
} from './chat.selector';
import { Router } from '@angular/router';
import { Observable, map, take, tap } from 'rxjs';
import { ChatApiService } from '../services/chat-api.service';
import { ChatStreamingService } from '../services/chat-streaming.service';
import { ChatStateMessage } from '../models/chat-message';
import { MessageParserService } from '../services/message-parser.service';
import { UserProfileService } from '../services/user.service';
import { User } from '../models/user';
import { StatsApiService } from '../services/stats.service';
import { ChatHistory } from '../models/chat-history';
import { error } from 'console';
import { ToastService } from 'src/app/toast.service';
import { AvailableModel } from '../models/available-model';
//import { ChatMessage } from 'src/app/pages/apps/chat/chat.model';

@Injectable({
  providedIn: 'root',
})
export class ChatStateService {
  checkedItemData: any;
  private activeConversationId: string = '';
  private selectedKpi: number = 4;
  private selectedKpiRange: number = 4;
  private selectedPeriod: string = '';
  private selectedModel: AvailableModel | null = null;
  private selectedKnowledgeBase: any = 0;
  private isAiRespondingSubject = new Subject<boolean>();
  isAiResponding$ = this.isAiRespondingSubject.asObservable();

  constructor(
    private store: Store<{ chat: ChatState }>,
    private chatApiService: ChatApiService,
    private chatStreamingService: ChatStreamingService,
    private messageParserService: MessageParserService,
    private userProfileService: UserProfileService,
    private statsApiService: StatsApiService,
    private router: Router,
    private toaster: ToastService
  ) {
    this.ChatId$.subscribe((conversationId) => {
      this.activeConversationId = conversationId;
    });

    // log user details until roles are fully implemented
    this.User$.subscribe((profile) => {
      console.log(profile);
    });
    this.UserRoles$.subscribe((roles) => {
      console.log(roles);
    });
  }

  ChatId$ = this.store.select(selectChatId);
  Messages$ = this.store.select(selectMessages);
  History$ = this.store.select(selectHistory);
  Typing$ = this.store.select(selectTyping);
  ResponseStream$ = this.store.select(selectStreamingResponse);
  User$ = this.store.select(selectUser);
  UserRoles$ = this.store.select(selectUserRoles);
  Sidebar$ = this.store.select(selectSidebar);
  moblieMenu$ = this.store.select(selectMoblieMenu);
  SplashScreen$ = this.store.select(selectSplashScreen);
  Quota$ = this.store.select(selectQuota);
  Deployment$ = this.store.select(selectDeployment);
  AvailableModels$ = this.store.select(selectAvailableModels);
  AdminStats$ = this.store.select(selectAdminStats);
  AdminTopUsers$ = this.store.select(selectAdminTopUsers);
  AdminGraph$ = this.store.select(selectAdminGraph);
  SelectedKpi$ = this.store.select(selectKpi);
  SelectedPeriod$ = this.store.select(selectPeriod);
  selectedChathistory$ = this.store.select(selectedChatHistory);
  Copilots$ = this.store.select(getCopilots);
  AttachedFiles$ = this.store.select(getAttachedFiles);

  replaceMessages(message: ChatStateMessage) {
    this.store.dispatch(MessageActions.replaceMessages({ message }));
  }

  addMessage(message: ChatStateMessage) {
    this.store.dispatch(MessageActions.addMessage({ message }));
    this.store.dispatch(startTyping());
    //Clearing out response stream to make sure that typing indicator is shown
    this.store.dispatch(MessageActions.addResponseStream({message:''}));
    this.chatStreamingService.initializeSignalR();

    const chatId = this.activeConversationId;
    this.chatStreamingService.chatMessages$.subscribe((message) => {
      if(message) {
        var formatedStreamingMessage = this.chatApiService.formatStreamingMessage(chatId, message);
        this.store.dispatch(
          MessageActions.addMessage({ message: formatedStreamingMessage })
        );
        this.store.dispatch(MessageActions.addResponseStream({message}));
      }
    });
    var azureSearch = this.selectedKnowledgeBase;
    var modelName = this.selectedModel?.deploymentName ?? '';

    if (this.activeConversationId.length === 0) {
      // new conversation
      this.chatApiService
        .postMegaChat(message.text, message.file, message.copilotId, azureSearch, modelName)
        .subscribe({
          next: (message) => {
            var formatedUserMsg = this.formatUserMessage(message);
            var formatedMessage = this.chatApiService.formatMessage(message);
            this.store.dispatch(
              MessageActions.addMessage({ message: formatedUserMsg })
            );
            this.store.dispatch(
              MessageActions.addMessage({ message: formatedMessage })
            );
            this.store.dispatch(MessageActions.addId({ id: message.id }));
            this.store.dispatch(
              MessageActions.updateQuota({ quota: message.quota })
            );
            this.store.dispatch(MessageActions.setSelectedChatHistory({ history: {
              id: message.id,
              title: message.title,
              messages: message.messages,
              copilotId: message.copilotId,
              indexId: message.indexId
            }}))
            this.store.dispatch(endTyping());
            this.loadChatHistory();
          },
          error: (err) => {
            this.store.dispatch(endTyping());
            this.toaster.showError(err.error.error);
            this.isAiRespondingSubject.next(false);
          },
        });
    } else {
      // extended conversation
      this.chatApiService
        .putMegaChat(
          this.activeConversationId,
          message.text,
          message.file,
          azureSearch,
          modelName
        )
        .subscribe({
          next: (message) => {
            var formatedMessage = this.chatApiService.formatMessage(message);
            this.store.dispatch(
              MessageActions.addMessage({ message: formatedMessage })
            );
            this.store.dispatch(
              MessageActions.updateQuota({ quota: message.quota })
            );
            this.store.dispatch(endTyping());
            this.loadChatHistory();
          },
          error: (err) => {
            this.store.dispatch(endTyping());
            this.toaster.showError(err.error.error);
            this.isAiRespondingSubject.next(false);
          },
        });
    }
  }

  setModel(value: AvailableModel): void {
    this.selectedModel = value;
  }

  setKnowledgeBase(value: number): void {
    this.selectedKnowledgeBase = value;
    this.store.dispatch(MessageActions.setChatIndex({ indexId: value }));
  }

  getActiveConversationId(): string {
    return this.activeConversationId;
  }

  loadAdminStats(period: string) {
    this.statsApiService.getAdminStats(period).subscribe((stats) => {
      stats.AdminStats.monthlyCostUsed = stats.MonthlyCostUsed;
      stats.AdminStats.monthlyCostLimit = stats.MonthlyCostLimit;
      this.store.dispatch(
        MessageActions.loadAdminStats({
          stats: stats.AdminStats,
          deployment: stats.Deployment,
          availableModels: stats.AvailableModels,
        })
      );
    });
  }

  setQuotaLimit(newQuota: number) {
    this.statsApiService.setQuotaLimit(newQuota).subscribe({
      next: (quota) => {
        this.loadAdminStats(this.selectedPeriod);
      },
      error: (err) => {
        this.toaster.showError(err.error);
      }
    });
  }

  selectPeriod(period: string) {
    this.selectedPeriod = period;
    this.loadAdminStats(period);
    this.loadAdminTopUsers(period);
    this.selectKpi(this.selectedKpi);
    this.store.dispatch(
      MessageActions.selectPeriod({
        period: period,
      })
    );
  }

  selectPeriodRange(startDate: string, endDate: string) {
    this.selectedPeriod = startDate;
    this.loadAdminStatsRange(startDate, endDate);
    this.loadAdminTopUsersRange(startDate, endDate);
    this.selectKpiRange(this.selectedKpi, startDate, endDate);
    this.store.dispatch(
      MessageActions.selectPeriodRange({
        startDate: startDate,
        endDate: endDate,
      })
    );
  }
  loadAdminStatsRange(startDate: string, endDate: string) {
    this.statsApiService
      .getAdminStatsRange(startDate, endDate)
      .subscribe((stats) => {
        stats.AdminStats.monthlyCostUsed = stats.MonthlyCostUsed;
        stats.AdminStats.monthlyCostLimit = stats.MonthlyCostLimit;
        this.store.dispatch(
          MessageActions.loadAdminStats({
            stats: stats.AdminStats,
            deployment: stats.Deployment,
            availableModels: stats.AvailableModels,
          })
        );
      });
  }

  getCopilots() {
    this.chatApiService.getCopilots().subscribe((copilots) => {
      this.store.dispatch(
        MessageActions.getCopilots({
          copilots: copilots,
        })
      );
    });
  }

  addAttachedFiles(files: File[]) {
    this.store.dispatch(MessageActions.addAttachedFiles({
      attachedFiles: files
    }))
  }

  removeAttachedFiles(files: File[]) {
    this.store.dispatch(MessageActions.removeAttachedFiles({
      attachedFiles: files
    }))
  }

  loadAdminTopUsersRange(startDate: string, endDate: string) {
    this.statsApiService
      .getTopUsersRange(startDate, endDate)
      .subscribe((topUsers) => {
        this.store.dispatch(
          MessageActions.loadAdminTopUsers({
            adminTopUsers: topUsers,
          })
        );
      });
  }

  loadAdminTopUsers(period: string) {
    this.statsApiService.getTopUsers(period).subscribe((topUsers) => {
      this.store.dispatch(
        MessageActions.loadAdminTopUsers({
          adminTopUsers: topUsers,
        })
      );
    });
  }

  setCurrentModel(modelId: number) {
    this.statsApiService.setCurrentModel(modelId).subscribe(() => {
      this.loadAdminStats(this.selectedPeriod);
    });
  }

  formatUserMessage(message: any): ChatStateMessage {
    var chatMessage: ChatStateMessage = {
      id: message.id,
      from: 'User',
      text: message.messages[0].content,
      time: '',
      chunks: [],
    };
    return chatMessage;
  }

  loadChatHistory() {
    this.chatApiService.getMegaChatHistory().subscribe((history) => {
      var mapped = history
        .map((item: { id: any; title: any; messages: any[], copilotId: any, indexId: number }) => {
          return {
            id: item.id,
            title: item.title,
            messages: this.messageParserService.formatMessages(item.messages, item.id),
            copilotId: item.copilotId,
            indexId: item.indexId
          };
        });
      this.store.dispatch(MessageActions.loadHistory({ chatHitory: mapped }));
    });
  }

  selectChathistory(id: string) {
    this.store.dispatch(MessageActions.selectHistory({ id: id }));
    this.store.dispatch(MessageActions.addId({ id: id }));
    this.router.navigate(['/']);
  }

  selectKpi(index: number) {
    this.selectedKpi = index;
    this.store.dispatch(MessageActions.selectKpi({ id: index }));
    this.statsApiService
      .getHistoricalStats(index, this.selectedPeriod)
      .subscribe((stat) => {
        this.store.dispatch(
          MessageActions.loadAdminGraph({ adminGraph: stat })
        );
      });
  }
  selectKpiRange(index: number, startDate: string, endDate: string) {
    this.selectedKpi = index;
    this.store.dispatch(MessageActions.selectKpi({ id: index }));
    this.statsApiService
      .getHistoricalStatsRange(index, startDate, endDate)
      .subscribe({
        next: (stat) => {
          this.store.dispatch(
            MessageActions.loadAdminGraph({ adminGraph: stat })
          );
        },
        error: (err) => {
          this.toaster.showError(err.error.error);
        }
      })
  }

  deleteChathistoryItem(id: string) {
    this.chatApiService.deleteMegaChatItem(id).subscribe((response) => {
      console.log('item deleted');
      this.loadChatHistory();
    });
  }

  editChatHistoryItem(id: string, value: string) {
    this.chatApiService.renameMegaChat(id, value).subscribe((response) => {
      console.log('edited!');
      this.loadChatHistory();
    });
  }

  loadUser() {
    // use active directory for user identity
    this.userProfileService
      .getGraphProfile()
      .then((profile) => {
        this.userProfileService
          .getGraphAvatar()
          .then((avatar) => {
            var user: User = {
              name: profile.name,
              imageUrl: avatar as string,
            };
            this.store.dispatch(MessageActions.addUser({ user: user }));
          })
          .catch((status) => {
            if (status == 404) {
              console.log(
                'Profile photo for user not found. Update Azure AD. Using default avatar.'
              );
            } else {
              console.log(`Failed to load profile pic with error ${status}`);
            }
          });
      })
      .catch((status) => {
        console.log(`Failed to load user profile with error ${status}`);
      });

    // use the application for user details (e.g. roles and permissions)
    this.userProfileService.getUserDetails().then((details) => {
      this.store.dispatch(
        MessageActions.addUserRoles({ roles: details.roles })
      );
    });
  }

  toggleSidebar() {
    this.store.dispatch(toggleMoblieMenu());
  }

  hideSplashScreen() {
    this.store.dispatch(hideSplashScreen());
  }

  showSplashScreen() {
    this.store.dispatch(showSplashScreen());
  }

  newChat() {
    this.store.dispatch(newChat());
    this.router.navigate(['/']);
  }

  newChatWithCopilot(copilotId: number) {
    this.store.dispatch(MessageActions.newChatWithCopilot({copilotId}));
    this.router.navigate(['/']);
  }

  setSelectedChatHistory(history: ChatHistory) {
    this.store.dispatch(
      MessageActions.setSelectedChatHistory({ history: {
        ...history,
        indexId: history.indexId ?? 0
      } })
    );
  }
}
