import {
  HttpClient,
  HttpContext,
  HttpContextToken,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ChatState } from '../store/chat-state';
import { ChatStateMessage } from '../models/chat-message';
import { DatePipe } from '@angular/common';
import { MessageParserService } from './message-parser.service';
import { noSpinnerToken } from 'src/app/loadingInterceptor.service';

const headers = new HttpHeaders({ 'Content-Type': 'application/json' }); // auth will be injected by MSALv2
const context = new HttpContext().set(noSpinnerToken, true); // Include in HttpOptions when spinner shouldn't be shown

@Injectable({
  providedIn: 'root',
})
export class ChatApiService {
  constructor(
    private http: HttpClient,
    private datePipe: DatePipe,
    private messageParserService: MessageParserService
  ) {}

  getDropDownData(): Observable<any> {
    return this.http.get<any[]>(
      environment.usersApi + '/GetActiveKnowledgeBases'
    );
  }

  getModelData(): Observable<any> {
    return this.http.get<any[]>(environment.statsApi + '/Models');
  }

  formatMessage(message: any): ChatStateMessage {
    var chatMessage: ChatStateMessage = {
      id: message.id,
      from: 'OpenAI',
      text: message.messages[message.messages.length - 1].content, //message.title,
      time: this.datePipe.transform(new Date(), 'h:mm a')!,
      chunks: this.messageParserService.chunkMessage(
        message.messages[message.messages.length - 1].content
      ),
      file: message.file,
      copilotId: message.copilotId,
      streaming: false,
    };
    return chatMessage;
  }

  formatStreamingMessage(id: string, message: string): ChatStateMessage {
    var chatMessage: ChatStateMessage = {
      id: id,
      from: 'OpenAI',
      text: message,
      time: this.datePipe.transform(new Date(), 'h:mm a')!,
      chunks: this.messageParserService.chunkMessage(message),
      streaming: true,
    };
    return chatMessage;
  }

  postMegaChat(
    userMessage: string,
    fileName?: string,
    copilotId?: number,
    indexId?: number,
    modelName?: string
  ): Observable<any> {
    var url = environment.chatApi;
    var body = {
      input: userMessage,
      fileName: fileName,
      copilot: copilotId,
      indexId: indexId,
      modelName: modelName,
    };

    console.log(`POST -> ${url}`);
    return this.http.post(`${url}`, JSON.stringify(body), { headers, context });
  }

  putMegaChat(
    id: string,
    userMessage: string,
    fileName?: string,
    indexId?: number,
    modelName?: string
  ): Observable<any> {
    var url = environment.chatApi;
    var body = {
      input: userMessage,
      fileName: fileName,
      indexId: indexId,
      modelName: modelName,
    };

    console.log(`PUT -> ${url}`);

    return this.http.put(`${url}/${id}`, JSON.stringify(body), {
      headers,
      context,
    });
  }

  deleteMegaChatItem(id: string): Observable<any> {
    var url = environment.chatApi;
    console.log(`DELETE -> ${url}`);
    return this.http.delete(`${url}/${id}`, { headers });
  }

  renameMegaChat(id: string, userMessage: string): Observable<any> {
    var url = environment.chatApi + '/Rename';

    console.log(`PUT -> ${url}`);
    return this.http.put(
      `${url}/${id}?newTitle=${encodeURIComponent(userMessage)}`,
      JSON.stringify(prompt),
      { headers }
    );
  }

  getMegaChatHistory(): Observable<any> {
    var url = environment.chatApi;

    console.log(`GET -> ${url}`);
    return this.http.get(`${url}`); // base get will pull history by authenticated user account
  }

  getCopilots(): Observable<any> {
    var url = environment.chatApi + '/copilots';

    console.log(`GET -> ${url}`);
    return this.http.get(`${url}`);
  }

  do10xMegaChat(id: string): Observable<any> {
    var url = environment.chatApi;

    console.log(`POST -> ${url}`);
    return this.http.post(`${url}/10x/${id}`, JSON.stringify(prompt), {
      headers,
    });
  }

  getFile(fileName: string): Observable<any> {
    var url = `${environment.chatApi}/file?fileName=${encodeURIComponent(
      fileName
    )}`;
    console.log(`GET -> ${url}`);

    return this.http.get(url, { responseType: 'blob' });
  }

  getFileNameCheck(fileName: string): Observable<any> {
    var url = `${environment.chatApi}/file/check?fileName=${encodeURIComponent(
      fileName
    )}`;
    console.log(`GET -> ${url}`);

    return this.http.get(url, { context });
  }

  getSupportedFileInfo(): Observable<any> {
    var url = `${environment.chatApi}/file/supported`;
    console.log(`GET -> ${url}`);

    return this.http.get(url);
  }

  putFile(file: File): Observable<any> {
    var url = `${environment.chatApi}/file`;
    console.log(`PUT -> ${url}`);

    var formData = new FormData();
    formData.append('files', file);

    return this.http.put(url, formData, {
      reportProgress: true,
      observe: 'events',
    });
  }

  azureSearchAPI(query: string, indexId: number): Observable<any> {
    var url = environment.chatApi;

    return this.http.get(
      `${url}/CognitiveSearch?message=${query}&indexId=${indexId}`
    );
  }

  azureCognitiveSearchWithOpenAI(
    message: string,
    indexId: number
  ): Observable<any> {
    var url =
      environment.chatApi + `/CognitiveSearchWithOpenAI?message=${message}`;
    const indexIds = [indexId];
    // var requestBody = { indexIds };
    return this.http.post<any>(url, indexIds, { headers });
  }
}
