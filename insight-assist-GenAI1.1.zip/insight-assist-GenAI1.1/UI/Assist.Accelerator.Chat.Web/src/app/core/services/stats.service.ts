import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { DatePipe } from '@angular/common';
import { MessageParserService } from './message-parser.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' }), // auth will be injected by MSALv2
};

@Injectable({
  providedIn: 'root',
})
export class StatsApiService {
  constructor(
    private http: HttpClient,
    private datePipe: DatePipe,
    private messageParserService: MessageParserService
  ) {}
  
  getAdminStats(period: string): Observable<any> {
    var url = environment.statsApi;

    var path = `${url}/Dashboard/${period}`;
    console.log(`GET -> ${path}`);
    return this.http.get(path);
  }
  getAdminStatsRange(startDate: string,endDate:string): Observable<any> {
    var url = environment.statsApi;

    var path = `${url}/Dashboards/${startDate}/${endDate}`;
    console.log(`GET -> ${path}`);
    return this.http.get(path);
  }
  
  setCurrentModel(modelId: number): Observable<any> {
    var url = environment.statsApi;

    var path = `${url}/Models/${modelId}/activate`;
    console.log(`PUT -> ${path}`);
    return this.http.put(path, {});
  }
  
  getTopUsers(period: string): Observable<any> {
    var url = environment.statsApi;

    var path = `${url}/Users/Top/${period}`;
    console.log(`GET -> ${path}`);
    return this.http.get(path);
  }

  getTopUsersRange(startDate: string,endDate:string): Observable<any> {
    var url = environment.statsApi;

    var path = `${url}/Users/TopRange/${startDate}/${endDate}`;
    console.log(`GET -> ${path}`);
    return this.http.get(path);
  }
  
  getHistoricalStats(index: number, period: string): Observable<any> {
    var url = environment.statsApi;

    var path = `${url}/HistoricalStats/${index}/${period}`;
    console.log(`GET -> ${path}`);
    return this.http.get(path);
  }

  getHistoricalStatsRange(index: number, startDate: string,endDate:string): Observable<any> {
    var url = environment.statsApi;

    var path = `${url}/HistoricalStatsRangeNew/${index}/${startDate}/${endDate}`;
    console.log(`GET -> ${path}`);
    return this.http.get(path);
  }

  setQuotaLimit(amount:number){
    var url = environment.statsApi;

    var path = `${url}/OrgQuotaLimit/${amount}`;
    console.log(`PUT -> ${path}`);
    
    return this.http.put(
      `${path}`,
      JSON.stringify(prompt),
      httpOptions
    );
  }
}
