import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' }) // auth will be injected by MSALv2
};

@Injectable({
  providedIn: 'root'
})
export class restApiService {
  constructor(private http: HttpClient) { }

  /**
   * Chat Api
   */

  postMegaChat(userMessage: string): Observable<any> {
    var url = environment.chatApi;

    console.log(`POST -> ${url}`);
    return this.http.post(`${url}?input=${userMessage}`, JSON.stringify(prompt), httpOptions);
  }

  putMegaChat(id: string, userMessage: string): Observable<any> {
    var url = environment.chatApi;

    console.log(`PUT -> ${url}`);
    return this.http.put(`${url}/${id}?input=${userMessage}`, JSON.stringify(prompt), httpOptions);
  }

  getMegaChatHistory(): Observable<any> {
    var url = environment.chatApi;

    console.log(`GET -> ${url}`);
    return this.http.get(`${url}`); // base get will pull history by authenticated user account
  }

  do10xMegaChat(id: string): Observable<any> {
    var url = environment.chatApi;

    console.log(`POST -> ${url}`);
    return this.http.post(`${url}/10x/${id}`, JSON.stringify(prompt), httpOptions);
  }
}
