import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MessageChunk } from 'src/app/pages/apps/chat/chat.model';
import { ChatStateMessage } from '../models/chat-message';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class MessageParserService {
  constructor(private domSanitizer: DomSanitizer, private datePipe: DatePipe) { }

  createUserMessage(message: string): ChatStateMessage {
    return {
      id: '',
      from: 'user',
      text: message,
      time: this.datePipe.transform(new Date(), 'h:mm a')!,
      chunks: [],
      copilotId: undefined
    };
  }

  createSystemMessage(message: string, copilotId: number | undefined = undefined): ChatStateMessage {
    return {
      id: '',
      from: 'OpenAI',
      text: message,
      time: this.datePipe.transform(new Date(), 'h:mm a')!,
      chunks: [],
      copilotId: copilotId
    };
  }

  formatMessages(messages: any[], id: any): ChatStateMessage[] {
    var filteredMessages = messages.filter(
      (item: { role: { label: string } }) => {
        return item.role.label == 'user' || item.role.label == 'assistant';
      }
    );
    var mapedMessages: ChatStateMessage[] = filteredMessages.map((message) => {
      return {
        id: id,
        from: message.role.label == 'assistant' ? 'OpenAI' : 'User',
        text: message.content,
        time: '',
        chunks: this.chunkMessage(message.content),
      };
    });

    return mapedMessages;
  }

  chunkMessage(message: string): MessageChunk[] {
    // placeholder function for breaking a bot messgage down into custom formatted
    //  chunks (e.g. html tables or eml) based on use cases implemented in the
    //  backend engine - for now we simply return the same string
    const chunks: MessageChunk[] = [];

    if (message.includes('URL4UI:')) {
      const [citationText, citationLink] = message.split('URL4UI:');
      const urlPrefix = 'Title4UI:';
      const urlStartIndex = citationLink.indexOf(urlPrefix); // Extract the citation title and URL
      const citationTitle = citationLink
        .substring(urlStartIndex + urlPrefix.length)
        .trim();
      const citationUrl = citationLink.substring(0, urlStartIndex - 1).trim();
      chunks.push({
        type: 'citation',
        content: citationText,
        metadata: { url: citationUrl, title: citationTitle },
      });
    } else {
      // Handle regular text message
      const regex = /```(?:\w*\n)?([^```]*)```|(\n*.*\n*)/gm;
      // Define the regular expression to match the Markdown table
      const tableRegex = /(\|.*\|\r?\n)+/g;

      // Use the regex to extract the table from the message
      const tableMatch = message.match(tableRegex);
      let lineCount = 0;

      // Store the extracted table in a variable
      const tableContentString = tableMatch ? tableMatch[0] : null;
      if (tableContentString) {
        // Split the markdownTable into lines using a regular expression
        const tableLines = tableContentString.split(/\r?\n/);

        // Count the number of lines
        lineCount = tableLines.length - 1;

        // Print the line count
        console.log(`Number of lines in the table: ${lineCount}`);
      }

      /*console.log("NEW", tableContentString);*/
      const chunksOther = message.match(regex) || [];
      /*console.log("CHUNKSOTHER", chunksOther);*/
      for (let i = 0; i < chunksOther?.length; i++) {
        let content: any = chunksOther[i].trim();
        let metadata: { [key: string]: string } = {};
        /*console.log("CONTENT", content);*/
        if (content === '') continue;
        const type = content.startsWith('|')
          ? 'table'
          : content.startsWith('```')
            ? 'code'
            : 'text';

        if (type === 'table') {
         /* console.log("TABLE", content);
          console.log("TABLECONTENT", tableContentString);*/
          /* content = content + '\n' + chunksOther[i + 1].trim();
           i++;*/
          content = tableContentString;
          // Use a regular expression to match lines in the table
         /* const tableRegex = /\|.*\|/g;*/

          // Match lines and count them
          /*const tableLines = tableContentString.match(tableRegex);
          const numberOfTableLines = tableLines ? tableLines.length : 0;
          console.log("TABLELINES", tableLines);
          console.log("AFTERLINE", chunksOther[i + numberOfTableLines]);
          console.log(`Number of lines in the table: ${numberOfTableLines}`);
          i=i+(numberOfTableLines);*/
          i = i + (2 * lineCount);
        }

        if (type === 'text' && chunks.length > 0 && chunks[chunks.length - 1].type === 'text') {
          chunks[chunks.length - 1].content += '\n\n' + content;
          continue;
        } else {
          chunks.push({
            type: type,
            content,
            metadata,
          });
        }
      }
    }

    return chunks;
  }

  // Stolen from SO: https://stackoverflow.com/a/14991797
  private parseCSV(str: string): string[][] {
    const arr: string[][] = [];
    let quote = false; // 'true' means we're inside a quoted field

    // Iterate over each character, keep track of current row and column (of the returned array)
    for (let row = 0, col = 0, c = 0; c < str.length; c++) {
      let cc = str[c],
        nc = str[c + 1]; // Current character, next character
      arr[row] = arr[row] || []; // Create a new row if necessary
      arr[row][col] = arr[row][col] || ''; // Create a new column (start with empty string) if necessary

      // If the current character is a quotation mark, and we're inside a
      // quoted field, and the next character is also a quotation mark,
      // add a quotation mark to the current column and skip the next character
      if (cc == '"' && quote && nc == '"') {
        arr[row][col] += cc;
        ++c;
        continue;
      }

      // If it's just one quotation mark, begin/end quoted field
      if (cc == '"') {
        quote = !quote;
        continue;
      }

      // If it's a comma and we're not in a quoted field, move on to the next column
      if (cc == ',' && !quote) {
        ++col;
        continue;
      }

      // If it's a newline (CRLF) and we're not in a quoted field, skip the next character
      // and move on to the next row and move to column 0 of that new row
      if (cc == '\r' && nc == '\n' && !quote) {
        ++row;
        col = 0;
        ++c;
        continue;
      }

      // If it's a newline (LF or CR) and we're not in a quoted field,
      // move on to the next row and move to column 0 of that new row
      if (cc == '\n' && !quote) {
        ++row;
        col = 0;
        continue;
      }
      if (cc == '\r' && !quote) {
        ++row;
        col = 0;
        continue;
      }

      // Otherwise, append the current character to the current column
      arr[row][col] += cc;
    }
    console.log("ARR", arr);
    return arr;
  }

  toTitleCase(str: any): string {
    return str
      .split('_')
      .map((s: string) => s.charAt(0).toUpperCase() + s.substring(1))
      .join(' ');
  }

  tryParseJSONObject(jsonString: string): any {
    try {
      var o = JSON.parse(jsonString);

      // Handle non-exception-throwing cases:
      // Neither JSON.parse(false) or JSON.parse(1234) throw errors, hence the type-checking,
      // but... JSON.parse(null) returns null, and typeof null === "object",
      // so we must check for that, too. Thankfully, null is falsey, so this suffices:
      if (o && typeof o === 'object') {
        return o;
      }
    } catch (e) { }

    return false;
  }
}
