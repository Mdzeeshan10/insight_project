export interface splashSuggestionModel {
  id: any;
  label: string;
  caption: string;
  bg_color: string;
}

