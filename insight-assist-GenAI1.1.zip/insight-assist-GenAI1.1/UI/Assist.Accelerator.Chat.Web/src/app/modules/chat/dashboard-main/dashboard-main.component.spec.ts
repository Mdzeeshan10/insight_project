import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardMainComponent } from './dashboard-main.component';

describe('DashboardMainComponent', () => {
  let component: DashboardMainComponent;
  let mockChatStateService: any;

  beforeEach(async () => {
    component = new DashboardMainComponent(mockChatStateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
