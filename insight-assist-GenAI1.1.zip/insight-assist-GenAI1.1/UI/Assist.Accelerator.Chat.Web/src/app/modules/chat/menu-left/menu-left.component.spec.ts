import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuLeftComponent } from './menu-left.component';

describe('MenuLeftComponent', () => {
  let component: MenuLeftComponent;

  beforeEach(async () => {
    component = new MenuLeftComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
