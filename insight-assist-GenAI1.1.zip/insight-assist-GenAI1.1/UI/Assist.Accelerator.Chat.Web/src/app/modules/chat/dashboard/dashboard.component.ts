import { Component, OnInit } from '@angular/core';
import { ChatStateService } from 'src/app/core/store/chat-state.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  constructor(public chatStateService: ChatStateService) {}
  ngOnInit(): void {
  }
}