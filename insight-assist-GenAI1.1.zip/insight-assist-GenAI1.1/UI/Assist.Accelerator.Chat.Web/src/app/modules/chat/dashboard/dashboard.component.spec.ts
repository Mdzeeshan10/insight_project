import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardComponent } from './dashboard.component';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let mockChatStateService: any;

  beforeEach(async () => {
    component = new  DashboardComponent(mockChatStateService);

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
