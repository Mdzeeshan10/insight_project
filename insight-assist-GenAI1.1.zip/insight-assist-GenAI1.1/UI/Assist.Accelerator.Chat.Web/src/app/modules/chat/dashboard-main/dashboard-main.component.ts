import { Component, OnInit } from '@angular/core';
import { ChatStateService } from 'src/app/core/store/chat-state.service';
import { Store } from '@ngrx/store';
import { ChatState } from 'src/app/core/store/chat-state';
import { FormControl } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field'
import { updateSeletedPeriod } from 'src/app/core/store/chat.actons';
import { dateToMidnightUTC, getShortDateString } from 'src/app/shared/date-utils';

@Component({
  selector: 'dashboard-main',
  templateUrl: './dashboard-main.component.html',
  styleUrls: ['./dashboard-main.component.scss'],
})
export class DashboardMainComponent implements OnInit {
  startDate!: Date;
  endDate!: Date;
  showDateRangePicker = false;
  colorPicker = false;
  today = new Date();

  constructor(public chatStateService: ChatStateService, private store: Store<{ chat: ChatState }>,) { }

  ngOnInit() {
    this.selectDate('this year');
  }

  selectDate(id: string) {
    const date = dateToMidnightUTC(new Date()).toISOString();
    if (id === 'today') {
      this.chatStateService.selectPeriod(date.substring(0, 10));
    } else if (id === 'this month') {
      this.chatStateService.selectPeriod(date.substring(0, 7));
    } else if (id === 'this year') {
      this.chatStateService.selectPeriod(date.substring(0, 4));
    } else if (id === 'now') {
      this.chatStateService.selectPeriod(date.substring(0, 13).replaceAll('T', '-'));
    }
    this.colorPicker = false;
    this.showDateRangePicker = false;
  }
  toggleDateRangePicker() {
    this.store.dispatch(updateSeletedPeriod({ selectedPeriod: '' }));
    this.showDateRangePicker = !this.showDateRangePicker;
  }

  applyDateRange() {
    if (this.startDate && this.endDate) {
      console.log("StartDate", this.startDate);
      const startDate = getShortDateString(this.startDate);
      const endDate = getShortDateString(this.endDate);
      console.log("StartDate Length", startDate.length)
      // const period = `${startDateString}-${endDateString}`;

      this.chatStateService.selectPeriodRange(startDate, endDate);
      this.colorPicker = true;
    }
  }
}
