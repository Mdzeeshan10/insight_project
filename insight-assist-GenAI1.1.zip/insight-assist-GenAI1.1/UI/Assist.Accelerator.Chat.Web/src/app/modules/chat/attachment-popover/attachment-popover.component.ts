import { HttpClient, HttpEventType, HttpResponse } from '@angular/common/http';
import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewEncapsulation,
} from '@angular/core';
import { Observable, Subscription, forkJoin, mergeMap, of } from 'rxjs';
import { Copilot } from 'src/app/core/models/copilot';
import { FileSupportInfo } from 'src/app/core/models/file-support-info';
import { ChatApiService } from 'src/app/core/services/chat-api.service';
import { ChatStateService } from 'src/app/core/store/chat-state.service';
import { ToastService } from 'src/app/toast.service';

@Component({
  selector: 'app-attachment-popover',
  templateUrl: './attachment-popover.component.html',
  styleUrls: ['./attachment-popover.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class AttachmentPopoverComponent {
  @Input() onClearFiles: Observable<void> = of();
  @Output() isUploadingEvent = new EventEmitter<boolean>();
  @Output() filesEvent = new EventEmitter<string[]>();

  public allowedFileTypes = ['.txt'];
  public maxFileSizeText: string = '0 B';
  public allowUpload: boolean = true;
  public uploadedFiles: File[] = [];

  copilots: Copilot[] = [];
  allSupportedFileTypes = ['.txt'];
  uploadingSubscription: Subscription = new Subscription();
  uploadingFileName: string = '';
  uploadingProgress: number = -1;

  constructor(
    private chatApi: ChatApiService,
    private toastService: ToastService,
    private chatStateService: ChatStateService
  ) {}

  ngOnInit() {
    this.chatStateService.AttachedFiles$.subscribe({
      next: (files) => {
        this.uploadedFiles = files;
        this.allowUpload = files.length < 1;
      }
    });
    this.chatStateService.Copilots$
    .subscribe({
      next: (copilots) => {this.copilots = copilots}
    }), 
    this.chatStateService.selectedChathistory$
    .subscribe((history) => {
      var currentCopilot = this.copilots.find(c => c.id === history.copilotId);
      if (currentCopilot && currentCopilot.fileTypes.length > 0) {
        this.allowedFileTypes = this.allSupportedFileTypes
          .filter(ft => currentCopilot?.fileTypes.split(",").map(f => f.trim()).includes(ft));
      }
      else {
        this.allowedFileTypes = this.allSupportedFileTypes;
      }
    });
    this.chatApi.getSupportedFileInfo().subscribe({
      next: (supported: FileSupportInfo) => {
        this.allSupportedFileTypes = supported.extensions.sort();
        this.allowedFileTypes = this.allSupportedFileTypes;
        this.maxFileSizeText = this.readableFileSize(supported.maxFileSize);
      },
    });
    this.onClearFiles.subscribe(() => {
      this.chatStateService.removeAttachedFiles(this.uploadedFiles)
      this.updateStatus();
    });
    window.addEventListener(
      'dragover',
      (e) => {
        e && e.preventDefault();
      },
      false
    );
    window.addEventListener(
      'drop',
      (e) => {
        e && e.preventDefault();
      },
      false
    );
  }

  onFileSelected(event: any) {
    if (event.target?.files?.length > 0 && this.allowUpload) {
      this.addFile(event.target?.files[0]);
    }
  }

  onFilesDropped(files: File[]) {
    if (files?.length > 0 && this.allowUpload) {
      this.addFile(files[0]);
    }
    else {
      this.toastService.showError(this.allowUpload 
        ? "Could not attach file: No file data found" 
        : "Could not attach file: Maximum of 1 attached file allowed");
    }
  }

  addFile(file: File) {
    if (this.allowUpload) {
      if (
        file &&
        this.allowedFileTypes.includes(
          file.name.substring(file.name.lastIndexOf('.'))
        )
      ) {
        this.onUploadStart(file);

        this.uploadingSubscription = this.chatApi
          .getFileNameCheck(file.name)
          .pipe(
            mergeMap((checkResult) => {
              if (!checkResult.exists && checkResult.isSupported) {
                var putFileObservable = this.chatApi.putFile(file);
                // this.uploadingSubscription = putFileObservable.subscribe();
                return putFileObservable;
              } else {
                this.showFileExistsWarning('File already exists.');
                return of();
              }
            })
          )
          .subscribe({
            next: (event: any) => {
              if (event && event.type === HttpEventType.UploadProgress) {
                this.uploadingProgress = Math.round(
                  (100 * event.loaded) / event.total
                );
              }
            },
            error: (err: any) => {
              console.log(err);
              const msg: string =
                err.error?.error ??
                Object.values(err.error?.errors).join("; ") ??
                err.error ??
                'Failed to upload file.';
              if (
                err.status === 409 &&
                msg.includes(`${file.name} already exists`)
              ) {
                this.showFileExistsWarning(msg);
                this.chatStateService.addAttachedFiles([file]);
              } else {
                this.toastService.showError(msg);
              }
              this.onUploadEnd();
            },
            complete: () => {
              this.chatStateService.addAttachedFiles([file]);
              this.onUploadEnd();
            },
          });
      } else {
        this.toastService.showError(
          `Can only attach ${this.allowedFileTypes.join(', ')} files.`
        );
      }
    } else {
      this.toastService.showError('Cannot attach more than one file.');
    }
  }

  cancelUpload() {
    if (this.uploadingSubscription) this.uploadingSubscription.unsubscribe();
    this.onUploadEnd();
  }

  onUploadStart(file: File) {
    this.uploadingFileName = file.name;
    this.uploadingProgress = 0;
    this.isUploadingEvent.emit(true);
    this.updateStatus();
  }

  onUploadEnd() {
    this.uploadingFileName = '';
    this.uploadingProgress = -1;
    this.isUploadingEvent.emit(false);
    this.updateStatus();
  }

  removeFile(file: File) {
    if (file && this.uploadedFiles?.length > 0) {
      this.chatStateService.removeAttachedFiles([file]);
      this.updateStatus();
    }
  }

  updateStatus() {
    this.filesEvent.emit(this.uploadedFiles.map((f) => f.name));
  }

  showFileExistsWarning(message: string) {
    this.toastService.showWarning(message + ' Using previously uploaded file.');
  }

  readableFileSize(bytes: number): string {
    var factor = 0;

    while (bytes >= 1000) {
      bytes = bytes / 1000;
      factor++;
      if (factor === 3) break;
    }

    if (factor === 4) return `${bytes} TB`;
    if (factor === 3) return `${bytes} GB`;
    if (factor === 2) return `${bytes} MB`;
    if (factor === 1) return `${bytes} kB`;
    if (factor === 0) return `${bytes} B`;
    return `${bytes} x 10^${factor * 3} B`;
  }
}
