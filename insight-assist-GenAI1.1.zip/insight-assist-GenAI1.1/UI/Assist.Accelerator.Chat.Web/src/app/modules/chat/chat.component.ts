import { Component, OnInit } from '@angular/core';
import { ChatModule } from './chat.module';
import { ChatApiService } from 'src/app/core/services/chat-api.service';
import { chatMessagesData } from 'src/app/pages/apps/chat/data';
import { restApiService } from 'src/app/core/services/rest-api.service';
import { UserProfileService } from 'src/app/core/services/user.service';
import { ChatStateService } from 'src/app/core/store/chat-state.service';


@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss'],
})
export class ChatComponentV2 implements OnInit {
  constructor(public chatStateService: ChatStateService) {}
  ngOnInit(): void {}
}
