import { Component, Input } from '@angular/core';
import { ChatStateMessage } from 'src/app/core/models/chat-message';
import { ChatApiService } from 'src/app/core/services/chat-api.service';
import { ChatStateService } from 'src/app/core/store/chat-state.service';
import { ToastService } from 'src/app/toast.service';

@Component({
  selector: 'user-message',
  templateUrl: './user-message.component.html',
  styleUrls: ['./user-message.component.scss'],
})
export class UserMessageComponent {
  @Input() chatMessage: ChatStateMessage = {
    id: '',
    text: '',
    from: '',
    time: '',
    chunks: [],
  };
  @Input() CurrConvoId: string = '';
  message: string = '';
  filename?: string;

  constructor(
    public chatStateService: ChatStateService,
    private chatApiService: ChatApiService,
    private toastService: ToastService
) {}

  ngOnInit() {
    var fileNameMatches = Array.from(
      this.chatMessage.text.matchAll(/(.*) Attached file name: (.*)/g)
    )[0];

    if (fileNameMatches?.length === 3) {
      this.message = fileNameMatches[1];
      this.filename = fileNameMatches[2];
    } else {
      this.message = this.chatMessage.text;
      this.filename = this.chatMessage.file;
    }
  }

  downloadFile() {
    if (this.filename) {
      this.chatApiService.getFile(this.filename).subscribe({
        next: (value) => {
          const a = document.createElement('a');
          a.href = URL.createObjectURL(value);
          a.download = this.filename ?? 'file.txt';
          document.body.appendChild(a);
          a.click();
        },
        error: (error) => {
          this.toastService.showError(error.error?.error);
        },
      });
    }
  }
}
