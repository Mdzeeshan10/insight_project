import { Component, ViewChild } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ToastService } from '../../../../../app/toast.service';
import { environment } from '../../../../../environments/environment';
import { UserUpdateService } from '../user-update.service';
import { MatDialog } from '@angular/material/dialog';
import { UserDetailsModalComponent } from '../user-details-modal/user-details-modal.component';

interface user {
  userId: number;
  name: string;
  lastName: string;
  emailAddress: string;
  isActive: boolean;
  model_control: boolean;
}

interface UserResponse {
  users: user[];
  totalCount: number;
}
interface UserRole { roleId: number; roleName: string; }

@Component({
  selector: 'app-active-users',
  templateUrl: './active-users.component.html',
  styleUrls: ['./active-users.component.scss'],
})
export class ActiveUsersComponent {
  activeUserSearchKeyword: string = '';
  activeUsers: any[] = [];
  prevRoleId: number=0;
  currentPage: number = 1;
  pageSize: number = 10;
  totalCount: number = 0;
  pageNumbers: number[] = [];
  totalPages: number = 0;
  userRoles: UserRole[] = [
    { roleId: 1, roleName: 'Admin' },
    { roleId: 2, roleName: 'User' },
  ];

  isGroup: boolean = false;
  users: user[] = [];
  pageCoung: number = 0;
  cmp: UserResponse = { users: [], totalCount: 0 };
  x: user[] = [];

  constructor(
    private http: HttpClient,
    public toastService: ToastService,
    private userUpdateService: UserUpdateService,
    private dialog: MatDialog
  ) {}

  ngOnInit() {
    this.loadActiveUsers();

    this.userUpdateService.userAdded$.subscribe(() => {
      this.loadActiveUsers();
    });
  }

  loadActiveUsers() {
    const filter = this.activeUserSearchKeyword;

    const params = new HttpParams()
      .set('filter', filter || '')
      .set('pageNumber', this.currentPage.toString())
      .set('pageSize', this.pageSize.toString());

    this.http
      .get<any[]>(environment.usersApi + '/GetApplicationUsers', {
        params,
      })
      .subscribe({
        next: (response: any) => {
          this.activeUsers = response.users.map((users: any) => {
            return users;
          });
          this.totalCount = response.pageCount;

          this.totalPages = Math.ceil(this.totalCount / this.pageSize);

          console.log('total pages', this.totalPages);

          this.calculateDisplayedPageNumbers();
        },
        error: (error: any) => {
          console.error('Error loading active users:', error);
          this.toastService.showError('Error loading active users');
        },
      });
  }

  searchActiveUsers() {
    this.currentPage = 1; //Reset to the first page
    this.loadActiveUsers();
  }

  calculateDisplayedPageNumbers(): number[] {
    const displayedPages = [];
    const maxDisplayedPages = 5; // Maximum number of page numbers to display

    // Calculate the start and end page numbers for the displayed range
    let startPage = this.currentPage - Math.floor(maxDisplayedPages / 2);
    let endPage = this.currentPage + Math.floor(maxDisplayedPages / 2);

    // Adjust the start and end page numbers if they go beyond the valid range
    if (startPage < 1) {
      startPage = 1;
      endPage = Math.min(maxDisplayedPages, this.totalPages);
    }

    if (endPage > this.totalPages) {
      endPage = this.totalPages;
      startPage = Math.max(1, this.totalPages - maxDisplayedPages + 1);
    }

    // Generate the array of displayed page numbers
    for (let i = startPage; i <= endPage; i++) {
      displayedPages.push(i);
    }

    return displayedPages;
  }

  goToPage(pageNumber: number) {
    if (pageNumber >= 1 && pageNumber <= this.totalPages) {
      this.currentPage = pageNumber;
      this.loadActiveUsers();
    }
  }

  toggleUserStatus(user: any) {
    const status = user.isActive;
    const userIds = user.userId.toString();
    const url = environment.usersApi + '/DeleteUsers';
    const body = { userIds: userIds, status: status };
    let params = new HttpParams();
    params = params.set('userIds', userIds);
    params = params.set('status', status.toString());
    this.http.post(url, null, { params }).subscribe(
      (response) => {
        if (user.isActive === true) {
          console.log('ToggleUserStatus API response:', response);
          this.toastService.showSuccess(
            'User Status Successfully Changed to Active'
          );
        } else {
          this.toastService.showSuccess(
            'User Status Successfully Changed to Inactive'
          );
        }
        // Handle the successful response if needed
      },
      (error) => {
        console.error('Error while calling ToggleUserStatus API:', error);
        this.toastService.showError('Error while changing User Status');
        // Handle the error or show an error message to the user
        // Revert the toggle switch state if necessary
        user.isActive = !user.isActive;
      }
    );
  }

  toggleModelStatus(user: any) {
    const status = user.model_control;
    const userId = user.userId.toString();
    const isGroup = this.isGroup;
    const url = environment.usersApi + '/ToggleModelControl';
    const body = { Id: userId, status: status, isGroup: isGroup };
    let params = new HttpParams();
    params = params.set('Id', userId);
    params = params.set('status', status.toString());
    params = params.set('isGroup', isGroup.toString());
    this.http.post(url, null, { params }).subscribe(
      (response) => {
        if (user.model_control === true) {
          console.log('ToggleModelStatus API response:', response);
          this.toastService.showSuccess(
            'Model Status Successfully Changed to Active'
          );
        } else {
          this.toastService.showSuccess(
            'Model Status Successfully Changed to Inactive'
          );
        }
        // Handle the successful response if needed
      },
      (error) => {
        console.error('Error while calling ToggleModelStatus API:', error);
        this.toastService.showError('Error while changing Model Status');
        // Handle the error or show an error message to the user
        // Revert the toggle switch state if necessary
        user.model_Control = !user.model_Control;
      }
    );
  }

  onMatSelectOpen(user: any): void {
    this.prevRoleId = user.roleId;
  }

  toggleUserRole(user: any) {
    const roleId = user.roleId == 1 ? 1 : 2;
    const prevRole = this.prevRoleId;
    const userIds = user.userId.toString();
    const url = environment.usersApi + '/UpdateAppUserRole';
    const body = { UserId: userIds, RoleId: roleId };
    let params = new HttpParams();
    params = params.set('UserId', userIds);
    params = params.set('RoleId', roleId);
    this.http.post(url, null, { params }).subscribe(
      (response) => {
        if (roleId === 1) {
          console.log('ToggleUserStatus API response:', response);
          this.toastService.showSuccess(
            'User Role Successfully Changed to Admin'
          );
        } else {
          this.toastService.showSuccess(
            'User Role Successfully Changed to User'
          );
        }
        // Handle the successful response if needed
      },
      (error) => {
        console.error('Error while calling ToggleUserStatus API:', error);
        if (error.status === 500) {
          this.toastService.showError(error.error);
          user.roleId = prevRole; //Revert the user's role to old role
        }
        else {
          this.toastService.showError("An unexpected error occurred while changing User Role.");
        }

        // Handle the error or show an error message to the user
        // Revert the toggle switch state if necessary
        /* user.isActive = !user.isActive;*/
      }
    );
  }
  isAnyUserSelected() {
    return this.activeUsers.some((user) => user.selected);
  }

  compareRoles(role1: UserRole, role2: UserRole) {
    return role1 && role2 ? role1.roleId === role2.roleId : role1 === role2;
  }

  openDetailsDialog(user: any) {
    const dialogRef = this.dialog.open(UserDetailsModalComponent, {
      width: '65%',
      height: '95%',
      data: { user },
    });
  }
}
