import { Component } from '@angular/core';

@Component({
  selector: 'typing-balls',
  templateUrl: './typing-balls.component.html',
  styleUrls: ['./typing-balls.component.scss'],
})
export class TypingBallsComponent {}
