import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardGraphComponent } from './dashboard-graph.component';
import { BehaviorSubject } from 'rxjs';

describe('DashboardGraphComponent', () => {
  let component: DashboardGraphComponent;
  let mockChatStateService: any;

  mockChatStateService = { AdminGraph$: new BehaviorSubject(null) };

  beforeEach(async () => {
    component = new DashboardGraphComponent(mockChatStateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
