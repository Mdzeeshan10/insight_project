import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BotMessageComponent } from './bot-message.component';

describe('BotMessageComponent', () => {
  let component: BotMessageComponent;
  let mockMessageParserService: any;

  beforeEach(async () => {
    component = new BotMessageComponent(mockMessageParserService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
