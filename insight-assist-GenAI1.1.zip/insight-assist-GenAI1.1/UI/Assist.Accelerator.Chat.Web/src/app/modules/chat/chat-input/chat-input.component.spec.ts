import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatInputComponent } from './chat-input.component';

describe('ChatInputComponent', () => {
  let component: ChatInputComponent;
  let mockChatStateService: any;
  let mockDataPipe: any

  beforeEach(async () => {

    component = new ChatInputComponent(mockChatStateService, mockDataPipe);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
