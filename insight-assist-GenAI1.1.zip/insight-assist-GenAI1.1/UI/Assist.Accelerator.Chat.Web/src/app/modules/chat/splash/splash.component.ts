import { Component, OnInit } from '@angular/core';
import { splashSuggestionModel } from './splash.model';
import { ChatSamplePrompts } from './data';
import { Output, EventEmitter } from '@angular/core';
import { ChatStateService } from 'src/app/core/store/chat-state.service';
import { ChatStateMessage } from 'src/app/core/models/chat-message';
import { MessageParserService } from 'src/app/core/services/message-parser.service';
import { Copilot } from 'src/app/core/models/copilot';

@Component({
  selector: 'chat-splash',
  templateUrl: './splash.component.html',
  styleUrls: ['./splash.component.scss'],
})

/**
 * Chat Component
 */
export class SplashComponent implements OnInit {
  @Output() splashItemPicked = new EventEmitter<any>();
  @Output() splashItemFavorite = new EventEmitter<any>();

  chatSamplePrompts!: splashSuggestionModel;

  constructor(
    public chatStateService: ChatStateService,
    private messageParserService: MessageParserService
  ) { }

  ngOnInit(): void {
    console.log('SplashComponent initialized');
    this.chatSamplePrompts = ChatSamplePrompts;
  }

  ngAfterViewInit() { }

  handleSplashItemPicked(text: string) {
    let message = this.messageParserService.createUserMessage(text);
    this.chatStateService.addMessage(message);
  }

  getCopilotImage(copilot: Copilot): string {
    switch (true) {
      case copilot.name.toLocaleLowerCase().includes('claims triage'):
        return 'assets/images/copilots/claimstriage.png';
      case copilot.name.toLocaleLowerCase().includes('clinical trial'):
        return 'assets/images/copilots/clinicaltrial.png';
      case copilot.name.toLocaleLowerCase().includes('content creator'):
        return 'assets/images/copilots/contentcreator.png';
      case copilot.name.toLocaleLowerCase().includes('meeting summarizer'):
        return 'assets/images/copilots/meetingsummarizer.png';
    };
    return '';
  }

  getCopilotSubtitle(copilot: Copilot): string {
    switch (true) {
      case copilot.name.toLocaleLowerCase().includes('claims triage'):
        return '(Insurance Demo)';
      case copilot.name.toLocaleLowerCase().includes('clinical trial'):
        return '(HLS Demo)';
      case copilot.name.toLocaleLowerCase().includes('content creator'):
        return '(Retail Demo)';
      case copilot.name.toLocaleLowerCase().includes('meeting summarizer'):
        return '(Productivity Demo)';
    };
    return '';
  }
  handleCopilotAdded(copilot: Copilot) {
    let message = this.messageParserService.createSystemMessage(copilot.introMessage, copilot.id);
    
    this.chatStateService.newChatWithCopilot(copilot.id);
    this.chatStateService.replaceMessages(message);
  }

  handleSplashItemFavorite(event: Event, id: any) {
    // event.stopPropagation(); // consume click before it hits the parent card
    // this.splashItemFavorite.emit(
    //   this.chatSamplePrompts.find(p => p.id == id));
  }
}
