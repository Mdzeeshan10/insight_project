import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuComponent } from './menu.component';

describe('MenuComponent', () => {
  let component: MenuComponent;
  let mockChatStateService: any;
  let mockUserProfileService: any;
  let mockRouter: any;

  mockChatStateService = { loadUser: jasmine.createSpy('loadUser') };

  beforeEach(async () => {
    component = new MenuComponent(
      mockChatStateService,
      mockUserProfileService,
      mockRouter
    );
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
