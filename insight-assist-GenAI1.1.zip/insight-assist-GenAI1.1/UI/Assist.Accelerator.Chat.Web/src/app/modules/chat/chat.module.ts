import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatComponentV2 } from './chat.component';
import { HeaderComponent } from './header/header.component';
import { MenuComponent } from './menu/menu.component';
import { ChatMainComponent } from './chat-main/chat-main.component';
import { ConversationComponent } from './conversation/conversation.component';
import { ChatInputComponent } from './chat-input/chat-input.component';
import { UserMessageComponent } from './user-message/user-message.component';
import { BotMessageComponent } from './bot-message/bot-message.component';
import { MarkdownModule } from 'ngx-markdown';
import { NgbPopoverModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { TypingComponent } from './typing/typing.component';
import { ChatHistoryComponent } from './chat-history/chat-history.component';
import { MenuPopoutComponent } from './menu-popout/menu-popout.component';
import { MenuLeftComponent } from './menu-left/menu-left.component';
import { SplashComponent } from './splash/splash.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DashboardMainComponent } from './dashboard-main/dashboard-main.component';
import { DashboardSummaryComponent } from './dashboard-summary/dashboard-summary.component';
import { DashboardUsersComponent } from './dashboard-users/dashboard-users.component';
import { DashboardGraphComponent } from './dashboard-graph/dashboard-graph.component';
import { DashboardCostComponent } from './dashboard-cost/dashboard-cost.component';
import { DashboardQueriesComponent } from './dashboard-queries/dashboard-queries.component';
import { DashboardDataSourcesComponent } from './dashboard-data-sources/dashboard-data-sources.component';
import { TypingBallsComponent } from './typing-balls/typing-balls.component';
import { StreamingStatusComponent } from './streaming-status/streaming-status.component';
import { InviteComponent } from './invite/invite.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DialogComponent } from './dialog/dialog.component';
import { SetModelModalComponent } from './set-model-modal/set-model-modal.component';
import { MatIconModule } from '@angular/material/icon';
import { MatNativeDateModule } from '@angular/material/core';
import {
  MAT_AUTOCOMPLETE_SCROLL_STRATEGY,
  MAT_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY,
  MAT_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatAutocompleteModule,
} from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';
import {
  MatFormFieldControl,
  MatFormFieldModule,
} from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';

// Charts
import { NgApexchartsModule } from 'ng-apexcharts';
import { TermsComponent } from './terms/terms.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { AddUsersComponent } from './user-management/add-users/add-users.component';
import { ActiveUsersComponent } from './user-management/active-users/active-users.component';
import { NotLoggedInComponent } from './not-logged-in/not-logged-in.component';
import { ChatHistoryNameComponent } from './chat-history-name/chat-history-name.component';
import { MatOptionModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatRadioModule } from '@angular/material/radio';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatBadgeModule } from '@angular/material/badge';
import { MatDividerModule } from '@angular/material/divider';
import { MatTabsModule } from '@angular/material/tabs';  
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { AttachmentPopoverComponent } from './attachment-popover/attachment-popover.component';
import { DirectivesModule } from '../directives/directives.module';
import { AddGroupsComponent } from './user-management/add-groups/add-groups.component';
import { ActiveGroupsComponent } from './user-management/active-groups/active-groups.component';
import { MatMenuModule } from '@angular/material/menu';
import { GroupDetailsModalComponent } from './user-management/group-details-modal/group-details-modal.component';
import { UserDetailsModalComponent } from './user-management/user-details-modal/user-details-modal.component';
import { KnowledgeBaseComponent } from './user-management/knowledge-base/knowledge-base.component';

@NgModule({
  declarations: [
    ChatComponentV2,
    HeaderComponent,
    MenuComponent,
    ChatMainComponent,
    ConversationComponent,
    ChatInputComponent,
    UserMessageComponent,
    BotMessageComponent,
    TypingComponent,
    ChatHistoryComponent,
    MenuPopoutComponent,
    MenuLeftComponent,
    InviteComponent,
    SplashComponent,
    DashboardComponent,
    DashboardMainComponent,
    DashboardSummaryComponent,
    DashboardUsersComponent,
    DashboardCostComponent,
    DashboardQueriesComponent,
    DashboardDataSourcesComponent,
    TermsComponent,
    DashboardGraphComponent,
    DialogComponent,
    SetModelModalComponent,
    UserManagementComponent,
    AddUsersComponent,
    ActiveUsersComponent,
    NotLoggedInComponent,
    ChatHistoryNameComponent,
    AttachmentPopoverComponent,
    AddGroupsComponent,
    ActiveGroupsComponent,
    GroupDetailsModalComponent,
    UserDetailsModalComponent,
    KnowledgeBaseComponent,
    TypingBallsComponent,
    StreamingStatusComponent,
  ],
  imports: [
    CommonModule,
    MarkdownModule.forChild(),
    HttpClientModule,
    NgbTooltipModule,
    NgApexchartsModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    MatOptionModule,
    FormsModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatInputModule,
    MatFormFieldModule,
    ScrollingModule,
    MatSelectModule,
    MatChipsModule,
    MatButtonModule,
    MatCardModule,
    MatProgressBarModule,
    MatRadioModule,
    MatButtonToggleModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatBadgeModule,
    MatDividerModule,
    MatTabsModule,
    NgbPopoverModule,
    DirectivesModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule
  ],
})
export class ChatModule {}
