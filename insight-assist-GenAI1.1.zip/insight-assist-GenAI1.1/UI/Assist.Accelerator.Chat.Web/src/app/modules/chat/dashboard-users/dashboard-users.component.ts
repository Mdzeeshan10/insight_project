import { Component, OnInit } from '@angular/core';
import { ChatStateService } from 'src/app/core/store/chat-state.service';

@Component({
  selector: 'dashboard-users',
  templateUrl: './dashboard-users.component.html',
  styleUrls: ['./dashboard-users.component.scss']
})
export class DashboardUsersComponent implements OnInit {
  constructor(public chatStateService: ChatStateService) {}
  ngOnInit(): void {
  }
}