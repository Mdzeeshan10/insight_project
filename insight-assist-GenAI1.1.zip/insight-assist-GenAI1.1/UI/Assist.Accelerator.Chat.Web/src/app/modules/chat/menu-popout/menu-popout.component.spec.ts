import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuPopoutComponent } from './menu-popout.component';

describe('MenuPopoutComponent', () => {
  let component: MenuPopoutComponent;
  let mockChatStateService: any;

  beforeEach(async () => {
    component = new MenuPopoutComponent(mockChatStateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
