import { Component, OnInit } from '@angular/core';
import { ChatStateService } from 'src/app/core/store/chat-state.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-dialog',
  templateUrl: './set-model-modal.component.html',
  styleUrls: ['./set-model-modal.component.scss']
})
export class SetModelModalComponent  {
  public selectedModelId?: number;

  constructor(public dialogRef: MatDialogRef<SetModelModalComponent>, public chatStateService: ChatStateService) { }

  closeDialog() {
    this.dialogRef.close();
  }

  saveCurrentModel() {
    if (this.selectedModelId) {
      this.chatStateService.setCurrentModel(this.selectedModelId);
    }

    this.closeDialog();
  }
}