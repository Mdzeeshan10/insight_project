import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { environment } from '../../../../../environments/environment';
import { ToastService } from '../../../../toast.service';
import { UserUpdateService } from '../user-update.service';

interface group {
  groupId: number;
  groupName: string;
  roleId: number;
  objectId: string;
  model_Control: boolean;
  isActive: boolean;
}

interface GroupResponse {
  groups: group[];
  totalCount: number;
}
interface GroupRole { roleId: number; roleName: string; }

@Component({
  selector: 'app-user-details-modal',
  templateUrl: './user-details-modal.component.html',
  styleUrls: ['./user-details-modal.component.scss']
})
export class UserDetailsModalComponent {

  activeGroupSearchKeyword: string = '';
  activeKnowledgeSearchKeyword: string = '';
  activeGroups: any[] = [];
  activeKnowledge: any[] = [];
  prevRoleId: number = 0;
  currentPageGroup: number = 1;
  currentPageKnowledge: number = 1;
  pageSizeGroup: number = 10;
  pageSizeKnowledge: number = 10;
  totalCountGroup: number = 0;
  totalCountKnowledge: number = 0;
  pageNumbersGroup: number[] = [];
  pageNumbersKnowledge: number[] = [];
  totalPagesGroup: number = 0;
  totalPagesKnowledge: number = 0;
  groupRoles: GroupRole[] = [
    { roleId: 1, roleName: 'Admin' },
    { roleId: 2, roleName: 'User' },
  ];

  users: group[] = [];
  pageCoung: number = 0;
  cmp: GroupResponse = { groups: [], totalCount: 0 };
  x: group[] = [];
  constructor(
    private http: HttpClient,
    public toastService: ToastService,
    private userUpdateService: UserUpdateService,
    public dialogRef: MatDialogRef<UserDetailsModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { user: any }
  ) {
    //Fetch data from the api
  }

  ngOnInit() {
    this.loadActiveGroups();
    this.loadActiveKnowledge();

    this.userUpdateService.userAdded$.subscribe(() => {
      this.loadActiveGroups();
    });
  }

  loadActiveGroups() {
    const filter = this.activeGroupSearchKeyword;
    const params = new HttpParams()
      .set('filter', filter || '')
      .set('pageNumber', this.currentPageGroup.toString())
      .set('pageSize', this.pageSizeGroup.toString())
      .set('userId', this.data.user.userId.toString());

    this.http
      .get<any[]>(environment.usersApi + '/GetGroupNamesForUser', {
        params,
      })
      .subscribe({
        next: (response: any) => {
          this.activeGroups = response.groups.map((groups: any) => {
            return groups;
          });

          this.totalCountGroup = response.pageCount;
          console.log("Active groups", this.activeGroups);
          this.totalPagesGroup = Math.ceil(this.totalCountGroup / this.pageSizeGroup);

          console.log('total pages', this.totalPagesGroup);

          this.calculateDisplayedPageNumbersGroup();
        },
        error: (error: any) => {
          console.error('Error loading active users:', error);
          this.toastService.showError('Error loading active users');
        },
      });
  }

  searchActiveGroups() {
    this.currentPageGroup = 1; //Reset to the first page
    this.loadActiveGroups();
  }

  calculateDisplayedPageNumbersGroup(): number[] {
    const displayedPages = [];
    const maxDisplayedPages = 5; // Maximum number of page numbers to display

    // Calculate the start and end page numbers for the displayed range
    let startPage = this.currentPageGroup - Math.floor(maxDisplayedPages / 2);
    let endPage = this.currentPageGroup + Math.floor(maxDisplayedPages / 2);

    // Adjust the start and end page numbers if they go beyond the valid range
    if (startPage < 1) {
      startPage = 1;
      endPage = Math.min(maxDisplayedPages, this.totalPagesGroup);
    }

    if (endPage > this.totalPagesGroup) {
      endPage = this.totalPagesGroup;
      startPage = Math.max(1, this.totalPagesGroup - maxDisplayedPages + 1);
    }

    // Generate the array of displayed page numbers
    for (let i = startPage; i <= endPage; i++) {
      displayedPages.push(i);
    }

    return displayedPages;
  }

  goToPageGroup(pageNumberGroup: number) {
    if (pageNumberGroup >= 1 && pageNumberGroup <= this.totalPagesGroup) {
      this.currentPageGroup = pageNumberGroup;
      this.loadActiveGroups();
    }
  }

  loadActiveKnowledge() {
    const filter = this.activeKnowledgeSearchKeyword;
    const params = new HttpParams()
      .set('filter', filter || '')
      .set('pageNumber', this.currentPageKnowledge.toString())
      .set('pageSize', this.pageSizeKnowledge.toString())
      .set('userId', this.data.user.userId.toString());

    this.http
      .get<any[]>(environment.usersApi + '/GetKnowledgeBaseForUser', {
        params,
      })
      .subscribe({
        next: (response: any) => {
          this.activeKnowledge = response.knowledgeBase.map((knowledgeBase: any) => {
            return knowledgeBase;
          });

          this.totalCountKnowledge = response.pageCount;
          console.log("Active knowledge", this.activeKnowledge);
          this.totalPagesKnowledge = Math.ceil(this.totalCountKnowledge / this.pageSizeKnowledge);

          console.log('total pages', this.totalPagesKnowledge);

          this.calculateDisplayedPageNumbersKnowledge();
        },
        error: (error: any) => {
          console.error('Error loading active users:', error);
          this.toastService.showError('Error loading active users');
        },
      });
  }

  searchActiveKnowledge() {
    this.currentPageKnowledge = 1; //Reset to the first page
    this.loadActiveKnowledge();
  }

  calculateDisplayedPageNumbersKnowledge(): number[] {
    const displayedPages = [];
    const maxDisplayedPages = 5; // Maximum number of page numbers to display

    // Calculate the start and end page numbers for the displayed range
    let startPage = this.currentPageKnowledge - Math.floor(maxDisplayedPages / 2);
    let endPage = this.currentPageKnowledge + Math.floor(maxDisplayedPages / 2);
    // Adjust the start and end page numbers if they go beyond the valid range
    if (startPage < 1) {
      startPage = 1;
      endPage = Math.min(maxDisplayedPages, this.totalPagesKnowledge);
    }

    if (endPage > this.totalPagesKnowledge) {
      endPage = this.totalPagesKnowledge;
      startPage = Math.max(1, this.totalPagesKnowledge - maxDisplayedPages + 1);
    }

    // Generate the array of displayed page numbers
    for (let i = startPage; i <= endPage; i++) {
      displayedPages.push(i);
    }
    return displayedPages;
  }

  goToPageKnowledge(pageNumberKnowledge: number) {
    if (pageNumberKnowledge >= 1 && pageNumberKnowledge <= this.totalPagesKnowledge) {
      this.currentPageKnowledge = pageNumberKnowledge;
      this.loadActiveKnowledge();
    }
  }

  toggleKnowledgeStatus(knowledge: any) {
    const status = knowledge.isActive;
    const userId = this.data.user.userId.toString();
    const indexId = knowledge.indexId;
    const url = environment.usersApi + '/ToggleKnowledgeBase';
    const body = { indexId: indexId, userId: userId, status: status };
    let params = new HttpParams();
    params = params.set('indexId', indexId.toString());
    params = params.set('userId', userId);
    params = params.set('status', status.toString());
    this.http.post(url, null, { params }).subscribe(
      (response) => {
        if (response === true) {
          console.log('ToggleModelStatus API response:', response);
          this.toastService.showSuccess(
            'KnowledgeBase Status Successfully Changed to Active'
          );
        } else {
          knowledge.isActive = !knowledge.isActive;
          this.toastService.showInfo(
            'Add DisplayName on Knowledge Base Page'
          );
        }
        // Handle the successful response if needed
      },
      (error) => {
        console.error('Error while calling ToggleModelStatus API:', error);
        this.toastService.showError('Error while changing Model Status');
        // Handle the error or show an error message to the user
        // Revert the toggle switch state if necessary
        knowledge.isActive = !knowledge.isActive;
      }
    );
  }
  get user(): any {
    return this.data.user;
  }

  closeDialog(): void {
    this.dialogRef.close();
  }
}
