import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardDataSourcesComponent } from './dashboard-data-sources.component';

describe('DashboardDataSourcesComponent', () => {
  let component: DashboardDataSourcesComponent;

  beforeEach(async () => {
    component = new DashboardDataSourcesComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
