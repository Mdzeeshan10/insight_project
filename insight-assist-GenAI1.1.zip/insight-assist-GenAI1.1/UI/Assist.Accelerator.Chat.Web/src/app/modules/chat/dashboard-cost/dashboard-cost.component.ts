import { Component, ViewChild } from '@angular/core';

import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../dialog/dialog.component';
import { ChatStateService } from 'src/app/core/store/chat-state.service';
import { Observable, forkJoin } from 'rxjs';

@Component({
  selector: 'dashboard-cost',
  templateUrl: './dashboard-cost.component.html',
  styleUrls: ['./dashboard-cost.component.scss'],
})
export class DashboardCostComponent {
  constructor(
    public chatStateService: ChatStateService,
    public dialog: MatDialog
  ) {}

  openDialog(): void {
    let dialogRef = this.dialog.open(DialogComponent, {
      width: '436px',
      height: '313px',
    });

    dialogRef.afterClosed().subscribe((result) => {});
  }
}
