import { Component } from '@angular/core';

@Component({
  selector: 'chat-menu-left',
  templateUrl: './menu-left.component.html',
  styleUrls: ['./menu-left.component.scss']
})
export class MenuLeftComponent {

}
