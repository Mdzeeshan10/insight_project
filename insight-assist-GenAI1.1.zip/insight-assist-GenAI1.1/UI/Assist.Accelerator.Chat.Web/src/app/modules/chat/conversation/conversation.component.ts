import { Component, ElementRef, OnDestroy, ViewChild } from '@angular/core';
import { async, map } from 'rxjs';
import { ChatHistory } from 'src/app/core/models/chat-history';
import { ChatStateService } from 'src/app/core/store/chat-state.service';

@Component({
  selector: 'chat-conversation',
  templateUrl: './conversation.component.html',
  styleUrls: ['./conversation.component.scss'],
})
export class ConversationComponent implements OnDestroy {

  @ViewChild('scrollContainer') private scrollContainer!: ElementRef;
  private isConversationVisible: boolean = false;
  public selectedChatHistoryId: string = '';
  public shouldShowSplash: boolean = true;
  constructor(public chatStateService: ChatStateService) {
    this.chatStateService.ChatId$.subscribe((chatId) => {
      this.convoId = chatId;
      console.log('chat ID conversation:', this.convoId);
    });
    chatStateService.showSplashScreen();
    chatStateService.SplashScreen$.subscribe((splashScreen) => {
      this.isConversationVisible = !splashScreen;
      this.shouldShowSplash = splashScreen && this.convoId == '';
    });
  }
  public convoId = '';
  ngOnDestroy(): void {
    //throw new Error('Method not implemented.');
  }

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  scrollToBottom(): void {
    try {
      if (this.isConversationVisible) {
        this.scrollContainer.nativeElement.scrollTop =
          this.scrollContainer.nativeElement.scrollHeight;
      }
    }
    catch (err) {
      console.error(err);
    }
  }
  selectChatHistory(chatHistory: ChatHistory) {
    this.selectedChatHistoryId = chatHistory.id;
  }
}
