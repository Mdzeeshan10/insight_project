import { Component } from '@angular/core';

import { MatDialog } from "@angular/material/dialog";
import { SetModelModalComponent } from "../set-model-modal/set-model-modal.component";
import { ChatStateService } from 'src/app/core/store/chat-state.service';

@Component({
  selector: 'dashboard-summary',
  templateUrl: './dashboard-summary.component.html',
  styleUrls: ['./dashboard-summary.component.scss']
})
export class DashboardSummaryComponent {
  constructor(public chatStateService: ChatStateService, public dialog: MatDialog) {}

  openDialog(): void {
    let dialogRef = this.dialog.open(SetModelModalComponent);
  
    dialogRef.afterClosed().subscribe(result => {

    });
  }
}
