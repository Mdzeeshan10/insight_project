import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardQueriesComponent } from './dashboard-queries.component';

describe('DashboardQueriesComponent', () => {
  let component: DashboardQueriesComponent;

  beforeEach(async () => {
    component = new DashboardQueriesComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
