import { Component } from '@angular/core';
import { UserProfileService } from 'src/app/core/services/user.service';

@Component({
  selector: 'app-not-logged-in',
  templateUrl: './not-logged-in.component.html',
  styleUrls: ['./not-logged-in.component.scss'],
})
export class NotLoggedInComponent {
  constructor(private userProfileService: UserProfileService) {}

  logOut() {
    this.userProfileService.logout();
  }
}
