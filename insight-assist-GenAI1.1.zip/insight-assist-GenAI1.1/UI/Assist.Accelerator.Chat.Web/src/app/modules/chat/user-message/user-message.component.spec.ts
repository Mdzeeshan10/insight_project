import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserMessageComponent } from './user-message.component';

describe('UserMessageComponent', () => {
  let component: UserMessageComponent;
  let mockChatStateService: any;

  beforeEach(async () => {
    component = new UserMessageComponent(mockChatStateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
