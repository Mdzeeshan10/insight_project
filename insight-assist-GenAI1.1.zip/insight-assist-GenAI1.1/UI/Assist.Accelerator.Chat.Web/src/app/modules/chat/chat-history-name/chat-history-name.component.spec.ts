import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatHistoryNameComponent } from './chat-history-name.component';

describe('ChatHistoryNameComponent', () => {
  let component: ChatHistoryNameComponent;
  let mockChatStateService: any;

  beforeEach(async () => {

    component = new ChatHistoryNameComponent(mockChatStateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
