import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatComponentV2 } from './chat.component';

describe('ChatComponent', () => {
  let component: ChatComponentV2;
  let mockChatStateService: any;

  beforeEach(async () => {
    component = new ChatComponentV2(mockChatStateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
