import { Component } from '@angular/core';
import { ChatStateService } from 'src/app/core/store/chat-state.service';

@Component({
  selector: 'chat-menu-popout',
  templateUrl: './menu-popout.component.html',
  styleUrls: ['./menu-popout.component.scss'],
})
export class MenuPopoutComponent {
  constructor(public chatStateService: ChatStateService) {}
}
