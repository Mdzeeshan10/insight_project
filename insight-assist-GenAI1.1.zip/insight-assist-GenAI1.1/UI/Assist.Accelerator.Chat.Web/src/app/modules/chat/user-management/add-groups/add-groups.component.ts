import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { debounceTime, of, switchMap } from 'rxjs';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { HttpClient } from '@angular/common/http';
import { ToastService } from 'src/app/toast.service';
import { UserUpdateService } from '../user-update.service';
import { UserProfileService } from 'src/app/core/services/user.service';
import { environment } from 'src/environments/environment';

interface Group {
  GroupId: string;
  groupName: number;
  ObjectId: string;
  Model_Control: string;
  isActive: boolean;
}

interface GroupRole {
  roleId: number;
  roleName: string;
}

@Component({
  selector: 'app-add-groups',
  templateUrl: './add-groups.component.html',
  styleUrls: ['./add-groups.component.scss']
})
export class AddGroupsComponent implements OnInit{
  adGroupSuggestions: Group[] = [];
  selectedGroups: Group[] = [];
  groupRoles: GroupRole[] = [];
  separatorKeysCodes: number[] = [ENTER, COMMA];
  addGroupForm: FormGroup;
  groupnameChips: FormControl = new FormControl([], (control) =>
    !control.pristine &&
    this.selectedGroups.length > 0
      ? null
      : { groups: 'Search for and select a group' }
  );
  groupnameInput: FormControl = new FormControl([]);
  roleSelect: FormControl = new FormControl(null, (control) =>
     !control.pristine && control.value > 0
      ? null
      : { role: 'Select a role' }
  );

  @ViewChild('groupnameElement') groupnameElement!: ElementRef<HTMLInputElement>;

  constructor(
    private http: HttpClient,
    private toast: ToastService,
    private groupService: UserProfileService,
    private formBuilder: FormBuilder,
    private groupUpdateService: UserUpdateService
  ) {
    this.addGroupForm = this.formBuilder.group({
      groupnameChips: this.groupnameChips,
      groupnameInput: this.groupnameInput,
      roleSelect: this.roleSelect,
    });
  }

  ngOnInit() {
    this.getGroupRoles();
    this.addGroupForm.controls['groupnameInput'].valueChanges
      .pipe(
        debounceTime(500),
        switchMap((value: string) => {
          if (value?.length >= 3) {
            return this.http.get<Group[]>(
              environment.usersApi + `/SearchADGroups?initials=${value}`
            );
          } else {
            return of([]);
          }
        })
      )
      .subscribe((groups) => {
        this.adGroupSuggestions =
          groups?.filter(
            (group) =>
              !this.selectedGroups
                .map((u) => u.groupName)
                .includes(group.groupName)
          ) ?? [];
      });
  }

  getGroupRoles() {
    this.http.get<GroupRole[]>(environment.usersApi + '/GetRoles').subscribe({
      next: (response: GroupRole[]) => {
        this.groupRoles = response;
      },
      error: (error) => {
        console.error('Error while fetching group roles:', error);
        // Handle the error or show an error message to the group
      },
    });
  }

  addGroupChip(event: MatAutocompleteSelectedEvent) {
    const group = event.option.value;
    const groupName = group.groupName;
    if (
      groupName &&
      !this.selectedGroups.map((u) => u.groupName).includes(groupName)
    ) {
      this.selectedGroups.push(group);
      this.addGroupForm.controls['groupnameChips'].updateValueAndValidity();
    }
    this.groupnameElement.nativeElement.value = '';
    this.addGroupForm.controls['groupnameInput'].setValue(null);
  }

  removeGroupChip(group: Group) {
    const chipIndex = this.selectedGroups
      .map((u) => u.groupName)
      .indexOf(group.groupName);
    if (chipIndex > -1) {
      this.selectedGroups.splice(chipIndex, 1);
      this.addGroupForm.controls['groupnameChips'].updateValueAndValidity();
    }
  }

  clearGroupInput(event: MatChipInputEvent): void {
    event.chipInput!.clear();
    this.addGroupForm.controls['groupnameInput'].setValue(null);
  }

  updateRoleValidity() {
    this.addGroupForm.controls['roleSelect'].updateValueAndValidity();
  }

  addGroups() {
     const groupRoleIdInt = parseInt(this.roleSelect.value);

     this.groupService
      .addGroups(groupRoleIdInt, this.selectedGroups)
       .then((result) => {
        this.toast.showSuccess('Groups added successfully.');
       this.groupUpdateService.notifyGroupAdded();
       this.resetForm();
     })
      .catch((reason) => {
       console.error(`Failed to add groups: ${reason.status}`);
       console.log(reason.error);
        if (typeof reason.error === 'string') {
           this.toast.showError(reason.error);
        } else {
           this.toast.showError('Unexpected error. Please try again.');
         }
         this.resetForm();
       });
   }

  resetForm() {
    this.selectedGroups = [];
    this.adGroupSuggestions = [];
    this.addGroupForm.reset();
    this.addGroupForm.updateValueAndValidity();
  }

}
