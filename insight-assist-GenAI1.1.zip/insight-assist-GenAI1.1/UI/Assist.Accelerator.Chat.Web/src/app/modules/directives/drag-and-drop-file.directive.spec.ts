import { ElementRef } from '@angular/core';
import { DragAndDropFileDirective } from './drag-and-drop-file.directive';

describe('DragAndDropFileDirective', () => {
  it('should create an instance', () => {
    const directive = new DragAndDropFileDirective(new ElementRef({}));
    expect(directive).toBeTruthy();
  });
});
