import { Component } from '@angular/core';
import { SpinnerLoaderService } from '../spinner-loader.service';

@Component({
  selector: 'app-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent {
  constructor(public spinnerLoaderService:SpinnerLoaderService) {}
  

  startSpinner(): void {
    this.spinnerLoaderService.startSpinner();
  }

  stopSpinner():void{
    this.spinnerLoaderService.stopSpinner();
  }

  changeSpinnerColor(color:string,text:string):void {
    this.spinnerLoaderService.changeSpinnerColorAndText(color,text);
  }

}
