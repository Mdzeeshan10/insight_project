import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

 

@Injectable({
  providedIn: 'root'
})
export class SpinnerLoaderService {
  private showSpinnerSubject = new BehaviorSubject<boolean>(false);
  public showSpinner$ = this.showSpinnerSubject.asObservable();
  public spinnerText: string = 'Loading..';
  public spinnerColor:string = '';
  public showProgressBarSubject = new BehaviorSubject<boolean>(false);
  public showProgressBar$ = this.showProgressBarSubject.asObservable();

  constructor() {}

  public startSpinner(): void {
    this.showSpinnerSubject.next(true);
    this.showProgressBarSubject.next(true); //Start showing the progress bar
  }

 

  public stopSpinner(): void {
    this.showSpinnerSubject.next(false);
    this.showProgressBarSubject.next(false); //Stop showing the progress bar
  }

  public changeSpinnerColorAndText(color:string,text:string):void {
//     const loaderDots = document.getElementsByClassName('dot');
//   for (let i = 0; i < loaderDots.length; i++) {
//     const dot = loaderDots[i] as HTMLElement;
//     dot.style.backgroundColor = color;
//   }
    this.spinnerColor = color;
    this.spinnerText = text;
  }

  public changeSpinnerText(text: string):void {
    this.spinnerText = text;
  }
}