import { TestBed } from '@angular/core/testing';

import { LoadingInterceptorService } from './loadingInterceptor.service';

describe('LoadingInterceptorService', () => {
  let service: LoadingInterceptorService;
  let mockNgxUiLoaderService: any;

  beforeEach(() => {
    service = new LoadingInterceptorService(mockNgxUiLoaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
