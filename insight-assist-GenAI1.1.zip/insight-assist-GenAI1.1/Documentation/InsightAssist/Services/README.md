# Insight Assist Services

[Source Code](/Services/Assist.Accelerator.Chat.Api/README.md)

## Documents

- [Semantic Kernel Overview](/Documentation/InsightAssist/Services/Semantic-Kernel-Overview.md)

## Getting Started

To run the API locally:

- Open `Services/Assist.Accelerator.Chat.Api/Assist.Services.sln` in Visual Studio
- Create a copy of `appsettings.json` and name it `appsettings.Development.json`
- **Make sure the "CorsAllowedHosts" value in `appsettings.Development.json` is set to `http://localhost:4200`.** The API will not start up if this value is not configured.
- In the Azure Portal, go to the Dev environment's `mega-dev-app-openapi-api` Web App's Configuration section [here](https://portal.azure.com/#@insightipengineering.onmicrosoft.com/resource/subscriptions/1ea8407e-c34f-4e4e-8270-608b7b91a17f/resourceGroups/megademo-openai-dev-001/providers/Microsoft.Web/sites/mega-dev-app-openai-api/configuration)
  - If the link above doesn't work, go to the Azure portal and go to:
    - All Services
    - Subscriptions
    - `Insight_IP_Engineering`
    - Resource Groups
    - `megademo-openai-dev-001`
    - `mega-dev-app-openapi-api`
    - Configuration
- Copy the necessary configuration values from the Azure portal to `appsettings.Development.json`
- In Visual Studio, click the green Play icon near the top. You may need to select the `https` run profile from the dropdown.
- You should be able to access the API's Swagger page at `https://localhost:7295/swagger` or hit the API using a tool like [Postman](https://www.postman.com/downloads/)
  - Get a bearer token for authentication from the UI
    - Go to [the Dev UI](https://mega-dev-app-openai-webapp.azurewebsites.net/) (or [run the UI locally](/Documentation/InsightAssist/UI/README.md#getting-started))
    - Open DevTools and go to the Network tab (refresh if it's empty)
    - Select a call to the API (e.g. the `/me` endpoint)
    - Under Request Headers, copy the Authorization header

### SignalR Configuration

- You may run SignalR locally with a Redis backplane (useful if you are testing scale-out scenarios). To do so, update the `Redis` block in your `appsettings.Development.json`:
  - Configure the backplane: `"Backplane": "REDIS"` (valid values are NONE, REDIS, or AZURE).
  - Set the connection string; for a local Redis instance this is typically `localhost:6379` with no password.
  - You can install Redis directly on Windows, or run it in Docker with `docker run -p 6379:6379 -d redis`
  - Note that you _may_ need to configure sticky sessions when running the Redis backplane in a scale-out scenario; the SignalR documentation implies that this is not necessary if your clients are set to use the WebSockets connection type only and are set to skip negotiation.
- You may run the application in a scale-out scenario in Azure; to do so, configure the `Redis` block as follows:
  - Set the Backplane value to `AZURE`
  - Obtain the connection string from your Azure SignalR Service instance in Azure, and put it into `AzureSignalRServiceConnectionString`.

The `AddSignalRForLens` service will set default values for no backplane if none is specified or the Redis block is missing.

When using the Redis backplane, the default channel prefix (to allow multiple applications to use the same Redis instance, if necessary) is `lensai`; you can set the `ChannelPrefix` option to change this if needed.
