# Insight Assist Database

[Source Code](/Database/Assist.Accelerator.Chat.Sql/README.md)

The absolute easiest way of getting the database configured and seeded is to use the [Dev/Assist.Accelerator.Chat.Sql makefile](../../../Dev/Assist.Accelerator.Chat.Sql/Makefile) to start up the file. However, that requires several additional components to stand up correctly. Please see the [Dev/Sql readme](../../../Dev/Assist.Accelerator.Chat.Sql/README.md) for full details on configuring and running this.