# Insight Assist UI

[Source Code](/UI/Assist.Accelerator.Chat.Web/README.md)

## Documents

- [Theming and Validation](/Documentation/InsightAssist/UI/Theming-and-Validation.md)

## Getting Started

To run the UI locally:

- Ensure Node.js, NPM, and the Angular CLI are installed with the correct versions - run `ng version` and you should see these (or comparable) versions:
  ```
  Angular CLI: 15.0.4        
  Node: 18.12.1
  Package Manager: npm 8.19.2
  ```
  - You may need to install [Node.js and NPM](https://docs.npmjs.com/downloading-and-installing-node-js-and-npm) (ideally using [nvm](https://github.com/nvm-sh/nvm)) and/or the [Angular CLI](https://angular.io/cli)
- In your terminal of choice, go to `UI/Assist.Accelerator.Chat.Web`
  - Run `npm run start` to target the [local API](/Documentation/InsightAssist/Services/README.md#getting-started)
  - Run `npm run start -- --configuration devintegration` to target the deployed Dev API
- Go to `https://localhost:4200`
- If prompted, log in with your Insight account
  - If you have issues logging in, you may need an admin's assistance to be added to the `Insight_IP_Engineering` AD tenant or the user database via the web app's *Manage Users* page
- If you are running the API locally, you may need to add yourself as a user to the database:
  - Connect to your local dev database and