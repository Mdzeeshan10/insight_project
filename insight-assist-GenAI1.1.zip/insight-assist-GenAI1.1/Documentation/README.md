# Documentation

Any images or other documentation / assets should be added here.

Documentation in the form of text, Markdown files or images can be viewed directly in GitHub.

## Writing Markdown Docs

Markdown is a simple markup language that can be used to easily add basic formatting to plaintext documents. It is supported by GitHub, Visual Studio/VS Code and many other websites and programs. Its simplicity and portability makes it a popular format for all kinds of documentation.

## Resources

- [Basic writing and formatting syntax](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax)

### Useful VS Code Extensions

- [Markdown All in One](https://marketplace.visualstudio.com/items?itemName=yzhang.markdown-all-in-one) - Useful keyboard shortcuts, automatic table of contents support, and other handy goodies
- [GitHub Markdown Preview](https://marketplace.visualstudio.com/items?itemName=bierner.github-markdown-preview) - VS Code has a native markdown preview, which this extension modifies to use GitHub's Markdown rendering, so that previews match exactly what will be displayed in GitHub