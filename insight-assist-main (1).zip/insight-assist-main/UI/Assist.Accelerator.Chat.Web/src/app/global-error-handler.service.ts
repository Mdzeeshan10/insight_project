import { Injectable, ErrorHandler, Injector } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from './auth.service';


@Injectable()
export class GlobalErrorHandlerService implements ErrorHandler {
  
  constructor(private injector: Injector,private router:Router,private authService:AuthService) { }

  handleError(error: any) {

    let router = this.injector.get(Router);
    console.log('URL: ' + router.url);
     const toastrService = this.injector.get(ToastrService);

      if (error instanceof HttpErrorResponse) {

      console.error('Backend returned status code: ', error.status);
      console.error('Response body:', error.message);

      // Handle specific HTTP error codes
      if (error.status === 404) {
        toastrService.error('Resource not found.');
      } else if (error.status === 500) {
        toastrService.error('Internal server error.');
      }
        else if (error.status === 401) {
          toastrService.error('Unauthorized user. Please contact admin');
          setTimeout(()=>{
            this.authService.logout();
          },4000);


      } else {
        toastrService.error('An error occurred. Please try again.');
      }
    } else {
      console.error('An error occurred:', error.message);
      // Log component and method information
      console.trace();
      toastrService.error('An error occurred. Please try again.');
    }
  }
}
