import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupDetailsModalComponent } from './group-details-modal.component';

describe('GroupDetailsModalComponent', () => {
  let component: GroupDetailsModalComponent;
  let fixture: ComponentFixture<GroupDetailsModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GroupDetailsModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GroupDetailsModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
