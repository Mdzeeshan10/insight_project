import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TypingBallsComponent } from './typing-balls.component';

describe('TypingBallsComponent', () => {
  let component: TypingBallsComponent;
  let fixture: ComponentFixture<TypingBallsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TypingBallsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TypingBallsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
