import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ChatModule } from '../chat.module';
import { MsalService } from '@azure/msal-angular';
import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { environment } from '../../../../environments/environment';

declare let FormData: any;
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' }), // auth will be injected by MSALv2
};

@Component({
  selector: 'app-dashboard',
  templateUrl: './invite.component.html',
  styleUrls: ['./invite.component.scss']
})
@Injectable({ providedIn:'root' })
export class InviteComponent {
  emailAddress: string = '';
  firstName: string = '';
  lastName: string = '';
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  errorMessage: string = '';
  constructor(private http: HttpClient, private authService: MsalService, private toastr: ToastrService) { }
  submitForm(form: any) {
    this.errorMessage = '';
    this.http.post<any>(environment.usersApi, form, httpOptions).subscribe(
      response => {
        // Handle the response from the API

        const emailInput = document.querySelectorAll("#email")[0] as HTMLInputElement;
        emailInput.value = "";
        const firstNameInput = document.querySelectorAll("#firstName")[0] as HTMLInputElement;
        firstNameInput.value = "";
        const lastNameInput = document.querySelectorAll("#lastName")[0] as HTMLInputElement;
        lastNameInput.value = "";
        this.toastr.success('User has been added', 'Success');
        
      },
      error => {
        // Handle the error
        console.log(form);
        this.errorMessage = `Error: ${error.status}`;
        this.toastr.error('An error occurred. Please try again.', 'Error');
        console.error(error);
      }
    );
  }
}
