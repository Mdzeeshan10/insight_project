import { Component, OnInit } from '@angular/core';
import { ChatStateService } from 'src/app/core/store/chat-state.service';
import { MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent  {
  quotaLimitForm: FormGroup;
  quotaLimit: FormControl = new FormControl(
    [],
    [
      Validators.required, 
      Validators.pattern(new RegExp('^[0-9]+$')),
      Validators.min(0),
      Validators.max(92233720368 )
    ]
  );

  constructor (
    public dialogRef: MatDialogRef<DialogComponent>, 
    public chatStateService: ChatStateService,
    private formBuilder: FormBuilder
  ) { 
    this.quotaLimitForm = this.formBuilder.group({
      quotaLimit: this.quotaLimit,
    });
  }

  closeDialog() {
    this.dialogRef.close('Pizza!');
  }

  setQuotaLimit(limit:string){

    this.chatStateService.setQuotaLimit(parseInt(limit) * 100000000);
    this.closeDialog();
  }
}