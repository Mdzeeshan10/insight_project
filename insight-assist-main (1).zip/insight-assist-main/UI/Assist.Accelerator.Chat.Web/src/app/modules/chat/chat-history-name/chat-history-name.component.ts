import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ChatHistory } from 'src/app/core/models/chat-history';
import { ChatStateService } from 'src/app/core/store/chat-state.service';
import { environment } from '../../../../environments/environment.prod';
import { ChatApiService } from '../../../core/services/chat-api.service';
import { AvailableModel } from 'src/app/core/models/available-model';

@Component({
  selector: 'chat-history-name',
  templateUrl: './chat-history-name.component.html',
  styleUrls: ['./chat-history-name.component.scss'],
})
export class ChatHistoryNameComponent {
  models: AvailableModel[] = [];
  selectedModel: string = '';
  selectedKnowledgeBase: number | undefined = 0;
  genAI: number = 0;
  dropdownData: any[] = [];
  editing: boolean = false;
  deleteing: boolean = false;
  titleReceived: boolean = false;
  constructor(
    public chatStateService: ChatStateService,
    private http: HttpClient,
    public chatApiService: ChatApiService
  ) {}
  ngOnInit(): void {
    this.chatApiService.getDropDownData().subscribe((data: any) => {
      this.dropdownData = data;
    });
    console.log('DROPDOWN DATA', this.dropdownData);
    this.chatApiService.getModelData().subscribe((data: any) => {
      this.models = data;
    });
    this.chatStateService.selectedChathistory$.subscribe({
      next: (history) => {
        this.selectedKnowledgeBase = history.indexId;
      }
    })
    /*this.chatStateService.Messages$.subscribe((data: any) => {
      if (!this.titleReceived) {
        this.
      }
    });*/
  }
  onModelChange(selectedValue: AvailableModel): void {
    this.chatStateService.setModel(selectedValue);
  }
  onKnowledgeBaseChange(selectedValue: number): void {
    this.chatStateService.setKnowledgeBase(selectedValue);
  }

  public async editChatName(chatHistory: ChatHistory, newTitle: string) {
    this.editing = false;

    var newChatHistory: ChatHistory = {
      id: chatHistory.id,
      title: newTitle,
      messages: chatHistory.messages,
      indexId: 0
    };
    this.chatStateService.setSelectedChatHistory(newChatHistory);

    this.chatStateService.editChatHistoryItem(chatHistory.id, newTitle);
  }

  public async deleteChat(id: string) {
    this.deleteing = false;
    var emptyChatHistory: ChatHistory = {
      id: '',
      title: '',
      messages: [],
      indexId: 0
    };
    this.chatStateService.setSelectedChatHistory(emptyChatHistory);
    this.chatStateService.deleteChathistoryItem(id);
    this.chatStateService.newChat();
  }

  truncateTitle(title: string | undefined): string {
    if (!title) {
      return '';
    }
    //Split the title into words
    const words = title.split(' ');

    //Check if there are more than 4 words
    if (words.length > 4) {
      //Take the first 4 words and join them with a space
      return words.slice(0, 4).join(' ') + '...';
    } else {
      return title;
    }
  }
}
