import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastService } from '../../../../../app/toast.service';
import { UserProfileService } from '../../../../core/services/user.service';
import { environment } from '../../../../../environments/environment';
import { UserUpdateService } from '../user-update.service';
import { debounceTime, of, switchMap } from 'rxjs';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';

import { COMMA, ENTER } from '@angular/cdk/keycodes';

interface User {
  emailAddress: string;
  userId: number;
  name: string;
  lastName: string;
  isActive: boolean;
}

interface UserRole {
  roleId: number;
  roleName: string;
}

@Component({
  selector: 'app-add-users',
  templateUrl: './add-users.component.html',
  styleUrls: ['./add-users.component.scss'],
})
export class AddUsersComponent implements OnInit {
  autoRegisterEnabled: boolean = false;
  adUserSuggestions: User[] = [];
  selectedUsers: User[] = [];
  userRoles: UserRole[] = [];
  separatorKeysCodes: number[] = [ENTER, COMMA];
  addUserForm: FormGroup;
  usernameChips: FormControl = new FormControl([], (control) =>
    !this?.autoRegisterEnabled &&
    !control.pristine &&
    this.selectedUsers.length > 0
      ? null
      : { users: 'Search for and select a user' }
  );
  usernameInput: FormControl = new FormControl([]);
  roleSelect: FormControl = new FormControl(null, (control) =>
    !this?.autoRegisterEnabled && !control.pristine && control.value > 0
      ? null
      : { role: 'Select a role' }
  );

  @ViewChild('usernameElement') usernameElement!: ElementRef<HTMLInputElement>;

  constructor(
    private http: HttpClient,
    private toast: ToastService,
    private userService: UserProfileService,
    private formBuilder: FormBuilder,
    private userUpdateService: UserUpdateService
  ) {
    this.addUserForm = this.formBuilder.group({
      usernameChips: this.usernameChips,
      usernameInput: this.usernameInput,
      roleSelect: this.roleSelect,
    });
  }

  ngOnInit() {
    this.getAutoRegisterFlag();
    this.getUserRoles();
    this.addUserForm.controls['usernameInput'].valueChanges
      .pipe(
        debounceTime(500),
        switchMap((value: string) => {
          if (value?.length >= 3) {
            return this.http.get<User[]>(
              environment.usersApi + `/GetADUsers?filter=${value}`
            );
          } else {
            return of([]);
          }
        })
      )
      .subscribe((users) => {
        this.adUserSuggestions =
          users?.filter(
            (user) =>
              !this.selectedUsers
                .map((u) => u.emailAddress)
                .includes(user.emailAddress)
          ) ?? [];
      });
  }

  getUserRoles() {
    this.http.get<UserRole[]>(environment.usersApi + '/GetRoles').subscribe({
      next: (response: UserRole[]) => {
        this.userRoles = response;
      },
      error: (error) => {
        console.error('Error while fetching user roles:', error);
        // Handle the error or show an error message to the user
      },
    });
  }

  addUserChip(event: MatAutocompleteSelectedEvent) {
    const user = event.option.value;
    const email = user.emailAddress;
    if (
      email &&
      !this.selectedUsers.map((u) => u.emailAddress).includes(email)
    ) {
      this.selectedUsers.push(user);
      this.addUserForm.controls['usernameChips'].updateValueAndValidity();
    }
    this.usernameElement.nativeElement.value = '';
    this.addUserForm.controls['usernameInput'].setValue(null);
  }

  removeUserChip(user: User) {
    const chipIndex = this.selectedUsers
      .map((u) => u.emailAddress)
      .indexOf(user.emailAddress);
    if (chipIndex > -1) {
      this.selectedUsers.splice(chipIndex, 1);
      this.addUserForm.controls['usernameChips'].updateValueAndValidity();
    }
  }

  clearUserInput(event: MatChipInputEvent): void {
    event.chipInput!.clear();
    this.addUserForm.controls['usernameInput'].setValue(null);
  }

  updateRoleValidity() {
    this.addUserForm.controls['roleSelect'].updateValueAndValidity();
  }

  addUsers() {
    const userRoleIdInt = parseInt(this.roleSelect.value);

    this.userService
      .addUsers(userRoleIdInt, this.selectedUsers)
      .then((result) => {
        this.toast.showSuccess('Users added successfully.');
        this.userUpdateService.notifyUserAdded();
        this.resetForm();
      })
      .catch((reason) => {
        console.error(`Failed to add users: ${reason.status}`);
        console.log(reason.error);
        if (typeof reason.error === 'string') {
          this.toast.showError(reason.error);
        } else {
          this.toast.showError('Unexpected error. Please try again.');
        }
        this.resetForm();
      });
  }

  resetForm() {
    this.selectedUsers = [];
    this.adUserSuggestions = [];
    this.addUserForm.reset();
    this.addUserForm.updateValueAndValidity();
  }

  setAutoRegisterEnabled(value: boolean) {
    this.autoRegisterEnabled = value;

    if (this.autoRegisterEnabled) {
      this.resetForm();
      this.addUserForm.disable();
    } else {
      this.addUserForm.enable();
    }
  }

  toggleAutoRegister() {
    this.setAutoRegisterEnabled(!this.autoRegisterEnabled);
    this.UpdateAutoRegisterFlag();
    // Clear the selected users and search keyword if auto register is enabled
  }

  getAutoRegisterFlag() {
    this.http
      .get<boolean>(environment.usersApi + '/GetAutoRegisterFlag')
      .subscribe({
        next: (response: boolean) => {
          this.setAutoRegisterEnabled(response);
        },
        error: (error) => {
          console.error('Error while fetching auto register flag:', error);
          // Handle the error or show an error message to the user
        },
      });
  }

  UpdateAutoRegisterFlag() {
    const url = environment.usersApi + '/UpdateAutoRegisterFlag';
    const params = { flag: this.autoRegisterEnabled.toString() };
    this.http.post<any>(url, null, { params: params }).subscribe({
      next: (response) => {
        if (this.autoRegisterEnabled) {
          this.toast.showSuccess('Auto Register ON');
        } else {
          this.toast.showSuccess('Auto Register OFF');
        }
      },
      error: (error) => {
        console.error('Error while calling UpdateAutoRegisterFlag API:', error);
        this.toast.showError('Some error occured, please Retry');
        // Handle the error or show an error message to the user
      },
    });
  }
}
