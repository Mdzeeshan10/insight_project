import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserUpdateService {
  private userAddedSource = new Subject<void>();
  private groupAddedSource = new Subject<void>();

  userAdded$ = this.userAddedSource.asObservable();
  groupAdded$ = this.groupAddedSource.asObservable();

  notifyUserAdded(): void {
    this.userAddedSource.next();
  }

  notifyGroupAdded(): void {
    this.groupAddedSource.next();
  }
}
