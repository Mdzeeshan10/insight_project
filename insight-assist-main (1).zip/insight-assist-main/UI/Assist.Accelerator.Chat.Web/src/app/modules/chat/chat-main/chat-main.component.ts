import { Component, ElementRef, NgZone, OnDestroy, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'chat-main',
  templateUrl: './chat-main.component.html',
  styleUrls: ['./chat-main.component.scss']
})
export class ChatMainComponent implements OnInit, OnDestroy {
  height$ = new BehaviorSubject<number>(0);
  observer: ResizeObserver | null = null;

  constructor(private host: ElementRef, private zone: NgZone) { }

  ngOnInit() {
    this.observer = new ResizeObserver(entries => {
      entries.forEach(entry => {
        this.zone.run(() => {
          this.height$.next(entry.contentRect.height);
          const conversationDiv = document.getElementById('main-conversation');
          conversationDiv?.scrollTo(0, conversationDiv.scrollHeight);
        });
      });
    });
    this.observer.observe(this.host.nativeElement.querySelector('#conversation-wrapper'));
  }

  ngOnDestroy(): void {
    if(this.observer) {
      this.observer.unobserve(this.host.nativeElement.querySelector('#conversation-wrapper'));
    }
  }
}
