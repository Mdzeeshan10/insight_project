import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConversationComponent } from './conversation.component';
import { BehaviorSubject } from 'rxjs';

describe('ConversationComponent', () => {
  let component: ConversationComponent;
  let mockChatStateService: any;

  mockChatStateService = { SplashScreen$: new BehaviorSubject(null) };

  beforeEach(async () => {
    component = new ConversationComponent(mockChatStateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
