import { Component, Input } from '@angular/core';

@Component({
  selector: 'streaming-status',
  templateUrl: './streaming-status.component.html',
  styleUrls: ['./streaming-status.component.scss'],
})
export class StreamingStatusComponent {
  @Input() statusText = '';
}
