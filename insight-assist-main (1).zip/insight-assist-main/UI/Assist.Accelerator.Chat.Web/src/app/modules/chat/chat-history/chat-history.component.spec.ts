import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatHistoryComponent } from './chat-history.component';
import { BehaviorSubject, of } from 'rxjs';

describe('ChatHistoryComponent', () => {
  let component: ChatHistoryComponent;
  let mockChatStateService: any;
  let mockRouter: any;

  mockChatStateService = { History$: new BehaviorSubject(null) };

  beforeEach(async () => {
    component = new ChatHistoryComponent(mockChatStateService, mockRouter);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
