import { Component, OnInit } from '@angular/core';
import { Chart, registerables } from 'chart.js';


Chart.register(...registerables);
@Component({
  selector: 'dashboard-queries',
  templateUrl: './dashboard-queries.component.html',
  styleUrls: ['./dashboard-queries.component.scss'],
})
export class DashboardQueriesComponent implements OnInit {
  ngOnInit(): void {
    var myChart = new Chart('queries-by-type', {
      type: 'doughnut',
      data: {
        labels: ['Legal', 'Inventory', 'Product', 'Misc', ],
        datasets: [
          {
            label: '# of Votes',
            data: [40,30,20,20],
            backgroundColor: [
              '#B01C87',
              '#D30C55',
              '#4F93D9',
              '#3E332D',
            ],

          },
        ],
      },
      options: {
        scales: {
          // y: {
          //   beginAtZero: true,
          // },
        },
      },

    });

    var myChart2 = new Chart('queries-by-team', {
      type: 'bar',
      data: {
        labels: ['Legal', 'Inventory', 'Product', 'Misc', ],
        datasets: [
          {
            label: 'Legal',
            data: [40,30,20,20],
            backgroundColor: [
              '#B01C87',
              '#D30C55',
              '#4F93D9',
              '#3E332D',
            ],

          },
        ],
      },
      options: {
        indexAxis: 'y',
        scales: {
          // y: {
          //   beginAtZero: true,
          // },
        },
      },
      // plugins: {
      //   legend: {
      //     position: 'right',
      //   },
      // },
    });

  }
}
