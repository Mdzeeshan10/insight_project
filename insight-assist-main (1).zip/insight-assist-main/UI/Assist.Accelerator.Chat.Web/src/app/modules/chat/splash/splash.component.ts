import { Component, OnInit, Output, EventEmitter, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { splashSuggestionModel } from './splash.model';
import { ChatSamplePrompts } from './data';
import { ChatStateService } from 'src/app/core/store/chat-state.service';
import { MessageParserService } from 'src/app/core/services/message-parser.service';
import { Copilot } from 'src/app/core/models/copilot';

@Component({
  selector: 'chat-splash',
  templateUrl: './splash.component.html',
  styleUrls: ['./splash.component.scss'],
})

/**
 * Chat Component
 */
export class SplashComponent implements OnInit, AfterViewInit {
  @Output() splashItemPicked = new EventEmitter<any>();
  @Output() splashItemFavorite = new EventEmitter<any>();
  @ViewChild('swiperContainer') private swiperContainer!: ElementRef;

  public config = {
    spaceBetween: 10,
    slidesPerView: 'auto',
    navigation: true,
    injectStyles: [
      `
        :host .swiper-button-next {
          margin-top: calc(-190px - (var(--swiper-navigation-size)/ 2));
        }
        :host .swiper-button-prev {
          margin-top: calc(-190px - (var(--swiper-navigation-size)/ 2));
          left: unset;
          right: calc(var(--swiper-navigation-size) + var(--swiper-navigation-sides-offset,10px) * 2);
        }
      `
    ],
  }
  copilotsRetrieved = false;
  viewInitialized = false;
  chatSamplePrompts!: splashSuggestionModel;

  constructor(
    public chatStateService: ChatStateService,
    private messageParserService: MessageParserService
  ) { }

  ngOnInit(): void {
    console.log('SplashComponent initialized');
    this.chatSamplePrompts = ChatSamplePrompts;
    this.chatStateService.Copilots$.subscribe(copilots => {
      this.copilotsRetrieved = true;
      this.initSwiper();
    });
  }

  ngAfterViewInit() {
    this.viewInitialized = true;
    this.initSwiper();
  }

  initSwiper() {
    if(this.swiperContainer) {
      this.swiperContainer.nativeElement.style.setProperty('--swiper-theme-color', '#d40a54');
      this.swiperContainer.nativeElement.style.setProperty('--swiper-navigation-color', '#000000');
      this.swiperContainer.nativeElement.style.setProperty('--swiper-navigation-size', '12px');
    }
  }

  handleSplashItemPicked(text: string) {
    let message = this.messageParserService.createUserMessage(text);
    this.chatStateService.addMessage(message);
  }

  handleCopilotAdded(copilot: Copilot) {
    let message = this.messageParserService.createSystemMessage(copilot.introMessage, copilot.id);
    
    this.chatStateService.newChatWithCopilot(copilot.id);
    this.chatStateService.replaceMessages(message);
  }

  handleSplashItemFavorite(event: Event, id: any) {
    // event.stopPropagation(); // consume click before it hits the parent card
    // this.splashItemFavorite.emit(
    //   this.chatSamplePrompts.find(p => p.id == id));
  }
}
