import { Component } from '@angular/core';

@Component({
  selector: 'dashboard-data-sources',
  templateUrl: './dashboard-data-sources.component.html',
  styleUrls: ['./dashboard-data-sources.component.scss']
})
export class DashboardDataSourcesComponent {

}
