import { Component, Input } from '@angular/core';
import { ChatStateMessage } from 'src/app/core/models/chat-message';
import { MarkdownModule } from 'ngx-markdown';
import { MessageParserService } from 'src/app/core/services/message-parser.service';
import { MessageChunk } from 'src/app/pages/apps/chat/chat.model';
import { messages } from '../../../core/store/chat.reducer';
import { ChatStateService } from 'src/app/core/store/chat-state.service';

@Component({
  selector: 'bot-message',
  templateUrl: './bot-message.component.html',
  styleUrls: ['./bot-message.component.scss'],
})
export class BotMessageComponent {
  constructor
    (
    public chatStateService: ChatStateService,
    public messageParserService: MessageParserService
  )
  {
    /*chatStateService.ChatId$.subscribe((conversationId) => {
      this.chatId = conversationId;
    });
    chatStateService.Messages$.subscribe((object) => {
      if (Array.isArray(object) && object.length > 0) {
        this.messageId = object[0].id;
      } else {
        // Handle the case where the JSON object is empty or not an array
        this.messageId = '';
      }
    });*/
  }
  /*public chatId = '';
  public messageId: any = '';*/
  @Input() chatMessage: ChatStateMessage = {
    id: '',
    text: '',
    from: '',
    time: '',
    chunks: [],
  };
  @Input() selectedChatHistoryId: string = '';
  openUrl(url: string) {
    window.open(url);    
  }
  /*ngOnChanges() {
    console.log('selectedConversaionId-bot:', this.chatMessage.id);
    console.log('selectedChatHistoryId-bot:', this.selectedChatHistoryId);
  }*/
}
