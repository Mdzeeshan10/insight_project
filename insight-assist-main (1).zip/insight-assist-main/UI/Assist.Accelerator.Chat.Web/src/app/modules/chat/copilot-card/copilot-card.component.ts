import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Copilot } from 'src/app/core/models/copilot';

@Component({
  selector: 'app-copilot-card',
  templateUrl: './copilot-card.component.html',
  styleUrls: ['./copilot-card.component.scss'],
})
export class CopilotCardComponent {
  @Input() copilot: Copilot = {
    id: 0,
    name: '',
    description: '',
    introMessage: '',
    fileTypes: '',
    imageURL: '',
    subTitle:''
  };
  @Output() copilotClick: EventEmitter<Copilot> = new EventEmitter();

  copilotClicked(copilot: Copilot) {
    this.copilotClick.emit(copilot);
  }
}
