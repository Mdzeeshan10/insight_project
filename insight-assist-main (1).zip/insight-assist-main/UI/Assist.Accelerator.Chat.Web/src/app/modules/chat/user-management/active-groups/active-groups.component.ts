import { HttpClient, HttpParams } from '@angular/common/http';
import { Component } from '@angular/core';
import { ToastService } from 'src/app/toast.service';
import { UserUpdateService } from '../user-update.service';
import { environment } from 'src/environments/environment';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import {MatMenuModule} from '@angular/material/menu'; 
import { MatDialog } from '@angular/material/dialog';
import {GroupDetailsModalComponent} from '../group-details-modal/group-details-modal.component';

interface group {
  groupId: number;
  groupName: string;
  objectId: string;
  model_Control: boolean;
  isActive: boolean;
}

interface GroupResponse {
  groups: group[];                                              
  totalCount: number;
}
interface GroupRole { roleId: number; roleName: string; }

@Component({
  selector: 'app-active-groups',
  templateUrl: './active-groups.component.html',
  styleUrls: ['./active-groups.component.scss'],
})
export class ActiveGroupsComponent {
  activeGroupSearchKeyword: string = '';
  activeGroups: any[] = [];
  prevRoleId: number = 0;
  currentPage: number = 1;
  pageSize: number = 10;
  totalCount: number = 0;
  pageNumbers: number[] = [];
  totalPages: number = 0;
  groupRoles: GroupRole[] = [
    { roleId: 1, roleName: 'Admin' },
    { roleId: 2, roleName: 'User' },
  ];

  isGroup: boolean = true;
  groups: group[] = [];
  pageCoung: number = 0;
  cmp: GroupResponse = { groups: [], totalCount: 0 };
  x: group[] = [];

  constructor(
    private http: HttpClient,
    public toastService: ToastService,
    private userUpdateService: UserUpdateService,
    private dialog: MatDialog
  ) { }

  ngOnInit() {
    this.loadActiveGroups();

    this.userUpdateService.groupAdded$.subscribe(() => {
      this.loadActiveGroups();
    });
  }

  loadActiveGroups() {
    const filter = this.activeGroupSearchKeyword;

    const params = new HttpParams()
      .set('filter', filter || '')
      .set('pageNumber', this.currentPage.toString())
      .set('pageSize', this.pageSize.toString());

    this.http
      .get<any[]>(environment.usersApi + '/GetApplicationGroups', {
        params,
      })
      .subscribe({
        next: (response: any) => {
          this.activeGroups = response.groups.map((groups: any) => {
            return groups;
          });
          console.log('active groups', this.activeGroups);
          this.totalCount = response.pageCount;

          this.totalPages = Math.ceil(this.totalCount / this.pageSize);

          console.log('total pages', this.totalPages);

          this.calculateDisplayedPageNumbers();
        },
        error: (error: any) => {
          console.error('Error loading active users:', error);
          this.toastService.showError('Error loading active users');
        },
      });
  }

  searchActiveGroups() {
    this.currentPage = 1; //Reset to the first page
    this.loadActiveGroups();
  }

  calculateDisplayedPageNumbers(): number[] {
    const displayedPages = [];
    const maxDisplayedPages = 5; // Maximum number of page numbers to display

    // Calculate the start and end page numbers for the displayed range
    let startPage = this.currentPage - Math.floor(maxDisplayedPages / 2);
    let endPage = this.currentPage + Math.floor(maxDisplayedPages / 2);

    // Adjust the start and end page numbers if they go beyond the valid range
    if (startPage < 1) {
      startPage = 1;
      endPage = Math.min(maxDisplayedPages, this.totalPages);
    }

    if (endPage > this.totalPages) {
      endPage = this.totalPages;
      startPage = Math.max(1, this.totalPages - maxDisplayedPages + 1);
    }

    // Generate the array of displayed page numbers
    for (let i = startPage; i <= endPage; i++) {
      displayedPages.push(i);
    }

    return displayedPages;
  }

  goToPage(pageNumber: number) {
    if (pageNumber >= 1 && pageNumber <= this.totalPages) {
      this.currentPage = pageNumber;
      this.loadActiveGroups();
    }
  }

  toggleGroupStatus(group: any) {
    const status = group.isActive;
    const userId = group.groupId.toString();
    const url = environment.usersApi + '/ApplicationGroupStatus';
    const body = { userId: userId, status: status };
    let params = new HttpParams();
    params = params.set('userId', userId);
    params = params.set('status', status.toString());
    this.http.post(url, null, { params }).subscribe(
      (response) => {
        if (group.isActive === true) {
          console.log('ToggleGroupStatus API response:', response);
          this.toastService.showSuccess(
            'Group Status Successfully Changed to Active'
          );
        } else {
          this.toastService.showSuccess(
            'Group Status Successfully Changed to Inactive'
          );
        }
        // Handle the successful response if needed
      },
      (error) => {
        console.error('Error while calling ToggleUserStatus API:', error);
        this.toastService.showError('Error while changing User Status');
        // Handle the error or show an error message to the user
        // Revert the toggle switch state if necessary
        group.isActive = !group.isActive;
      }
    );
  }

  toggleModelStatus(group: any) {
    const status = group.model_Control;
    const userId = group.groupId.toString();
    const isGroup = this.isGroup;
    const url = environment.usersApi + '/ToggleModelControl';
    const body = { Id: userId, status: status, isGroup: isGroup };
    let params = new HttpParams();
    params = params.set('Id', userId);
    params = params.set('status', status.toString());
    params = params.set('isGroup', isGroup.toString());
    this.http.post(url, null, { params }).subscribe(
      (response) => {
        if (group.model_Control === true) {
          console.log('ToggleModelStatus API response:', response);
          this.toastService.showSuccess(
            'Model Status Successfully Changed to Active'
          );
        } else {
          this.toastService.showSuccess(
            'Model Status Successfully Changed to Inactive'
          );
        }
        // Handle the successful response if needed
      },
      (error) => {
        console.error('Error while calling ToggleModelStatus API:', error);
        this.toastService.showError('Error while changing Model Status');
        // Handle the error or show an error message to the user
        // Revert the toggle switch state if necessary
        group.model_Control = !group.model_Control;
      }
    );
  }

  onMatSelectOpen(user: any): void {
    this.prevRoleId = user.roleId;
  }

  toggleGroupRole(group: any) {
    const roleId = group.roleId == 1 ? 1 : 2;
    const prevRole = this.prevRoleId;
    const groupIds = group.groupId.toString();
    const url = environment.usersApi + '/UpdateGroupRole';
    const body = { GroupId: groupIds, RoleId: roleId };
    let params = new HttpParams();
    params = params.set('GroupId', groupIds);
    params = params.set('RoleId', roleId);
    this.http.post(url, null, { params }).subscribe(
      (response) => {
        if (roleId === 1) {
          console.log('ToggleUserStatus API response:', response);
          this.toastService.showSuccess(
            'Group Role Successfully Changed to Admin'
          );
        } else {
          this.toastService.showSuccess(
            'Group Role Successfully Changed to User'
          );
        }
        // Handle the successful response if needed
      },
      (error) => {
        console.error('Error while calling ToggleGroupRole API:', error);
        if (error.status === 500) {
          this.toastService.showError(error.error);
          group.roleId = prevRole; //Revert the user's role to old role
        }
        else {
          this.toastService.showError("An unexpected error occurred while changing Group Role.");
        }

        // Handle the error or show an error message to the user
        // Revert the toggle switch state if necessary
        /* user.isActive = !user.isActive;*/
      }
    );
  }
  isAnyUserSelected() {
    return this.activeGroups.some((group) => group.selected);
  }

  compareRoles(role1: GroupRole, role2: GroupRole) {
    return role1 && role2 ? role1.roleId === role2.roleId : role1 === role2;
  }

  openDetailsDialog(group:any) {
    const dialogRef = this.dialog.open(GroupDetailsModalComponent, {
      width: '65%',
      height: '95%',
      data: { group },
    });
  }
}
