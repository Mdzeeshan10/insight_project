import { ComponentFixture, TestBed } from '@angular/core/testing';
import { StreamingStatusComponent } from './streaming-status.component';

describe('StreamingStatusComponent', () => {
  let component: StreamingStatusComponent;
  let fixture: ComponentFixture<StreamingStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [StreamingStatusComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(StreamingStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
