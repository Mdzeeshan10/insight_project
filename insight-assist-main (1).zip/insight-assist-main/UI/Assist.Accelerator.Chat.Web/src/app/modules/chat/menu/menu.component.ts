import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserProfileService } from 'src/app/core/services/user.service';
import { ChatStateService } from 'src/app/core/store/chat-state.service';

@Component({
  selector: 'chat-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss'],
})
export class MenuComponent {

  private isConversationVisible: boolean = false;
  public selectedChatHistoryId: string = '';
  public shouldShowSplash: boolean = true;
  public chatId = '';
  constructor(
    public chatStateService: ChatStateService,
    private userProfileService: UserProfileService,
    private router: Router
  ) {
    this.chatStateService.ChatId$.subscribe((chatId) => {
      this.chatId = chatId;
      console.log('chat ID conversation:', this.chatId);
    });
    chatStateService.showSplashScreen();
    chatStateService.SplashScreen$.subscribe((splashScreen) => {
      this.isConversationVisible = !splashScreen;
      this.shouldShowSplash = splashScreen && this.chatId == '' && this.router.url == '';
    });
    this.chatStateService.loadUser();
  }
  logout() {

    this.userProfileService.logout();

  }
  newChat() {
    this.chatStateService.newChat();
    this.router.navigate(['']);
  }
}
