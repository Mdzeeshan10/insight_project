export interface splashSuggestionModel {
  //trending: string[];
  examples: string[];
  capabilities: string[];
  limitations: string[];
  //shared: string[];
}

