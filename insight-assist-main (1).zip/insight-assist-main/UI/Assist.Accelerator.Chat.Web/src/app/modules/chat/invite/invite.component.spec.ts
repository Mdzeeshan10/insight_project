import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InviteComponent } from './invite.component';

describe('InviteComponent', () => {
  let component: InviteComponent;
  let mockHttpClient:any;
  let mockMsalService: any;
  let mockToastrService: any;

  beforeEach(async () => {

    component = new InviteComponent(mockHttpClient, mockMsalService, mockToastrService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
