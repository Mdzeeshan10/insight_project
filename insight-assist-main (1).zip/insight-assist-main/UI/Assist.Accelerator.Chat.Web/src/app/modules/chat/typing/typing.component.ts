import { Component } from '@angular/core';
import { ChatStateService } from 'src/app/core/store/chat-state.service';

@Component({
  selector: 'chat-typing',
  templateUrl: './typing.component.html',
  styleUrls: ['./typing.component.scss']
})
export class TypingComponent {
  constructor(public chatStateService: ChatStateService) {};
}
