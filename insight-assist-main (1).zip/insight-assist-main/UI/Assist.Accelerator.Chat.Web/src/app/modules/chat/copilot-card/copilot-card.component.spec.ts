import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CopilotCardComponent } from './copilot-card.component';

describe('CopilotCardComponent', () => {
  let component: CopilotCardComponent;
  let fixture: ComponentFixture<CopilotCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CopilotCardComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(CopilotCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
