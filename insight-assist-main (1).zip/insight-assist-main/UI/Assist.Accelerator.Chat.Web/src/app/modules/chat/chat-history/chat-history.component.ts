import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { ChatHistory } from 'src/app/core/models/chat-history';
import { ChatState } from 'src/app/core/store/chat-state';
import { ChatStateService } from 'src/app/core/store/chat-state.service';


@Component({
  selector: 'chat-history',
  templateUrl: './chat-history.component.html',
  styleUrls: ['./chat-history.component.scss'],
})
export class ChatHistoryComponent implements OnInit {
  constructor(
    public chatStateService: ChatStateService,
    private router: Router,
    private store: Store<{ chat: ChatState }>,
  ) {
    chatStateService.ChatId$.subscribe((chatId) => {
      if (this.x == true) { this.chat = chatId; }
      else { this.selectedId = chatId; }
      this.x = false;
    });
    chatStateService.History$.subscribe((history) => {
      console.log("HISTORY", history);
      this.confirmDeleteMap = new Map<string, boolean>();
      this.confirmEditMap = new Map<string, boolean>();
      this.showLoading = '';
    });
  }

  public confirmDeleteMap = new Map<string, boolean>();
  public confirmEditMap = new Map<string, boolean>();
  public showLoading = '';
  public selectedId = '';
  /*public chatId = '';*/
  public editing = false;
  public x = false;
  public deleteing = false;
  public chat = '';
 

  ngOnInit(): void {
    //logging
    this.chatStateService.loadChatHistory();
    this.chatStateService.getCopilots();
  }

  
  public async editChatName(chatHistory: ChatHistory, id: string, newTitle: string) {
    this.editing = false;
    this.showLoading = id;
    var newChatHistory: ChatHistory = {
      id: chatHistory.id,
      title: newTitle,
      messages: chatHistory.messages,
    };
    this.chatStateService.setSelectedChatHistory(newChatHistory);
    this.chatStateService.editChatHistoryItem(id, newTitle);
  }

  public async deleteChat(id: string) {
    this.showLoading = id;
    this.chatStateService.deleteChathistoryItem(id);
    this.x = true;
    console.log("Select Chatid", this.selectedId);
    this.chatStateService.newChat();
  }
  public showEditing(id: string): boolean {
    return this.selectedId === id && this.editing;
  }
  public showSelected(id: string): boolean {
    return this.selectedId === id && !this.editing && !this.deleteing;
  }
  public showDeleting(id: string): boolean {
    return this.selectedId === id && this.deleteing;
  }
  public goTohistory(chatHistory: ChatHistory) {
    this.editing = false;
    this.deleteing = false;
    this.selectedId = chatHistory.id;
    console.log("Selected Id", this.selectedId);
    this.chatStateService.setSelectedChatHistory(chatHistory);
    this.chatStateService.selectChathistory(chatHistory.id);
    this.router.navigate(['']);
  }
}
