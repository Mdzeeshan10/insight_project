import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderComponent } from './header.component';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let mockChatStateService: any;
  let mockRouter: any;

  beforeEach(async () => {
    component = new HeaderComponent(mockChatStateService, mockRouter);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
