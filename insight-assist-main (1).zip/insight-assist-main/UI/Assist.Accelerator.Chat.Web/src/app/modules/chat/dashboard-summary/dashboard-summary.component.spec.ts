import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardSummaryComponent } from './dashboard-summary.component';

describe('DashboardSummaryComponent', () => {
  let component: DashboardSummaryComponent;
  let mockChatStateService: any;
  let mockMatDialog: any;

  beforeEach(async () => {

    component = new DashboardSummaryComponent(mockChatStateService, mockMatDialog);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
