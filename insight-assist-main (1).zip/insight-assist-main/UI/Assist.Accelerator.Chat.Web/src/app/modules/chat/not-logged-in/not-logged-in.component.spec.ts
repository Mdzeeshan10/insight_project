import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotLoggedInComponent } from './not-logged-in.component';

describe('NotLoggedInComponent', () => {
  let component: NotLoggedInComponent;
  let mockUserProfileService: any;

  beforeEach(async () => {

    component = new NotLoggedInComponent(mockUserProfileService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
