import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ChatStateService } from 'src/app/core/store/chat-state.service';

@Component({
  selector: 'chat-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  constructor(public chatStateService: ChatStateService,
    private router: Router){

  }
  newChat()
  {
    this.chatStateService.newChat();
    this.router.navigate(['']);
  }
}
