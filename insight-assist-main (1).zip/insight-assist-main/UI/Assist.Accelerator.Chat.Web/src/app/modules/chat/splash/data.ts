const ChatSamplePrompts = {

  examples: [
    'What is Generative AI, and what are some tips and tricks for working with it?',
    'Where can I learn more about Generative AI?',
    'How do I write a blog post about working with Generative AI?'
  ],
  capabilities: [
    'Remembers what user said earlier in the conversation',
    'Allows user to provide follow-up corrections',
    'Trained to decline inappropriate requests'
  ],
  limitations: [
    'May occasionally generate incorrect information',
    'May occasionally produce harmful instructions or biased content',
    'Limited knowledge of world and events after 2021'
  ]

};
export { ChatSamplePrompts };
