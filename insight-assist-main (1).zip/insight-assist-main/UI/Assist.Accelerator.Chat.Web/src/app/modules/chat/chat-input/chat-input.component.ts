import { DatePipe } from '@angular/common';
import { Component, ElementRef, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
} from '@angular/forms';
import { Subject } from 'rxjs';
import { ChatStateMessage } from 'src/app/core/models/chat-message';
import { ChatStreamingService } from 'src/app/core/services/chat-streaming.service';
import { ChatStateService } from 'src/app/core/store/chat-state.service';

// let userText: string;
@Component({
  selector: 'chat-input',
  templateUrl: './chat-input.component.html',
  styleUrls: ['./chat-input.component.scss'],
})
export class ChatInputComponent {
  @ViewChild('userText') userText!: ElementRef;

  isUploading: boolean = false;
  isAiResponding: boolean = false;
  currentCopilotId: number | undefined = undefined;
  files: string[] = [];
  responseStatus: string = '';
  onClearFiles: Subject<void> = new Subject<void>();
  chatInputForm: FormGroup;
  chatInput: FormControl = new FormControl(
    [],
    [
      () => this.isUploading ? {isFileUploading: {valid: false}} : null,
      () => this.isAiResponding ? {isAiResponding: {valid: false}} : null
    ]
  );

  constructor(
    public chatStateService: ChatStateService,
    public chatStreamingService: ChatStreamingService,
    private datePipe: DatePipe,
    private formBuilder: FormBuilder
  ) {
    this.chatInput.setValue('');
    this.chatInputForm = this.formBuilder.group({
      chatInput: this.chatInput,
    });
    this.chatStateService.ChatId$.subscribe({
      next: (chatId) => {
        this.chatId = chatId;
      }
    })
    this.chatStateService.selectedChathistory$.subscribe({
      next: (history) => {
        this.currentCopilotId = history?.copilotId;
      }
    })
    this.chatStateService.Messages$.subscribe({
      next: (messages) => {
        if (messages && messages.length > 0) {
          this.currentCopilotId = messages[0].copilotId;
          this.isAiResponding = 
            messages[messages.length - 1].from === 'user'
            || messages[messages.length - 1].streaming === true;
          this.updateValidity();
        }
      }
    })
    this.chatStateService.AttachedFiles$.subscribe({
      next: (files) => {
        this.files = files.map(f => f.name);
      }
    })

    this.chatStreamingService.responseStreamingStatus$.subscribe({
      next: (status) => {
        this.responseStatus = status;
      }
    })
  }
  public chatId = '';
  onSubmit() {
    let userMessage: ChatStateMessage = {
      id: this.chatId,
      from: 'user',
      text: this.chatInput.value,
      time: this.datePipe.transform(new Date(), 'h:mm a')!,
      chunks: [],
      file: this.files?.length > 0 ? this.files[0] : undefined,
      copilotId: this.currentCopilotId
    };
    this.chatStateService.addMessage(userMessage);
    this.clearInput();
    this.isAiResponding = true;
  }

  updateValidity() {
    this.chatInput.updateValueAndValidity();
  }

  onIsUploadingEvent(value: any) {
    this.isUploading = value;
    this.updateValidity();
  }

  onFilesEvent(value: any) {
    this.files = value;
    this.updateValidity();
  }

  clearInput() {
    this.chatInput.setValue("");
    this.onClearFiles.next();
  }
}
