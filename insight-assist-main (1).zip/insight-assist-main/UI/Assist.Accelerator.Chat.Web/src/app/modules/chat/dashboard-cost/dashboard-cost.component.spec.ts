import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardCostComponent } from './dashboard-cost.component';

describe('DashboardCostComponent', () => {
  let component: DashboardCostComponent;
  let mockChatStateService: any;
  let mockMatDialog: any

  beforeEach(async () => {

    component = new DashboardCostComponent(mockChatStateService, mockMatDialog);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
