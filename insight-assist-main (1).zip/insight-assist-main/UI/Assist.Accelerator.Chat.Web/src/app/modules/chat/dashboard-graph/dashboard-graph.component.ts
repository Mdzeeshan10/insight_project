import { Component, ViewChild } from "@angular/core";
import { ChatStateService } from 'src/app/core/store/chat-state.service';
import { dateToMidnightUTC, getShortDateString, getUTCShortDateString } from 'src/app/shared/date-utils';
let moment = require('moment');

import {
  ChartComponent,
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  ApexYAxis,
  ApexDataLabels,
  ApexTitleSubtitle,
  ApexStroke,
  ApexGrid,
  ApexLegend,
  ApexFill,
  ApexTooltip
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  fill: ApexFill;
  dataLabels: ApexDataLabels;
  grid: ApexGrid;
  stroke: ApexStroke;
  title: ApexTitleSubtitle;
  legend: ApexLegend;
  yAxis: ApexYAxis;
  tooltip: ApexTooltip;
};

@Component({
  selector: 'dashboard-graph',
  templateUrl: './dashboard-graph.component.html',
  styleUrls: ['./dashboard-graph.component.scss']
})
export class DashboardGraphComponent {
  public chartOptions?: Partial<ChartOptions>;
  public chartSeries?: ApexAxisChartSeries;
  public xaxis?: ApexXAxis;
  public selectedStat: number = 1;
  public name: string = '';
  public statSpan: number = 0;
  public start: Date = new Date();
  public end: Date = new Date();
  public startDateTime = new Date();
  public startDate:string='';
  public endDate :string='';
  public statName: string = '';
  public costUnitsPerDollar = 100000000;

  constructor(public chatStateService: ChatStateService) {
    this.chatStateService.AdminGraph$.subscribe((stat) => {
      if (stat) {
        this.name = stat.name;
        this.statSpan = stat.span;

        const startDate = moment.utc(`${stat.startDateTime}+00`);
        this.startDateTime = startDate.toDate();

        let xStart = 0, xEnd = 0;
        switch (stat.span) {
          case 1:
            xEnd = 60;
            break;
          case 2:
            xEnd = 24;
            break;
          case 3:
            xStart = 1;
            xEnd = startDate.daysInMonth();
            break;
          case 4:
            xStart = 1;
            xEnd = 12;
            break;
        };
        const seriesData = [];
        //span:4 =>Month, span:3 =>Day, span:2 => Hour, span:1 =>Minute
        if (stat.name === "CombinedStats" && stat.span === 3) {

          const dayOfYearKeys = Object.keys(stat.data).map(Number);
          xStart = Math.min(...dayOfYearKeys);
          xEnd = Math.max(...dayOfYearKeys);
          this.start = this.convertDayOfYearToDate((xStart), startDate.year());
          this.end = this.convertDayOfYearToDate((xEnd - 1), startDate.year());
          const xRange = Array.from({ length: xEnd - xStart }, (_, i) => i + xStart);

          const delta: { [key: string]: string } = { '1': 'm', '2': 'h', '3': 'd', '4': 'd' };
          const spanDuration = delta[stat.span.toString()];

          for (let i = 0; i < xRange.length; i++) {
            const date = this.convertDayOfYearToDate(xRange[i], startDate.year());
            const utcDate = dateToMidnightUTC(date);
            seriesData.push([
              utcDate.getTime(),
              stat.data[xRange[i]] || 0,
            ]);
            // startDate.add(stat.span === 4 ? 31 : 1, spanDuration);
          }
          console.log("Series Data", seriesData);
        }
        else {
          const xRange = Array.from({ length: xEnd }, (_, i) => i + xStart);

          const delta: { [key: string]: string } = { '1': 'm', '2': 'h', '3': 'd', '4': 'd' };
          const spanDuration = delta[stat.span.toString()];

          for (let i = 0; i < xRange.length; i++) {
            seriesData.push([
              startDate.toDate(),
              stat.data[xRange[i]]
            ]);
            startDate.add(stat.span === 4 ? 31 : 1, spanDuration);
          }
        }
        let primaryColor = "#d40a54";
        if(document.querySelector("#primary")){
          primaryColor = window.getComputedStyle(
            document.querySelector("#primary")!
          ).background;
        }

        switch (stat.index) {
          case 0:
            this.statName = "Active Users";
            break;
          case 1:
            this.statName = "Total Coversations";
            break;
          case 2:
            this.statName = "Average Chats Per User";
            break;
          case 3:
            this.statName = "Average Response Time";
            break;
          case 4:
            this.statName = "Quota Used";
            break;
          case 5:
            this.statName = "Quota Limit";
            break;
          case 6:
            this.statName = "Average Cost Per User";
            break;
          case 7:
            this.statName = "Average Cost Per Chat";
            break;
          case 8:
            this.statName = "Total Interactions";
            break;
        };
        this.chartSeries = [
          {
            name: this.statName,
            data: seriesData,
            color: primaryColor
          }
        ];

        this.xaxis = {
          type: "datetime",
          labels: {
            datetimeUTC: true,
            datetimeFormatter: {
              year: 'yyyy',
              month: "MMM 'yy",
              day: 'd MMM',
              hour: 'htt',
              minute: 'h:mm tt',
            },
          }
        };


        const tooltipFormats: { [key: string]: string } = {
          '1': 'MMM d, yyyy h:mmtt',
          '2': 'MMM d, yyyy htt',
          '3': 'MMM d, yyyy',
          '4': 'MMM yyyy',
        };

        if(this.chartOptions) {
          this.chartOptions!.tooltip!.x!.format = tooltipFormats[stat.span.toString()];
        }
      }
    });
  }

  ngOnInit() {
    this.chartOptions = {
      chart: {
        height: 250,
        width: '100%',
        type: "area",
        zoom: {
          enabled: false
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: "smooth",
        width: 2
      },
      grid: {
      },
      legend: {
        showForSingleSeries: true,
        fontSize: '14px',
        fontFamily: 'Open Sans',
        fontWeight: 400,
      },
      fill: {
        colors: ['#000000']
      },
      yAxis: {
        min: 0,
        tickAmount: 5,
        labels: {
          formatter: (val) => val.toString()
        }
      },
      tooltip: {
        x: {
          format: 'MMM d yyyy h:mmtt'
        }
      }
    };

    this.selectStat(4);
  }

  selectStat(index: number) {
    const newEndDate = new Date(this.startDateTime);
    newEndDate.setDate(newEndDate.getDate() + 33);

    //Initialising startDate and endDate by checking the statSpan
     //span:4 =>Month, span:3 =>Day, span:2 => Hour, span:1 =>Minute
    switch (this.statSpan) {
      case 2:
        this.startDate = getUTCShortDateString(this.startDateTime);
        this.endDate = getUTCShortDateString(this.startDateTime);
        break;
      case 3:
        this.startDate = getShortDateString(this.start);
        this.endDate = getShortDateString(this.end);
        break;
      case 4:
        this.startDate = getShortDateString(this.startDateTime);
        this.endDate = getShortDateString(newEndDate);
        break;
    };
    
    if (this.name === "CombinedStats") {
      this.chatStateService.selectKpiRange(index, this.startDate, this.endDate);
    }
    else {
      this.chatStateService.selectKpi(index);
    }

    if (index === 4 || index == 6) {
      this.chartOptions!.yAxis!.labels!.formatter = (val) => {
        if (val > 0 && val < this.costUnitsPerDollar / 100) {
          return '<$0.01';
        }
        else {
          return `$${(val / this.costUnitsPerDollar).toFixed(2).toString()}`;
        }
      }
    } else {
      this.chartOptions!.yAxis!.labels!.formatter = (val) => (Math.round(val * 100) / 100).toString()
    }
  }

  convertDayOfYearToDate(datOfYear: number, year: number): Date {
    const date = new Date(year, 0); // January 1st of given year
    date.setDate(datOfYear);
    return date;
  }
}
