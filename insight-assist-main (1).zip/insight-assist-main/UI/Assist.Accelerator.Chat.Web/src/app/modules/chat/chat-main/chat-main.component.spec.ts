import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatMainComponent } from './chat-main.component';

describe('ChatMainComponent', () => {
  let component: ChatMainComponent;

  beforeEach(async () => {
    component = new ChatMainComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
