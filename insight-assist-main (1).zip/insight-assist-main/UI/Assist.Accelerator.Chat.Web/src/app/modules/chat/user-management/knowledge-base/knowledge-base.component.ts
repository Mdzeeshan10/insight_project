import { HttpClient, HttpParams } from '@angular/common/http';
import { Component } from '@angular/core';
import { environment } from '../../../../../environments/environment';
import { ToastService } from '../../../../toast.service';

interface TableSetting {
  indexId: number;
  indexName: string;
  semanticName: string;
  displayName: string;
  isActive: boolean;
  searchUrl: string;
  editMode: boolean;
  conflict: boolean;
}


@Component({
  selector: 'app-knowledge-base',
  templateUrl: './knowledge-base.component.html',
  styleUrls: ['./knowledge-base.component.scss']
})
export class KnowledgeBaseComponent {
  indexSearchKeyword: string = '';
  currentPage: number = 1;
  pageSize: number = 10;
  totalCount: number = 0;
  pageNumbers: number[] = [];
  totalPages: number = 0;

  formSetting = {
    azureSearchUrl: '',
    azureKey: '',
  };

  // tableSettings: TableSetting[] = [
  //   { indexName: 'Index 1', dataSource: 'Data Source 1', isActive: true },
  //   { indexName: 'Index 2', dataSource: 'Data Source 2',  isActive: false},
  //   { indexName: 'Index 3', dataSource: 'Data Source 3',  isActive: true }
  // ];
  tableSettings: TableSetting[] = [];

  constructor(private http: HttpClient, public toastService: ToastService,) { }
  ngOnInit() {
    this.indexTable();
  }

  addSetting() {
    const azureSearchUrl = this.formSetting.azureSearchUrl;
    const azureKey = this.formSetting.azureKey;

    //Make a POST request to create a new setting
    const apiUrl = environment.usersApi + "/GetIndexes";
    const requestBody = {
      azureSearchUrl,
      azureKey
    };

    this.http.post(apiUrl, requestBody).subscribe(
      (response: any) => {
        //Handle successful response
        console.log("Setting added successfully:", response);
        this.toastService.showSuccess('Index added successfully.');

        //Clear form inputs after successful addition
        this.formSetting.azureSearchUrl = '';
        this.formSetting.azureKey = '';
        this.indexTable();
      },
      (error) => {
        console.error('Error while adding setting:', error);
        this.toastService.showError('Unexpected error. Please try again.');


        this.formSetting.azureSearchUrl = '';
        this.formSetting.azureKey = '';
      }
    );
  }

  searchIndex() {
    this.currentPage = 1; //Reset to the first page
    this.indexTable();
  }

  indexTable() {
    const filter = this.indexSearchKeyword;

    const params = new HttpParams()
      .set('filter', filter || '')
      .set('pageNumber', this.currentPage.toString())
      .set('pageSize', this.pageSize.toString());
    //Make a Get request to fetch the settings data
    const apiUrl = environment.usersApi + "/GetInfo";

    this.http
      .get<any[]>(environment.usersApi + '/GetInfo', {
        params,
      }).subscribe(
        (response: any) => {
          //Extracting relevant information
          const indexList = response.indexList;
          const settings = indexList.map((item: any) => ({
            indexId: item.indexId,
            indexName: item.indexName,
            semanticName: item.semanticName,
            displayName: item.displayName,
            isActive: item.isActive,
            searchUrl: item.searchUrl,
            conflict: false,
          }));

          this.tableSettings = settings;
          this.totalCount = response.itemCount;
          this.totalPages = Math.ceil(this.totalCount / this.pageSize);

          this.calculateDisplayedPageNumbers();

          console.log("Item count is", this.totalCount);
          console.log('total pages', this.totalPages);

        },
        (error) => {
          console.error('Error while fetching settings:', error);
        }
      );
  }

  calculateDisplayedPageNumbers(): number[] {
    const displayedPages = [];
    const maxDisplayedPages = 5; // Maximum number of page numbers to display

    // Calculate the start and end page numbers for the displayed range
    let startPage = this.currentPage - Math.floor(maxDisplayedPages / 2);
    let endPage = this.currentPage + Math.floor(maxDisplayedPages / 2);

    // Adjust the start and end page numbers if they go beyond the valid range
    if (startPage < 1) {
      startPage = 1;
      endPage = Math.min(maxDisplayedPages, this.totalPages);
    }

    if (endPage > this.totalPages) {
      endPage = this.totalPages;
      startPage = Math.max(1, this.totalPages - maxDisplayedPages + 1);
    }

    // Generate the array of displayed page numbers
    for (let i = startPage; i <= endPage; i++) {
      displayedPages.push(i);
    }

    return displayedPages;
  }

  goToPage(pageNumber: number) {
    if (pageNumber >= 1 && pageNumber <= this.totalPages) {
      this.currentPage = pageNumber;
      this.indexTable();
    }
  }

  toggleEditMode(setting: TableSetting) {
    setting.editMode = !setting.editMode;
  }


  toggleSetting(setting: TableSetting) {
    // if(!setting.displayName){
    //   setting.isActive=false;
    //   this.toastService.showInfo("Enter your display name first");
    //   console.log('Display name is empty');
    //   return;
    // }
    const indexId = setting.indexId;
    // this.tableSettings.indexOf(setting);
    const status = setting.isActive ? true : false;

    // Make a POST request to update the setting status
    const apiUrl = environment.usersApi + "/DeleteKnowledgeBase";
    let params = new HttpParams();
    params = params.set('indexId', indexId);
    params = params.set('status', status);
    // const requestBody = {
    //   indexId:indexId,
    //   status:status
    // };

    this.http.post(apiUrl, null, { params }).subscribe(
      (response: any) => {
        if (response !== true) {
          setting.isActive = !setting.isActive;
          // setting.conflict=true; //Set the conflict flag to true
          this.toastService.showInfo("Enter your display name first");
        }
        else {
          // setting.conflict = false; //Reset the conflict flag to false
          if (setting.isActive === true) {
            this.toastService.showSuccess(
              'Index status Successfully Changed to Active'
            );
          }
          else {
            this.toastService.showSuccess(
              'Index status Successfully Changed to InActive'
            );
          }

          console.log("Setting status updated successfully:", response);
        }
      },
      (error) => {
        console.error('Error while updating setting status:', error);
      }
    );
  }


  updateDisplayName(setting: TableSetting) {

    //Make API call to update the display name
    const indexId = setting.indexId;
    const displayName = setting.displayName;
    const apiUrl = environment.usersApi + "/DisplayName";
    // const requestBody = {
    //   indexId: setting.indexId,
    //   displayName: setting.displayName
    // };
    let params = new HttpParams();
    params = params.set('indexId', indexId);
    params = params.set('displayName', displayName);

    this.http.post(apiUrl, null, { params }).subscribe(
      (response: any) => {
        console.log("Display name updated successfully:", response);
        this.toastService.showSuccess(
          'Display name Changed successfully'
        );
        setting.editMode = false;
      },
      (error) => {
        console.error("Error while updating display name", error);
        if (error.status === 409) {
          this.toastService.showError("The display name is already in use.Please use a different name.");
          setting.conflict = true;
        }
        else {
          this.toastService.showError("Enter the display name");
          setting.conflict = true;
        }
      }
    );

  }
}
