import { AfterViewInit, Directive, ElementRef, Input } from "@angular/core";

@Directive({
  selector: "[appSwiper]"
})
export class SwiperDirective implements AfterViewInit {
    private readonly swiperElement: HTMLElement;

    @Input() config?: any;

    constructor(private el: ElementRef<HTMLElement>) {
        this.swiperElement = el.nativeElement;
    }

    ngAfterViewInit() {
        Object.assign(this.el.nativeElement, this.config);
        console.log(this.config)
        this.el.nativeElement.style.setProperty('--swiper-theme-color', '#d40a54');
        this.el.nativeElement.style.setProperty('--swiper-navigation-color', '#000000');
        this.el.nativeElement.style.setProperty('--swiper-navigation-size', '12px');
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        this.el.nativeElement.initialize();
    }
}