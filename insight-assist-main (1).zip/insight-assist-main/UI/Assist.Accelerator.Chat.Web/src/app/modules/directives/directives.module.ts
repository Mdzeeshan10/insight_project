import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DragAndDropFileDirective } from './drag-and-drop-file.directive';
import { SwiperDirective } from './swiper.directive';

@NgModule({
  declarations: [DragAndDropFileDirective, SwiperDirective],
  imports: [CommonModule],
  exports: [DragAndDropFileDirective, SwiperDirective],
})
export class DirectivesModule {}
