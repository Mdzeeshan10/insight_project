import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable, from } from 'rxjs';
import { map } from 'rxjs/operators';
import { UserProfileService } from '../core/services/user.service';



@Injectable({
  providedIn: 'root'
})
export class AdminGuard implements CanActivate {
  constructor(
    private userProfileService: UserProfileService,
    private router: Router
  ) { }



  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return from(this.userProfileService.getUserDetails()).pipe(
      map(userDetails => {
        if (userDetails.roles.includes('Admin') || userDetails.roles.includes('SuperAdmin')) {
          return true; // Allow access to the route
        } else {
          this.router.navigate(['/']); // Redirect to a different route if not authorized
          return false; // Prevent access to the route
        }
      })
    );
  }
}
