import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MsalService } from '@azure/msal-angular';
import { environment } from '../../../environments/environment';

const GRAPH_ENDPOINT = 'https://graph.microsoft.com/v1.0/me';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }) // auth will be injected by MSALv2
  };

/***
 * User Profile Service
 * 
 * NOTE: User Profiles are retrieved from the Azure AD Graph API. Inject this service
 *       into any component that is protected by MsalGuard and the MSALv2 interceptor
 *       will inject the require auth headers into outgoing requests.
 */
@Injectable({ providedIn: 'root' })
export class UserProfileService {
    constructor(
        private http: HttpClient,
        private authService: MsalService) { 
    }

    /***
     * Get Graph Profile (/me)
     */
    getGraphProfile(): Promise<any> {
        return new Promise((resolve, reject) => {
            this.http.get<any>(GRAPH_ENDPOINT)
                .subscribe(profile => {
                    resolve({
                        displayName: profile.displayName,
                        email: profile.mail,
                        name: `${profile.givenName} ${profile.surname}`
                    });
                });
        });
    }

    /***
     * Get Graph Profile (/me/photo)
     */
    getGraphAvatar() 
    {
        var blobPromise = new Promise((resolve, reject) => {
            // pull the raw image blob
            this.http
                .get(`${GRAPH_ENDPOINT}/photos/48x48/$value`, {responseType: 'blob'})
                .subscribe({
                    next: (blob) => {
                        resolve(blob);
                    },
                    error: (error) => {
                        reject(error.status);
                    },
                    complete: () => {}
                });
        });

        var dataPromise = new Promise((resolve, reject) => 
        {
            // resolve the blob and stream to a base64 image
            blobPromise.then(blob => {
                const reader = new FileReader();

                reader.onloadend = () => resolve(reader.result as string);
                reader.onerror = () => reject(reader.error);

                reader.readAsDataURL(blob as Blob);
            })
            .catch(status => {
                reject(status);
            })
        });

        return dataPromise;
    }

    /***
     * Get Application User Details (/me)
     */
    getUserDetails(): Promise<any> {
        var url = environment.usersApi;
        return new Promise((resolve, reject) => {
            this.http.get<any>(`${url}/me`)
                .subscribe(deets => {
                    resolve({
                        userAppId: deets.userId,
                        email: deets.emailAddress,
                        roles: deets.roles
                    });
                });
        });
    }

    /***
     * Add users to the application
     */
    addUsers(role:number, users:any): Promise<any> {
        var url = environment.usersApi;
        return new Promise((resolve, reject) => {
            this.http
                .post<any>(`${url}/addusers?userroleid=${role}`, users, httpOptions)
                .subscribe({
                    next: (result) => {
                        resolve(result);
                    },
                    error: (error) => {
                        reject(error);
                    },
                    complete: () => {}
                });
            });
    }

  addGroups(role: number, groups: any): Promise<any> {
    var url = environment.usersApi;
    return new Promise((resolve, reject) => {
      this.http
        .post<any>(`${url}/AddADGroups?groupRoleid=${role}`, groups, httpOptions)
        .subscribe({
          next: (result) => {
            resolve(result);
          },
          error: (error) => {
            reject(error);
          },
          complete: () => { }
        });
    });
  } 

    /**
     * Log Out
     */
    logout() {
        this.authService.logoutRedirect({
            postLogoutRedirectUri: location.origin
          });
    }
}
