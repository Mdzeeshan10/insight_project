import { TestBed } from '@angular/core/testing';

import { ChatStreamingService } from './chat-streaming.service';

describe('ChatStreamingServiceService', () => {
  let service: ChatStreamingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ChatStreamingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
