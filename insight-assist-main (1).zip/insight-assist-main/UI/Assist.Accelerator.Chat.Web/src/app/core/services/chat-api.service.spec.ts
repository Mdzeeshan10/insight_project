import { TestBed } from '@angular/core/testing';

import { ChatApiService } from './chat-api.service';

describe('ChatApiService', () => {
  let service: ChatApiService;
  let mockHttp: any;
  let mockDatePipe: any;
  let mockMessageParserService: any;

  beforeEach(() => {
    service = new ChatApiService(
      mockHttp,
      mockDatePipe,
      mockMessageParserService
    );
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
