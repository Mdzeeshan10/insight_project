import { TestBed } from '@angular/core/testing';

import { MessageParserService } from './message-parser.service';

describe('MessageParserService', () => {
  let service: MessageParserService;
  let mockDomSanitizer: any;
  let mockDatePipe: any;

  beforeEach(() => {
    service = new MessageParserService(mockDomSanitizer, mockDatePipe);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
