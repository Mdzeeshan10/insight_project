import { Injectable } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MsalService } from '@azure/msal-angular';

const DEFAULT_STATUS = 'Sending input';

@Injectable({
  providedIn: 'root',
})
export class ChatStreamingService {
  connection: any;

  chatMessages$: BehaviorSubject<string>;

  responseStreamingStatus$: BehaviorSubject<string>;

  constructor(private authService: MsalService) {
    this.connection = null;
    this.chatMessages$ = new BehaviorSubject<string>('');
    this.responseStreamingStatus$ = new BehaviorSubject<string>(DEFAULT_STATUS);
  }

  public initializeSignalR(): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      // Restart progress at "Sending input"
      this.responseStreamingStatus$.next(DEFAULT_STATUS);

      if (
        this.connection &&
        this.connection.state === signalR.HubConnectionState.Connected
      ) {
        console.log('SignalR already connected!');

        resolve();
        return;
      }

      const account = this.authService.instance.getAllAccounts()[0];

      const accessTokenRequest = {
        scopes: ['user.read'],
        account: account,
      };

      this.authService
        .acquireTokenSilent(accessTokenRequest)
        .subscribe((accessTokenResponse) => {
          let accessToken = accessTokenResponse.accessToken;

          this.connection = new signalR.HubConnectionBuilder()
            .withUrl(environment.chatSignalR, {
              withCredentials: true,
              // skipNegotiation: true, 
              // transport: signalR.HttpTransportType.WebSockets,
              accessTokenFactory: () => accessToken,
            })
            .build();

          this.connection.on(
            'ReceiveChatMessage',
            (label: any, message: string) => {
              this.chatMessages$.next(message);
            }
          );

          this.connection.on('BeginChatStream', () => {
            this.responseStreamingStatus$.next('Processing input');
          });

          this.connection.on('UpdateStatus', (label: any, status: string) => {
            this.responseStreamingStatus$.next(status);
          });

          this.connection.on('EndChatStream', () => {
            this.chatMessages$.next('');
            this.responseStreamingStatus$.next('Finishing up');
          });

          this.connection.onclose((error: any) => {
            console.log('SignalR Connection Closed!');
            if (error) {
              console.log(`SignalR Connection Error: ${error}`);
            }
          });

          this.connection.onreconnected((connectionId: any) => {
            console.log('SignalR Connection Reconnected!');
          });

          this.connection
            .start()
            .then(() => {
              console.log('SignalR Connected!');
              this.connection.send('addUserToGroup', accessTokenResponse.account?.username);

              resolve();
            })

            .catch((error: any) => {
              console.log(`SignalR Connection Error: ${error}`);
              reject(new Error('SignalR Connection Error'));
            });
        });
    });
  }
}
