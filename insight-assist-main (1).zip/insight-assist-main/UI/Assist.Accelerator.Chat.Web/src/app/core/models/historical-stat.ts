export interface HistoricalStat {
    id: number;
    index: number;
    name: string;
    startDateTime: Date;
    span: number;
    data: { [key: string]: number };
}