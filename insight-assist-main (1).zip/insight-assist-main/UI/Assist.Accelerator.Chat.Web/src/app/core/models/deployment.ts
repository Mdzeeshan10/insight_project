export interface Deployment {
    id: number;
    deploymentName: string;
    modelType: string | null;
    modelVersion: string | null;
    costPerCompletionToken: number;
    costPerPromptToken: number;
    costUnit: number;
    provider: number;
    isActive: boolean;
}