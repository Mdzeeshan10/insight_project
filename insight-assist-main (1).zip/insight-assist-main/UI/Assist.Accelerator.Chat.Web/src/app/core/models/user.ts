export interface User {
  name: string;
  imageUrl: string;
}
