export interface FileSupportInfo {
    extensions: string[],
    maxFileSize: number
}