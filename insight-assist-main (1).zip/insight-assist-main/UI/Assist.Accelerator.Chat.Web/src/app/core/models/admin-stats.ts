export interface AdminStats {
    totalUsers: number;
    totalConversations: number;
    averageChatsPerUser: number;
    averageResponseTimeInMs: number;
    quotaUsed: number;
    quotaLimit: number;
    averageCostPerUser: number;
    averageCostPerChat: number;
    monthlyCostUsed: number;
    monthlyCostLimit: number;
}