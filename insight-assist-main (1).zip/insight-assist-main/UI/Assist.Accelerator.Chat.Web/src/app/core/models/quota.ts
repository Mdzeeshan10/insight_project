export interface Quota {
    id: number;
    user: { name: string, lastName: string };
    costUsed: number;
    costLimit: number;
    period: string;
    conversationCount: number;
    completionTokenCount: number;
    promptTokenCount: number;
    hasBeenExceeded: boolean;
  }
  