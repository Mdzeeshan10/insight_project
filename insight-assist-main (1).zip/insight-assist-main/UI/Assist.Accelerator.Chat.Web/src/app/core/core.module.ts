import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { chatReducer } from './store/chat.reducer';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    // StoreModule.forRoot({layout: layoutReducer})
  ]
})
export class CoreModule { }
