import { ChatHistory } from '../models/chat-history';
import { ChatStateMessage } from '../models/chat-message';
import { User } from '../models/user';
import { Quota } from '../models/quota';
import { AdminStats } from '../models/admin-stats';
import { Deployment } from '../models/deployment';
import { HistoricalStat } from '../models/historical-stat';
import { Copilot } from '../models/copilot';

export interface ChatState {
  sidebar: boolean;
  chatId: string;
  chatMessages: any[];
  typing: boolean;
  chatStreamingResponse: string;
  chatHistory: ChatHistory[];
  user: User;
  userRoles: string[];
  splashScreen: boolean;
  moblieMenu: boolean;
  quota: Quota | null;
  deployment: Deployment | null;
  availableModels: Deployment[] | null;
  adminStats: AdminStats | null;
  adminTopUsers: Quota[] | null;
  adminGraph: HistoricalStat | null;
  selectedKpi: number | null;
  selectedKpiRange: number | null;
  selectedPeriod: string | null;
  selectedPeriodRange: string[];
  selectedChatHistory: ChatHistory;
  copilots: Copilot[];
  attachedFiles: File[];
  replaceMessages: ChatStateMessage;
}
