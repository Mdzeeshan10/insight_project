import { createAction, createActionGroup, props } from '@ngrx/store';
import { ChatStateMessage } from '../models/chat-message';
import { ChatHistory } from '../models/chat-history';
import { User } from '../models/user';
import { Quota } from '../models/quota';
import { AdminStats } from '../models/admin-stats';
import { Deployment } from '../models/deployment';
import { HistoricalStat } from '../models/historical-stat';
import { Copilot } from '../models/copilot';

export const showSidebar = createAction('[Sidebar Component] Show');
export const hideSidebar = createAction('[Sidebar Component] Hide');
export const toggleMoblieMenu = createAction('[menu Component] toggle');
export const hideSplashScreen = createAction('[Splash Component] Hide');
export const showSplashScreen = createAction('[Splash Component] Show');
export const newChat = createAction('[chat Component] New');

export const startTyping = createAction('[typing Component] start');
export const endTyping = createAction('[typing Component] end');

export const updateSeletedPeriod = createAction(
  '[Chat Component] Update Selected Period',
  props<{ selectedPeriod: string }>()
);

export const MessageActions = createActionGroup({
  source: 'Message',
  events: {
    'Add Message': props<{ message: ChatStateMessage }>(),
    'Add Id': props<{ id: string }>(),
    'Add Response Stream': props<{ message: string }>(),
    'Load History': props<{ chatHitory: ChatHistory[] }>(),
    'Select History': props<{ id: string }>(),
    'Set Selected Chat History': props<{ history: ChatHistory }>(),
    'Set Chat Index': props<{ indexId: number }>(),
    'Add User': props<{ user: User }>(),
    'Add User Roles': props<{ roles: string[] }>(),
    'Update Quota': props<{ quota: Quota }>(),
    'Load Admin Stats': props<{ stats: AdminStats, deployment: Deployment, availableModels: Deployment[] }>(),
    'Load Admin Top Users': props<{ adminTopUsers: Quota[] }>(),
    'Load Admin Graph': props<{ adminGraph: HistoricalStat }>(),
    'Select KPI': props<{ id: number }>(),
    'Select KPI Range': props<{ id: number }>(),
    'Select Period': props<{ period: string }>(),
    'Select Period Range': props<{ startDate: string, endDate: string }>(),
    'Get Copilots': props<{ copilots: Copilot[] }>(),
    'Add Attached Files': props<{ attachedFiles: File[] }>(),
    'Remove Attached Files': props<{ attachedFiles: File[] }>(),
    'Replace Messages': props<{ message: ChatStateMessage }>(),
    'New Chat With Copilot': props<{ copilotId: number }>(),

    // 'Remove Book': props<{ bookId: string }>(),
  },
});
