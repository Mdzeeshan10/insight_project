// import { createSelector, createFeatureSelector } from '@ngrx/store';
// import { LayoutState } from '../models/layout-state';

import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ChatState } from './chat-state';
import * as fromChatState from './chat.reducer';

const chatFeature = createFeatureSelector<ChatState>(
  fromChatState.chatFeatureKey
);

export const selectChatId = createSelector(
  chatFeature,
  (state: ChatState) => state.chatId
);

export const selectMessages = createSelector(
  chatFeature,
  (state: ChatState) => state.chatMessages
);

export const selectHistory = createSelector(
  chatFeature,
  (state: ChatState) => state.chatHistory
);

export const selectTyping = createSelector(
  chatFeature,
  (state: ChatState) => state.typing
);

export const selectStreamingResponse = createSelector(
  chatFeature,
  (state: ChatState) => state.chatStreamingResponse
);

export const selectUser = createSelector(
  chatFeature,
  (state: ChatState) => state.user
);

export const selectUserRoles = createSelector(
  chatFeature,
  (state: ChatState) => state.userRoles
);

export const selectSidebar = createSelector(
  chatFeature,
  (state: ChatState) => state.sidebar
);

export const selectSplashScreen = createSelector(
  chatFeature,
  (state: ChatState) => state.splashScreen
);

export const selectMoblieMenu = createSelector(
  chatFeature,
  (state: ChatState) => state.moblieMenu
);

export const selectQuota = createSelector(
  chatFeature,
  (state: ChatState) => state.quota
);

export const selectDeployment = createSelector(
  chatFeature,
  (state: ChatState) => state.deployment
);

export const selectAvailableModels = createSelector(
  chatFeature,
  (state: ChatState) => state.availableModels
);

export const selectAdminStats = createSelector(
  chatFeature,
  (state: ChatState) => state.adminStats
);

export const selectAdminTopUsers = createSelector(
  chatFeature,
  (state: ChatState) => state.adminTopUsers
);

export const selectAdminGraph = createSelector(
  chatFeature,
  (state: ChatState) => state.adminGraph
);

export const selectKpi = createSelector(
  chatFeature,
  (state: ChatState) => state.selectedKpi
);

export const selectKpiRange = createSelector(
  chatFeature,
  (state: ChatState) => state.selectedKpi
);

export const selectPeriod = createSelector(
  chatFeature,
  (state: ChatState) => state.selectedPeriod
);

export const selectPeriodRange = createSelector(
  chatFeature,
  (state: ChatState) => state.selectedPeriodRange
);

export const selectedChatHistory = createSelector(
  chatFeature,
  (state: ChatState) => state.selectedChatHistory
);

export const getCopilots = createSelector(
  chatFeature,
  (state: ChatState) => state.copilots
);

export const getAttachedFiles = createSelector(
  chatFeature,
  (state: ChatState) => state.attachedFiles
)

export const replaceMessages = createSelector(
  chatFeature,
  (state: ChatState) => state.replaceMessages
);
