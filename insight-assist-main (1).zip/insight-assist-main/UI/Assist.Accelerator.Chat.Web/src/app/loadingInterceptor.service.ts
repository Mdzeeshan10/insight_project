import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpResponse,
  HttpContextToken,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { SpinnerLoaderService } from './spinner-loader.service';
import { environment } from '../environments/environment';
import { LogService } from './core/services/log.service';
import { ChatStateService } from 'src/app/core/store/chat-state.service';

export const noSpinnerToken = new HttpContextToken(() => false);

@Injectable()
export class LoadingInterceptorService implements HttpInterceptor {
  private spinnerStartTime: number = 0; // Track the start time of the first request
  private activeRequests: number = 0; // Track the number of active requests
  private spinnerDelay: number = 400; // Time in milliseconds for the spinner to start
  activeConversationId: string = '';
  constructor(
    private spinnerLoaderService: SpinnerLoaderService,
    private logService: LogService,
    private chatStateService: ChatStateService
  ) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<any> {
    console.log('Interceptor - Request started');

    if (request.reportProgress || request.context.get(noSpinnerToken)) {
      return next.handle(request);
    }

    if (this.activeRequests === 0) {
      this.startSpinner();
    }

    this.activeRequests++;
    const requestStartTime = Date.now();

    return next.handle(request).pipe(
      catchError((error) => {
        this.logService.logException(error);
        return throwError(() => error);
      }),
      finalize(() => {
        console.log('Interceptor - Request completed');
        this.activeRequests--;

        const elapsedTime = Date.now() - this.spinnerStartTime;

        console.log('ELAPSED TIME', elapsedTime);

        const spinnerTime = elapsedTime + (Date.now() - requestStartTime);
        console.log('SPINNER TIME', spinnerTime);

        if (spinnerTime > 2500) {
          console.log('Change');
          this.spinnerLoaderService.changeSpinnerColorAndText(
            'green',
            'Please Wait..'
          );
          // this.spinnerLoaderService.changeSpinnerText('Please Wait..');
        }

        if (this.activeRequests === 0) {
          this.spinnerStartTime = 0;
          this.stopSpinner();
        }
      })
    );
  }

  private startSpinner(): void {
    this.spinnerStartTime = Date.now();

    setTimeout(() => {
      if (this.activeRequests > 0) {
        this.spinnerLoaderService.startSpinner();
        console.log('Spinner started', this.spinnerLoaderService);
      }
    }, this.spinnerDelay);
  }

  private stopSpinner(): void {
    this.spinnerLoaderService.stopSpinner();
  }
}
