import { Injectable } from '@angular/core';
import { UserProfileService } from './core/services/user.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private userProfileService:UserProfileService) { }
  logout() {

    this.userProfileService.logout();

}

}
