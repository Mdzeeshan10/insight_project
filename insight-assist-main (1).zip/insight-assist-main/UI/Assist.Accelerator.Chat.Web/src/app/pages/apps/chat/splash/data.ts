const ChatSamplePrompts = [
  // row 1 x 3 cols
  {
    id: 1,
    label: 'Find',
    caption: "What does Insight Enterprise do and what's a summary of their 10-K strategy statement?",
    bg_color: "find" 
  },
  {
    id: 5,
    label: 'Find',
    caption: "What products are currently in stock?",
    bg_color: "find"
  },
  {
    id: 9,
    label: 'Find',
    caption: "What product didn't sell in our NY Store last month?",
    bg_color: "find"
  },
  // row 2 x 3 cols
  {
    id: 2,
    label: 'Find',
    caption: 'Can you provide me a list of our latest users who purchased a bike?',
    bg_color: "find"
  },
  {
    id: 6,
    label: 'Find',
    caption: 'Of the bikes we have in inventory, which ones are most likely to sell well heading into the summer months in the US? Please summarize why that is and what features will be most desirable to potential buyers.',
    bg_color: "find"
  },
  {
    id: 10,
    label: 'Find',
    caption: 'If you match our available inventory with our best user reviews, what is a good theme for an ad campaign?',
    bg_color: "find"
  },
  // row 3 x 3 cols
  {
    id: 3,
    label: 'Create',
    caption: 'Generate an email to our sales team encouraging them to sell the bike models we have in inventory.',
    bg_color: "create"
  },
  {
    id: 7,
    label: 'Create',
    caption: 'Create ad copy for Facebook for our mountain bikes.',
    bg_color: "create"
  },
  {
    id: 11,
    label: 'Create',
    caption: 'Create a blog post for our road bikes targeting advanced riders in North Carolina heading into summer.',
    bg_color: "create"
  },
  // row 4 x 3 cols
  {
    id: 4,
    label: 'Create',
    caption: 'Code a web landing page in Angular 15 and .NET Core for our new electric bikes with a call to action of "buy now and save" for an earth day campaign and sale.',
    bg_color: "create"
  },
  {
    id: 8,
    label: 'Create',
    caption: 'Outline a talk track for a 30 minute LinkedIn Live session discussing Generative AI, challenges enterprise will face, and how a professional consulting company like Insight Enterprise can help.',
    bg_color: "create"
  },
  {
    id: 12,
    label: 'Create',
    caption: 'Write a promotional email marketing our road bike targeting city dwellers in the tone of Barack Obama.',
    bg_color: "create"
  }
];
export { ChatSamplePrompts };