import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import {
  UntypedFormBuilder,
  Validators,
  UntypedFormGroup,
} from '@angular/forms';
import {
  GroupUser,
  ChatUser,
  ChatMessage,
  ContactModel,
  MessageChunk,
} from './chat.model';
import { groupData, chatData, chatMessagesData } from './data';
import { NgbOffcanvas } from '@ng-bootstrap/ng-bootstrap';
import { MarkdownModule } from 'ngx-markdown';
import { DomSanitizer } from '@angular/platform-browser';

// Date Format
import { DatePipe } from '@angular/common';

// Light Box
import { Lightbox } from 'ngx-lightbox';

// Backend Services
import { restApiService } from 'src/app/core/services/rest-api.service';
import { UserProfileService } from 'src/app/core/services/user.service';
import { MessageParserService } from 'src/app/core/services/message-parser.service';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { ChatState } from 'src/app/core/store/chat-state';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss'],
})

/**
 * Chat Component
 */
export class ChatComponent implements OnInit {
  searchText: any;
  searchMsgText: any;
  chatHistory: any[] = [];
  groupData!: GroupUser[];
  chatMessagesData!: ChatMessage[];
  contactData!: ContactModel[];
  formData!: UntypedFormGroup;
  usermessage!: string;
  isFlag: boolean = false;
  submitted = false;
  isProfile: string = 'assets/images/users/avatar-2.jpg';
  username: any = 'Lisa Parker';
  @ViewChild('scrollRef') scrollRef: any;
  images: { src: string; thumb: string; caption: string }[] = [];
  isreplyMessage = false;
  emoji = '';
  typing = false;

  // megademo chat conversations
  currentChatId: string = ''; // currently refresh the page to clear the chat
  //   todo: support new chat button and history by id and user
  // megademo analytics
  showAnalytics: boolean = false; // currently hacked into the main chat page
  //   todo: show settings as separate pages/components
  // megademo splash
  showSplash: boolean = false; // initial splash screen with conversation suggestions
  showNavbar: boolean = false;

  constructor(
    public formBuilder: UntypedFormBuilder,
    private lightbox: Lightbox,
    private datePipe: DatePipe,
    private restApiService: restApiService,
    private offcanvasService: NgbOffcanvas,
    private userProfileService: UserProfileService,
    private messageParserService: MessageParserService,
    private domSanitizer: DomSanitizer,
    private store: Store<{ chat: ChatState }>
  ) {
    for (let i = 1; i <= 24; i++) {
      const src = '../../../../assets/images/small/img-' + i + '.jpg';
      const caption = 'Image ' + i + ' caption here';
      const thumb = '../../../../assets/images/small/img-' + i + '-thumb.jpg';
      const item = {
        src: src,
        caption: caption,
        thumb: thumb,
      };
      this.images.push(item);
    }
    store.select('chat').subscribe((chatState) => {
      this.showNavbar = chatState.sidebar;
      if (chatState.sidebar == true) {
        // this.hideChat();
      }
    });
  }

  ngOnInit(): void {
    // Validation
    this.formData = this.formBuilder.group({
      message: ['', [Validators.required]],
    });

    // Load Data
    this.fetchData();
    this.onListScroll();

    // Start Chat Session
    this.chatNewChat();

    // Show the Sample Prompts
    this.showSplash = true;
  }

  ngAfterViewInit() {
    this.scrollRef.SimpleBar.getScrollElement().scrollTop = 300;
    this.onListScroll();
  }

  /**
   * Returns form
   */
  get form() {
    return this.formData.controls;
  }

  onListScroll() {
    if (this.scrollRef !== undefined) {
      setTimeout(() => {
        this.scrollRef.SimpleBar.getScrollElement().scrollTop =
          this.scrollRef.SimpleBar.getScrollElement().scrollHeight;
      }, 500);
    }
  }

  // --------------------------------------------------------------------------
  // #region: Chat Send
  // --------------------------------------------------------------------------

  messageSend() {
    console.log('messageSend()');
    const message = this.formData.get('message')!.value;

    // immediately display the outgoing message
    this.messageSave();
    this.showSplash = false;

    if (message.length > 0) {
      this.messageSendMegaDemoChat(message);
    }
  }

  private messageSendMegaDemoChat(message: string) {
    console.log('Sending to MegaDemo Chat');
    this.typing = true;

    if (this.currentChatId == '') {
      console.log('New Conversation');
      this.restApiService.postMegaChat(message).subscribe((response) => {
        console.log(response);

        this.currentChatId = response.id;

        var assistantResponses = response.messages.filter(
          (p: { role: { label: string } }) => p.role.label == 'assistant'
        );

        this.responseSave(assistantResponses[assistantResponses.length - 1]);
        this.updateChatHistoryItem(response);
        this.typing = false;
      });
    } else {
      console.log(`Existing Conversation (${this.currentChatId})`);
      this.restApiService
        .putMegaChat(this.currentChatId, message)
        .subscribe((response) => {
          console.log(response);

          var assistantResponses = response.messages.filter(
            (p: { role: { label: string } }) => p.role.label == 'assistant'
          );

          this.responseSave(assistantResponses[assistantResponses.length - 1]);
          this.updateChatHistoryItem(response);
          this.typing = false;
        });
    }
  }

  messageSave() {
    console.log('messageSave()');
    const message = this.formData.get('message')!.value;

    if (this.formData.valid && message) {
      // Message Push in Chat
      this.chatMessagesData.push({
        align: 'right',
        message,
        time: this.datePipe.transform(new Date(), 'h:mm a'),
      });
      this.onListScroll();

      // Set Form Data Reset
      this.formData = this.formBuilder.group({
        message: null,
      });
    }

    this.emoji = '';
    this.submitted = true;
  }

  // --------------------------------------------------------------------------
  // #endregion
  // --------------------------------------------------------------------------

  // --------------------------------------------------------------------------
  // #region: Chat Response
  // --------------------------------------------------------------------------

  responseSave(reply: any) {
    console.log('responseSave()');

    const message = {
      align: 'left',
      name: 'OpenAI',
      message: reply.content,
      time: this.datePipe.transform(new Date(), 'h:mm a'),
      profile: 'assets/images/AssistAtar.png',
      chunks: this.messageParserService.chunkMessage(reply.content),
    };

    // Message Push in Chat
    this.chatMessagesData.push(message);
    this.onListScroll();
    this.emoji = '';
  }

  // --------------------------------------------------------------------------
  // #endregion
  // --------------------------------------------------------------------------

  // --------------------------------------------------------------------------
  // #region: Chat History
  // --------------------------------------------------------------------------

  loadChatHistory() {
    this.restApiService.getMegaChatHistory().subscribe((history) => {
      var mapped = history
        .slice(0, 12)
        .map((item: { id: any; title: any; messages: any[] }) => {
          return {
            id: item.id,
            title: item.title,
            image: 'assets/images/chatBubble.png',
            messages: item.messages,
          };
        });
      this.chatHistory = mapped;
    });
  }

  selectChatHistoryItem(id: string, title: any) {
    console.log(`OnClick: chatHistoryItem ${id}, ${title}`);

    var chat = this.chatHistory.find((v) => v.id == id);
    var messages = chat.messages.filter((item: { role: { label: string } }) => {
      return item.role.label == 'user' || item.role.label == 'assistant';
    });

    var conversation = messages.map(
      (item: { content: any; role: { label: string } }) => {
        if (item.role.label == 'user') {
          return {
            align: 'right',
            message: item.content,
          };
        } else {
          return {
            align: 'left',
            name: 'OpenAI',
            message: item.content,
            profile: 'assets/images/AssistAtar.png',
            chunks: this.messageParserService.chunkMessage(item.content),
          };
        }
      }
    );

    conversation = this.chatMessagesData.slice(0, 1).concat(conversation);

    this.showSplash = false;
    this.currentChatId = id;
    this.chatMessagesData = conversation.slice();

    setTimeout(() => {
      this.onListScroll();
    }, 250);
  }

  updateChatHistoryItem(item: any) {
    console.log(`updateChatHistoryItem`);

    var existingItemIndex = this.chatHistory.findIndex((p) => p.id == item.id);
    if (existingItemIndex >= 0) {
      // updating an existing conversation
      this.chatHistory[existingItemIndex] = {
        id: item.id,
        title: item.title,
        image: 'assets/images/chatBubble.png',
        messages: item.messages,
      };
    } else {
      // new history item - add to the top and truncate the list
      this.chatHistory = [
        {
          id: item.id,
          title: item.title,
          image: 'assets/images/chatBubble.png',
          messages: item.messages,
        },
      ]
        .concat(this.chatHistory)
        .slice(0, 12);
    }
  }

  // --------------------------------------------------------------------------
  // #endregion
  // --------------------------------------------------------------------------

  // --------------------------------------------------------------------------
  // #region: Splash Screen Prompts
  // --------------------------------------------------------------------------

  splashItemPicked(itemPrompt: string) {
    console.log('hello from the other side!!');
    var input = this.formData.get('message');
    if (input) {
      input.setValue(itemPrompt);
      setTimeout(() => {
        this.messageSend();
      }, 250);
    }
  }

  // --------------------------------------------------------------------------
  // #endregion
  // --------------------------------------------------------------------------

  /***
   * OnClick Chat Settings Item
   */
  chatSettingsItem(name: string, profile: any) {
    console.log('OnClick: chatSettingsItem');

    if (name == 'Analytics') {
      this.showAnalytics = true;
    } else if (name == 'Logout') {
      this.userProfileService.logout();
    }
  }

  /***
   * OnClick Close Chat Settings
   */
  chatSettingsClose() {
    if (this.showAnalytics) {
      this.showAnalytics = false;
    }
  }

  /***
   * OnClick New Chat
   */
  chatNewChat() {
    console.log('OnClick: chatNewChat');

    this.currentChatId = '';
    this.chatMessagesData = [];
    this.responseSave({
      content: chatMessagesData.slice(0)[0].message,
    });

    // hide anyting we've placed over the chat
    this.showAnalytics = false;
    this.showSplash = false;
  }

  /**
   * Initialize Data
   */
  private fetchData() {
    this.groupData = groupData.slice(0);

    this.userProfileService.getGraphProfile().then((profile) => {
      this.groupData[0].name = profile.name;
    });

    this.userProfileService
      .getGraphAvatar()
      .then((avatar) => {
        this.groupData[0].imageStyle = 'rounded-circle';
        this.groupData[0].image = avatar as string;
      })
      .catch((status) => {
        if (status == 404) {
          console.log(
            'Profile photo for user not found. Update Azure AD. Using default avatar.'
          );
        } else {
          console.log(`Failed to load profile pic with error ${status}`);
        }
      });

    this.loadChatHistory();
  }

  open(index: number): void {
    // open lightbox
    this.lightbox.open(this.images, index, {});
  }

  close(): void {
    // close lightbox programmatically
    this.lightbox.close();
  }

  closeReplay() {
    document.querySelector('.replyCard')?.classList.remove('show');
  }

  // Delete All Message
  deleteAllMessage(event: any) {
    var allMsgDelete: any = document
      .getElementById('users-conversation')
      ?.querySelectorAll('.chat-list');
    allMsgDelete.forEach((item: any) => {
      item.remove();
    });
  }

  // Message Search
  // (called from top-bar (currently disabled))
  MessageSearch() {
    var input: any,
      filter: any,
      ul: any,
      li: any,
      a: any | undefined,
      i: any,
      txtValue: any;
    input = document.getElementById('searchMessage') as HTMLAreaElement;
    filter = input.value.toUpperCase();
    ul = document.getElementById('users-conversation');
    li = ul.getElementsByTagName('li');
    for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByTagName('p')[0];
      txtValue = a?.innerText;
      if (txtValue?.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = '';
      } else {
        li[i].style.display = 'none';
      }
    }
  }

  //  Filter Offcanvas Set
  openEnd(content: TemplateRef<any>) {
    this.offcanvasService.open(content, { position: 'end' });
  }

  // Emoji Picker
  showEmojiPicker = false;
  sets: any = [
    'native',
    'google',
    'twitter',
    'facebook',
    'emojione',
    'apple',
    'messenger',
  ];
  set: any = 'twitter';
  toggleEmojiPicker() {
    this.showEmojiPicker = !this.showEmojiPicker;
  }

  addEmoji(event: any) {
    const { emoji } = this;
    const text = `${emoji}${event.emoji.native}`;
    this.emoji = text;
    this.showEmojiPicker = false;
  }

  onFocus() {
    this.showEmojiPicker = false;
  }
  onBlur() {}

  /**
   * Delete Chat Contact Data
   */
  delete(event: any) {
    event.target.closest('li')?.remove();
  }

  hideChat() {
    // const userChatShow = document.querySelector('.user-chat');
    // if(userChatShow != null){
    //   userChatShow.classList.remove('user-chat-show');
    // }
  }
}
