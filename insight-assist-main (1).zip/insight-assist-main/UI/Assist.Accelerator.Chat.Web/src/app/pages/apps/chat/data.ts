
/**
 * Group List
 */
 const groupData = [
    {
        image: 'assets/images/users/user-dummy-img3.jpg',
        imageStyle: 'Default',
        name: '', // user profile - filled in async on login
    },
    {
        image: 'assets/images/Settings-Analytics.png',
        imageStyle: 'Default',
        name: 'Analytics'
    },
    {
        image: 'assets/images/Settings-Settings.png',
        imageStyle: 'Default',
        name: 'Settings',
    },
    {
        image: 'assets/images/Settings-DarkMode.png',
        imageStyle: 'Default',
        name: 'Dark Mode'
    },
    {
        image: 'assets/images/Settings-Logout.png',
        imageStyle: 'Default',
        name: 'Logout'
    },
  ];
  
  /**
   * Chat List
   */
   const chatData = [
    {
        image: 'assets/images/chatBubble.png',
        name: 'Most Popular Bike Features',
        status: 'online'
    },
    {
        image: 'assets/images/chatBubble.png',
        name: 'Bike Customer Ratings',
        status: 'online',
    },
    {
        image: 'assets/images/chatBubble.png',
        name: 'Bike Sales by Segment',
        status: 'online'
    },
    {
        image: 'assets/images/chatBubble.png',
        name: 'Summary of Features',
        status: 'online'
    },
  ];
  
  /**
   * Chat Message List
   * MegaDemo
   *   Messages defined here appear initially on load. Minimize content here.
   *   NOTE: The full admin demo has examples of additional default messages, including image content and replies.
   */
   const chatMessagesData = [
    {
        align: 'left',
        profile: 'assets/images/AssistAtar.png',
        message: 'I\'m the Insight Assist agent. How can I help you? 😊',
        chunks: [{type: 'text', content: 'I\'m the Insight Assist agent. How can I help you? 😊'}],
        time: '09:07 am' // tbd - can we make the time always current?
    }
  ];

  export { groupData, chatData, chatMessagesData };
  