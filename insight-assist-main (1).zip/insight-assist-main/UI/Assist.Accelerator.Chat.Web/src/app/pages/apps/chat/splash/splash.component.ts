import { Component, OnInit } from '@angular/core';
import { splashSuggestionModel } from './splash.model';
import { ChatSamplePrompts } from './data';
import { Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-chat-splash',
  templateUrl: './splash.component.html',
  styleUrls: ['./splash.component.scss']
})

/**
 * Chat Component
 */
export class SplashComponent implements OnInit {

  @Output() splashItemPicked = new EventEmitter<any>();
  @Output() splashItemFavorite = new EventEmitter<any>();

  chatSamplePrompts!: splashSuggestionModel[];

  constructor(
    ) {

  }

  ngOnInit(): void {
    this.chatSamplePrompts = ChatSamplePrompts.slice(0);
  }

  ngAfterViewInit() {

  }

  handleSplashItemPicked(id: any) {
    var item = this.chatSamplePrompts.find(p => p.id == id);
    if (item) {
      this.splashItemPicked.emit(
        item.caption);
    }
  }

  handleSplashItemFavorite(event: Event, id: any) {
    event.stopPropagation(); // consume click before it hits the parent card

    this.splashItemFavorite.emit(
      this.chatSamplePrompts.find(p => p.id == id));
  }
}
