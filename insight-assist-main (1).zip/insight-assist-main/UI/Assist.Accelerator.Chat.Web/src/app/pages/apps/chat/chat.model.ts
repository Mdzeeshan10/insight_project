/**
 * Group User List (MegaDemo: Repurposed as settings list items)
 */
 export interface GroupUser {
    image?: string;
    imageStyle?: string;
    name: string;
    unread?: string;
  }
  
  /**
   * Chat User List (MegaDemo: Repurposed as chat history list items)
   */
  export interface ChatUser {
    image?: string;
    name: string;
    status: string;
    unread?: string;
  }

  export interface MessageChunk {
    type: string; // "text", "table", or "code"
    content: any;
    metadata: { [key: string]: string};
  }
  
  /**
   * Chat Message List
   */
  export interface ChatMessage {
    align?: string;
    name?: any;
    profile?: any;
    message?: string;
    time?: any;
    image?: string[];
    replayName?:any;
    replaymsg?:any;
    chunks?: MessageChunk[];
  }

/**
 * Contact List
 */
 export interface ContactModel {
  title: string;
  contacts: Array<{
    name?: any;
    profile?: string;
  }>}

