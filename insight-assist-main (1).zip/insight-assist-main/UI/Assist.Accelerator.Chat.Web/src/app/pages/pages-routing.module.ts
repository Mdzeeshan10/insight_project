import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// Component pages
import { DashboardComponent } from "./dashboards/dashboard/dashboard.component";
import { ChatComponent } from "./apps/chat/chat.component";

// MegaDemo
//   Default to the chat screen
const routes: Routes = [
    {
        path: "",
        component: ChatComponent
    },
    {
      path: '', loadChildren: () => import('./apps/apps.module').then(m => m.AppsModule)
    },
    {
      path: 'apps', loadChildren: () => import('./apps/apps.module').then(m => m.AppsModule)
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
