// import { isDevMode } from '@angular/core';
// import {
//   ActionReducer,
//   ActionReducerMap,
//   createFeatureSelector,
//   createSelector,
//   MetaReducer
// } from '@ngrx/store';
// import { ChatState } from '../core/models/chat-state';
// import { AppState } from '../core/models/app-state';

// export interface State {
//  // layoutState: LayoutState;
// }

// export const initialState: State = {
//   layoutState: {
//   sidebar: true,},
// };

// export const reducers: ActionReducerMap<State> = {
//   //layoutState: initialState
// };


// export const metaReducers: MetaReducer<State>[] = isDevMode() ? [] : [];
