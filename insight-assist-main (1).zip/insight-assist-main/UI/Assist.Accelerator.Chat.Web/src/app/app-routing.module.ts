import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// MSAL v2
import { BrowserUtils } from '@azure/msal-browser';
import { MsalGuard } from '@azure/msal-angular';
import { ChatComponent } from './pages/apps/chat/chat.component';
import { ChatComponentV2 } from './modules/chat/chat.component';
import { DashboardComponent } from './modules/chat/dashboard/dashboard.component';
import { InviteComponent } from './modules/chat/invite/invite.component';
import { TermsComponent } from './modules/chat/terms/terms.component';
import { UserManagementComponent } from './modules/chat/user-management/user-management.component';
import { NotLoggedInComponent } from './modules/chat/not-logged-in/not-logged-in.component';
import { AdminGuard } from './guards/admin.guard';
//import { DashboardComponent } from './pages/dashboards/dashboard/dashboard.component';
//import { ChatComponentV2 } from './modules/chat/chat.component';
//import { ChatComponent } from './pages/apps/chat/chat.component';

const routes: Routes = [
  { path: '', component: ChatComponentV2, canActivate: [MsalGuard] },
  { path: 'v2', component: ChatComponentV2, canActivate: [MsalGuard] },
  { path: 'v2/dashboard', component: DashboardComponent, canActivate: [MsalGuard, AdminGuard] },
  { path: 'v2/invite', component: InviteComponent, canActivate: [MsalGuard, AdminGuard] },
  { path: 'v2/terms', component: TermsComponent, canActivate: [MsalGuard] },
  { path: 'v2/settings', component: UserManagementComponent, canActivate: [MsalGuard, AdminGuard] },
  { path: 'not-logged-in', component: NotLoggedInComponent },
  /* MegaDemo: Replaced firebase auth with MSALv2. All routes should be guarded to ensure forced login. */
];

const isIframe = window !== window.parent && !window.opener; // tbd probably not needed

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      // MSALv2 - don't perform initial navigation in iframes or popups
      initialNavigation:
        !BrowserUtils.isInIframe() && !BrowserUtils.isInPopup()
          ? 'enabledNonBlocking'
          : 'disabled', // Set to enabledBlocking to use Angular Universal
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
