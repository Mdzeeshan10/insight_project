export const GlobalConfig = {
    /*
     * Global Config
     * Note: Most global config should be set via environments file to support per-environment
     *       configs. All URLs shoulve move to environments.  Only application-wide config
     *       values that will never change should be stored globally here.
     *       (MegaDemo 05/05/2023)
     */

    // MegaDemo
    //   Suppress all menu items and side-bar visibility
    supportSideMenu: false,

    // MegaDemo
    //   Hide the global app search from the top-bar
    supportAppSearch: false
}