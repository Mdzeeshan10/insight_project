export function dateToMidnightUTC(date: Date): Date {
    var timeZoneOffset = date.getTimezoneOffset();
    var timeZoneDifference = (timeZoneOffset / 60) * -1;
    date.setTime(date.getTime() + (timeZoneDifference * 60) * 60 * 1000);
    date = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
    return date;
}

export function getShortDateString(date: Date): string {
    var y = date.getFullYear();
    var m = (date.getMonth() + 1).toString().padStart(2, "0");
    var d = date.getDate().toString().padStart(2, "0");
    var str = `${y}-${m}-${d}`;
    return str;
}

export function getUTCShortDateString(date: Date): string {
    var y = date.getUTCFullYear();
    var m = (date.getUTCMonth() + 1).toString().padStart(2, "0");
    var d = date.getUTCDate().toString().padStart(2, "0");
    var str = `${y}-${m}-${d}`;
    return str;
}
