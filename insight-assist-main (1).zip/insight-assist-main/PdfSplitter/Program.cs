﻿using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using Azure.Storage.Blobs;
using Microsoft.Extensions.Configuration;

public static class Program
{
    private static string? _pdfFolder;
    private static string? _blobConnectionString;
    private static string? _blobContainerName;
    private static string? _containerFolder;
    
    /// <summary>
    /// Splits all PDFs in specified folder and uploads them to Azure Blob Storage.
    /// </summary>
    /// <returns></returns>
    public static async Task Main()
    {
        var builder = new ConfigurationBuilder()
            .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
            .AddJsonFile("appsettings.json");

        var configuration = builder.Build();

        _pdfFolder = configuration["PdfFolder"];
        _blobConnectionString = configuration["AzureStorageSettings:BlobStorageConnectionString"];
        _blobContainerName = configuration["AzureStorageSettings:ContainerName"];
        _containerFolder = configuration["AzureStorageSettings:ContainerFolder"];

        var numberOfFiles = 0;

        Console.WriteLine($"Splitting PDF files in {_pdfFolder}");
        foreach (var file in Directory.GetFiles(_pdfFolder!, "*.pdf"))
        {
            numberOfFiles += 1;
            try
            {
                await SplitAndUploadPdf(file);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing {file}. Error: {ex.Message}");
            }

            Console.WriteLine($"Split and uploaded {numberOfFiles} PDF files.");
        }
    }

    private static async Task SplitAndUploadPdf(string pdfFilePath)
    {
        Console.WriteLine($"Splitting PDF file {pdfFilePath}");
        using PdfDocument inputDocument = PdfReader.Open(pdfFilePath, PdfDocumentOpenMode.Import);
        var name = Path.GetFileNameWithoutExtension(pdfFilePath);

        for (var idx = 0; idx < inputDocument.PageCount; idx++)
        {
            try
            {
                using PdfDocument outputDocument = new PdfDocument();
                outputDocument.AddPage(inputDocument.Pages[idx]);
                using MemoryStream stream = new MemoryStream();
                outputDocument.Save(stream, false);
                Console.WriteLine($"{pdfFilePath} split.");
                await UploadToBlob($"{name}-Page{idx + 1}.pdf", stream);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error splitting or uploading page {idx + 1} of {pdfFilePath}. Error: {ex.Message}");
            }
        }
    }

    private static async Task UploadToBlob(string blobName, MemoryStream memoryStream)
    {
        memoryStream.Position = 0;
        var blobServiceClient = new BlobServiceClient(_blobConnectionString);
        var containerClient = blobServiceClient.GetBlobContainerClient($"{_blobContainerName}");

        var blobPath = !string.IsNullOrWhiteSpace(_containerFolder) ? $"{_containerFolder}/{blobName}" : blobName;
        
        var blobClient = containerClient.GetBlobClient(blobPath);
        Console.WriteLine($"Uploading blob: {blobPath}");
        await blobClient.UploadAsync(memoryStream, true);
        Console.WriteLine($"{blobPath} uploaded");
    }
}