# GOAL

Facilitate UI development.

# DESCRIPTION

The code here will:
- Copy the config file ./environment.dev.ts to the application directory
- Check the dependencies for the application server to run
- Run the application server

# SETUP

Create a file in this folder called environment.dev.ts

# RUNNING THE CODE

```make```




