#!/bin/bash

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
SQLCMD="/opt/mssql-tools/bin/sqlcmd -Usa -P${SA_PASSWORD}"

./wait-for-health-check.sh

$SQLCMD -i test-script.sql

