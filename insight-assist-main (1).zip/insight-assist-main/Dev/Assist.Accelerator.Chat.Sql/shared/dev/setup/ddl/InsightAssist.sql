IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'InsightAssist')
BEGIN
    CREATE DATABASE InsightAssist
END;

