#!/bin/bash

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
SQLCMD="/opt/mssql-tools/bin/sqlcmd -Usa -P${SA_PASSWORD}"

for i in {1..10}; do
    ${SCRIPT_DIR}/health-check.sh && echo "Health Check Succeeded"  && break || echo "Health Check Failed"
    echo "Sleeping" && sleep 1
done



