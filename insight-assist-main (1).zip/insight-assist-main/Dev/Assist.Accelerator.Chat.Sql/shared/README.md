This directory is shared with the container.
The scripts here should be run from there.

