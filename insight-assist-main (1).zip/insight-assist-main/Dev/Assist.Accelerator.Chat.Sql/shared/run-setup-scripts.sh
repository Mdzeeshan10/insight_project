#!/bin/bash

set -e

./wait-for-health-check.sh

MY_DIR=$(cd "$(dirname "$0")"; pwd -P)

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
SQLCMD="/opt/mssql-tools/bin/sqlcmd -Usa -P${SA_PASSWORD}"

create_db() {
    cd "${MY_DIR}/dev/setup"
    $SQLCMD -i ./ddl/InsightAssist.sql
}

run_setup_scripts() {

    echo "Create ctl Schema"
    cd "${MY_DIR}/Assist.Accelerator.Chat.Sql/ctl"
    $SQLCMD -d InsightAssist -i "ctl.sql"

    echo "Create ctl Tables"
    cd "${MY_DIR}/Assist.Accelerator.Chat.Sql/ctl/Tables"
    for i in ./*sql; do
        echo "Running $i"
        $SQLCMD -d InsightAssist -i "$i"
    done

    echo "Create dbo User Defined Types"
    cd "${MY_DIR}/Assist.Accelerator.Chat.Sql/dbo/User Defined Types"
    for i in ./*sql; do
        echo "Running $i"
        $SQLCMD -d InsightAssist -i "$i"
    done

    echo "Create dbo Tables"
    cd "${MY_DIR}/Assist.Accelerator.Chat.Sql/dbo/Tables"
    for i in ./*sql; do
        echo "Running $i"
        $SQLCMD -d InsightAssist -i "$i"
    done

    echo "Create dbo Stored Procedures"
    cd "${MY_DIR}/Assist.Accelerator.Chat.Sql/dbo/Stored Procedures"
    for i in ./*sql; do
        echo "Running $i"
        $SQLCMD -d InsightAssist -i "$i"
    done

    echo "Run Post-Deployment scripts"
    cd "${MY_DIR}/Assist.Accelerator.Chat.Sql/Scripts/Post-Deployment"
    F="Script.PostDeployment.sql"
    SCRIPTS=$(cat $F | egrep '^:r' | cut -d'\' -f 2)
    for i in $SCRIPTS; do
        $SQLCMD -d InsightAssist -i "$i"
    done

    echo "Run DEV setup scripts"
    cd "${MY_DIR}/dev/setup/dml"
    F="Script.DevSetup.sql"
    SCRIPTS=$(cat $F | egrep '^:r' | cut -d'\' -f 2)
    for i in $SCRIPTS; do
        $SQLCMD -d InsightAssist -i "$i"
    done
}

create_db
run_setup_scripts

