# GOAL

Facilitate API Service development.

# DESCRIPTION

This copies a development config file from this directory to where it will
be used by the API server when it runs.

If Rider is installed in PATH, the API project will be opened with it.

# SETUP

Create appsettings.development.json.

The example config file can be used but it needs to be edited first.

# RUNNING THE CODE

```make```
