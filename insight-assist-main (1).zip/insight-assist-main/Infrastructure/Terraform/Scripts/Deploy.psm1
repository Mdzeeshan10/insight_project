function ModuleDeployment (
    [Parameter(Mandatory = $true)]
    [String]$terraformFolderPath,
    [Parameter(Mandatory = $true)]
    [String]$pathToReturnTo
) {
    Set-Location $terraformFolderPath
    
    $success = 1;
    try {
        $env:TF_VAR_tf_backend_loc = "remote"
        $tf = & terragrunt init --terragrunt-config terragrunt/terragrunt.hcl -reconfigure 2>&1 
        if($LastExitCode -eq 1)
        {
            Write-Host "Terraform init failed with remote state, ensure state exists / being referenced correctly via input json."
            Write-Host $tf;
            $success = 0;
        } else {
            Write-Host "Updating Current Architecture"
            terragrunt apply --terragrunt-config terragrunt/terragrunt.hcl --auto-approve

            if($LastExitCode -eq 1)
            {
                Write-Host "Failed to apply terraform."
                $success = 0;
            }
        }
    }
    catch {
        $message = $_
        Write-Host "Error, aborting."
        Write-Host $message
        $success = 0;
    }

    Set-Location $pathToReturnTo
    
    if ($success -eq 0)
    {
        throw "Error, aborting."
    }
}