# Infrastructure
TODO - running terraform, prerequisites, etc

## A note on API CORS Configuration

If you are deploying this into an environment with a custom domain name (i.e., not a *.azurewebsites.net as would be typical for a dev environment),
you need to ensure the API instances have the "CorsAllowedHosts" configuration value set to match that of the front-end deployment. If this is not
done, the application will not function as expected.

As of this writing (9/21/2023), Terraform sets this value automatically based on the webapp instance's configured URL. However, we likely need to add an additional override variable allowing custom domains to be added in.

## Required software to run Terraform deployments

- Azure CLI (`az` command, not the Azure Powershell module)
- Terraform CLI
- Terragrunt CLI
- Powershell - you must change the script execution policy to RemoteSigned in order for it to run
  - `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser` in an admin Powershell, then restart your user-level Powershell terminal

On Windows 11 machines, Azure CLI, Terraform, and Terragrunt are installable via Winget or Chocolatey.

## Deploying infrastructure via Terraform

1. Log in to the Azure CLI.

2. Run `az account list --output table` to confirm which subscriptions are available to you.

> Note that the TF variables for a given environment include tenant and subscription ids,
> so you should not need to change your current default subscription just to run the process.

3. Run `./deploy.ps1 {environment name}`. If you do not supply an `{environment name}` (positional argument) then you will be prompted to pick an environment from the list of directories in the `Environments/` directory of the `Infrastructure/` folder.

> Note that this will **immediately** apply the changes to your remote environment! If you need
> to evaluate what will change prior to actually deploying it, you need to edit the
> `Infrastructre/Terraform/Scripts/Deploy.psm1` script and change `terragrunt apply` to instead
> run `terragrunt plan`. Be certain not to check this into the repository.

## Creating a new environment

In the `Infrastructure/Environments/` directory, create a new subdirectory with the name of
the environment you want to create. Add single file to it called `inp.jsonc`; update the file
with the appropriate configuration for the environment you want to deploy.

TODO - description of all of the available input fields

## Creating an Azure Cognitive Search index

There is a Powershell script that will set up an index in Azure Cognitive Search that is derived from the text content of files in blob storage, and consists of small, overlapping chunks of text from those files.

### Prerequisites

1. An Azure Functions app with the TextChunkerSkill function deployed
2. An Azure Cognitive Search instance
3. A blob storage account and container
4. Role assignment(s) allowing the ACS instance's system-managed identity read access to blob containers and read/write access to tables for the storage account instance

### Creating the index

1. Log in to the Azure CLI in Powershell
2. Navigate to `insight-assist/Infrastructure`
3. Fill in the blanks and run the script below
   ``` powershell
   Import-Module ./Scripts/CreateSearchIndex.psm1
   Add-BlobContainerSearchIndex `
     -resourceGroupName ____
     -storageAccountName ____ 
     -storageContainerName ____ 
     -searchServiceName ____ 
     -searchIndexName ____
     -textChunkerSkillUri ____
   ```
   - Each parameter is the name or URI of the specified resource, and `searchIndexName` is any alphanumeric string, which will be used to name the created index and all other associated ACS components
