function Add-BlobContainerSearchIndex (
    [Parameter(Mandatory = $true)]
    [string]$resourceGroupName,

    [Parameter(Mandatory = $true)]
    [string]$storageAccountName,

    [Parameter(Mandatory = $true)]
    [string]$storageContainerName,

    [Parameter(Mandatory = $true)]
    [string]$searchServiceName,
    
    [ValidatePattern("^[a-z0-9]+$")]
    [Parameter(Mandatory = $true)]
    [string]$searchIndexName,

    [Parameter(Mandatory = $true)]
    [string]$textChunkerSkillUri
) {
    $resourceGroup = az group show --name $resourceGroupName | ConvertFrom-JSON

    $key = az search admin-key show --resource-group $resourceGroupName --service-name $searchServiceName
    $key = $key | ConvertFrom-Json
    $pk = $key.primaryKey
    
    $headers = @{
        'api-key'      = $pk
        'Content-Type' = 'application/json' 
        'Accept'       = 'application/json' 
    }

    $apiVersion = "2021-04-30-Preview"

    $searchIndexerName = $searchIndexName
    $searchDataSourceName = $searchIndexName

    $sourceIndexName = "${searchIndexName}-source"
    $sourceIndexerName = "${searchIndexerName}-source"
    $sourceDataSourceName = "${searchDataSourceName}-source"
    $sourceSkillsetName = "${searchIndexName}-source"

    $sourceTableName = $searchIndexName

    Write-Host "Azure Cognitive Search components to be created:"
    Write-Host "Search index:       ${searchIndexName}"
    Write-Host "Search indexer:     ${searchIndexerName}"
    Write-Host "Search data source: ${searchDataSourceName}"
    Write-Host "Source index:       ${sourceIndexName}"
    Write-Host "Source indexer:     ${sourceIndexerName}"
    Write-Host "Source data source: ${sourceDataSourceName}"
    Write-Host "Source skillset:    ${sourceSkillsetName}"
    Write-Host ""

    #---------------------------------------------------------------
    # Check if any of the components to be created already exist
    #---------------------------------------------------------------

    $doesNotExist = 0;

    $doesNotExist += Confirm-AcsComponentDoesNotExist -headers $headers -apiVersion $apiVersion -searchServiceName $searchServiceName -path "indexes" -name $searchIndexName

    $doesNotExist += Confirm-AcsComponentDoesNotExist -headers $headers -apiVersion $apiVersion -searchServiceName $searchServiceName -path "indexers" -name $searchIndexerName

    $doesNotExist += Confirm-AcsComponentDoesNotExist -headers $headers -apiVersion $apiVersion -searchServiceName $searchServiceName -path "datasources" -name $searchDataSourceName

    $doesNotExist += Confirm-AcsComponentDoesNotExist -headers $headers -apiVersion $apiVersion -searchServiceName $searchServiceName -path "indexes" -name $sourceIndexName

    $doesNotExist += Confirm-AcsComponentDoesNotExist -headers $headers -apiVersion $apiVersion -searchServiceName $searchServiceName -path "indexers" -name $sourceIndexerName

    $doesNotExist += Confirm-AcsComponentDoesNotExist -headers $headers -apiVersion $apiVersion -searchServiceName $searchServiceName -path "datasources" -name $sourceDataSourceName

    $doesNotExist += Confirm-AcsComponentDoesNotExist -headers $headers -apiVersion $apiVersion -searchServiceName $searchServiceName -path "skillsets" -name $sourceSkillsetName

    if ($doesNotExist -ne 7) {
        throw "Could not confirm that all Azure Cognitive Search components can be created."
    }

    #---------------------------------------------------------------
    # Create Source Skillset
    #---------------------------------------------------------------
    Write-Host $sourceTableName
    $sourceSkillsetBody = @"
{
    "name": "${sourceSkillsetName}",
    "description": "Breaks document text up into chunks and maps chunks to table rows",
    "skills": [
        {
            "@odata.type": "#Microsoft.Skills.Custom.WebApiSkill",
            "name": "TextChunkSkill",
            "description": "Breaks document text up into chunks by token length",
            "context": "/document",
            "uri": "${textChunkerSkillUri}",
            "httpMethod": "POST",
            "timeout": "PT30S",
            "batchSize": 1000,
            "degreeOfParallelism": null,
            "inputs": [
                {
                "name": "text",
                "source": "/document/content"
                }
            ],
            "outputs": [
                {
                "name": "chunks",
                "targetName": "chunks"
                }
            ],
            "httpHeaders": {}
        },
        {
            "@odata.type": "#Microsoft.Skills.Util.ShaperSkill",
            "name": "TextChunkShaper",
            "description": "Maps document properties to table fields",
            "context": "/document/chunks/*",
            "inputs": [
                {
                "name": "chunks",
                "sourceContext": "/document/chunks/*",
                "inputs": [
                    {
                    "name": "fileName",
                    "source": "/document/metadata_storage_name"
                    },
                    {
                    "name": "content",
                    "source": "/document/chunks/*"
                    }
                ]
                }
            ],
            "outputs": [
                {
                "name": "output",
                "targetName": "tableprojection"
                }
            ]
        }
    ],
    "knowledgeStore": {
        "storageConnectionString": "ResourceId=$($resourceGroup.id)/providers/Microsoft.Storage/storageAccounts/${storageAccountName};",
        "identity": null,
        "projections": [
        {
            "tables": [
            {
                "tableName": "${sourceTableName}",
                "referenceKeyName": null,
                "generatedKeyName": "ChunkKey",
                "source": null,
                "sourceContext": "/document/chunks/*",
                "inputs": [
                {
                    "name": "fileName",
                    "source": "/document/metadata_storage_name",
                    "sourceContext": null,
                    "inputs": []
                },
                {
                    "name": "content",
                    "source": "/document/chunks/*",
                    "sourceContext": null,
                    "inputs": []
                }
                ]
            }
            ],
            "objects": [],
            "files": []
        }
        ],
        "parameters": {
        "synthesizeGeneratedKeyName": true
        }
    },
    "encryptionKey": null
    }
"@

    Add-AcsComponent -headers $headers -apiVersion $apiVersion -method "post" -searchServiceName $searchServiceName `
        -path "skillsets" -body $sourceSkillsetBody

    #---------------------------------------------------------------
    # Create Source Data Source (blob container)
    #---------------------------------------------------------------
    
    $sourceDataSourceBody = @"
{
  "type": "azureblob",
  "credentials": {
    "connectionString": "ResourceId=$($resourceGroup.id)/providers/Microsoft.Storage/storageAccounts/${storageAccountName};"
  },
  "container": {
    "name": "${storageContainerName}"
  },
  "identity": null,
  "dataDeletionDetectionPolicy": {
    "@odata.type": "#Microsoft.Azure.Search.NativeBlobSoftDeleteDeletionDetectionPolicy"
  },
  "name": "${sourceDataSourceName}"
}
"@

    Add-AcsComponent -headers $headers -apiVersion $apiVersion -method "put" -searchServiceName $searchServiceName `
        -path "datasources" -name $sourceDataSourceName -body $sourceDataSourceBody

    #---------------------------------------------------------------
    # Create Source Index
    #---------------------------------------------------------------

    $sourceIndexBody = @"
{
    "defaultScoringProfile": null,
    "fields": [
        {
            "name": "id",
            "type": "Edm.String",
            "searchable": false,
            "filterable": false,
            "retrievable": true,
            "sortable": false,
            "facetable": false,
            "key": true
        },
        {
            "name": "metadata_storage_name",
            "type": "Edm.String",
            "searchable": false,
            "filterable": false,
            "retrievable": true,
            "sortable": false,
            "facetable": false,
            "key": false
        },
        {
            "name": "metadata_storage_path",
            "type": "Edm.String",
            "searchable": false,
            "filterable": false,
            "retrievable": true,
            "sortable": false,
            "facetable": false,
            "key": false
        }
    ],
    "scoringProfiles": [],
    "corsOptions": null,
    "suggesters": [],
    "analyzers": [],
    "normalizers": [],
    "tokenizers": [],
    "tokenFilters": [],
    "charFilters": [],
    "encryptionKey": null,
    "similarity": {
        "@odata.type": "#Microsoft.Azure.Search.BM25Similarity",
        "k1": null,
        "b": null
    },
    "semantic": null
}
"@

    Add-AcsComponent -headers $headers -apiVersion $apiVersion -method "put" -searchServiceName $searchServiceName `
        -path "indexes" -name $sourceIndexName -body $sourceIndexBody
    
    #---------------------------------------------------------------
    # Create Source Indexer
    #---------------------------------------------------------------

    $sourceIndexerBody = @"
{
    "description": null,
    "dataSourceName": "${sourceDataSourceName}",
    "skillsetName": "${sourceSkillsetName}",
    "targetIndexName": "${sourceIndexName}",
    "disabled": null,
    "schedule": null,
    "parameters": {
        "batchSize": null,
        "maxFailedItems": null,
        "maxFailedItemsPerBatch": null,
        "base64EncodeKeys": null,
        "configuration": {}
    },
    "fieldMappings": [],
    "outputFieldMappings": [],
    "cache": null,
    "encryptionKey": null
}
"@

    Add-AcsComponent -headers $headers -apiVersion $apiVersion -method "put" -searchServiceName $searchServiceName `
        -path "indexers" -name $sourceIndexerName -body $sourceIndexerBody
    
    #---------------------------------------------------------------
    # Create Search Data Source (source table)
    #---------------------------------------------------------------

    $searchDataSourceBody = @"
{
    "description": "Storage table containing chunks of text from files",
    "type": "azuretable",
    "subtype": null,
    "credentials": {
        "connectionString": "ResourceId=$($resourceGroup.id)/providers/Microsoft.Storage/storageAccounts/${storageAccountName};"
    },
    "container": {
        "name": "${sourceTableName}",
        "query": null
    },
    "dataChangeDetectionPolicy": null,
    "dataDeletionDetectionPolicy": null,
    "encryptionKey": null,
    "identity": null
    }
"@

    Add-AcsComponent -headers $headers -apiVersion $apiVersion -method "put" -searchServiceName $searchServiceName `
        -path "datasources" -name $searchDataSourceName -body $searchDataSourceBody
    
    #---------------------------------------------------------------
    # Create Search Index
    #---------------------------------------------------------------

    $searchIndexBody = @"
{
    "defaultScoringProfile": null,
    "fields": [
        {
            "name": "id",
            "type": "Edm.String",
            "searchable": false,
            "filterable": false,
            "retrievable": true,
            "sortable": false,
            "facetable": false,
            "key": true
        },
        {
            "name": "content",
            "type": "Edm.String",
            "searchable": true,
            "filterable": true,
            "retrievable": true,
            "sortable": true,
            "facetable": true,
            "key": false
        },
        {
            "name": "fileName",
            "type": "Edm.String",
            "searchable": false,
            "filterable": true,
            "retrievable": true,
            "sortable": true,
            "facetable": true,
            "key": false
        }
    ],
    "similarity": {
        "@odata.type": "#Microsoft.Azure.Search.BM25Similarity",
        "k1": null,
        "b": null
    },
    "semantic": {
        "defaultConfiguration": null,
        "configurations": [
            {
                "name": "default",
                "prioritizedFields": {
                "titleField": {
                    "fieldName": "fileName"
                },
                "prioritizedContentFields": [
                    {
                    "fieldName": "content"
                    }
                ],
                "prioritizedKeywordsFields": [
                    {
                    "fieldName": "content"
                    }
                ]
                }
            }
        ]
    }
}
"@

    Add-AcsComponent -headers $headers -apiVersion $apiVersion -method "put" -searchServiceName $searchServiceName `
        -path "indexes" -name $searchIndexName -body $searchIndexBody
    
    #---------------------------------------------------------------
    # Create Search Indexer
    #---------------------------------------------------------------

    $searchIndexerBody = @"
{
    "description": null,
    "dataSourceName": "${searchDataSourceName}",
    "skillsetName": null,
    "targetIndexName": "${searchIndexName}",
    "disabled": null,
    "schedule": null,
    "parameters": {
        "batchSize": null,
        "maxFailedItems": null,
        "maxFailedItemsPerBatch": null,
        "base64EncodeKeys": null,
        "configuration": {}
    },
    "fieldMappings": [
        {
            "sourceFieldName": "RowKey",
            "targetFieldName": "id",
            "mappingFunction": null
        },
        {
            "sourceFieldName": "content",
            "targetFieldName": "content",
            "mappingFunction": null
        },
        {
            "sourceFieldName": "fileName",
            "targetFieldName": "fileName",
            "mappingFunction": null
        }
    ],
    "outputFieldMappings": [],
    "cache": null,
    "encryptionKey": null
    }
"@

    Add-AcsComponent -headers $headers -apiVersion $apiVersion -method "put" -searchServiceName $searchServiceName `
        -path "indexers" -name $searchIndexerName -body $searchIndexerBody
}

function Add-AcsComponent(
    [Parameter(Mandatory = $true)]
    [Hashtable]$headers,
    [Parameter(Mandatory = $true)]
    [string]$apiVersion,
    [Parameter(Mandatory = $true)]
    [string]$method,
    [Parameter(Mandatory = $true)]
    [string]$searchServiceName,
    [Parameter(Mandatory = $true)]
    [string]$path,
    [Parameter(Mandatory = $false)]
    [string]$name,
    [Parameter(Mandatory = $true)]
    [string]$body
) {
    $route = $null -eq $name ? $path : "${path}/${name}"
    $uri = "https://${searchServiceName}.search.windows.net/${route}?api-version=${apiVersion}"

    Write-Host "Adding ${name} to ${path}"
    
    try {
        $response = Invoke-WebRequest -Method $method -Uri $uri -Headers $headers -Body $body
        Write-Host "Added $($response.name)"
    }
    catch {
        Write-Host "$([int]$_.Exception.Response.StatusCode) $($_.Exception.Response.ReasonPhrase)"
        Write-Host ($_ | ConvertFrom-Json | ConvertTo-Json)
    }
    
    Write-Host ""
}

function Confirm-AcsComponentDoesNotExist(
    [Parameter(Mandatory = $true)]
    [Hashtable]$headers,
    [Parameter(Mandatory = $true)]
    [string]$apiVersion,
    [Parameter(Mandatory = $true)]
    [string]$searchServiceName,
    [Parameter(Mandatory = $true)]
    [string]$path,
    [Parameter(Mandatory = $true)]
    [string]$name
) {
    $uri = "https://${searchServiceName}.search.windows.net/${path}/${name}?api-version=${apiVersion}"

    try 
    {
        $response = Invoke-WebRequest -Method get -Uri $uri -Headers $headers -Body $body

        Write-Host "${searchServiceName} ${path}/${name} already exists. Either provide a unique name for this component, or delete the existing one." -ForegroundColor Red

        return $false
    }
    catch 
    {
        $response = $_.Exception.Response

        return $response.StatusCode -eq 404
    }
}