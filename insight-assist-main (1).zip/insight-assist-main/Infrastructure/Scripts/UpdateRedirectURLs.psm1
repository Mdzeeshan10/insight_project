#This script is a dev only script for auto updating the app registration with the redirect URI for the web application
#unlikely to ever be used in a secure environment

$webAppRedirectURI = "https://$(tout.app_service_web_app_name).azurewebsites.net/signin-oidc"
$objectID = "97edce26-5c29-4e03-a3a2-ea59b1bd9459"
$app = az ad app show --id $objectID | ConvertFrom-Json


$redirectURIs = $app.web.redirectUris

$string = ""
foreach ($uri in $redirectURIs)
{
    $string = $string + " $($uri)" 
}

$string = $string + " $($webAppRedirectURI)"

az ad app update --id $objectID --web-redirect-uris $string
