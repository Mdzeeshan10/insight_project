
$env=$args[0]
function Get-SelectionFromUser {
    param (
        [Parameter(Mandatory=$true)]
        [string[]]$Options,
        [Parameter(Mandatory=$true)]
        [string]$Prompt        
    )
    
    [int]$Response = 0;
    [bool]$ValidResponse = $false    

    while (!($ValidResponse)) {            
        [int]$OptionNo = 0

        Write-Host $Prompt -ForegroundColor DarkYellow
        Write-Host "[0]: Quit"

        foreach ($Option in $Options) {
            $OptionNo += 1
            Write-Host ("[$OptionNo]: {0}" -f $Option)
        }

        if ([Int]::TryParse((Read-Host), [ref]$Response)) {
            if ($Response -eq 0) {
                return ''
            }
            elseif($Response -le $OptionNo) {
                $ValidResponse = $true
            }
        }
    }

    return $Options.Get($Response - 1)
} 

$environmentPath = "./Environments/"
$environmentChoice = $env

if ($null -eq $env)
{
    $environments = Get-ChildItem -Path $environmentPath -Directory 
    $environmentChoice = Get-SelectionFromUser -Options ($environments.Name) -Prompt "Select Deployment Environment:"
}

$env:TF_VAR_tf_EnvironmentName = $environmentChoice
$currentFolderPath = (Get-Location).Path
$deploymentFolderPath = "./Terraform/"
$moduleFolderPath = "./Terraform/Scripts/Deploy.psm1"

Import-Module $moduleFolderPath -force

#---------------------------------------------------------------
# Deploy via Terraform
#---------------------------------------------------------------
ModuleDeployment -terraformFolderPath $deploymentFolderPath -pathToReturnTo $currentFolderPath


################################################################
################################################################
# Post-Deploy Steps
################################################################
################################################################


#---------------------------------------------------------------
# Getting Terraform Outputs
#---------------------------------------------------------------
$deploymentFolderPath = "./Terraform/"
$moduleFolderPath = "./Terraform/Scripts/TerraformOutputs.psm1"

Import-Module $moduleFolderPath -force
$tout = TerraformOutputs -terraformFolderPath $deploymentFolderPath -pathToReturnTo $currentFolderPath

#---------------------------------------------------------------
# Check for SQL Module
#---------------------------------------------------------------

try { 
    $SqlInstalled = Get-InstalledModule SqlServer
}
catch { 
    "SqlServer PowerShell module not installed." 
}

if ($null -eq $SqlInstalled) {
    write-host "Installing SqlServer Module"
    Install-Module -Name SqlServer -Scope CurrentUser -Force
}

#---------------------------------------------------------------
# Publish Database Users (Update Firewall / MSI)
#---------------------------------------------------------------
$moduleFolderPath = "./Terraform/Scripts/Dbusers.psm1"

Import-Module $moduleFolderPath -force
DatabaseUsers -terraformFolderPath $deploymentFolderPath -pathToReturnTo $currentFolderPath -tout $tout

#---------------------------------------------------------------
# Create Default Search Service Index / Data Source / Indexer
#---------------------------------------------------------------
# $moduleFolderPath = "./Scripts/CreateDefaultSearchIndex.psm1"

# Import-Module $moduleFolderPath -force
# CreateDefaultSearchIndex -tout $tout