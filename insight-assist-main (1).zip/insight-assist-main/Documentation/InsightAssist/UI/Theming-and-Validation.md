# Theming and Validation <!-- omit in toc -->

- [Overview](#overview)
- [Color Variables and Sass Mixins](#color-variables-and-sass-mixins)
  - [Variable and Mixin Examples](#variable-and-mixin-examples)
- [Angular Material Component Library](#angular-material-component-library)
  - [Theming Angular Material Components](#theming-angular-material-components)
    - [Button Example](#button-example)
  - [Validation and Surfacing Errors](#validation-and-surfacing-errors)
    - [Validation Example](#validation-example)
  - [Components that Support Theming](#components-that-support-theming)
- [Creating New Themes](#creating-new-themes)

## Overview

There are two ways to use theme-dependent colors throughout the app. The Sass files of regular components can use existing variables and mixins, and components from the Angular Material Components Library will automatically pick up the colors from the configured theme.

There are two ways to use theme-dependent colors throughout the app. One is by using the Sass variables and mixins provided in `src/colors.scss`. The other is by using components provided by the Angular Material Component Library.

## Color Variables and Sass Mixins

In `src/colors.scss`, there are Sass variables and mixins that can be used in the `.scss` files of Angular components. The variables are simply replacements for color values, while the mixins are pairs of background and text colors that can be inserted into CSS blocks.

### Variable and Mixin Examples

To use variables and mixins, first add a `@use` statement at the top of the file to import `src/colors.scss`.

``` scss
@use 'src/colors.scss' as colors;
```

Variables can be assigned to any CSS attribute that accepts a hex color value.

``` scss
.class-name
{
  color: colors.$primary-color;
}
```

The opacity of a color can be controlled using the `rgba` function.

``` scss
.class-name
{
  background: rgba(colors.$primary-color, 0.33);
}
```

Mixins can be added to CSS classes with the `@include` statement.

``` scss
.class-name
{
  @include colors.theme-neutral;
}
```

## Angular Material Component Library

While this project isn't married to Google's Material Design guidelines, the [Angular Material Component Library](https://material.angular.io/) provides UI components that are commonly used both on Insight projects and in Angular apps in general. Their built-in support for validation and theming makes them useful tools for creating a unified, customizable look across the app. Angular Material components that support theming should generally be preferred over plain HTML/CSS elements, particularly when there is a need for form validation and surfacing validation errors.

### Theming Angular Material Components

In terms of theming, some (but not all) Angular Material components allow developers to specify one of three colors to use from a pre-defined theme - `primary`, `accent`, or `warn`. A good example that shows this feature in action is the library's [Button](https://material.angular.io/components/button/overview) documentation.

#### Button Example

To apply a theme color to a button, simply add a `color` attribute with one of the three supported theme colors as its value, as shown below. (There are several button styles to choose from, but the `mat-flat-button` style is used most commonly used in the app already.)

``` html
<button mat-flat-button color="primary">Primary</button>
<button mat-flat-button color="accent">Accent</button>
<button mat-flat-button color="warn">Warn</button>
```

### Validation and Surfacing Errors

Some components, like [Input](https://material.angular.io/components/input/overview) and [Select](https://material.angular.io/components/select/overview), will automatically apply the `warn` color and display [error messages](https://material.angular.io/components/form-field/overview#error-messages) when used inside a [Form Field](https://material.angular.io/components/form-field/overview) that is set up with an underlying `FormControl` with configured validation rules.

#### Validation Example

As an example, consider the email entry field in the [error messages](https://material.angular.io/components/form-field/overview#error-messages) documentation. The component's HTML file contains a `<mat-form-field>` element, which is wrapped around an `<input>` that is decorated with a `[formControl]="email"` attribute. This attribute connects it to the `FormControl` variable called `email` in the component's Typescript file. The `FormControl`'s constructor includes an array of built-in validators.

HTML:

``` html
<mat-form-field>
  <mat-label>Enter your email</mat-label>
  <input matInput placeholder="pat@example.com" [formControl]="email" required>
  <mat-error *ngIf="email.invalid">{{getErrorMessage()}}</mat-error>
</mat-form-field>
```

Typescript:

``` ts
export class FormFieldErrorExample {
  email = new FormControl('', [Validators.required, Validators.email]);

  getErrorMessage() {
    if (this.email.hasError('required')) {
      return 'You must enter a value';
    }

    return this.email.hasError('email') ? 'Not a valid email' : '';
  }
}
```

### Components that Support Theming

- [Badge](https://material.angular.io/components/badge/overview)
- [Button](https://material.angular.io/components/button/overview)
- [Checkbox](https://material.angular.io/components/checkbox/overview)
- [Chips](https://material.angular.io/components/chips/overview)
- [Datepicker](https://material.angular.io/components/datepicker/overview)
- [Expansion Panel](https://material.angular.io/components/expansion/overview)
- [Form Field](https://material.angular.io/components/form-field/overview)
- [Icon](https://material.angular.io/components/icon/overview)
- [Input](https://material.angular.io/components/input/overview)
- [Progress Bar](https://material.angular.io/components/progress-bar/overview)
- [Progress Spinner](https://material.angular.io/components/progress-spinner/overview)
- [Radio Button](https://material.angular.io/components/radio/overview)
- [Select](https://material.angular.io/components/select/overview)
- [Slide Toggle](https://material.angular.io/components/slide-toggle/overview)
- [Slider](https://material.angular.io/components/slider/overview)

## Creating New Themes

To create a new theme, create a copy of `src/theme.scss` in the `src/assets/scss/themes` folder, and give it a new name. Then, alter the colors in the file as needed.

The first three variables in the theme file are `$primary-hues`, `$accent-hues`, and `$warn-hues`. These Sass maps are used to set the theme for Angular Material components, and need to follow a specific (admittedly verbose for our purposes) format, as well as the `$primary-*`, `$accent-*`, and `$warn-*` variables in `src/colors.scss`.

Don't change these color maps manually! It's a pain in the butt. Instead, use a palette generator like [this one](http://mcg.mbitson.com/#!?primary=%23d40a54&accent=%23582873&warn=%23cc0000&themename=mcgtheme) to generate them automatically based on a single color for each of the three palettes.

There are two additional color maps that are only partially used by Angular Material, called `$light-colors` and `$dark-colors`. These define the background and text colors used in light and dark mode, as well as which hue from the color map is used for both Angular Material components and components that use the Sass variables and mixins.

The app's theme will be set during each environment's deployment, so to test a theme locally, you'll need to overwrite `src/theme.scss` with the contents of the new theme file. Revert this change before you commit.