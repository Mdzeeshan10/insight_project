# Semantic Kernel Overview <!-- omit in toc -->

- [Basic Components](#basic-components)
- [Semantic Kernel in Insight Lens for Gen AI](#semantic-kernel-in-insight-lens-for-gen-ai)
  - [KernelService](#kernelservice)
  - [Custom Plugins](#custom-plugins)
    - [Semantic Functions](#semantic-functions)
    - [Native Functions](#native-functions)
- [Resources](#resources)

Semantic Kernel is an AI orchestration layer that enables the integration of AI services into applications. It provides a common interface for interacting with multiple models and AI services, and includes tools for interacting with LLMs for text/chat completion, text embedding models and vector databases for simulating memories, integrating these services with native functions via plugins, and mixing and matching these skills based on user needs.

Note that Semantic Kernel is in _public preview_. Toolsets for working with LLMs and realted AI models and services are all emerging technologies, and are under heavy development across the board - Semantic Kernel included. Devs should be aware that it may change quickly and keep tabs on those changes and how they might impact this app.

- [Semantic Kernel on GitHub](https://github.com/microsoft/semantic-kernel)
- [Semantic Kernel Project Boards](https://github.com/microsoft/semantic-kernel/projects?query=is%3Aopen)

## Basic Components

There are a few basic components of Semantic Kernel that work together to process a user's request and generate a response.

- **Kernel**: Provides and orchestrates Semantic Kernel components
- **Connectors**: Configured when building the kernel to enable it to connect to AI services
- **Plugins and Functions**: Plugins are sets of functions that make use of the kernel and its connectors to perform tasks
  - **Semantic Functions**: Invoke an LLM with a prompt and configuration to get a text/chat completion
  - **Native Functions**: C# functions that interact with the app's other services
  - *Note: Plugins were originally called "Skills", and are in the process of being renamed.  Some functions that interact with plugins still have "Skill" in the name, but will likely change at some point.*
- **Memory**: Uses a kernel's embedding model and vector database to save and search for memories
- **Planner**: Creates a plan based on user input to use the kernel's functions to address the user's ask

## Semantic Kernel in Insight Lens for Gen AI

In Assist.Accelerator.Chat.Api, the core of Semantic Kernel is the `KernelService`.  Custom plugins are located in the `SemanticKernel/Plugins` directory.

### KernelService

First, in the class constructor, the kernel is built:

```csharp
_kernel = Kernel.Builder
    .WithLogger(logger)
    .WithAzureChatCompletionService(_model.DeploymentName, url, key)
    .WithAzureTextEmbeddingGenerationService(embeddingModel, url, key)
    .WithMemoryStorage(new VolatileMemoryStore())
    .Build();
```

Then, the plugins are imported:

```csharp
_chatPlugin = _kernel.ImportSkill(new ChatPlugin(_kernel, usageService, usersService));
_chatHistoryPlugin = _kernel.ImportSkill(new ChatHistoryPlugin(chatService));
_filePlugin = _kernel.ImportSkill(new FilePlugin(fileService, fileParserService));
_memoryPlugin = _kernel.ImportSkill(new MemoryPlugin());
```

In the `GetChatCompletionAsync` function, context variables are set, and the kernel is invoked with a manually selected chain of functions:

```csharp
var contextVars = new ContextVariables();
contextVars.Set("userInput", body.Input);
contextVars.Set("fileName", body.FileName);
contextVars.Set("chatId", chatId.ToString());
contextVars.Set("userId", user.UserId.ToString());
contextVars.Set("modelId", _model.Id.ToString());

var result = await _kernel.RunAsync(
    contextVars,
    _chatHistoryPlugin["GetChatHistory"],
    _chatPlugin["GetUserIntent"],
    _filePlugin["GetFileContents"],
    _memoryPlugin["GetMemories"],
    _chatPlugin["GetChatCompletion"],
    _chatPlugin["GetChatTitle"],
    _chatHistoryPlugin["UpdateChatHistory"]);
```

This is a basic setup of Semantic Kernel. This invocation of `RunAsync` is _manually orchestrated_, but could be _automatically orchestrated_ by creating a [planner](https://learn.microsoft.com/en-us/semantic-kernel/ai-orchestration/planner?tabs=Csharp), which uses an LLM to mix and match plugins and their functions based on the user's request. 

In the future, this service can be expanded to create multiple kernels (e.g. for GCP or other AI service connectors), select between a set of manually orchestrated invocations and/or one or more planners, etc.

### Custom Plugins

Semantic Kernel plugins are essentially services with functions that can be invoked by the kernel in series.  Some built-in plugins exist, but custom plugins are how Semantic Kernel interacts with other parts of the application it's used in.

There are two kinds of functions: [Semantic functions](https://learn.microsoft.com/en-us/semantic-kernel/ai-orchestration/semantic-functions?tabs=Csharp), which invoke an LLM with a prompt and some configuration, and [native functions](https://learn.microsoft.com/en-us/semantic-kernel/ai-orchestration/native-functions?tabs=Csharp), which are normal C# functions with a request context and context variables passed as input by Semantic Kernel.

#### Semantic Functions

There are two ways to create a semantic function.  One is by creating a `.txt` file with a prompt and a `.json` file with prompt configuration values in a directory that can be imported into a kernel.  The other is by declaring the prompt and configuration values inline in C# as part of a native function.  The `ChatPlugin` uses the latter approach because there is some pre-/post-processing logic that needs to accompany every invocation of the LLM.

As an example, consider the `GetChatCompletion` function.  First, in the `ChatPlugin` constructor, the semantic function is registered to the kernel using the `RegisterFunction` helper method:

``` csharp
_getChatCompletion = RegisterFunction(nameof(GetChatCompletion), @"
    You are a friendly and helpful assistant. 
    ...
    USER: {{$prompt}}
    ASSISTANT: 
    ");
```

In the text prompt, `{{$prompt}}` is a reference to a context variable, which is injected automatically when the LLM is invoked.  More on setting context variables below.

#### Native Functions

Next, the native function performs the aforementioned pre-/post-processing logic and invokes the semantic function:

``` csharp
[SKFunction, Description("Gets chat completion from a prompt")]
public async Task GetChatCompletion(
    [Description("The chat's ID")] string chatId,
    [Description("The user's input")] string userInput,
    SKContext context)
{
    if (!context.Variables.ContainsKey("prompt"))
    {
        context.Variables.Set("prompt", userInput);
    }

    var apiCall = CreateApiCall(context, nameof(GetChatCompletion), true);

    var result = await InvokeFunctionAsync(_getChatCompletion, context, apiCall);

    context.Variables.Set("llmOutput", result.Result);
}
```

The main things to note here are:

- The `SKFunction` attribute is what tells Semantic Kernel this is a plugin function that it can import
- The two string input variables with `Description` attributes are pulled from the `SKContext`, which is passed in by the kernel
- The `SKContext` is the context object itself, and exposes not only the collection of context variables, but also the `Memory` object that can set and search for memories, as well as other kernel functionality and data about the request chain
- Variables that are set using `context.Variables.Set` will be available to functions invoked later in the chain
- Context variables are strings, so other types must be passed around with e.g. `ToString()`/`Parse()` or JSON (de)serialization
- Variables that are passed in as function parameters are guaranteed to be set (but may still be empty strings) because when a function is invoked in a chain where any of those parameters aren't in the context variable collection, that function is simply skipped - this may or may not be desirable, so plan accordingly

## Resources

- Good introduction to basic concepts
  - [Semantic Kernel overview](https://learn.microsoft.com/en-us/semantic-kernel/overview/)
- Examples from the Semantic Kernel repo - in theory you can run these by following the setup instructions, but are an excellent reference as text and code samples alone
  - [Semantic Kernel syntax examples](https://github.com/microsoft/semantic-kernel/tree/main/dotnet/samples/KernelSyntaxExamples)
  - [Semantic Kernel C# Notebooks](https://github.com/microsoft/semantic-kernel/tree/main/dotnet/notebooks)
- Sample application showcasing Semantic Kernel's features - not the easiest to navigate with zero Semantic Kernel experience but good for clearing up implementation details
  - [Chat Copilot](https://github.com/microsoft/chat-copilot)
