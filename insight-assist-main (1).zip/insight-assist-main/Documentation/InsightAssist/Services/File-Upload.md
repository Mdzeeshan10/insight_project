# File Upload <!-- omit in toc -->

- [Overview](#overview)
- [Architecture](#architecture)

## Overview

When a user sends a chat message, they have the option of attaching a file to that message.  Files are attached by clicking the paperclip icon, then either dragging and dropping a file onto the popup that appears or clicking "Select File" and browsing to the desired file.  When a file is dropped or selected, it is uploaded to blob storage.  If the user has uploaded a file with the same name in the past, the upload is skipped, because the file is already available in blob storage.

After the upload is complete, the file is attached, and the user can click "Send" to send a message with the name of the file attached.  This allows the API to look up the file in blob storage.  The user may also type a message to send with the file, but this is not required.  When a message with an attached file is sent, the API retrieves the file from blob storage, reads its text content, and adds the text content to chat history.  Semantic Kernel then takes the user's message, the text content of the file, and the chat history (including the text content of any files uploaded previously in the conversation), selects the pieces of text most relevant to the user's prompt, and includes those pieces in a prompt to the LLM.

When viewing a chat's history in the UI, messages with files attached will include a button with the attached file name that allows the user to download the file.

## Architecture

When the API gets or retrieves a file from blob storage, it prefixes the file name with the email address retrieved from the claims in the user's auth token.  This way, users can only access their own files.

When a chat message with an attached file is processed, the text content of that file is added to that chat's history, which is stored in the SQL database.

[File Upload Architecture Diagram](https://insightonline-my.sharepoint.com/:p:/g/personal/katie_hess_insight_com/Ea_73zE02QZLsuFkx7n_lMIBz_AkeQgWUXkFpu2g1qjL-g?e=7YSNBS)
