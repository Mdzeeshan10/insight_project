# Insight Assist Python-Api

This project was done with [Python](https://github.com/python) version 3.11.

## API Web server
to run this project as standalone for testing
1. pip install -r requirements.txt
2. waitress-serve --call wsgi:create_app

## Local endpoint of api:
http://127.0.0.1:8080/api

 
## Example
request type- POST

request Body structure-

{
  "openai_endpoint": "",
  "openai_key": "",
  "openai_apiversion": "",
  "openai_llmdeployname": "",
  "openai_embeddeployname": "",
  "search_endpoint": "",
  "search_key": "",
  "index_name": "",
  "question": ""
}
Note- openai_llmdeployname is openai gpt deployment name, openai_embeddeployname is openai embedding model deployment name.