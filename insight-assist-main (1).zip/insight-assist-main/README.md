# Insight Assist Generative AI

An evolving accelerator based on Insight's offerings in the Generative AI space. The intention of this project is to slowly merge the efforts of -
- Insight-NA "Ask Me Anything" - <br> repo tbd
- Insight-APAC "Insight Assist" - <br> https://github.com/Insight-Services-APAC/chatgpt-insight-assist
- Insight-NA "Insight Assist MegaDemo" - <br>https://dev.azure.com/InsightIPEngineering/Demo%20Retail%20Application/_git/MegaAssist

Over time, code and use cases will be merged from the three projects above into a comprehensive IP offering around Insight's Generative AI capabilities - initially focused around Azure OpenAI.

## About Insight Assist

### Source Code

- [GitHub Repo](https://github.com/Insight-NA/insight-assist/tree/main)
  - [Backlog](https://github.com/orgs/Insight-NA/projects/24/views/6?filterQuery=-status%3ADone)
- [Database](/Database/Assist.Accelerator.Chat.Sql/)
- [Services](/Services/Assist.Accelerator.Chat.Api/)
- [Python-Api](/Python-Api/)
- [UI](/UI/Assist.Accelerator.Chat.Web/)

### Documentation

- [Documentation](/Documentation/README.md)
  - [Database](/Documentation/InsightAssist/Database/README.md)
  - [Infrastructure](/Documentation/InsightAssist/Infrastructure/README.md)
  - [Services](/Documentation/InsightAssist/Services/README.md)
  - [Python-Api](/Documentation/InsightAssist/Python-Api/README.md)
  - [UI](/Documentation/InsightAssist/UI/README.md)

### Getting Started

To access the web app in the Dev environment, [click here](https://mega-dev-app-openai-webapp.azurewebsites.net/). Log in with your Insight account. If you aren't able to access it, you either haven't been invited to the Insight IP Engineering Azure AD tenant, or you haven't been added as a user to the app itself. In either case, an admin (i.e. your manager, probably) can grant you access.

- [Run the API locally](/Documentation/InsightAssist/Services/README.md#getting-started)
- [Run the UI locally](/Documentation/InsightAssist/UI/README.md#getting-started)

