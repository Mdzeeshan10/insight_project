﻿/*
 Pre-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be executed before the build script.	
 Use SQLCMD syntax to include a file in the pre-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the pre-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
-- NOTE: This is an example of a drop-column pre-deployment step. Used only for future reference.
  IF EXISTS(SELECT 1 FROM sys.columns 
          WHERE Name = N'ExampleColumn'
          AND Object_ID = Object_ID(N'dbo.dimExampleTable'))
  BEGIN
    alter table dimExampleTable drop column ExampleColumn
  END
--

-- Drop Legacy Control Tables
DROP TABLE IF EXISTS [ctl].[Log];
DROP TABLE IF EXISTS [ctl].[LogType];
DROP TABLE IF EXISTS [ctl].[ChatHistory];
DROP TABLE IF EXISTS [ctl].[ChatType];
DROP TABLE IF EXISTS [ctl].[UserSourceObject];
DROP TABLE IF EXISTS [ctl].[SourceObject];
DROP TABLE IF EXISTS [ctl].[SourceObjectGroup];
DROP TABLE IF EXISTS [ctl].[APIUser];
--
