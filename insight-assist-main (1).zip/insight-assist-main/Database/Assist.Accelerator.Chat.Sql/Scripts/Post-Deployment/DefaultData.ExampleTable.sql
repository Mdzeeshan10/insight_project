﻿-- Example: Write SQL Insert for Seed Data Here
--
--SET IDENTITY_INSERT [dbo].[ExampleTable] ON 
--GO

--SET IDENTITY_INSERT [dbo].[ExampleTable] OFF
--GO