﻿CREATE TABLE [dbo].[AzureSearchIndexUsers] (
    [Id]       INT IDENTITY (1, 1) NOT NULL,
    [IndexID]  INT NOT NULL,
    [UserId]   INT NOT NULL,
    [isActive] BIT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);





