﻿CREATE TABLE [ctl].[CopilotSettings]
(
	[CopilotId] INT NOT NULL PRIMARY KEY,
	[Endpoint] [varchar](max) NOT NULL,
	[AuthProvider] INT NOT NULL,
	[CredentialData] [varchar](max) NOT NULL,
	[Pipeline] [varchar](max) NOT NULL DEFAULT ''
)
