﻿CREATE TABLE [ctl].[HistoricalStats]
(
	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Index] INT NOT NULL,
	[Name] [varchar](200) NOT NULL,
	[StartDateTime] [datetime] NOT NULL,
	[Span] INT NOT NULL,
	[Points] [varchar](max) NULL DEFAULT '[]',
	[Data] [varchar](max) NULL DEFAULT '{}'
)
