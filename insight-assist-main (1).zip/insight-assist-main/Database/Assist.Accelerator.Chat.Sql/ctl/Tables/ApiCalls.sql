﻿CREATE TABLE [ctl].[ApiCalls]
(
	[Id] BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[UserId] INT NOT NULL,
	[MethodName] [varchar](200) NOT NULL,
	[ModelId] INT NULL,
	[DeploymentName] [varchar](200) NOT NULL,
	[ChatId] [uniqueidentifier] NULL,
	[IsSystemAction] [bit] NULL,
	[RequestOptions] [varchar](max) NOT NULL,
	[Tags] [varchar](max) NULL,
	[RequestedAt] [datetime] NOT NULL,
	[ReceivedResponseAt] [datetime] NOT NULL,
	[RequestDurationMs] INT NULL,
	[CompletionTokenCount] INT NULL,
	[PromptTokenCount] INT NULL,
	[TotalTokenCount] INT NULL,
	[CostUsed] BIGINT NULL,
	[ResponseMessage] [varchar](max) NULL,
	[ResponseError] [varchar](max) NULL
)
