﻿CREATE TABLE [ctl].[CopilotChatState] (
    [ChatId]    VARCHAR (50)  NOT NULL,
    [ChatState] VARCHAR (MAX) NOT NULL
);