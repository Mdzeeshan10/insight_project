﻿CREATE TABLE [ctl].[BusinessLines]
(
	[LobId] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[LobName] NVARCHAR(64) NOT NULL,
	[LobDescription] NVARCHAR(255)
)
