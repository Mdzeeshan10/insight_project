﻿CREATE TABLE [ctl].[BusinessLineDataSources]
(
    [LobId] INT NOT NULL,
    [SourceId] INT NOT NULL,
    PRIMARY KEY([LobId], [SourceId]),
    FOREIGN KEY([LobId]) REFERENCES [ctl].[BusinessLines]([LobId]),
    FOREIGN KEY([SourceId]) REFERENCES [ctl].[DataSources]([SourceId])
)
