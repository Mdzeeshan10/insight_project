﻿CREATE TABLE [ctl].[QuotaAssignments]
(
	[UserId] INT NOT NULL,
	[QuotaTemplateId] INT NOT NULL,
	PRIMARY KEY([UserId],[QuotaTemplateId])
)
