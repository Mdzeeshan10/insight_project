﻿/****** Object:  Schema [ctl]    Script Date: 5/18/2023 9:43:32 PM ******/
CREATE SCHEMA [ctl]
    AUTHORIZATION [dbo];




GO
