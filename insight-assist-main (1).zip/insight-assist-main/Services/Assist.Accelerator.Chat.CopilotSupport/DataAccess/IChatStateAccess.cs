﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.CopilotSupport.DataAccess
{
    public interface IChatStateAccess
    {
        Task<string> GetCopilotChatStateAsync(string chatId);

        Task SaveCopilotChatAsync(string chatId, string stateJson);
    }
}
