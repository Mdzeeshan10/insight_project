﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.CopilotSupport.DataAccess
{
    internal interface ICopilotAccess
    {
        IEnumerable<CopilotRegistration> LoadRegisteredCopilots();

        int SaveCopilot(CopilotRegistration copilot);
    }
}
