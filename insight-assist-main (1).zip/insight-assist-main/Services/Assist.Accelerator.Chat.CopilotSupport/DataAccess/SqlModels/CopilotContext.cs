﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.CopilotSupport.DataAccess.SqlModels
{
    internal class CopilotContext:DbContext
    {
        private readonly string _connectionString;

        public DbSet<CopilotSqlModel> Copilots { get; set; }
        public DbSet<CopilotSettingsSqlModel> CopilotSettings { get; set; }

        public CopilotContext(string cn)
        {
            _connectionString = cn;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if(optionsBuilder.IsConfigured == false)
            {
                optionsBuilder.UseSqlServer(_connectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Do Nothing in here.
        }
    }
}
