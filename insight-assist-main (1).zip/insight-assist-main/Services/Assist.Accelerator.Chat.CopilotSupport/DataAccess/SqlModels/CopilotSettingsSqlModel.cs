﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.CopilotSupport.DataAccess.SqlModels
{
    [Table("CopilotSettings", Schema ="ctl")]
    internal class CopilotSettingsSqlModel
    {
        [Key]
        public int CopilotId { get; set; }

        [Required]
        public string Endpoint { get; set; }

        [Required]
        public int AuthProvider { get; set; }

        [Required]
        public string CredentialData { get; set; }

        [Required]
        public string Pipeline { get; set; }
    }
}
