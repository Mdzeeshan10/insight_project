﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.CopilotSupport.DataAccess.SqlModels
{
    [Table("Copilots", Schema ="ctl")]
    internal class CopilotSqlModel
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public string SystemName { get; set; }

        [Required]
        public string DisplayName { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public string IntroMessage { get; set; }

        [Required]
        public bool IsActive { get; set; }

        [Required]
        public string FileTypes { get; set; }
        
        public string? ImageURL { get; set; }

        public string? SubTitle { get; set; }    
    }
}
