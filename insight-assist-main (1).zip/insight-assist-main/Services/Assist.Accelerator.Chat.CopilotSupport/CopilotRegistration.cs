﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.CopilotSupport
{
    /// <summary>
    /// Used to store information needed at runtime for the CoPilots registered in the database.
    /// </summary>
    public class CopilotRegistration
    {
        public int Id { get; set; }

        public string SystemName { get; set; }

        public string DisplayName { get; set; }

        public string Description { get; set; }

        public string IntroMessage { get; set; }

        public bool IsActive { get; set; }

        public string FileTypes { get; set; }
        public string SubTitle { get; set; }
        public string ImageURL { get; set; }    

        public string Pipeline { get; set; }

        public int AuthProviderId { get; set; }

        public string? Endpoint { get; set; }

        public string? CredentialData { get; set; }

        public Type? Implementation { get; set; }
    }
}
