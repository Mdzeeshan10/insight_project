﻿using Microsoft.SemanticKernel.SkillDefinition;

namespace Assist.Accelerator.Chat.CopilotSupport
{
    public interface ICopilot
    {
        string Name { get; }

        Dictionary<string, IDictionary<string, ISKFunction>> AddCopilotSpecificPlugins(Dictionary<string, IDictionary<string, ISKFunction>> globalPlugins);

        static CopilotRegistration RegisterSelf(Func<CopilotRegistration, int> registrationVisitor)
        {
            throw new InvalidOperationException("This method must be called on a concrete implementation of ICopilot.");
        }
    }
}