﻿using Assist.Accelerator.Chat.CopilotSupport.DataAccess;
using Assist.Accelerator.Core.Events;
using Microsoft.Extensions.Configuration;
using Microsoft.SemanticKernel;
using System.Reflection;

namespace Assist.Accelerator.Chat.CopilotSupport
{
    public class CopilotSupportService : ICopilotSupport
    {
        private readonly Dictionary<int, CopilotRegistration> _registeredCopilots;
        private readonly string _connectionString;
        private readonly IConfiguration _configuration;
        private readonly IEventSink? _eventSink;

        public CopilotSupportService(IConfiguration configuration, IEventSink? eventSink = null)
        {
            _eventSink = eventSink;
            _configuration = configuration;
            _connectionString = configuration.GetConnectionString("ControlDb")!;
            _registeredCopilots = LoadCopilotRegistry();
        }

        public ICopilot? LoadCopilot(int copilotId, IKernel kernel)
        {
            ICopilot? copilot = null;
            
            Type? copilotType = null;
            CopilotRegistration? reg = null;

            if (_registeredCopilots.TryGetValue(copilotId, out reg))
            {
                copilotType = reg.Implementation;

                if(copilotType != null)
                {
                    copilot = CreateCopilot(copilotType, kernel);
                }
            }

            return copilot;
        }

        /// <summary>
        /// Instantiates a new instance of the requested copilot implementation.
        /// </summary>
        /// <param name="copilotType"></param>
        /// <param name="kernel"></param>
        /// <returns></returns>
        private ICopilot? CreateCopilot(Type copilotType, IKernel kernel)
        {
            ICopilot? ret = null;

            ConstructorInfo? eventConstructor = copilotType.GetConstructor(new Type[] { typeof(IKernel), typeof(IConfiguration), typeof(IEventSink) });
            if(eventConstructor != null)
            {
                ret = (ICopilot)eventConstructor.Invoke(new object[] { kernel, _configuration, _eventSink });
                return ret;
            }

            // See if there's a constructor that accepts kernel+configuration.  If so, use that and return.
            ConstructorInfo? configConstructor = copilotType.GetConstructor(new Type[] { typeof(IKernel),typeof(IConfiguration) });
            if(configConstructor != null)
            {
                ret = (ICopilot)configConstructor.Invoke(new object[] { kernel, _configuration });
                return ret;
            }

            ConstructorInfo? typeConstructor = copilotType.GetConstructor(new Type[] { typeof(IKernel) });
            if (typeConstructor != null)
            {
                ret = (ICopilot?)typeConstructor.Invoke(new object[] { kernel });
            }

            return ret;
        }

        private Dictionary<int, CopilotRegistration> LoadCopilotRegistry()
        {
            Dictionary<int, CopilotRegistration> ret = new Dictionary<int, CopilotRegistration>();

            CopilotAccess access = new CopilotAccess(_connectionString);
            
            List<CopilotRegistration> registeredCopilots = access.LoadRegisteredCopilots().ToList();
            Dictionary<string, Type> customCopilots = GetImplementedCopilots(access, registeredCopilots);


            if (registeredCopilots?.Any() ?? false)
            {
                foreach(CopilotRegistration copilot in registeredCopilots)
                {
                    if (customCopilots.ContainsKey(copilot.SystemName))
                    {
                        copilot.Implementation = customCopilots[copilot.SystemName];
                    }

                    ret.Add(copilot.Id, copilot);
                }
            }

            return ret;
        }

        public int RegisterCopilot(CopilotRegistration copilot)
        {
            ICopilotAccess access = new CopilotAccess(_connectionString);
            int copilotId = access.SaveCopilot(copilot);

            return copilotId;
        }

        /// <summary>
        /// Performs a scan of referenced assemblies whose name ends with "Copilot" 
        /// as well as a scan of the local assembly for any ICopilot implementations.
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, Type> GetImplementedCopilots(CopilotAccess access, List<CopilotRegistration> registeredCopilots)
        {
            Dictionary<string, Type> ret = new Dictionary<string, Type>();

            // Scan the program's local execution folder for any assemblies whose name ends with "Copilot.dll"
            string executionFolder = AppDomain.CurrentDomain.BaseDirectory;
            string[] copilotDlls = Directory.GetFiles(executionFolder, "*Copilot.dll");

            // for each identified dll, check the currently loaded assemblies and if it's not loaded, load it.
            foreach (var copilotDll in copilotDlls)
            {
                string copilotAssemblyName = Path.GetFileNameWithoutExtension(copilotDll);
                if (!AppDomain.CurrentDomain.GetAssemblies().Any(a => a.FullName?.StartsWith(copilotAssemblyName) ?? false))
                {
                    Assembly copilotAssembly = Assembly.LoadFrom(copilotDll);
                }
            }

            List<Assembly> copilotAssemblies = AppDomain.CurrentDomain.GetAssemblies().Where(a => (a.GetName()?.Name?.EndsWith("Copilot") ?? false) == true).ToList() ?? new List<Assembly>();
            List<Type> copilotTypes = copilotAssemblies.SelectMany(a => a.GetTypes().Where(t => t.GetInterfaces().Contains(typeof(ICopilot)))).ToList() ?? new List<Type>();

            foreach (var copilotType in copilotTypes)
            {
                string? name = copilotType.GetField("SystemName", BindingFlags.Public | BindingFlags.Static)?.GetValue(null)?.ToString();
                if (name == null) continue;

                ret.Add(name, copilotType);

                if (registeredCopilots.Any(c => c.SystemName == name) == false)
                {
                    // Get the registerSelf method from the copilot's type and invoke it now.
                    MethodInfo? registerSelfMethod = copilotType.GetMethod("RegisterSelf", BindingFlags.Public | BindingFlags.Static);
                    CopilotRegistration? newCopilot = (CopilotRegistration?)registerSelfMethod?.Invoke(null, new[] { this.RegisterCopilot });
                    if (newCopilot != null)
                    {
                        registeredCopilots.Add(newCopilot);
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Returns registered copilots that match all of the provided predicates.
        /// </summary>
        /// <param name="predicates">An array of CopilotPredicate</param>
        /// <returns></returns>
        public IEnumerable<CopilotRegistration> FilterCopilots(CopilotPredicate[] predicates)
        {
            var registrations = _registeredCopilots.Values.Where(c => predicates.All(p => p.Predicate(c) == true)).AsEnumerable();
            return registrations;
        }

        public CopilotRegistration GetCopilot(int copilotId)
        {
            CopilotRegistration? copilotRegistration = null;
            if(_registeredCopilots.TryGetValue(copilotId, out copilotRegistration) == false)
            {
                throw new ArgumentException($"No copilot with Id {copilotId} has been found.");
            }

            return copilotRegistration;
        }
    }
}
