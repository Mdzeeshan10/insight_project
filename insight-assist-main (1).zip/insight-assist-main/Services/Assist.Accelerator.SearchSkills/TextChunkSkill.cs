using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using AzureCognitiveSearch.PowerSkills.Common;
using Microsoft.SemanticKernel.Text;

namespace Assist.Accelerator.AcsSkills
{
    public static class TextChunkSkill
    {
        [FunctionName(nameof(TextChunkSkill))]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log,
            ExecutionContext executionContext)
        {
            var settings = new TextChunkSkillSettings();
            var skillName = executionContext.FunctionName;

            IEnumerable<WebApiRequestRecord> requestRecords = WebApiSkillHelpers.GetRequestRecords(req);
            if (requestRecords == null)
            {
                return new BadRequestObjectResult($"{skillName} - Invalid request record array.");
            }

            WebApiSkillResponse response = WebApiSkillHelpers.ProcessRequestRecords(skillName, requestRecords,
                (inRecord, outRecord) => {
                    var text = inRecord.Data["text"] as string;
                    var chunks = TextChunker.SplitPlainTextParagraphs(new List<string> { text }, settings.ChunkSize, settings.ChunkOverlap);
                    outRecord.Data["chunks"] = chunks;
                    return outRecord;
                });

            return new OkObjectResult(response);
        }
    }
}
