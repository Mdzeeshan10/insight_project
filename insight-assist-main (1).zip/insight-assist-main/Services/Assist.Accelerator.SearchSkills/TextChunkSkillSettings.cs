﻿using Common;

namespace Assist.Accelerator.AcsSkills
{
    public class TextChunkSkillSettings : AppSettings
    {
        public int ChunkSize { get; set; } = 256;
        public int ChunkOverlap { get; set; } = 32;

        public TextChunkSkillSettings() : base(typeof(TextChunkSkillSettings)) 
        { }
    }
}
