﻿using System;

namespace Common
{
    public class AppSettings
    {
        public AppSettings(Type type)
        {
            foreach (var prop in type.GetProperties())
            {
                var value = Environment.GetEnvironmentVariable(prop.Name);

                if (value != null)
                {
                    prop.SetValue(this, Convert.ChangeType(value, prop.PropertyType));
                }
            }
        }
    }
}
