using Assist.Accelerator.Chat.Api.Hubs;
using Assist.Accelerator.Core.Events;
using Azure.AI.OpenAI;
using Microsoft.AspNetCore.SignalR;

namespace Assist.Accelerator.Chat.Api.Services;

public static class StreamMessageTypes
{
    public const string BeginChatStream = "BeginChatStream";
    public const string ReceiveChatMessage = "ReceiveChatMessage";
    public const string EndChatStream = "EndChatStream";
    public const string UpdateStatus = "UpdateStatus";
}

public class BoundResponseStreamingService
{
    private readonly ResponseStreamingService _responseStreamingService;
    private readonly string _groupName;

    public BoundResponseStreamingService(ResponseStreamingService responseStreamingService, string groupName)
    {
        _responseStreamingService = responseStreamingService;
        _groupName = groupName;
    }
    
    public async Task BeginResponseStream()
    {
        await _responseStreamingService.BeginResponseStream(_groupName);
    }

    public async Task SendPartialResponse(string message)
    {
        await _responseStreamingService.SendPartialResponse(_groupName, message);
    }

    public async Task EndResponseStream()
    {
        await _responseStreamingService.EndResponseStream(_groupName);
    }

    public async Task UpdateResponseStatus(string updatedStatus)
    {
        await _responseStreamingService.UpdateResponseStatus(_groupName, updatedStatus);
    }
}

public class ResponseStreamingService : IOperationHandler, IDisposable
{
    private readonly IHubContext<MessageHub> _messageHubContext;
    private readonly IEventSink _eventSink;
    private readonly string _componentId;
    private bool disposedValue;

    public ResponseStreamingService(IHubContext<MessageHub> messageHubContext, IEventSink eventSink)
    {
        _componentId = $"{this.GetType().Name}_{Guid.NewGuid()}";

        _eventSink = eventSink;
        _messageHubContext = messageHubContext;

        RegisterHandlers(eventSink);
    }

    /// <summary>
    /// Convenience handler to return an object bound to the group name, to simplify the interface
    /// </summary>
    /// <param name="groupName"></param>
    /// <returns></returns>
    public BoundResponseStreamingService Bind(string groupName)
    {
        return new BoundResponseStreamingService(this, groupName);
    }

    /// <summary>
    /// Instructs client that response stream is being opened -- useful for preparing appropriate UI 
    /// </summary>
    /// <param name="groupName"></param>
    public async Task BeginResponseStream(string groupName)
    {
        await SendMessageToClientInternal(
            StreamMessageTypes.BeginChatStream, 
            string.Empty, 
            ChatRole.User,
            groupName);
    }

    /// <summary>
    /// Sends a partial response to the client
    /// </summary>
    /// <param name="groupName"></param>
    /// <param name="message">This is the entirety of the response constructed thus far</param>
    public async Task SendPartialResponse(string groupName, string message)
    {
        await SendMessageToClientInternal(
            StreamMessageTypes.ReceiveChatMessage, 
            message, 
            ChatRole.Assistant,
            groupName);
    }

    /// <summary>
    /// Instruct the client that the response has been completely sent and to not expect any more updates regarding this response
    /// </summary>
    /// <param name="groupName"></param>
    public async Task EndResponseStream(string groupName)
    {
        await SendMessageToClientInternal(
            StreamMessageTypes.EndChatStream, 
            string.Empty, 
            ChatRole.User,
            groupName);
    }

    /// <summary>
    /// Notifies the client of the current stage of response processing -- useful for when the system or a copilot is
    /// doing multiple things in the background, such as retrieving data or making intermediate LLM calls
    /// </summary>
    /// <param name="groupName"></param>
    /// <param name="updatedStatus"></param>
    public async Task UpdateResponseStatus(string groupName, string updatedStatus)
    {
        await SendMessageToClientInternal(
            StreamMessageTypes.UpdateStatus, 
            updatedStatus, 
            ChatRole.Assistant,
            groupName);
    }

    private async Task SendMessageToClientInternal(string method, string message, ChatRole role, string groupName)
    {
        try
        {
            await _messageHubContext.Clients.Groups(groupName).SendAsync(method, role, message);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Received SignalR error: " + ex.Message);
        }
    }

    public void RegisterHandlers(IEventSink eventSink)
    {
        string[] eventTypes = new string[]
        {
            nameof(OperationStartingEvent),
            nameof(OperationProgressedEvent),
            nameof(OperationCompletedEvent),
            nameof(OperationFailedEvent)
        };
        eventSink.RegisterHandler(_componentId, eventTypes, OnSignalReceived);

        //eventSink.Subscribe<OperationStartingEvent>(_componentId, OnOperationStarting);
        //eventSink.Subscribe<OperationProgressedEvent>(_componentId, OnOperationProgressed);
        //eventSink.Subscribe<OperationCompletedEvent>(_componentId, OnOperationCompleted);
        //eventSink.Subscribe<OperationFailedEvent>(_componentId, OnOperationFailed);
    }

    public async Task OnSignalReceived(ApplicationSignal signal)
    {
        // Switch is still evil, but at least we only have to enumerate the event types we care about.
        switch (signal.PayloadType)
        {
            case nameof(OperationStartingEvent):
                var startEvt = EventBase.FromJson<OperationStartingEvent>(signal.SerializedPayload);
                await OnOperationStarting(startEvt);
                break;

            case nameof(OperationProgressedEvent):
                var progEvt = EventBase.FromJson<OperationProgressedEvent>(signal.SerializedPayload);
                await OnOperationProgressed(progEvt);
                break;

            case nameof(OperationFailedEvent):
                var failEvt = EventBase.FromJson<OperationFailedEvent>(signal.SerializedPayload);
                await OnOperationFailed(failEvt);
                break;

            case nameof(OperationCompletedEvent):
                var completeEvt = EventBase.FromJson<OperationCompletedEvent>(signal.SerializedPayload);
                await OnOperationCompleted(completeEvt);
                break;
            default:
                return;
        }
    }

    public async Task OnOperationStarting(OperationStartingEvent eventArgs)
    {
        await BeginResponseStream(eventArgs.UserEmail);
    }

    public async Task OnOperationCompleted(OperationCompletedEvent eventArgs)
    {
        //TODO:  DO we want to do this, or should final reporting of the operation completing be delegated to the pipeline?
        await SendPartialResponse(eventArgs.UserEmail, eventArgs.ResponseContent);
        await EndResponseStream(eventArgs.UserEmail);
    }

    public async Task OnOperationFailed(OperationFailedEvent eventArgs)
    {
        await UpdateResponseStatus(eventArgs.UserEmail, eventArgs.ErrorText);
    }

    public async Task OnOperationProgressed(OperationProgressedEvent eventArgs)
    {
        switch (eventArgs.ProgressKind)
        {
            case ProgressEventKind.Status:
                await UpdateResponseStatus(eventArgs.UserEmail, eventArgs.ProgressText);
                break;
            case ProgressEventKind.Incremental:
                await SendPartialResponse(eventArgs.UserEmail, eventArgs.ProgressText);
                break;
        }
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!disposedValue)
        {
            if (disposing)
            {
                _eventSink.UnsubscribeAll(_componentId);
            }

            disposedValue = true;
        }
    }

    public void Dispose()
    {
        // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
        Dispose(disposing: true);
        GC.SuppressFinalize(this);
    }
}