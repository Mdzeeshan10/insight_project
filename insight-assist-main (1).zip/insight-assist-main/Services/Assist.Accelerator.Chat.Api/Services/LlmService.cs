﻿using Assist.Accelerator.Chat.Api.Providers;
using Azure.AI.OpenAI;
using Insight.Assist.Api.Models;
using System.Text;
using Assist.Accelerator.Chat.Api.Providers.Microsoft;

namespace Insight.Assist.Api.Services;

public class LlmService
{
    private readonly UsageService _usageService;
    private readonly UsersService _usersService;
    private readonly IConfiguration _configuration;
    private readonly HttpClient _httpClient;

    public LlmService(
        UsageService usageService,
        UsersService usersService,
        IConfiguration configuration,
        IHttpClientFactory httpClientFactory)
    {
        _usageService = usageService;
        _usersService = usersService;
        _configuration = configuration;
        _httpClient = httpClientFactory.CreateClient();
    }

    public async Task<string> GetChatCompletion(
        AvailableModel model,
        string dataSources,// changed object to string
        string input,
        IEnumerable<ChatMessage>? history = null,
        IEnumerable<string>? tags = null,
        Guid? chatId = null,
        bool isSystemAction = false)
    {
        var messageHistory = history == null ? new List<ChatMessage>() : new List<ChatMessage>(history);
        messageHistory.Add(new ChatMessage(ChatRole.User, input));

        // TODO: Make these parameters configurable via API
        var options = new ChatCompletionsOptions()
        {
            Temperature = (float)0.0,
            MaxTokens = 2048,
            //NucleusSamplingFactor = (float)0.95,
            FrequencyPenalty = 0,
            PresencePenalty = 0,
        };

        foreach (var chatMessage in messageHistory) options.Messages.Add(chatMessage);

        var response = await SendMessage(model, options, messageHistory, dataSources, input, tags: tags, chatId: chatId, isSystemAction: isSystemAction);
        //var response = await ProcessDataSources(dataSources, messageHistory);

        return response.Message;
    }

    private async Task<ChatResponse> SendMessage(AvailableModel model, ChatCompletionsOptions chatCompletionsOptions, List<ChatMessage> chatMessages, string dataSources, string input,
        IEnumerable<string>? tags = null, Guid? chatId = null, bool isSystemAction = false, CancellationToken cancellationToken = new CancellationToken())//changed object to string for datasource and added string input
    {
        var currentUser = _usersService.GetCurrentUser();
        if (currentUser == null)
        {
            throw new Exception("User must be logged in.");
        }

        ChatResponse result;

        if (dataSources != null)
        {
            //result = await ProcessDataSources(model, dataSources, chatMessages);
            result = await ProcessDataSources(model, input, dataSources);
        }
        else
        {
            var provider = GetProvider(model);
            result = await provider.SendMessage(model, chatCompletionsOptions, cancellationToken);
        }

        return result;
    }

    private IChatProvider GetProvider(AvailableModel model)
    {
        switch (model.Provider)
        {
            default:
                return new AzureOpenAIProvider(model, _configuration);
        }
    }

    private async Task<ChatResponse> ProcessDataSources(AvailableModel model, string prompt, string dataSource)
    {
        var result = new ChatResponse
        {
            Message = $"{dataSource}"
        };

        return result;
    }
    /*private async Task<ChatResponse> ProcessDataSources(AvailableModel model, string prompt, string dataSource)
    {
        *//*var openAIAPIUri = new Uri(new Uri(_configuration.GetSection("OpenAI")["URL"]), "/openai/deployments/gpt35/completions?api-version=2023-06-01-preview");
        var openAIAPIKey = _configuration.GetSection("OpenAI")["KeyCredential"];*//*
        var openAIAPIUri = "https://healthcareopenai.openai.azure.com/openai/deployments/text-davinci-003/completions?api-version=2022-12-01";
        var openAIAPIKey = "807d2112bf594dd4b0262f36f04d2305";

        var req = new HttpRequestMessage(HttpMethod.Post, openAIAPIUri);
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        req.Headers.Add("api-key", openAIAPIKey);

        // Construct the "prompt" string by including the provided "prompt" and "dataSource"
        string fullPrompt = $"You are an AI assistant that helps people find information. Given is the Context from which she answers the Given Question, if the question is not relavent in Context then she says I dont know. Note: dont add Answer: in the response. Begin!! Question: {prompt} Context: {dataSource}";

        var request = new
        {
            prompt = fullPrompt,
            temperature = (float)0.7,
            top_p = 1,
            max_tokens = 800,
            stop = ". \n\nQuestion:"
        };

        req.Content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");

        var response = await _httpClient.SendAsync(req);
        var responseContent = await response.Content.ReadAsStringAsync();
        var parsedRes = JsonConvert.DeserializeObject<dynamic>(responseContent);

        // Extract the text from the response
        string textObject = parsedRes.choices[0].text.ToString();
       *//* dynamic contentRes = JsonConvert.DeserializeObject<dynamic>(textObject);

        string title = string.Empty;
        string encodedUrl = string.Empty;
        string url = string.Empty;

        JArray citations = contentRes["citations"] as JArray;
        if (citations != null && citations.Count > 0)
        {
            title = citations[0]["title"]!.ToString();
            encodedUrl = citations[0]["url"]!.ToString();
            url = DecodeAndPrint(encodedUrl);
        }*//*

        var result = new ChatResponse
        {
            *//*Message = $"{textObject}\n\n URL4UI:{url},Title4UI:{title}"*//*
            Message = $"{textObject}"
        };

        return result;
    }*/


    /*private async Task<ChatResponse> ProcessDataSources(AvailableModel model, object dataSources, List<ChatMessage> chatMessages)
    {
        var openAIAPIUri = new Uri(new Uri(_configuration.GetSection("OpenAI")["URL"]), "/openai/deployments/gpt35/extensions/chat/completions?api-version=2023-06-01-preview");
        var openAIAPIKey = _configuration.GetSection("OpenAI")["KeyCredential"];
        *//*var openAIAPIUri = "https://cog-7wrk6lwxmsuvo.openai.azure.com/openai/deployments/gpt32/extensions/chat/completions?api-version=2023-06-01-preview";
        var openAIAPIKey = "069e7dab21f6484ab7c854a854f0ea79";*//*

        var req = new HttpRequestMessage(HttpMethod.Post, openAIAPIUri);
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        req.Headers.Add("api-key", openAIAPIKey);

        var msg = chatMessages.Select(chat => new
        {
            role = chat.Role.ToString().ToLower(),
            content = chat.Content
        }).ToList();

        var request = new
        {
            dataSources = new List<object> { dataSources },
            messages = msg,
            deployment = model.DeploymentName,
            temperature = (float)0.7,
            top_p = 1,
            max_tokens = 2048,
            stop = null as string,
            stream = false
        };

        req.Content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
       
        var response = await _httpClient.SendAsync(req);
        var responseContent = await response.Content.ReadAsStringAsync();
        var parsedRes = JsonConvert.DeserializeObject<dynamic>(responseContent);

        string contentResJson = parsedRes.choices[0].messages[0].content.ToString();
        dynamic contentRes = JsonConvert.DeserializeObject<dynamic>(contentResJson);
        
        string message = parsedRes.choices[0].messages[1].content.ToString();

        
        string title = string.Empty;
        string encodedUrl = string.Empty;
        string url = string.Empty;

        JArray citations = contentRes["citations"] as JArray;
        if(citations != null && citations.Count > 0)
        {
            title = citations[0]["title"]!.ToString();
            encodedUrl = citations[0]["url"]!.ToString();
            url = DecodeAndPrint(encodedUrl);
        }
        //var citations = contentRes.citations as List<dynamic>;

        //string title = citations != null ? contentRes.citations[0].title : "";
        //string encodedUrl = citations != null ? contentRes.citations[0].url : "";
        //string message = parsedRes.choices[0].messages[1].content.ToString();
        ////string link = $"<a href=\"{url}\">{title}";
        //string url = DecodeAndPrint(encodedUrl);

        var result = new ChatResponse
        {
            Message = $"{message}\n\n URL4UI:{url},Title4UI:{title}"
        };

        return result;
    }*/

    public class ProcessDataSourcesResponse { 
    }

    public static string DecodeAndPrint(string encodedBinaryData)
    {
        // Replace URL-safe characters and add padding if needed
        encodedBinaryData = encodedBinaryData.Replace('-', '+').Replace('_', '/');
        int padding = encodedBinaryData.Length % 4;
        if (padding > 0)
        {
            encodedBinaryData += new string('=', 4 - padding);
        }
        byte[] bytes = Convert.FromBase64String(encodedBinaryData);
        string decodedString = Encoding.UTF8.GetString(bytes);
        decodedString = Uri.UnescapeDataString(decodedString).Trim();
        return decodedString;
    }

}