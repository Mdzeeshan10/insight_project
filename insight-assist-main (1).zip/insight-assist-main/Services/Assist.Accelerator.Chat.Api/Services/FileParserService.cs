﻿using Assist.Accelerator.Chat.Api.Extensions;
using Assist.Accelerator.Chat.Api.Models;
using Assist.Accelerator.Chat.Api.Models.Exceptions;
using Assist.Accelerator.Chat.Api.Services.ChatFileParsers;
using DocumentFormat.OpenXml.Office2010.ExcelAc;
using System.Net;

namespace Assist.Accelerator.Chat.Api.Services
{
    public class FileParserService
    {
        private readonly IEnumerable<IChatFileParser> _parsers;

        public FileParserService(IEnumerable<IChatFileParser> parsers) 
        {
            if (parsers == null || !parsers.Any()) throw new ArgumentNullException(nameof(parsers));

            _parsers = parsers;
        }

        public List<string> GetSupportedFileExtensions()
        {
            var supportedExtensions = new List<string>();

            foreach (var parser in _parsers)
            {
                supportedExtensions.AddRange(parser.SupportedFileExtensions);
            }

            return supportedExtensions.Distinct().ToList();
        }

        public async Task<string> ParseAsync(ChatFile chatFile)
        {
            var parser = _parsers
                .Where(p => p.SupportedFileExtensions.Contains(chatFile.FileExtension))
                .FirstOrDefault();

            if (parser == null)
            {
                throw new ChatApiException(
                    HttpStatusCode.BadRequest,
                    $"No parser found for file type: {chatFile.FileExtension}"
                );
            }

            var text = await parser.ParseFileAsync(chatFile);

            text = text.Trim().RemoveDuplicateWhitespace();

            if (string.IsNullOrWhiteSpace(text))
            {
                text = "Error: Could not read text from file.";
            }

            return text;
        }
    }
}
