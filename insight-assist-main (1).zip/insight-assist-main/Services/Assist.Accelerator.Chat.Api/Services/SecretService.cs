﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;

namespace Assist.Accelerator.Chat.Api.Services
{
    /// <summary>
    /// Manages secrets in Azure Key Vault.
    /// </summary>
    public class SecretService
    {
        private readonly SecretClient _client;

        public SecretService(IConfiguration configuration)
        {
            var keyVaultUri = new Uri(configuration.GetValue<string>("KeyVaultUri") ?? throw new ArgumentNullException("KeyVaultUri"));
            var tenantId = configuration.GetValue<string>("AzureAd:TenantId") ?? throw new ArgumentNullException("TenantId");
            var cred = new DefaultAzureCredential(new DefaultAzureCredentialOptions { TenantId = tenantId });
            var secretClient = new SecretClient(keyVaultUri, cred);

            _client = secretClient;
        }

        /// <summary>
        /// Get a secret from Azure Key Vault.
        /// </summary>
        /// <param name="secretName"></param>
        /// <returns></returns>
        public async Task<string> GetSecretAsync(string secretName)
        {
            var secret = await _client.GetSecretAsync(secretName);
            return secret.Value.Value;
        }

        /// <summary>
        /// Get the Azure Search key for the specified Azure Cognitive Search instance.
        /// </summary>
        /// <param name="acsUrl"></param>
        /// <returns></returns>
        public async Task<string> GetAzureSearchKeyAsync(string acsUrl)
        {
            var secretName = GetAcsSecretName(acsUrl);

            return await GetSecretAsync(secretName);
        }

        /// <summary>
        /// Set a secret in Azure Key Vault.
        /// </summary>
        /// <param name="secretName"></param>
        /// <param name="secretValue"></param>
        /// <returns></returns>
        public async Task SetSecretAsync(string secretName, string secretValue)
        {
            await _client.SetSecretAsync(secretName, secretValue);
        }

        /// <summary>
        /// Set the Azure Search key for the specified Azure Cognitive Search instance.
        /// Returns the name of the Azure Cognitive Search instance.
        /// </summary>
        /// <param name="acsUrl"></param>
        /// <param name="secretValue"></param>
        /// <returns>The name of the Key Vault secret</returns>
        public async Task<string> SetAzureSearchKeyAsync(string acsUrl, string secretValue)
        {
            var secretName = GetAcsSecretName(acsUrl);

            await _client.SetSecretAsync(secretName, secretValue);

            return secretName;
        }

        /// <summary>
        /// Get the name of the Azure Cognitive Search instance from the URL.
        /// </summary>
        /// <param name="acsUrl"></param>
        /// <returns>Azure Cognitive Search instance name</returns>
        private static string GetAcsName(string acsUrl)
        {
            return acsUrl.Replace("https://", "").Replace(".search.windows.net", "");
        }

        /// <summary>
        /// Get the name of the Key Vault secret containing the key for an Azure Cognitive Search instance.
        /// </summary>
        /// <param name="acsUrl"></param>
        /// <returns>Secret name</returns>
        private static string GetAcsSecretName(string acsUrl)
        {
            var acsName = GetAcsName(acsUrl);
            return $"AzureSearchKeys--{acsName}";
        }
    }
}
