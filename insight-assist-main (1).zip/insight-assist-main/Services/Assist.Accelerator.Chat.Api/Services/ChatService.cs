using Assist.Accelerator.Chat.Api.Services;
using Insight.Assist.Api.Clients.Interfaces;
using Insight.Assist.Api.DAL;
using Insight.Assist.Api.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Data;
using Assist.Accelerator.Chat.Api.Models;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json.Linq;
using Assist.Accelerator.Chat.CopilotSupport;
using Assist.Accelerator.Chat.Api.Models.MapExtensions;

namespace Insight.Assist.Api.Services;

public class ChatService
{
    private readonly ILogger<ChatService> _logger;
    private readonly ChatContext _chatContext;
    private readonly LlmService _llmService;
    private readonly UsersService _usersService;
    private readonly IConfiguration _configuration;
    private readonly HttpClient _httpClient;
    private readonly ICopilotSupport _copilotSupport;
    private readonly SecretService _secretService;

    public ChatService(
        ILogger<ChatService> logger,
        ChatContext chatContext,
        LlmService llmService,
        UsersService usersService,
        IConfiguration configuration,
        IHttpClientFactory httpClientFactory,
        ICopilotSupport copilotSupport,
        SecretService secretService)
    {
        _logger = logger;
        _chatContext = chatContext;
        _llmService = llmService;
        _usersService = usersService;
        _configuration = configuration;
        _httpClient = httpClientFactory.CreateClient();
        _copilotSupport = copilotSupport;
        _secretService = secretService;
    }

    public IQueryable<Models.Chat> Get()
    {
        var user = _usersService.GetCurrentUser();
        if (user == null) { throw new NullReferenceException("Current user not found."); }

        return _chatContext.Chats
            .Where(c => c.UserId == user.UserId)
            .OrderByDescending(c => c.CreatedAt);
    }

    public Models.Chat Get(Guid guid)
    {
        var user = _usersService.GetCurrentUser();
        if (user == null) { throw new NullReferenceException("Current user not found."); }

        var chat = _chatContext.Chats.Find(guid);
        if (chat == null || !user.OwnsChat(chat))
        { throw new NullReferenceException("Chat not found."); }

        return chat;
    }

    public async Task Delete(Guid guid)
    {
        var user = _usersService.GetCurrentUser();
        if (user == null) { throw new NullReferenceException("Current user not found."); }

        var chat = _chatContext.Chats.Find(guid);
        if (chat == null || !user.OwnsChat(chat))
        { throw new NullReferenceException("Chat not found."); }

        _chatContext.Entry(chat).State = EntityState.Deleted;
        await _chatContext.SaveChangesAsync();

        return;
    }

    public async Task<Models.Chat> Rename(string newTitle, Guid guid)
    {
        var user = _usersService.GetCurrentUser();
        if (user == null) { throw new NullReferenceException("Current user not found."); }

        var chat = _chatContext.Chats.Find(guid);
        if (chat == null || !user.OwnsChat(chat))
        { throw new NullReferenceException("Chat not found."); }

        chat.Title = newTitle;

        _chatContext.Entry(chat).State = EntityState.Modified;
        await _chatContext.SaveChangesAsync();

        return chat;
    }

    public async Task<Chat> GetChatAsync(Guid? chatId)
    {
        var user = _usersService.GetCurrentUser() ?? throw new NullReferenceException("Current user not found.");

        var chat = chatId.HasValue ? await _chatContext.Chats.FindAsync(chatId) : null;
        if (chat == null || !user.OwnsChat(chat))
        {
            chat = new Chat
            {
                Id = Guid.NewGuid(),
                UserId = user.UserId
            };
        }

        return chat;
    }


    public async Task CreateOrUpdateChatAsync(Chat chat)
    {
        if (await _chatContext.Chats.ContainsAsync(chat))
        {
            var savedChat = await GetChatAsync(chat.Id);
            savedChat.Messages = chat.Messages;
            savedChat.Title = chat.Title;
            savedChat.Quota = chat.Quota;
            savedChat.TokenCount = chat.TokenCount;
            savedChat.IndexId = chat.IndexId;
        }
        else
        {
           await _chatContext.Chats.AddAsync(chat);
        }

        await _chatContext.SaveChangesAsync();
    }

    public async Task<List<AzureSearchIndex>> GetActiveIndexes()
    {
        try
        {
            var activeIndexes = await _chatContext.AzureSearchIndices
                .Where(index => index.IsActive)
                .ToListAsync();

            return activeIndexes;
        }
        catch (Exception ex)
        {
            throw new Exception("Error occurred while retrieving active indexes.", ex);
        }
    }

    public bool UpdateIndexStatus(int indexId, bool status)
    {
        var index = _chatContext.AzureSearchIndices.FirstOrDefault(i => i.IndexId == indexId);
        if (index != null && index.DisplayName != null)
        {
            index.IsActive = status;
            _chatContext.SaveChangesAsync();
            return true;
        }
        else
        {
            return false;
        }
    }

    public async Task<(string, string, string)> GetAzureResultWIthOpenAI(string message, List<int> indexIds)
    {
        var dataSources = new List<object>();
        foreach (var indexId in indexIds)
        {
            var row = await GetDataSourceFromDatabase(indexId);
            if (row != null)
            {
                dataSources.Add(row);
            }
        }

        string OpenAIAPIUrl = _configuration.GetSection("OpenAI")["URL"] + "/openai/deployments/gpt35/extensions/chat/completions?api-version=2023-06-01-preview";
        string OpenAIAPIKey = _configuration.GetSection("OpenAI")["KeyCredential"];

        _httpClient.DefaultRequestHeaders.Add("api-key", OpenAIAPIKey);
        var requestData = new
        {
            dataSources,
            messages = new[]
            {
            new
            {
                role = "user",
                content = $"{message}\n"
            }
        },
            deployment = "gpt35",
            temperature = 0,
            top_p = 1,
            max_tokens = 800,
            stop = null as string,
            stream = false
        };
        var content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(requestData), Encoding.UTF8, "application/json");
        var response = await _httpClient.PostAsync(OpenAIAPIUrl, content);
        var responseContent = await response.Content.ReadAsStringAsync();
        var (assistantResponse, title, url) = ParseAssistantResponse(responseContent);

        return (assistantResponse, title, url);
    }

    public async Task<string?> GetDataFromCogSearch(int indexId, string prompt)
    {
        var row = await _chatContext.AzureSearchIndices
            .Include(x => x.AzureSearch)
            .FirstOrDefaultAsync(x => x.IndexId == indexId);

        var azureKey = await _secretService.GetAzureSearchKeyAsync(row.AzureSearch.SearchUrl);

        if (row != null)
        {
            // Construct the URL using information from the 'row' variable
            string searchUrl = row.AzureSearch.SearchUrl;
            string searchKey = azureKey;
            string indexName = row.IndexName;
            var openAIAPIUri = _configuration.GetSection("OpenAI")["URL"];
            var openAIAPIKey = _configuration.GetSection("OpenAI")["KeyCredential"];
            var openAIembed = _configuration.GetSection("OpenAI")["EMBEDDING_MODEL"];

            string requestBodyJson = JsonConvert.SerializeObject(new
            {
                openai_endpoint = openAIAPIUri,
                openai_key = openAIAPIKey,
                openai_apiversion = "2023-07-01-preview",
                openai_llmdeployname = "gpt35",
                openai_embeddeployname = openAIembed,
                search_endpoint = searchUrl,
                search_key = searchKey,
                index_name = indexName,
                question = prompt
            });

            var apiUrl = _configuration.GetSection("Python_Cognitive_api")["URL"]; ;

            using (HttpClient client = new HttpClient())
            {
                //client.DefaultRequestHeaders.Add("Content-Type", "application/json");

                // Send a POST request to the API
                HttpResponseMessage response = await client.PostAsync(apiUrl, new StringContent(requestBodyJson, Encoding.UTF8, "application/json"));

                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();

                    // Parse the JSON response
                    var responseObject = JObject.Parse(jsonResponse);

                    // Extract the "answer" property from the JSON response
                    var answer = responseObject["answer"]?.ToString();

                    return answer;
                }
                else
                {
                    // Handle the API request failure here if needed
                    return "python server not able to return message due to overload.";
                }
            }
        }

        return null;
    }

    /*public async Task<string?> GetDataFromCogSearch(int indexId, string prompt)
    {
        var row = await _chatContext.AzureSearchIndices
                .Include(x => x.AzureSearch)
                .FirstOrDefaultAsync(x => x.IndexId == indexId);

        if (row != null)
        {
            // Construct the URL using information from the 'row' variable
            string searchUrl = row.AzureSearch.SearchUrl;
            string azureKey = row.AzureSearch.AzureKey;
            string indexName = row.IndexName;

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("api-key", azureKey);

                string apiUrl = $"{searchUrl}/indexes/{indexName}/docs?api-version=2023-07-01-Preview&search={Uri.EscapeDataString(prompt)}";

                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();
                    // Parse the JSON response
                    var responseObject = JsonConvert.DeserializeObject<dynamic>(jsonResponse);

                    // Extract the "content" object
                    var content = responseObject.value[0].content.ToString();

                    return content;
                }
                else
                {
                    return null;
                }
            }
        }


        return null;
    }*/

    public async Task<object?> GetDataSourceFromDatabase(int indexId)
    {
        var row = await _chatContext.AzureSearchIndices
                .Include(x => x.AzureSearch)
                .FirstOrDefaultAsync(x => x.IndexId == indexId);

        if (row != null)
        {
            var azureKey = await _secretService.GetAzureSearchKeyAsync(row.AzureSearch.SearchUrl);

            return new
            {
                type = "AzureCognitiveSearch",
                parameters = new
                {
                    endpoint = row.AzureSearch.SearchUrl,
                    key = azureKey,
                    indexName = row.IndexName,
                    semanticConfiguration = row.SemanticName,
                    queryType = "semantic",
                    fieldsMapping = new
                    {
                        contentFieldsSeparator = "\n",
                        contentFields = new[] { "content" },
                        filepathField = "metadata_storage_path",
                        titleField = "metadata_storage_name",
                        urlField = "metadata_storage_path"
                    },
                    inScope = true,
                    roleInformation = "You are an AI assistant that helps people find information."
                }
            };
        }

        return null;
    }

    public async Task<bool> IsDisplayNameExists(int indexId, string displayName)
    {
        //Check if the display name already exists in the database
        bool isDisplayNameExists = await _chatContext.AzureSearchIndices.AnyAsync(x => x.IndexId != indexId && x.DisplayName == displayName);
        return isDisplayNameExists;
    }

    public async Task UpdateDisplayName(int indexId, string displayName)
    {
        var azureSearchIndex = await _chatContext.AzureSearchIndices.FirstOrDefaultAsync(i => i.IndexId == indexId);

        if (azureSearchIndex == null)
        {
            throw new ArgumentException($"AzureSearchIndex with {indexId} not found.");
        }

        azureSearchIndex.DisplayName = displayName;
        await _chatContext.SaveChangesAsync();
    }

    internal async Task<IndexInfoResponse> GetIndexInfo(string filter, int pageNumber, int pageSize)
    {
        try
        {
            var query = await _chatContext.AzureSearchIndices.Include(a => a.AzureSearch).ToListAsync();

            int totalCount = query.Count();

            // Apply filter if provided
            if (!string.IsNullOrEmpty(filter))
            {
                filter = filter.ToLower();
                query = query.Where(x => x.IndexName.ToLower().StartsWith(filter) || (x.SemanticName != null && x.SemanticName.ToLower().StartsWith(filter)) || (x.DisplayName != null && x.DisplayName.ToLower().StartsWith(filter))).Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();
            }

            else
            {
                query = query.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();
            }

            // Get the total count for pagination
            var indexList = query.Select(i => new IndexWithSearchUrl
            {
                IndexId = i.IndexId,
                IndexName = i.IndexName,
                SemanticName = i.SemanticName,
                AzureSearchId = i.AzureSearchId,
                IsActive = i.IsActive,
                DisplayName = i.DisplayName,
                SearchUrl = i.AzureSearch.SearchUrl
            }).ToList();

            // Create a response object with index list and pagination details
            return new IndexInfoResponse { IndexList = indexList, ItemCount = totalCount };
        }
        catch (Exception ex)
        {
            throw new Exception("An error occurred while retrieving indexes.", ex);
        }
    }

    private (string, string, string) ParseAssistantResponse(string responseContent)
    {
        dynamic parsedResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(responseContent);
        string assistantResponse = parsedResponse.choices[0].messages[1].content.ToString();
        string title = parsedResponse.choices[0].messages[0].content.title.ToString();
        string url = parsedResponse.choices[0].messages[0].content.url.ToString();
        return (assistantResponse, title, url);
    }
}
