﻿using Assist.Accelerator.Chat.Api.Models;
using Assist.Accelerator.Chat.Api.Models.Exceptions;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.StaticFiles;
using System.Net;

namespace Assist.Accelerator.Chat.Api.Services
{
    public class FileService
    {
        private readonly FileExtensionContentTypeProvider _contentTypeProvider = new();

        private readonly BlobContainerClient _containerClient;
        private readonly IHttpContextAccessor _contextAccessor;
        private readonly List<string> _supportedFileExtensions;

        public FileService(
            IConfiguration configuration,
            IHttpContextAccessor contextAccessor,
            FileParserService fileParserService
        )
        {
            var blobServiceClient = new BlobServiceClient(configuration.GetSection("FileStorage").GetValue<string>("ConnectionString"));

            _containerClient = blobServiceClient.GetBlobContainerClient("chat-files");
            _contextAccessor = contextAccessor;
            _supportedFileExtensions = fileParserService.GetSupportedFileExtensions();
        }

        public List<string> GetSupportedFileExtensions()
        {
            return _supportedFileExtensions;
        }

        public async Task<bool> FileExistsAsync(string fileName)
        {
            var blobExists = await _containerClient.GetBlobClient(GetFullFileName(fileName)).ExistsAsync();

            return blobExists.Value;
        }

        public async Task UploadFileAsync(string fileName, Stream file, CancellationToken cancellationToken)
        {
            if (!_supportedFileExtensions.Contains(Path.GetExtension(fileName)))
            {
                throw new ChatApiException(
                    HttpStatusCode.BadRequest, 
                    $"The file {fileName} is not a supported type. Supported file types are: {string.Join(" ", _supportedFileExtensions)}"
                );
            }

            if (await FileExistsAsync(fileName)) throw new ChatApiException(HttpStatusCode.Conflict, $"The file {fileName} already exists for the current user.");

            await _containerClient.UploadBlobAsync(GetFullFileName(fileName), file, cancellationToken);
        }

        public async Task<ChatFile> DownloadFileAsync(string fileName)
        {
            var blobClient = _containerClient.GetBlobClient(GetFullFileName(fileName));
            
            if (!await FileExistsAsync(fileName)) throw new ChatApiException(HttpStatusCode.NotFound, $"The file {fileName} does not exist for the current user.");

            if (!_contentTypeProvider.TryGetContentType(fileName, out var contentTypeString))
            {
                contentTypeString = "text/plain";
            }

            return new ChatFile
            {
                FileName = fileName,
                ContentType = contentTypeString,
                Stream = await blobClient.OpenReadAsync()
            };
        }

        private string GetFullFileName(string fileName)
        {
            var email = _contextAccessor.HttpContext?.User?.Identity?.Name
                ?? throw new ChatApiException(HttpStatusCode.BadRequest, "User email could not be retrieved from the token.");

            return $"{email}_{fileName}";
        }
    }
}
