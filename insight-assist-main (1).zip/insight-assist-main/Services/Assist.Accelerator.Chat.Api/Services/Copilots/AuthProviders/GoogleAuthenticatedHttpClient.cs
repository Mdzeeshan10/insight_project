using Google.Apis.Auth.OAuth2;
using System.Net.Http.Headers;
using Assist.Accelerator.Chat.Api.Models;

class GoogleAuthenticatedHttpClient
{
    private readonly string _endpoint;
    private readonly string _credentialData;

    public GoogleAuthenticatedHttpClient(string endpoint, string credentialData)
    {
        _endpoint = endpoint;
        _credentialData = credentialData;
    }
    
    public HttpClient GetAuthenticatedClient()
    {
        GoogleCredential credential = GoogleCredential.FromJson(_credentialData);

        var httpClient = new HttpClient(new AuthenticatedMessageHandler(credential, _endpoint));
        return httpClient;
    }

    class AuthenticatedMessageHandler : DelegatingHandler
    {
        private readonly GoogleCredential _credential;
        private readonly string _endpoint;

        public AuthenticatedMessageHandler(GoogleCredential credential, string endpoint, HttpMessageHandler innerHandler = null)
            : base(innerHandler ?? new HttpClientHandler())
        {
            _credential = credential;
            _endpoint = endpoint;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var idToken =
                await _credential.GetOidcTokenAsync(OidcTokenOptions.FromTargetAudience(_endpoint));
            var accessToken = await idToken.GetAccessTokenAsync();
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            return await base.SendAsync(request, cancellationToken).ConfigureAwait(false);
        }
    }
}