﻿using Assist.Accelerator.Chat.Api.Extensions;
using Assist.Accelerator.Chat.Api.Models;
using DocumentFormat.OpenXml.Packaging;
using System.Text;
using System.Xml;

namespace Assist.Accelerator.Chat.Api.Services.ChatFileParsers
{
    public class DocxFileParser : IChatFileParser
    {
        private static readonly string _wordmlNamespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        private static readonly List<string> _supportedFileExtensions = new() { ".docx" };

        /// <inheritdoc />
        public List<string> SupportedFileExtensions => _supportedFileExtensions;

        /// <inheritdoc />
        public async Task<string> ParseFileAsync(ChatFile chatFile)
        {
            StringBuilder sb = new();
            using (WordprocessingDocument document = WordprocessingDocument.Open(chatFile.Stream, false))
            { 
                var nameTable = new NameTable();
                var nsManager = new XmlNamespaceManager(nameTable);
                nsManager.AddNamespace("w", _wordmlNamespace);
 
                var xdoc = new XmlDocument(nameTable);
                if (document.MainDocumentPart == null) return "";

                xdoc.Load(document.MainDocumentPart.GetStream());

                XmlNodeList? paragraphNodes = xdoc.SelectNodes("//w:p", nsManager);
                if (paragraphNodes == null) return "";

                foreach (XmlNode paragraphNode in paragraphNodes)
                {
                    XmlNodeList? textNodes = paragraphNode.SelectNodes(".//w:t", nsManager);

                    if (textNodes != null)
                    {
                        foreach (XmlNode textNode in textNodes)
                        {
                            sb.Append($" {textNode.InnerText} ");
                        }
                    }
                }
            }

            var text = sb.ToString();
            return text;
        }
    }
}
