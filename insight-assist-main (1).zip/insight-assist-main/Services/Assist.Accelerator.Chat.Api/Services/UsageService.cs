using Assist.Accelerator.Core.Events;
using Insight.Assist.Api.DAL;
using Insight.Assist.Api.Models;
using Microsoft.EntityFrameworkCore;


namespace Insight.Assist.Api.Services;

public class UsageService
{
    private readonly UsageContext _usageContext;
    private readonly IEventSink _eventSink;
    private readonly string _componentId;
    private readonly UsersContext _db;
    private readonly UsersService _usersService;
    
    private static object QuotaLock = new();

    public UsageService(UsageContext usageContext, IEventSink eventSink, UsersContext usersContext, UsersService usersService)
    {
        _componentId = $"{this.GetType().Name}_{Guid.NewGuid()}";
        _eventSink = eventSink;
        _usageContext = usageContext;
        _db = usersContext;
        _usersService = usersService;

        _eventSink.RegisterHandler(_componentId, new string[] { nameof(LlmCallCompletedEvent) }, OnSignalReceived);
    }

    private async Task OnSignalReceived(ApplicationSignal signal)
    {
        switch (signal.PayloadType)
        {
            case (nameof(LlmCallCompletedEvent)):
                LlmCallCompletedEvent apiCallEvt = EventBase.FromJson<LlmCallCompletedEvent>(signal.SerializedPayload);
                await ProcessLlmCompleted(apiCallEvt);
                break;
            default:
                await Task.CompletedTask;
                break;
        }
    }

    private async Task ProcessLlmCompleted(LlmCallCompletedEvent evt)
    {
        ApiCall callToLog = new ApiCall
        {
            ChatId= Guid.TryParse(evt.ChatId, out Guid chatId)?chatId:Guid.Empty,
            MethodName = evt.MethodName,
            RequestedAt = evt.RequestTime,
            ReceivedResponseAt = evt.ResponseTime,
            ModelId = evt.ModelId,
            IsSystemAction = evt.IsSystemAction,
            PromptTokenCount = evt.PromptTokenCount,
            CompletionTokenCount = evt.CompletionTokenCount,
            RequestDurationMs = (int)(evt.ResponseTime - evt.RequestTime).TotalMilliseconds,
            ResponseError = evt.ErrorContent,
            TotalTokenCount = evt.PromptTokenCount + evt.CompletionTokenCount,
            UserId = evt.UserId,
            ResponseMessage = new Azure.AI.OpenAI.ChatMessage(evt.ResponseRole, evt.ResponseContent),
            Tags = new List<string>(),
            RequestOptions = new Azure.AI.OpenAI.ChatCompletionsOptions
            {
                MaxTokens = evt.MaxTokens,
                FrequencyPenalty = (float?)evt.FrequencyPenalty,
                PresencePenalty = (float?)evt.PresencePenalty,
                Temperature = (float?)evt.Temperature,
                NucleusSamplingFactor = (float?)evt.TopP
            }
        };

        //TODO:  Get the DeploymentName and CostUsed.  For now, just set them to empty and 0.
        callToLog = await SetApiCallDatabaseValues(callToLog);
        
        await SaveApiCall(callToLog);
        
        var orgQuota = (await GetQuota(
            teamId: Quota.AllUsersTeamId,
            month: DateTime.UtcNow))!;
        await IncreaseQuota(orgQuota.Id, callToLog);
    }

    private async Task<ApiCall> SetApiCallDatabaseValues(ApiCall call)
    {
        var model = GetModel(call.ModelId, ModelPurpose.Chat);

        if(model == null)
        {
            // We have a problem.  We don't have a logger here, and we don't want to throw.
            // The success of the primary operation is not dependent on this succeeding.
            //TODO:  Figure this out.  For now, we'll return the call instance, unaltered.

            return call;
        }

        call.DeploymentName = model.DeploymentName;
        
        //TODO:  Is this correct?
        call.CostUsed = model.CostPerPromptToken * call.PromptTokenCount + model.CostPerCompletionToken*call.CompletionTokenCount;

        return call;
    }

    public async Task<QuotaTemplate> GetQuotaTemplate(int? userId = null, int? teamId = null)
    {
        var quotaTemplateId = 0;
        if (userId.HasValue)
        {
            quotaTemplateId =
                _usageContext.QuotaAssignments.FirstOrDefault(qa => qa.UserId == userId)?.QuotaTemplateId ??
                QuotaTemplate.DefaultId;
        }
        else if (teamId.HasValue)
        {
            // TODO: teams are hardcoded for now to represent entire org
            quotaTemplateId = QuotaTemplate.OrgDefaultId;
        }

        return (await _usageContext.QuotaTemplates.FindAsync(quotaTemplateId))!;
    }
    
    public async Task<Quota> CreateQuota(int? userId = null, int? teamId = null, QuotaTemplate? template = null, string? period = null)
    {
        template ??= await GetQuotaTemplate(userId: userId, teamId: teamId);

        var newQuota = Quota.FromTemplate(template: template, userId: userId, teamId: teamId, period: period);
        _usageContext.Quotas.Add(newQuota);
        await _usageContext.SaveChangesAsync();

        return newQuota;
    }
    
    public async Task<Quota?> GetQuota(int? userId = null, int? teamId = null, DateTime? month = null, string? period = null, bool createIfDoesntExist = true)
    {
        period ??= Quota.GetPeriodStringForDate(month ?? DateTime.UtcNow);
        var query = _usageContext.Quotas;
        Quota? quota = null;
        if (userId.HasValue)
        {
            quota = query.FirstOrDefault(q => q.UserId == userId.Value && q.Period == period);
        }
        
        if (teamId.HasValue)
        {
            quota = query.FirstOrDefault(q => q.TeamId == teamId.Value && q.Period == period);
        }
        
        if (quota == null && createIfDoesntExist)
        {
            quota = await CreateQuota(userId: userId, teamId: teamId, period: period);
        }

        return quota;
    }

    public async Task IncreaseQuota(int quotaId, ApiCall apiCall)
    {
        void IncreaseQuotaFn(Quota q, ApiCall a)
        {
            q.IncreaseQuota(a);

            _usageContext.Entry(q).State = EntityState.Modified;
            _usageContext.SaveChanges();
        }
        
        lock (QuotaLock)
        {
            try
            {
                using var transaction = _usageContext.Database.BeginTransaction();
                var retrievedQuota = _usageContext.Quotas.First(q => q.Id == quotaId);
                IncreaseQuotaFn(retrievedQuota, apiCall);
                transaction.Commit();
            }
            catch (Exception e)
            {
                // TODO: handle
            }
        }
    }

    public async Task IncreaseQuota(ApiCall apiCall, int? userId = null, int? teamId = null, DateTime? month = null, bool createIfDoesntExist = true)
    {
        month ??= DateTime.UtcNow;
        var quota = await GetQuota(userId: userId, teamId: teamId, month: month, createIfDoesntExist: createIfDoesntExist);
        if (quota == null)
        {
            throw new Exception(
                $"Quota does not exist for {(userId.HasValue ? "user ID " + userId.Value : "")}{
                    (teamId.HasValue ? "team ID " + teamId.Value : "")} for period {
                        Quota.GetPeriodStringForDate(month.Value)}");
        }

        await IncreaseQuota(quota.Id, apiCall);
    }

    public IEnumerable<Quota> GetQuotasForPeriod(string period, bool orderByUsageDesc = false, int? limit = null)
    {
        // TODO: need to add pagination
        var query = _usageContext.Quotas
            .Where(q => q.Period == period);
        
        if (limit != null)
        {
            query = query.Take(limit.Value);
        }

        if (orderByUsageDesc)
        {
            query = query.OrderByDescending(q => q.CostUsed);
        }

        return query.Include(q => q.User);
    }
    
    public async Task SaveApiCall(ApiCall apiCall)
    {
        _usageContext.ApiCalls.Add(apiCall);
        await _usageContext.SaveChangesAsync();
    }
    
    public AvailableModel? GetModel(string deploymentName, ModelPurpose purpose = ModelPurpose.Chat)
    {
        return _usageContext.AvailableModels.FirstOrDefault(am => am.DeploymentName == deploymentName && am.Purpose == purpose);
    }
    
    public AvailableModel? GetModel(int modelId, ModelPurpose purpose = ModelPurpose.Chat)
    {
        return _usageContext.AvailableModels.FirstOrDefault(am => am.Id == modelId && am.Purpose == purpose);
    }

    public IEnumerable<AvailableModel> GetAvailableModels(ModelPurpose purpose = ModelPurpose.Chat)
    {
        if (_usersService?.GetCurrentUser()?.model_control == true)
        {
            return _usageContext.AvailableModels.Where(am => am.Purpose == purpose);
        }
        else
        {
            return Enumerable.Empty<AvailableModel>();
        }
    }

    public AvailableModel GetCurrentModel(ModelPurpose purpose = ModelPurpose.Chat)
    {
        // TODO: will need to figure out requirements for whether users can select between models or the admin selects the model everyone uses.
        //          but for now -- try to find one marked IsActive.  If not, just use the first one by ID.
        var model = _usageContext.AvailableModels.FirstOrDefault(am => am.IsActive == true && am.Purpose == purpose);
        model ??= _usageContext.AvailableModels.OrderBy(am => am.Id).First(am => am.Purpose == purpose);
        return model;
    }

    public AvailableModel GetModelFromDatabase(int modelId)
    {
        return _usageContext.AvailableModels.FirstOrDefault(am =>  am.Id == modelId)!;
    }
    
    public async Task SetCurrentModel(int id, ModelPurpose purpose = ModelPurpose.Chat)
    {
        var model = _usageContext.AvailableModels.FirstOrDefault(am => am.Id == id && am.Purpose == purpose);
        if (model == null)
        {
            throw new ArgumentException("Model with ID " + id + " and Purpose " + purpose + " does not exist");
        }

        model.IsActive = true;
        
        foreach (var inactiveModel in _usageContext.AvailableModels.Where(am => am.Id != id && am.Purpose == purpose))
        {
            inactiveModel.IsActive = false;
        }

        await _usageContext.SaveChangesAsync();
    }

    public async Task SetOrgQuotaLimit(long costLimit)
    {
        // Update current quota
        var quota = await GetQuota(teamId: Quota.AllUsersTeamId);
        quota.CostLimit = costLimit;
        
        // Update quota template for org
        var quotaTemplate = await GetQuotaTemplate(teamId: Quota.AllUsersTeamId);
        quotaTemplate.CostLimit = costLimit;

        await _usageContext.SaveChangesAsync();
    }
}