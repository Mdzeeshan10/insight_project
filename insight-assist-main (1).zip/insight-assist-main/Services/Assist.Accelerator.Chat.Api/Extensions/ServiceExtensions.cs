﻿namespace Assist.Accelerator.Chat.Api.Extensions
{
    public static class ServiceExtensions
    {
        public static IServiceCollection AddSignalRForLens(this IServiceCollection services, IConfiguration configuration)
        {
            var signalRConfig = configuration.GetSection("SignalR");
            string signalRBackplane = "NONE";
            string signalRConnectionString = string.Empty;
            string channelPrefix = "lensai";
            string azureSignalRConnectionString = string.Empty;

            if (signalRConfig != null)
            {
                signalRBackplane = signalRConfig.GetValue<string>("Backplane") ?? "NONE";
                signalRConnectionString = signalRConfig.GetValue<string>("RedisConnectionString") ?? string.Empty;
                channelPrefix = signalRConfig.GetValue<string>("ChannelPrefix") ?? "lensai";
                azureSignalRConnectionString = signalRConfig.GetValue<string>("AzureSignalRServiceConnectionString") ?? string.Empty;
            }

            switch (signalRBackplane)
            {
                case "REDIS":
                    services.AddSignalR().AddStackExchangeRedis(signalRConnectionString, options =>
                    {
                        options.Configuration.ChannelPrefix = channelPrefix;
                        options.Configuration.AbortOnConnectFail = false;
                    });
                    break;
                case "AZURE":
                    services.AddSignalR().AddAzureSignalR(azureSignalRConnectionString);
                    break;
                default:
                    services.AddSignalR();
                    break;
            }


            return services;
        }
    }
}
