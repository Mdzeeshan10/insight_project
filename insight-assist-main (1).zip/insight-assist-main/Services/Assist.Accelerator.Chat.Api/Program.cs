using Assist.Accelerator.Chat.Api.HostedServices;
using Assist.Accelerator.Chat.Api.Hubs;
using Assist.Accelerator.Chat.Api.Services;
using Assist.Accelerator.Chat.Api.Services.ChatFileParsers;
using Assist.Accelerator.Chat.Api.Services.Middleware;
using Insight.Assist.Api.DAL;
using Insight.Assist.Api.Services;
using Insight.Assist.Api.Services.Middleware;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Primitives;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Identity.Web;
using Microsoft.OpenApi.Models;
using Assist.Accelerator.Chat.Api.Extensions;
using Assist.Accelerator.Chat.CopilotSupport;
using Assist.Accelerator.Core.Events;
using Azure.Identity;

var builder = WebApplication.CreateBuilder(args);

builder.Logging.ClearProviders();
builder.Logging.AddConsole();

var keyVaultUri = new Uri(builder.Configuration.GetValue<string>("KeyVaultUri"));
var tenantId = builder.Configuration.GetValue<string>("AzureAd:TenantId");
var cred = new DefaultAzureCredential(new DefaultAzureCredentialOptions { TenantId = tenantId });

builder.Configuration.AddAzureKeyVault(keyVaultUri, cred);

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApi(
        builder.Configuration.GetSection("AzureAd"), JwtBearerDefaults.AuthenticationScheme);

builder.Services.Configure<JwtBearerOptions>(options =>
{
    Func<MessageReceivedContext, Task> existingOnMessageReceivedHandler = options.Events.OnMessageReceived;
    options.Events.OnMessageReceived = async context =>
    {
        await existingOnMessageReceivedHandler(context);

        StringValues accessToken = context.Request.Query["access_token"];
        PathString path = context.HttpContext.Request.Path;

        // If the request is for our hub...
        if (!string.IsNullOrEmpty(accessToken) && path.ToString().Contains("/messageHub"))
        {
            // Read the token out of the query string
            context.Token = accessToken;
        }
    };
});

builder.Services.AddSignalRForLens(builder.Configuration);
builder.Services.AddControllers();
builder.Services.AddApplicationInsightsTelemetry();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Format: Bearer {JWT}",
        BearerFormat = "JWT",
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
});

string? corsAllowedHosts = builder.Configuration.GetValue("CorsAllowedHosts", string.Empty);

if (string.IsNullOrEmpty(corsAllowedHosts))
{
    throw new ApplicationException("No CORS allowed hosts specified in configuration, can be multiple values semicolon delimited");
}

builder.Services.AddCors(options =>
{
    options.AddPolicy(
        "AllowAll",
        builder =>
            builder
            .WithMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
            .AllowAnyHeader()
            .AllowCredentials()
            .WithOrigins(corsAllowedHosts.Split(';'))
        );
});

var maxFileSize = builder.Configuration.GetValue<long>("FileStorage:MaxFileSize");

builder.Services.Configure<IISServerOptions>(options =>
{
    options.MaxRequestBodySize = maxFileSize;
});

builder.Services.Configure<KestrelServerOptions>(options =>
{
    options.Limits.MaxRequestBodySize = maxFileSize;
});

IEventSink eventSink = new InProcEventSink();

builder.Services.AddSingleton(eventSink);

builder.Services.AddCopilotSupport(builder.Configuration, eventSink);

builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ChatContext>();
builder.Services.AddScoped<ChatService>();
builder.Services.AddScoped<UsersContext>();
builder.Services.AddScoped<UsersService>();
builder.Services.AddScoped<UsageContext>();
builder.Services.AddScoped<UsageService>();
builder.Services.AddScoped<StatsService>();
builder.Services.AddScoped<FileService>();
builder.Services.AddScoped<ResponseStreamingService>();
builder.Services.AddScoped<FileParserService>();
builder.Services.AddScoped<KernelService>();
builder.Services.AddScoped<LlmService>();
builder.Services.AddScoped<SecretService>();
builder.Services.AddScoped<AuthMiddleware>();

builder.Services.AddHostedService<MinutelyHistoricalStatsService>();
builder.Services.AddHostedService<HourlyHistoricalStatsService>();
builder.Services.AddHostedService<DailyHistoricalStatsService>();
builder.Services.AddHostedService<MonthlyHistoricalStatsService>();

builder.Services.AddScoped<IChatFileParser, PlainTextFileParser>();
builder.Services.AddScoped<IChatFileParser, PdfFileParser>();
builder.Services.AddScoped<IChatFileParser, DocxFileParser>();



var app = builder.Build();

app.UseMiddleware<ExceptionHandlingMiddleware>();
app.UseHttpsRedirection();

app.UseSwagger();
app.UseSwaggerUI();

app.UseCors("AllowAll");
app.UseStaticFiles();
app.UseRouting();


app.MapHub<MessageHub>("/messageHub");

app.UseAuthentication();
app.UseMiddleware<AuthMiddleware>();
app.UseAuthorization();
app.MapControllers();

app.Run();