﻿namespace Insight.Assist.Api.Models;

public class AzureSearchIndexUsers
    {
    public int Id { get; set; }
    public int IndexID { get; set; }
    public int UserId { get; set; }
    public bool isActive { get; set; }
}

