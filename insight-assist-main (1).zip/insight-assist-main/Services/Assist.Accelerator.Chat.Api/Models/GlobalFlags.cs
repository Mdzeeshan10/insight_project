﻿using System.ComponentModel.DataAnnotations;

namespace Insight.Assist.Api.Models;
public class GlobalFlags
{
    [Key]
    public int FlagId { get; set; }
    public string FlagName { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
}
 
