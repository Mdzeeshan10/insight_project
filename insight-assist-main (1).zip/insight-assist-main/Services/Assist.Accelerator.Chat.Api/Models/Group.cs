﻿namespace Insight.Assist.Api.Models
{
    public class Group
    {
        public int GroupId { get; set; }
        public string? GroupName { get; set; }
        public string? ObjectId { get; set; }

        public bool isActive { get; set; }
        public bool Model_Control { get; set; }
    }
}
