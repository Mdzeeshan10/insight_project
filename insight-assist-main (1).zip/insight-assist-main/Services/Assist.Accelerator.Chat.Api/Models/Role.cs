using System.ComponentModel.DataAnnotations;

namespace Insight.Assist.Api.Models;

public class Role
{
    [Key]
    public int RoleId { get; set; }
    public string RoleName { get; set; } = string.Empty;
    public string RoleDescription { get; set; } = string.Empty; 

    
    public const string Admin = "Admin";
    public const string User = "User";
    
    
}