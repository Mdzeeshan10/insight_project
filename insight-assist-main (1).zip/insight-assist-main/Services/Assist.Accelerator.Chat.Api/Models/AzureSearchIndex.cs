﻿using System.ComponentModel.DataAnnotations;

namespace Insight.Assist.Api.Models;

public partial class AzureSearchIndex
{
    [Key]
    public int IndexId { get; set; }

    public string IndexName { get; set; } = null!;

    public string? SemanticName { get; set; }

    public int AzureSearchId { get; set; }

    public bool IsActive { get; set; }
    public string? DisplayName { get; set; }

    public virtual AzureSearch AzureSearch { get; set; } = null!;
}


public class KnowledgeBaseResponse
{
    public List<AzureSearchIndex> KnowledgeBase { get; set; }
    public int PageCount { get; set; }
}

public class AzureSearchResult
{
    public bool IsSuccess { get; set; }
    public string? Message { get; set; }
    public string? Title { get; set; }
    public string? Category { get; set; }
    public string? Content { get; set; }
    public string? Client { get; set; }
    public string? SourceFile { get; set; }
}

public class IndexRequest
{
    public string? AzureSearchUrl { get; set; }
    public string? AzureKey { get; set; }
}
public class IndexWithSearchUrl
{

    public int IndexId { get; set; }
    public string? IndexName { get; set; }
    public string? SemanticName { get; set; }
    public int AzureSearchId { get; set; }
    public bool IsActive { get; set; }
    public string? DisplayName { get; set; }
    public string? SearchUrl { get; set; }
}

public class IndexInfoResponse
{
    public IEnumerable<IndexWithSearchUrl> IndexList { get; set; }
    public int ItemCount { get; set; }
}