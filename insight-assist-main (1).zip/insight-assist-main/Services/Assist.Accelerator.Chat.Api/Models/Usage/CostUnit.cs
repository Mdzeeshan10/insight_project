namespace Assist.Accelerator.Chat.Api.Models.Usage;

public enum CostUnit
{
    Token = 1,
    Character = 2
}