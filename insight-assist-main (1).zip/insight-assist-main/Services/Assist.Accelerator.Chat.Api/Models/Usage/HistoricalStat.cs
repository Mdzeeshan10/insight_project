using Assist.Accelerator.Chat.Api.Models.Exceptions;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Globalization;

namespace Assist.Accelerator.Chat.Api.Models.Usage;

public class HistoricalStat
{
    /// <summary>
    /// ID of the attribute
    /// </summary>
    [Key]
    public int Id { get; set; }

    /// <summary>
    /// The index of the attribute, as defined by the HistoricalStatAttribute
    /// </summary>
    public int Index { get; set; }

    /// <summary>
    /// The name of the attribute, as defined by the HistoricalStatAttribute
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// The start time of the first stat
    /// </summary>
    public DateTime StartDateTime { get; set; }

    /// <summary>
    /// The time between each stat
    /// </summary>
    public HistoricalStatSpan Span { get; set; }

    /// <summary>
    /// A dictionary of the [x, y] axis points.
    /// Key => X axis is time (e.g. for a daily span, each X axis value is the number of the hour).
    /// Value => Y axis is the value of the measured stat.
    /// </summary>
    public Dictionary<int, object> Data { get; set; }
}

public enum HistoricalStatSpan
{
    Minute = 1,
    Hour,
    Day,
    Month,
    Year
}

public static class HistoricalStatSpanExtensions
{
    public static DateTime LastDayOfMonth(this DateTime date)
    {
        return new DateTime(date.Year, date.Month, DateTime.DaysInMonth(date.Year, date.Month));
    }

    public static DateTime PeriodDateTimeForSpan(this HistoricalStatSpan span, DateTime dateTime)
    {
        return new DateTime(dateTime.Year,
            span >= HistoricalStatSpan.Month ? 1 : dateTime.Month,
            span >= HistoricalStatSpan.Day ? 1 : dateTime.Day,
            span >= HistoricalStatSpan.Hour ? 0 : dateTime.Hour,
            span >= HistoricalStatSpan.Minute ? 0 : dateTime.Minute,
            0);
    }

    public static DateTime StartDateTimeForSpan(this HistoricalStatSpan span, DateTime dateTime)
    {
        return new DateTime(dateTime.Year,
            span >= HistoricalStatSpan.Year ? 1 : dateTime.Month,
            span >= HistoricalStatSpan.Month ? 1 : dateTime.Day,
            span >= HistoricalStatSpan.Day ? 0 : dateTime.Hour,
            span >= HistoricalStatSpan.Hour ? 0 : dateTime.Minute,
            0, 0);
    }

    public static int StartingDataValue(this HistoricalStatSpan span)
    {
        return span switch
        {
            HistoricalStatSpan.Minute => 0,
            HistoricalStatSpan.Hour => 0,
            HistoricalStatSpan.Day => 1,
            HistoricalStatSpan.Month => 1,
            _ => throw new ArgumentOutOfRangeException(nameof(span), span, null)
        };
    }

    public static int NumDataPoints(this HistoricalStatSpan span, DateTime dateTime)
    {
        return span switch
        {
            HistoricalStatSpan.Minute => 60,
            HistoricalStatSpan.Hour => 24,
            HistoricalStatSpan.Day => DateTime.DaysInMonth(dateTime.Year, dateTime.Month),
            HistoricalStatSpan.Month => 12,
            _ => throw new ArgumentOutOfRangeException(nameof(span), span, null)
        };
    }

    public static DateTime EndDateTimeForSpan(this HistoricalStatSpan span, DateTime dateTime)
    {
        return new DateTime(dateTime.Year,
            span >= HistoricalStatSpan.Year ? 12 : dateTime.Month,
            span >= HistoricalStatSpan.Month ? DateTime.DaysInMonth(dateTime.Year, dateTime.Month) : dateTime.Day,
            span >= HistoricalStatSpan.Day ? 23 : dateTime.Hour,
            span >= HistoricalStatSpan.Hour ? 59 : dateTime.Minute,
            59, 999, 999);
    }

    public static DateTime PreviousStartDate(this HistoricalStatSpan span, DateTime now)
    {
        var prevMonthDate = now.Subtract(TimeSpan.FromDays(1));
        var delta = span.ToTimeSpan(prevMonthDate);

        return span.StartDateTimeForSpan(now.Subtract(delta));
    }

    public static TimeSpan ToTimeSpan(this HistoricalStatSpan span, DateTime now)
    {
        return span switch
        {
            HistoricalStatSpan.Minute => TimeSpan.FromMinutes(1),
            HistoricalStatSpan.Hour => TimeSpan.FromHours(1),
            HistoricalStatSpan.Day => TimeSpan.FromDays(1),
            HistoricalStatSpan.Month => TimeSpan.FromDays(DateTime.DaysInMonth(now.Year, now.Month)),
            HistoricalStatSpan.Year => TimeSpan.FromDays(DateTime.IsLeapYear(now.Year) ? 366 : 365),
            _ => throw new ArgumentOutOfRangeException(nameof(span), span, null)
        };
    }

    public static DateTime DateTimeFromPeriod(this HistoricalStatSpan span, string period)
    {
        return DateTime.ParseExact(period, span.ToDateFormat(), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal);
    }

    public static string ToDateFormat(this HistoricalStatSpan span)
    {
        return span switch
        {
            HistoricalStatSpan.Month => "yyyy",
            HistoricalStatSpan.Day => "yyyy-MM",
            HistoricalStatSpan.Hour => "yyyy-MM-dd",
            HistoricalStatSpan.Minute => "yyyy-MM-dd-HH",
            _ => throw new ChatApiException(System.Net.HttpStatusCode.BadRequest, $"Cannot get stats for time span {span}")
        };
    }
}