using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Insight.Assist.Api.Models;

[PrimaryKey("UserId", "QuotaTemplateId")]
public class QuotaAssignment
{
    /// <summary>
    /// ID of the user to assign the quota to
    /// </summary>
    public int UserId { get; set; }
    
    /// <summary>
    /// ID of the quota template being assigned to the user
    /// </summary>
    public int QuotaTemplateId { get; set; }
}