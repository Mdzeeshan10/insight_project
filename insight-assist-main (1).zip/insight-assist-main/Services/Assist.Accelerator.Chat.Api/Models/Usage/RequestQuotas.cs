namespace Insight.Assist.Api.Models;

/// <summary>
/// Quota information for a given request
/// </summary>
public class RequestQuotas
{
    /// <summary>
    /// Quota for the organization of the user who made the request
    /// </summary>
    public Quota? OrgQuota { get; set; }

    /// <summary>
    /// Quota for the user who made the request
    /// </summary>
    public Quota? UserQuota { get; set; }
}