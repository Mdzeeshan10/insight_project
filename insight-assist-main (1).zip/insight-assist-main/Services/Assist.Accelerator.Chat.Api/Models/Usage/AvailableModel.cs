using System.ComponentModel.DataAnnotations;
using Assist.Accelerator.Chat.Api.Models.Usage;

namespace Insight.Assist.Api.Models;

public enum ModelPurpose
{
    Chat = 0,
    Embedding = 1,
}

public class AvailableModel
{
    /// <summary>
    /// ID of the model
    /// </summary>
    [Key]
    public int Id { get; set; }
    
    /// <summary>
    /// The service providing the model
    /// </summary>
    public ModelProvider? Provider { get; set; }
    
    /// <summary>
    /// The name of the deployed model in Azure OpenAI Service
    /// </summary>
    public string DeploymentName { get; set; }
    
    /// <summary>
    /// The type of model (e.g. "GPT")
    /// </summary>
    public string? ModelType { get; set; }
    
    /// <summary>
    /// The version of the model (e.g. "3.5-turbo")
    /// </summary>
    public string? ModelVersion { get; set; }
    
    /// <summary>
    /// Cost per prompt unit for this model, in millionths of a cent
    /// </summary>
    public int CostPerPromptToken { get; set; }
    
    /// <summary>
    /// Cost per completion unit for this model, in millionths of a cent
    /// </summary>
    public int CostPerCompletionToken { get; set; }
    
    /// <summary>
    /// Cost unit (e.g. tokens or characters)
    /// </summary>
    public CostUnit CostUnit { get; set; }
    
    /// <summary>
    /// Path in the appsettings.json that the credentials are stored
    /// </summary>
    public string? CredentialPath { get; set; }
    
    /// <summary>
    /// Whether or not this model is the active model
    /// </summary>
    public bool? IsActive { get; set; }
    
    /// <summary>
    /// The purpose of the model
    /// </summary>
    public ModelPurpose Purpose { get; set; }

    public int CalculateCost(ChatResponse response)
    {
        return response.InputTokens * CostPerPromptToken +
               response.OutputTokens * CostPerCompletionToken;
    }
}