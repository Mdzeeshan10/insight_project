using Assist.Accelerator.Chat.Api.Util;
using Azure.AI.OpenAI;
using Insight.Assist.Api.Models;

namespace Insight.Assist.Api;

public class ApiCall
{
    /// <summary>
    /// ID of the API call
    /// </summary>
    public Int64 Id { get; set; }
    
    /// <summary>
    /// ID of the user making the API call
    /// </summary>
    public int UserId { get; set; }

    /// <summary>
    /// User that initiated this API call
    /// </summary>
    public User? User { get; init; }
    
    /// <summary>
    /// Name of the method called on the OpenAIClient
    /// </summary>
    public string MethodName { get; set; }
    
    /// <summary>
    /// The ID of the model providing completions in this request
    /// </summary>
    public int ModelId { get; set; }
    
    /// <summary>
    /// The deployment name of the model providing completions
    /// </summary>
    public string DeploymentName { get; set; }
    
    /// <summary>
    /// ID of the chat this call was made as a part of
    /// </summary>
    public Guid? ChatId { get; set; }
    
    /// <summary>
    /// Whether or not this is a request sent by the system or is fulfilling a direct user request
    /// </summary>
    public bool? IsSystemAction { get; set; }

    // TODO: We should consider using our own class here instead of one from an external package.
    /// <summary>
    /// The chat completion options (model parameters & messages) sent with the request
    /// </summary>
    public ChatCompletionsOptions RequestOptions { get; set; }
    
    /// <summary>
    /// Any tags that were assigned to the API call
    /// </summary>
    public IEnumerable<string>? Tags { get; set; }
    
    /// <summary>
    /// When the API call was sent
    /// </summary>
    public DateTime RequestedAt { get; set; }
    
    /// <summary>
    /// When a response from the API was received
    /// </summary>
    public DateTime ReceivedResponseAt { get; set; }
    
    /// <summary>
    /// How long a request took, in milliseconds (between RequestedAt and ReceivedResponseAt)
    /// </summary>
    public int? RequestDurationMs { get; set; }
    
    /// <summary>
    /// Number of completion tokens used during this quota period
    /// </summary>
    public int? CompletionTokenCount { get; set; }
    
    /// <summary>
    /// Number of prompt tokens used during this quota period
    /// </summary>
    public int? PromptTokenCount { get; set; }
    
    /// <summary>
    /// Total number of tokens used between the prompt and completion
    /// </summary>
    public int? TotalTokenCount { get; set; }
    
    /// <summary>
    /// The amount spent by the user for this API call, in millionths of a cent
    /// </summary>
    public Int64? CostUsed { get; set; }

    // TODO: We should consider using our own class here instead of one from an external package.
    /// <summary>
    /// The message that was sent in the response (if successful)
    /// </summary>
    public ChatMessage? ResponseMessage { get; set; }
    
    /// <summary>
    /// The error that was sent in the response (if not successful)
    /// </summary>
    public string? ResponseError { get; set; }

    public void MarkResponseReceived()
    {
        ReceivedResponseAt = DateTime.UtcNow;
        RequestDurationMs = (int)(ReceivedResponseAt - RequestedAt).TotalMilliseconds;
    }
    
    public void SetResponseAttributes(ChatResponse response)
    {
        ResponseMessage = response.ChatMessage;
        PromptTokenCount = response.InputTokens;
        CompletionTokenCount = response.OutputTokens;
        TotalTokenCount = PromptTokenCount + CompletionTokenCount;
    }
}