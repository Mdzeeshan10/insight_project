namespace Assist.Accelerator.Chat.Api.Models;

public class ChatHistory : Microsoft.SemanticKernel.AI.ChatCompletion.ChatHistory
{
    public ChatHistory(string? instructions)
    {
        if (!string.IsNullOrWhiteSpace(instructions))
        {
            this.AddSystemMessage(instructions);
        }
    }
}