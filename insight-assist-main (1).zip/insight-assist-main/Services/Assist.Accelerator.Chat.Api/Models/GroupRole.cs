﻿using Microsoft.EntityFrameworkCore;

namespace Insight.Assist.Api.Models;

[PrimaryKey(nameof(GroupId), nameof(RoleId))]

public class GroupRole
{
    public int GroupId { get; set; }
    public int RoleId { get; set; }
}

public class GroupWithRoleMapped
{

    public int RoleId { get; set; }

    public int GroupId { get; set; }
    public string? GroupName { get; set; }
    public string? ObjectId { get; set; }
    public bool Model_Control { get; set; }
    public bool IsActive { get; set; }
}

public class GroupResponse
{
    public List<GroupWithRoleMapped> Groups { get; set; }
    public int PageCount { get; set; }
}