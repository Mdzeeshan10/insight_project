﻿namespace Assist.Accelerator.Chat.Api.Models
{
    public class FileCheckResponse
    {
        public string FileName { get; set; }
        public bool IsSupported { get; set; }
        public bool Exists { get; set; }
    }
}
