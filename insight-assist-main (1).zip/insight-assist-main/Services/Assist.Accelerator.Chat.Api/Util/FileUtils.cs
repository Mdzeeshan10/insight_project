﻿namespace Assist.Accelerator.Chat.Api.Util
{
    public static class FileUtils
    {
        public static string GetFileSizeString(long bytes)
        {
            var factor = 0;

            while (bytes >= 1000)
            {
                bytes /= 1000;
                factor++;
                if (factor == 3) break;
            }

            if (factor == 4) return $"{ bytes} TB";
            if (factor == 3) return $"{ bytes} GB";
            if (factor == 2) return $"{ bytes} MB";
            if (factor == 1) return $"{ bytes} kB";
            if (factor == 0) return $"{ bytes} B";
            return $"{ bytes} x 10 ^${ factor * 3} B";
        }
    }
}
