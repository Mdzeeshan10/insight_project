﻿using Microsoft.Graph.Models;

namespace Assist.Accelerator.Chat.Api.Util
{
    public class SendEmail
    {
        private readonly IConfiguration _configuration;
        public async Task SendEmailAsync(string ToAddress, string subject, string messages)
        {
            //string fromAddress = Convert.ToString(_configuration.GetSection("SendGridSMTP")["FromAddress"]!);
            //string SubjectName = Convert.ToString(_configuration.GetSection("SendGridSMTP")["SubjectName"]!);
            //string AzureSendGridKey = Convert.ToString(_configuration.GetSection("SendGridSMTP")["AzureSendGridKey"]!);
            //var client = new SendGridClient(AzureSendGridKey);
            //var msg = new SendGridMessage();

            //msg.SetFrom(new EmailAddress(fromAddress, SubjectName));

            //var recipients = new List<EmailAddress>
            //    {
            //        new EmailAddress(ToAddress)
            //    };
            //msg.AddTos(recipients);

            //msg.SetSubject(subject);

            ////msg.AddContent(MimeType.Text, messages);  
            //msg.AddContent(MimeType.Html, messages);
            //var response = await client.SendEmailAsync(msg);
        }
    }
}
