namespace Assist.Accelerator.Chat.Api.Util.Exceptions;

public class UserConflictException : Exception
{
    public UserConflictException() 
        : base("User Already Exists") { }
}