﻿using Insight.Assist.Api.Services;
using Microsoft.SemanticKernel.Orchestration;
using Microsoft.SemanticKernel.SkillDefinition;
using System.ComponentModel;
using Azure.AI.OpenAI;
using Newtonsoft.Json;

namespace Assist.Accelerator.Chat.Api.SemanticKernel.Plugins
{
    public class ChatHistoryPlugin
    {
        private readonly ChatService _chatService;

        /// <summary>
        /// Plugin containing functions for managing chat history.
        /// </summary>
        public ChatHistoryPlugin(ChatService chatService)
        {
            _chatService = chatService;
        }

        /// <summary>
        /// Gets chat history as a string and adds it to the SKContext.
        /// </summary>
        [SKFunction, Description("Gets chat history as a string")]
        public async Task GetChatHistory(
            [Description("The chat's ID")] string chatId,
            [Description("The ID of the Azure Cognitive Search index to query")] string indexId,
            SKContext context)
        {
            Guid.TryParse(chatId, out var chatGuid);

            var chat = await _chatService.GetChatAsync(chatGuid);

            chat.IndexId = int.TryParse(indexId, out int indexIdInt) ? indexIdInt : 0;

            var chatHistory = chat.Messages.Any()
                ? string.Join("\n", chat.Messages.Select(m => $"{m.Role.ToString().ToUpper()}:  {m.Content}"))
                : "No chat history";

            context.Variables.Set("chatId", chat.Id.ToString());
            context.Variables.Set("chatHistory", chatHistory);
            context.Variables.Set("chatTitle", chat.Title ?? "");
            context.Variables.Set("chatJson", JsonConvert.SerializeObject(chat));
        }

        /// <summary>
        /// Adds the most recent user and assistant messages and chat title to the chat history.
        /// </summary>
        [SKFunction, Description("Updates chat history")]
        public async Task UpdateChatHistory(
            [Description("The serialized Chat object")] string chatJson,
            [Description("The title of the chat")] string chatTitle,
            [Description("The name of the attached file")] string fileName,
            [Description("The parsed text of the attached file")] string fileText,
            [Description("The message sent by the user")] string userInput,
            [Description("The message returned by the LLM")] string llmOutput,
            SKContext context)
        {
            var chat = JsonConvert.DeserializeObject<Insight.Assist.Api.Models.Chat>(chatJson);
            
            chat.Title ??= chatTitle;
            
            context.Variables.TryGetValue("copilotId", out var copilotId);
            if (chat.CopilotId == null && int.TryParse(copilotId, out var copilotIdInt))
            {
                chat.CopilotId = copilotIdInt;
            }
            
            var appendText = (!string.IsNullOrEmpty(fileName) && !string.IsNullOrEmpty(fileText))
                ? $" Attached file name: {fileName}" : "";

            chat.Messages = chat.Messages.Append(new ChatMessage(ChatRole.User, $"{userInput}{appendText}"));

            if (!string.IsNullOrEmpty(fileName) && !string.IsNullOrEmpty(fileText))
            {
                var safeFileText = GetDbSafeString(fileText);
                var fileMessage = $"Attached file name: {fileName}\n Attached file contents: {safeFileText}";

                chat.Messages = chat.Messages.Append(new ChatMessage(ChatRole.System, fileMessage));
            }

            chat.Messages = chat.Messages.Append(new ChatMessage(ChatRole.Assistant, llmOutput));

            context.Variables.Set("chatJson", JsonConvert.SerializeObject(chat));

            await _chatService.CreateOrUpdateChatAsync(chat);
        }

        /// <summary>
        ///     Replaces characters in the provided text with ones that are safe to use in a
        ///     JSON string saved to the database
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        private static string GetDbSafeString(string text)
        {
            var safeText = text
                .Replace('\u02ba', '"')
                .Replace('\u2033', '"')
                .Replace('\u030e', '"')
                .Replace('\u29f9', '\\')
                .Replace('\u2216', '\\');

            return safeText;
        }
    }
}
