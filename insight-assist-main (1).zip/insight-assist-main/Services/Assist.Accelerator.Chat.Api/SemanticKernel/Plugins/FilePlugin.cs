﻿using Assist.Accelerator.Chat.Api.Services;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.SemanticKernel.Orchestration;
using Microsoft.SemanticKernel.SkillDefinition;
using System.ComponentModel;

namespace Assist.Accelerator.Chat.Api.SemanticKernel.Plugins
{
    public class FilePlugin
    {
        private readonly FileService _fileService;
        private readonly FileParserService _fileParserService;

        public FilePlugin(FileService fileService, FileParserService fileParserService)
        {
            _fileService = fileService;
            _fileParserService = fileParserService;
        }

        /// <summary>
        /// Adds a file's contents to the chat context.
        /// </summary>
        [SKFunction, Description("Adds a file's contents to the chat context")]
        public async Task GetFileContents(
            [Description("The name of the attached file")] string fileName,
            SKContext context)
        {
            if (!string.IsNullOrEmpty(fileName))
            {
                var file = await _fileService.DownloadFileAsync(fileName);
                var fileText = await _fileParserService.ParseAsync(file);

                context.Variables.Set("fileText", fileText);
            }
            else
            {
                context.Variables.Set("fileName", "");
                context.Variables.Set("fileText", "");
            }
        }
    }
}
