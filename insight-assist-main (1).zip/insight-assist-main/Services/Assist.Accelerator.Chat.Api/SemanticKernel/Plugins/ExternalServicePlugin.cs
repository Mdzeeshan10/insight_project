using System.ComponentModel;
using Assist.Accelerator.Chat.Api.Models;
using Assist.Accelerator.Chat.Api.Services.Copilots.AuthProviders;
using Azure.AI.OpenAI;
using Insight.Assist.Api.Services;
using Microsoft.SemanticKernel.Orchestration;
using Microsoft.SemanticKernel.SkillDefinition;
using Newtonsoft.Json;

namespace Assist.Accelerator.Chat.Api.SemanticKernel.Plugins;

public class ExternalServicePlugin
{
    private readonly ChatService _chatService;

    public ExternalServicePlugin(ChatService chatService)
    {
        _chatService = chatService;
    }
    
    /// <summary>
    /// Gets a response for an existing chat.
    /// </summary>
    [SKFunction, Description("Invokes an external service to get a chat completion based on the user's prompt")]
    public async Task Fetch(
        [Description("The endpoint to fetch")] string externalEndpoint,
        [Description("The auth provider to use to fetch")] string externalAuthProvider,
        [Description("The credential data for making the request")] string externalCredentialData,
        [Description("The serialized Chat object")] string chatJson,
        [Description("The user's input")] string userInput,
        [Description("The parsed text of the attached file")] string fileText,
        SKContext context)
    {
        var chat = JsonConvert.DeserializeObject<Insight.Assist.Api.Models.Chat>(chatJson);
        var authProvider = GetProvider(Enum.Parse<CopilotAuthProvider>(externalAuthProvider));

        var textToSend = string.IsNullOrEmpty(fileText) ? userInput : fileText; 
        
        var copilotResponse = await authProvider.GetCopilotResponse(externalEndpoint, externalCredentialData, textToSend, chat?.Messages ?? Array.Empty<ChatMessage>());

        context.Variables.Set("llmOutput", copilotResponse);
    }

    private ICopilotAuthProvider GetProvider(CopilotAuthProvider authProvider)
    {
        switch (authProvider)
        {
            case CopilotAuthProvider.GoogleCloudServiceAccount:
                return new GCPSACopilotAuthProvider();
            case CopilotAuthProvider.NoAuth:
            default:
                return new NoAuthProvider();
        }
    }
}