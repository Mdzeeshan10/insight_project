using Insight.Assist.Api.Models;

namespace Insight.Assist.Api.Clients.Interfaces;

public interface IConversation
{
    public Task GetChatCompletion(string input, Models.Chat chat);
}