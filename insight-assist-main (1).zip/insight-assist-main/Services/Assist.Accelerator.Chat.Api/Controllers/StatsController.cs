using System.Reflection;
using Assist.Accelerator.Chat.Api.Models.Usage;
using Assist.Accelerator.Chat.Api.Util;
using Insight.Assist.Api.DAL;
using Insight.Assist.Api.Models;
using Insight.Assist.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Collections;
using System;
using static Google.Cloud.AIPlatform.V1.Artifact.Types;

namespace Insight.Assist.Api.Controllers;

[Authorize]
[ApiController]
[Route("[controller]")]
public class StatsController : ControllerBase
{
    private readonly UsageService _usageService;
    private readonly StatsService _statsService;
    private readonly UsersService _usersService;

    public StatsController(IConfiguration configuration, UsageService usageService, StatsService statsService, UsersService usersService)
    {
        _usageService = usageService;
        _statsService = statsService;
        _usersService = usersService;
    }

    [HttpGet("/me")]
    [Authorize(Roles = Policy.User)]
    public async Task<Quota> GetCurrentUserQuota()
    {
        return (await _usageService.GetQuota(userId: _usersService.GetCurrentUser().UserId))!;
    }


    private HistoricalStatSpan SpanFromPeriodString(string? period)
    {
        return period?.Length switch
        {
            4 => HistoricalStatSpan.Month, // 2023
            7 => HistoricalStatSpan.Day, // 2023-06
            10 => HistoricalStatSpan.Hour, // 2023-06-08
            13 => HistoricalStatSpan.Minute, // 2023-06-08-17
            _ => HistoricalStatSpan.Day // default (if invalid format or null) 
        };
    }

    [HttpGet("Dashboard")]
    [HttpGet("Dashboard/{period}")]
    [Authorize(Roles = Policy.Admin)]
    public async Task<Dictionary<string, object>> GetDashboardStats(string? period)
    {
        
        // TODO: try to not always compute this API call every time (e.g. cache for 5 mins?) since with enough usage
        // it may be very computationally intensive

        var span = SpanFromPeriodString(period);

        // Because we want the aggregate across an entire window instead of the chunks within a window, we need to add one to the span
        var adjustedSpan = (HistoricalStatSpan)Math.Min((int)HistoricalStatSpan.Year, ((int)SpanFromPeriodString(period) + 1));
        period ??= DateTime.UtcNow.ToString(span.ToDateFormat());
        var targetStartDate = span.DateTimeFromPeriod(period);
        var orgQuota = (await _usageService.GetQuota(teamId: Quota.AllUsersTeamId, month: DateTime.UtcNow))!;
        return new Dictionary<string, object>
        {
            { "Deployment", _usageService.GetCurrentModel() },
            { "AvailableModels", _usageService.GetAvailableModels() },
            { "AdminStats", await _statsService.ComputeHistoricalStats(targetStartDate, adjustedSpan) },
            { "MonthlyCostUsed", orgQuota.CostUsed },
            { "MonthlyCostLimit", orgQuota.CostLimit },
        };
    }

    [HttpGet("Dashboards/{startDate}/{endDate}")]
    [Authorize(Roles = Policy.Admin)]
    public async Task<Dictionary<string, object>> GetDashboardStatsRange(DateTime startDate, DateTime endDate)
    {
        // TODO: try to not always compute this API call every time (e.g. cache for 5 mins?) since with enough usage
        // it may be very computationally intensive

        var span = _statsService.GetSpanFromDates(startDate, endDate);

        // Because we want the aggregate across an entire window instead of the chunks within a window, we need to add one to the span
        var adjustedSpan = (HistoricalStatSpan)Math.Min((int)HistoricalStatSpan.Year, ((int)span + 1));

        /*var targetStartDate = span.StartDateTimeForSpan(startDate ?? DateTime.UtcNow);*/
        var orgQuota = (await _usageService.GetQuota(teamId: Quota.AllUsersTeamId, month: DateTime.UtcNow))!;

        return new Dictionary<string, object>
        {
            { "Deployment", _usageService.GetCurrentModel() },
            { "AvailableModels", _usageService.GetAvailableModels() },
            { "AdminStats", await _statsService.ComputeHistoricalStatsRange( startDate,  endDate,adjustedSpan) },
            { "MonthlyCostUsed", orgQuota.CostUsed },
            { "MonthlyCostLimit", orgQuota.CostLimit },
        };      
    }

    [HttpGet("HistoricalStats/{statIndex}")]
    [HttpGet("HistoricalStats/{statIndex}/{period}")]
    [Authorize(Roles = Policy.Admin)]
    public async Task<HistoricalStat?> GetHistoricalDashboardStats(int statIndex, string? period)
    {
        var span = SpanFromPeriodString(period);
        period ??= DateTime.UtcNow.ToString(span.ToDateFormat());
        var stat = _statsService.GetHistoricalStat(statIndex, span, span.DateTimeFromPeriod(period)) ?? new HistoricalStat
        {
            Index = statIndex,
            Span = span,
            StartDateTime = span.PeriodDateTimeForSpan(DateTime.UtcNow),
            Data = new Dictionary<int, object>()
        };
        if (stat != null) return stat;

        return await _statsService.ComputeHistoricalStatsForTimeWindow(statIndex, span.DateTimeFromPeriod(period), span);
    }


    [HttpGet("HistoricalStatsRangeNew/{statIndex}/{startDate}/{endDate}")]
    [Authorize(Roles = Policy.Admin)]
    public async Task<HistoricalStat?> GetHistoricalDashboardStatsRange(int statIndex, DateTime startDate, DateTime endDate)
    {
       return await _statsService.GetHistoricalDashboardStatsRange(statIndex, startDate, endDate);
    }

    [HttpGet("Quotas")]
    [HttpGet("Quotas/{period}")]
    [Authorize(Roles = Policy.Admin)]
    public IEnumerable<Quota> GetAllQuotasForMonth(string? period)
    {
        return _usageService.GetQuotasForPeriod(period ?? Quota.CurrentPeriodString);
    }

    [HttpGet("Quotas/Top")]
    [HttpGet("Quotas/Top/{period}")]
    [Authorize(Roles = Policy.Admin)]
    public IEnumerable<Quota> GetTopQuotasForCurrentMonth(string? period)
    {
        return _usageService.GetQuotasForPeriod(period ?? Quota.CurrentPeriodString, orderByUsageDesc: true, limit: 10);
    }

    [HttpGet("Users/Top/{period}")]
    [Authorize(Roles = Policy.Admin)]
    public IEnumerable<Quota> GetTopUsers(string period)
    {
        var span = SpanFromPeriodString(period);

        // Because we want the aggregate across an entire window instead of the chunks within a window, we need to add one to the span
        var adjustedSpan =
            (HistoricalStatSpan)Math.Min((int)HistoricalStatSpan.Year, ((int)SpanFromPeriodString(period) + 1));
        var targetStartDate = span.DateTimeFromPeriod(period);
        return _statsService.GetTopUsers(targetStartDate, adjustedSpan);
    }

    [HttpGet("Users/TopRange/{startDate}/{endDate}")]
    [Authorize(Roles = Policy.Admin)]
    public IEnumerable<Quota> GetTopUsersRange(DateTime startDate, DateTime endDate)
    {
        var span = _statsService.GetSpanFromDates(startDate, endDate);

        // Because we want the aggregate across an entire window instead of the chunks within a window, we need to add one to the span
        var adjustedSpan = (HistoricalStatSpan)Math.Min((int)HistoricalStatSpan.Year, ((int)span + 1));
        /* var targetStartDate = span.DateTimeFromPeriod(period);*/
        return _statsService.GetTopUsersRange(startDate, endDate, adjustedSpan);
    }


    [HttpGet("Models")]
    public IEnumerable<AvailableModel> GetCurrentModels()
    {
            return _usageService.GetAvailableModels();
    }

    [HttpPut("Models/{id}/activate")]
    [Authorize(Roles = Policy.Admin)]
    public async Task SetCurrentModel(int id)
    {
        await _usageService.SetCurrentModel(id);
    }

    [HttpPut("OrgQuotaLimit/{amount}")]
    [Authorize(Roles = Policy.Admin)]
    public async Task<IActionResult> SetOrgQuotaLimit(string amount)
    {
        long parsedAmount;
        
        try
        {
            parsedAmount = long.Parse(amount);
        }
        catch (OverflowException)
        {
            return BadRequest($"Cost limit cannot be greater than {long.MaxValue / 100000000}");
        }
        catch (Exception ex)
        {
            return BadRequest($"Cost limit could not be determined. Amount must be a whole number  0 - 92233720368.");
        }

        if (parsedAmount < 0)
        {
            return BadRequest("Cost limit cannot be negative.");
        }

        await _usageService.SetOrgQuotaLimit(parsedAmount);

        return Ok();      
    }
}