using Assist.Accelerator.Chat.Api.Models.Usage;
using Assist.Accelerator.Chat.Api.Providers.Amazon;
using Assist.Accelerator.Chat.Api.Providers.Google;
using Insight.Assist.Api.Models;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.AI.ChatCompletion;
using Microsoft.SemanticKernel.AI.Embeddings;
using Microsoft.SemanticKernel.AI.TextCompletion;

namespace Assist.Accelerator.Chat.Api.Providers;

public static class KernelBuilderExtensions
{
    public static KernelBuilder WithChatCompletionService(this KernelBuilder builder,
        AvailableModel model,
        IConfiguration configuration,
        bool alsoAsTextCompletion = true,
        string? serviceId = null,
        bool setAsDefault = false,
        HttpClient? httpClient = null)
    {
        switch (model.Provider)
        {
            case ModelProvider.AzureOpenAiService:
                return builder.WithAzureChatCompletionServiceInternal(model, configuration, alsoAsTextCompletion,
                    serviceId, setAsDefault, httpClient);
            case ModelProvider.GoogleVertexAi:
                return builder.WithGoogleVertexChatCompletionServiceInternal(model, configuration, alsoAsTextCompletion,
                    serviceId, setAsDefault);
            case ModelProvider.AmazonBedrockAi:
                return builder.WithAmazonBedrockChatCompletionServiceInternal(model, configuration, alsoAsTextCompletion,
                    serviceId, setAsDefault);
            default:
                throw new ArgumentOutOfRangeException();
        }
    }

    private static KernelBuilder WithAzureChatCompletionServiceInternal(this KernelBuilder builder,
        AvailableModel model,
        IConfiguration configuration,
        bool alsoAsTextCompletion = true,
        string? serviceId = null,
        bool setAsDefault = false,
        HttpClient? httpClient = null)
    {
        var url = configuration["URL"]!;
        var keyCredential = configuration["KeyCredential"]!;
        return builder.WithAzureChatCompletionService(model.DeploymentName, url, keyCredential, alsoAsTextCompletion,
            serviceId, setAsDefault, httpClient);
    }

    private static KernelBuilder WithGoogleVertexChatCompletionServiceInternal(this KernelBuilder builder,
        AvailableModel model,
        IConfiguration configuration,
        bool alsoAsTextCompletion = true,
        string? serviceId = null,
        bool setAsDefault = false)
    {
        GoogleVertexAICompletion Factory((ILogger Logger, KernelConfig Config) parameters) => new(
            model,
            configuration);

        builder.WithAIService<IChatCompletion>(serviceId, Factory, setAsDefault);

        // If the class implements the text completion interface, allow to use it also for semantic functions
        if (alsoAsTextCompletion && typeof(ITextCompletion).IsAssignableFrom(typeof(GoogleVertexAICompletion)))
        {
            builder.WithAIService<ITextCompletion>(serviceId, Factory, setAsDefault);
        }

        return builder;
    }

    private static KernelBuilder WithAmazonBedrockChatCompletionServiceInternal(this KernelBuilder builder,
        AvailableModel model,
        IConfiguration configuration,
        bool alsoAsTextCompletion = true,
        string? serviceId = null,
        bool setAsDefault = false)
    {
        AmazonBedrockCompletion Factory((ILogger Logger, KernelConfig Config) parameters) => new(
            model,
            configuration);

        builder.WithAIService<IChatCompletion>(serviceId, Factory, setAsDefault);

        // If the class implements the text completion interface, allow to use it also for semantic functions
        if (alsoAsTextCompletion && typeof(ITextCompletion).IsAssignableFrom(typeof(AmazonBedrockCompletion)))
        {
            builder.WithAIService<ITextCompletion>(serviceId, Factory, setAsDefault);
        }

        return builder;
    }
    
    
    public static KernelBuilder WithTextEmbeddingGenerationService(this KernelBuilder builder,
        AvailableModel model,
        IConfiguration configuration,
        string? serviceId = null,
        bool setAsDefault = false,
        HttpClient? httpClient = null)
    {
        switch (model.Provider)
        {
            case ModelProvider.AzureOpenAiService:
                return builder.WithAzureTextEmbeddingGenerationServiceInternal(model, configuration,
                    serviceId, setAsDefault, httpClient);
            case ModelProvider.GoogleVertexAi:
                return builder.WithGoogleTextEmbeddingGenerationServiceInternal(model, configuration,
                    serviceId, setAsDefault);
            case ModelProvider.AmazonBedrockAi:
            default:
                return builder;
        }
    }
    
    private static KernelBuilder WithAzureTextEmbeddingGenerationServiceInternal(this KernelBuilder builder,
        AvailableModel model,
        IConfiguration configuration,
        string? serviceId = null,
        bool setAsDefault = false,
        HttpClient? httpClient = null)
    {
        var url = configuration["URL"]!;
        var keyCredential = configuration["KeyCredential"]!;
        return builder.WithAzureTextEmbeddingGenerationService(model.DeploymentName, url, keyCredential,
            serviceId, setAsDefault, httpClient);
    }

    private static KernelBuilder WithGoogleTextEmbeddingGenerationServiceInternal(this KernelBuilder builder,
        AvailableModel model,
        IConfiguration configuration,
        string? serviceId = null,
        bool setAsDefault = false)
    {
        GoogleVertexAIEmbeddings Factory((ILogger Logger, KernelConfig Config) parameters) => new(
            model,
            configuration);

        builder.WithAIService<ITextEmbeddingGeneration>(serviceId, Factory, setAsDefault);
        return builder;
    }
}