using Azure.AI.OpenAI;
using Microsoft.SemanticKernel.Orchestration;

namespace Assist.Accelerator.Chat.Api.Providers;

public static class ModelResultExtensions
{
    private static CompletionUsage GetCompletionsUsage(this ModelResult resultBase)
    {
        return resultBase.GetResult<CompletionUsage>();
    }
    
    private static CompletionsUsage GetOpenAIUsage(this ModelResult resultBase)
    {
        return resultBase.GetResult<ChatCompletions>().Usage;
    }
    
    public static CompletionUsage GetUsage(this ModelResult resultBase)
    {
        if (resultBase.GetRawResult() is CompletionUsage)
        {
            return resultBase.GetCompletionsUsage();
        } 
        
        var usage = resultBase.GetOpenAIUsage();
        
        return new CompletionUsage
        {
            CompletionTokens = usage.CompletionTokens,
            PromptTokens = usage.PromptTokens,
            TotalTokens = usage.TotalTokens
        };
    }
}