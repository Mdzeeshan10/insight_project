using Azure;
using Azure.AI.OpenAI;
using Insight.Assist.Api.Models;

namespace Assist.Accelerator.Chat.Api.Providers.Microsoft;

public class AzureOpenAIProvider : IChatProvider
{
    private readonly OpenAIClient _client;

    public AzureOpenAIProvider(AvailableModel model, IConfiguration configuration)
    {
        var url = configuration.GetSection(model.CredentialPath!)["URL"];
        var keyCredential = configuration.GetSection(model.CredentialPath!)["KeyCredential"];
        _client = new OpenAIClient(new Uri(url), new AzureKeyCredential(keyCredential!));
    }
    
    public async Task<ChatResponse> SendMessage(AvailableModel model, ChatCompletionsOptions chatCompletionsOptions,
        CancellationToken cancellationToken = new CancellationToken())
    {
        // Because we initially built this for Azure OpenAI Service, there is not much
        // to do in this provider other than call the completion endpoint
        var result = await _client.GetChatCompletionsAsync(model.DeploymentName, chatCompletionsOptions, cancellationToken);
        return new ChatResponse
        {
            Message = result.Value.Choices[0].Message.Content,
            InputTokens = result.Value.Usage.PromptTokens,
            OutputTokens = result.Value.Usage.CompletionTokens
        };
    }
}