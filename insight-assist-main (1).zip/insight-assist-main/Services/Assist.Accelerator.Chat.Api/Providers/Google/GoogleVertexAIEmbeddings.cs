using Google.Apis.Auth.OAuth2;
using Google.Cloud.AIPlatform.V1;
using Insight.Assist.Api.Models;
using Microsoft.SemanticKernel.AI.Embeddings;
using wkt = Google.Protobuf.WellKnownTypes;

namespace Assist.Accelerator.Chat.Api.Providers.Google;

public class GoogleVertexAIEmbeddings : GoogleProviderBase, ITextEmbeddingGeneration
{
    public GoogleVertexAIEmbeddings(AvailableModel model, IConfiguration configuration) : base(model, configuration)
    {
    }
    
    public async Task<IList<Embedding<float>>> GenerateEmbeddingsAsync(IList<string> data, CancellationToken cancellationToken = new CancellationToken())
    {
        var client = await new PredictionServiceClientBuilder
        {
            Endpoint = ApiEndpoint,
            GoogleCredential = GoogleCredential.FromJson(KeyCredential)
        }.BuildAsync(cancellationToken);
        
        var endpoint = $"projects/{ProjectId}/locations/{Location}/publishers/google/models/{DeploymentName}";

        var instances = ToVertexInstances(data);
        var parameters = GetParams();
        var response = await client.PredictAsync(endpoint, instances, parameters);
        
        // TODO: probably wanna exception handle these deep dereferences...
        var embeddings = response.Predictions
            .Select(p => new Embedding<float>(
                p.StructValue.Fields["embeddings"].StructValue
                .Fields["values"].ListValue.Values
                    .Select(v => (float)v.NumberValue)
            ))
            .ToList();

        return embeddings;
    }
    
    private static wkt::Value GetParams()
    {
        var parameters = new wkt::Struct();
        parameters.Fields.Add("temperature", wkt::Value.ForNumber(0));
        parameters.Fields.Add("topP", wkt::Value.ForNumber(0));
        parameters.Fields.Add("topK", wkt::Value.ForNumber(1)); // Default is 40
        // parameters.Fields.Add("maxOutputTokens", wkt::Value.ForNumber(256));
        
        return wkt::Value.ForStruct(parameters);
    }
    
    private static IEnumerable<wkt::Value> ToVertexInstances(IList<string> data)
    {
        var instances = data.Select(d => 
            wkt::Value.ForStruct(new wkt.Struct
            {
                Fields =
                {
                    ["content"] = wkt::Value.ForString(d)
                }
            })).ToList();

        return instances;
    }
}