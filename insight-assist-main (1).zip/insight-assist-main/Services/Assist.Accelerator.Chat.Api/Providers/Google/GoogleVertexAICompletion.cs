using Google.Apis.Auth.OAuth2;
using Google.Cloud.AIPlatform.V1;
using Insight.Assist.Api.Models;
using Microsoft.SemanticKernel.AI.ChatCompletion;
using Microsoft.SemanticKernel.AI.TextCompletion;
using Microsoft.SemanticKernel.Orchestration;
using wkt = Google.Protobuf.WellKnownTypes;

namespace Assist.Accelerator.Chat.Api.Providers.Google;

public class GoogleVertexAICompletion : GoogleProviderBase, IChatCompletion, ITextCompletion
{
    public GoogleVertexAICompletion(AvailableModel model, IConfiguration configuration) : base(model, configuration)
    {
    }
    
    private static wkt::Value ConvertMessage(ChatMessageBase message)
    {
        return wkt::Value.ForStruct(new wkt::Struct()
        {
            Fields =
            {
                ["author"] = wkt::Value.ForString(ToVertexAuthor(message.Role)),
                ["content"] = wkt::Value.ForString(message.Content)
            }
        });
    }

    private static string ToVertexAuthor(AuthorRole role)
    {
        if (role == AuthorRole.Assistant) return "bot";
        if (role == AuthorRole.User) return "user";

        throw new ArgumentOutOfRangeException(nameof(role), role, "Unsupported chat role");
    }

    private static wkt::Value ToVertexParams(ChatRequestSettings options)
    {
        // Relevant documentation: https://cloud.google.com/vertex-ai/docs/generative-ai/migrate-from-azure#use_equivalent_parameters
        var parameters = new wkt::Struct();
        parameters.Fields.Add("temperature", wkt::Value.ForNumber(options.Temperature));
        parameters.Fields.Add("topP", wkt::Value.ForNumber(options.TopP));
        parameters.Fields.Add("topK", wkt::Value.ForNumber(40)); // Default is 40
        if (options.MaxTokens.HasValue)
            parameters.Fields.Add("maxOutputTokens",
                wkt::Value.ForNumber(Math.Min((double)options.MaxTokens, 1024))); // supported range [0, 1025)

        return wkt::Value.ForStruct(parameters);
    }

    private static wkt::Value ToVertexParams(CompleteRequestSettings options)
    {
        // Relevant documentation: https://cloud.google.com/vertex-ai/docs/generative-ai/migrate-from-azure#use_equivalent_parameters
        var parameters = new wkt::Struct();
        parameters.Fields.Add("temperature", wkt::Value.ForNumber(options.Temperature));
        parameters.Fields.Add("topP", wkt::Value.ForNumber(options.TopP));
        parameters.Fields.Add("topK", wkt::Value.ForNumber(40)); // Default is 40
        if (options.MaxTokens.HasValue)
            parameters.Fields.Add("maxOutputTokens",
                wkt::Value.ForNumber(Math.Min((double)options.MaxTokens, 1024))); // supported range [0, 1025)

        return wkt::Value.ForStruct(parameters);
    }

    private static IEnumerable<wkt::Value> ToVertexInstances(string context, IEnumerable<ChatMessageBase> messages)
    {
        var instances = new List<wkt::Value>();
        instances.Add(wkt::Value.ForStruct(new wkt.Struct
        {
            Fields =
            {
                ["context"] = wkt::Value.ForString(context),
                ["examples"] = wkt::Value.ForList(),
                ["messages"] = wkt::Value.ForList(messages.Select(ConvertMessage).ToArray())
            }
        }));

        return instances;
    }

    public ChatHistory CreateNewChat(string? instructions = null)
    {
        return new Models.ChatHistory(instructions);
    }

    public async Task<IReadOnlyList<IChatResult>> GetChatCompletionsAsync(ChatHistory chat,
        ChatRequestSettings? requestSettings = null,
        CancellationToken cancellationToken = new CancellationToken())
    {
        // Grab context, assuming it is simply the first System message in the list.  Ignore other System messages.
        var context = chat.Messages
            .FirstOrDefault(m => m.Role == AuthorRole.System)
            ?.Content ?? "";

        // Convert to VertexAI message format
        var messages = chat.Messages
            .Where(m => m.Role != AuthorRole.System)
            .ToList();
        
        var parameters = ToVertexParams(requestSettings ?? new ChatRequestSettings());
        var instances = ToVertexInstances(context, messages);

        var response = await Predict(instances, parameters, cancellationToken);
        var usage = new CompletionUsage
        {
            CompletionTokens = response.Sum(message => message.Length),
            PromptTokens = context.Length + messages.Sum(m => m.Content.Length)
        };
        usage.TotalTokens = usage.CompletionTokens + usage.PromptTokens;
        
        return response.Select(message => new ChatResult(message, usage)).ToList();
    }

    private async Task<IReadOnlyList<string>> Predict(IEnumerable<wkt::Value> instances, 
        wkt::Value parameters,
        CancellationToken cancellationToken = new CancellationToken())
    {
        var client = await new PredictionServiceClientBuilder
        {
            Endpoint = ApiEndpoint,
            GoogleCredential = GoogleCredential.FromJson(KeyCredential)
        }.BuildAsync(cancellationToken);
        
        var endpoint = $"projects/{ProjectId}/locations/{Location}/publishers/google/models/{DeploymentName}";

        var prediction = await client.PredictAsync(endpoint, instances, parameters);
        
        // TODO: probably wanna exception handle these deep dereferences...
        var responses = prediction.Predictions[0].StructValue.Fields["candidates"].ListValue.Values;
        var result = responses.Select(r => r.StructValue.Fields["content"].StringValue).ToList();

        return result;
    }
    
    private class NotStreamingChatResult : IChatStreamingResult, ITextStreamingResult
    {
        private readonly string _text;
        private readonly ChatMessageBase _message;

        public NotStreamingChatResult(ChatMessageBase message)
        {
            _message = message;
        }

        public NotStreamingChatResult(string text, object modelResult)
        {
            _text = text;
            ModelResult = new ModelResult(modelResult);
        }

        public async Task<ChatMessageBase> GetChatMessageAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            return _message;
        }

        public async IAsyncEnumerable<ChatMessageBase> GetStreamingChatMessageAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            yield return _message;
        }

        public async Task<string> GetCompletionAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            return _text;
        }

        public ModelResult ModelResult { get; }

        public async IAsyncEnumerable<string> GetCompletionStreamingAsync(
            CancellationToken cancellationToken = new CancellationToken())
        {
            yield return _text;
        }
    }

    public async IAsyncEnumerable<IChatStreamingResult> GetStreamingChatCompletionsAsync(ChatHistory chat, ChatRequestSettings? requestSettings = null,
        CancellationToken cancellationToken = new CancellationToken())
    {
        // Simply make this a synchronous call for now, since Google models don't get much usage
        var result = await GetChatCompletionsAsync(chat, requestSettings, cancellationToken);
        yield return new NotStreamingChatResult(await result[0].GetChatMessageAsync(cancellationToken));
    }

    public async Task<IReadOnlyList<ITextResult>> GetCompletionsAsync(string text, CompleteRequestSettings requestSettings,
        CancellationToken cancellationToken = new CancellationToken())
    {
        // Needs to be made to use the actual text completion API, but a good hack for now to test things...
        var history = new ChatHistory();
        history.AddUserMessage(text);
        var settings = new ChatRequestSettings
        {
            Temperature = requestSettings.Temperature,
            MaxTokens = requestSettings.MaxTokens,
            TopP = requestSettings.TopP,
            FrequencyPenalty = requestSettings.FrequencyPenalty,
            PresencePenalty = requestSettings.PresencePenalty,
            StopSequences = requestSettings.StopSequences,
            ResultsPerPrompt = requestSettings.ResultsPerPrompt,
            TokenSelectionBiases = requestSettings.TokenSelectionBiases
        };

        var chatResults = await GetChatCompletionsAsync(history, settings, cancellationToken);
        var textResults = chatResults.Select(x => (ITextResult)x).ToList();
        return textResults;
    }

    public async IAsyncEnumerable<ITextStreamingResult> GetStreamingCompletionsAsync(string text, CompleteRequestSettings requestSettings,
        CancellationToken cancellationToken = new CancellationToken())
    {
        // Simply make this a synchronous call for now, since Google models don't get much usage
        var result = await GetCompletionsAsync(text, requestSettings, cancellationToken);
        yield return new NotStreamingChatResult(await result[0].GetCompletionAsync(cancellationToken), result[0].ModelResult);
    }
}