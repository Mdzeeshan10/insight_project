using Insight.Assist.Api.Models;
using Newtonsoft.Json;

namespace Assist.Accelerator.Chat.Api.Providers.Google;

public abstract class GoogleProviderBase
{
    protected readonly string Location;
    protected readonly string DeploymentName;
    protected readonly string ProjectId;
    protected readonly string KeyCredential;
    protected readonly string ApiEndpoint;

    protected GoogleProviderBase(AvailableModel model, IConfiguration configuration)
    {
        ApiEndpoint = configuration["API_ENDPOINT"]!;
        ProjectId = configuration["PROJECT_ID"]!;
        Location = configuration["LOCATION"]!;
        DeploymentName = model.DeploymentName;
        var keyCredentialSection = configuration.GetSection("KeyCredential").Get<Dictionary<string, object>>();
        KeyCredential = JsonConvert.SerializeObject(keyCredentialSection);
    }
}