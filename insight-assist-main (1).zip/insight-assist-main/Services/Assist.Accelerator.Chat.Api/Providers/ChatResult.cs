using Azure.AI.OpenAI;
using Microsoft.SemanticKernel.AI.ChatCompletion;
using Microsoft.SemanticKernel.AI.TextCompletion;
using Microsoft.SemanticKernel.Connectors.AI.OpenAI.AzureSdk;
using Microsoft.SemanticKernel.Orchestration;

namespace Assist.Accelerator.Chat.Api.Providers;

public class ChatResult : IChatResult, ITextResult
{
    private readonly string _message;

    public ChatResult(string message)
    {
        _message = message;
    }

    public ChatResult(string message, object result)
    {
        _message = message;
        ModelResult = new ModelResult(result);
    }

    public Task<ChatMessageBase> GetChatMessageAsync(CancellationToken cancellationToken = default)
        => Task.FromResult<ChatMessageBase>(new SKChatMessage(new ChatMessage(ChatRole.Assistant, _message)));
    
    
    public ModelResult ModelResult { get; }

    public Task<string> GetCompletionAsync(CancellationToken cancellationToken = default)
    {
        return Task.FromResult(_message);
    }
}

public class CompletionUsage
{
    /// <summary> Number of tokens received in the completion. </summary>
    public int CompletionTokens { get; set; }
    /// <summary> Number of tokens sent in the original request. </summary>
    public int PromptTokens { get; set; }

    /// <summary> Total number of tokens transacted in this request/response. </summary>
    public int TotalTokens { get; set; }
}