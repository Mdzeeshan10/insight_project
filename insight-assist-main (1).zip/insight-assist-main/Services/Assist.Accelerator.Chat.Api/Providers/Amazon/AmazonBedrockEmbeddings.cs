namespace Assist.Accelerator.Chat.Api.Providers.Amazon;

public class AmazonBedrockEmbeddings
{
    
}