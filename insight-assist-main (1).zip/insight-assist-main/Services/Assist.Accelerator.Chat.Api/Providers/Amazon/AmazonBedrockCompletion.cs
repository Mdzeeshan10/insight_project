using System.Text.Json;
using Insight.Assist.Api.Models;
using Microsoft.SemanticKernel.AI.ChatCompletion;
using Microsoft.SemanticKernel.AI.TextCompletion;

namespace Assist.Accelerator.Chat.Api.Providers.Amazon;

public class AmazonBedrockCompletion : AmazonProviderBase, IChatCompletion, ITextCompletion
{
    public AmazonBedrockCompletion(AvailableModel model, IConfiguration configuration) : base(model, configuration)
    {
    }

    public ChatHistory CreateNewChat(string? instructions = null)
    {
        return new Models.ChatHistory(instructions);
    }

    public async Task<IReadOnlyList<IChatResult>> GetChatCompletionsAsync(ChatHistory chat, ChatRequestSettings? requestSettings = null,
        CancellationToken cancellationToken = new CancellationToken())
    {
        var text = GetPrompt(chat);
        var chatResponse = Model.DeploymentName switch
        {
            "Amazon" => GetTitanChatResponse(text, Model),
            "Anthropic" => GetClaudeChatResponse(text, Model),
            "AI21" => GetAi21ChatResponse(text, Model),
            _ => throw new Exception("Invalid model name: " + Model.DeploymentName)
        };
        
        var result = new ChatResult(chatResponse.Message, new CompletionUsage
        {
            PromptTokens = chatResponse.InputTokens,
            CompletionTokens = chatResponse.OutputTokens,
            TotalTokens = chatResponse.TotalTokens
        });

        var resultList = new List<IChatResult> { result };

        return resultList;
    }

    private class NotStreamingChatResult : IChatStreamingResult
    {
        private readonly ChatMessageBase _message;

        public NotStreamingChatResult(ChatMessageBase message)
        {
            _message = message;
        }
        
        public async Task<ChatMessageBase> GetChatMessageAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            return _message;
        }

        public async IAsyncEnumerable<ChatMessageBase> GetStreamingChatMessageAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            yield return _message;
        }
    }

    public async IAsyncEnumerable<IChatStreamingResult> GetStreamingChatCompletionsAsync(ChatHistory chat, ChatRequestSettings? requestSettings = null,
        CancellationToken cancellationToken = new CancellationToken())
    {
        var result = await GetChatCompletionsAsync(chat, requestSettings, cancellationToken);
        yield return new NotStreamingChatResult(await result[0].GetChatMessageAsync(cancellationToken));
    }

    public async Task<IReadOnlyList<ITextResult>> GetCompletionsAsync(string text, CompleteRequestSettings requestSettings,
        CancellationToken cancellationToken = new CancellationToken())
    {
        var history = new ChatHistory();
        history.AddUserMessage(text);
        var settings = new ChatRequestSettings
        {
            Temperature = requestSettings.Temperature,
            MaxTokens = requestSettings.MaxTokens,
            TopP = requestSettings.TopP,
            FrequencyPenalty = requestSettings.FrequencyPenalty,
            PresencePenalty = requestSettings.PresencePenalty,
            StopSequences = requestSettings.StopSequences,
            ResultsPerPrompt = requestSettings.ResultsPerPrompt,
            TokenSelectionBiases = requestSettings.TokenSelectionBiases
        };
        var result = await GetChatCompletionsAsync(history, settings, cancellationToken);
        return result.Select(x => (ITextResult)x).ToList();
    }

    public IAsyncEnumerable<ITextStreamingResult> GetStreamingCompletionsAsync(string text, CompleteRequestSettings requestSettings,
        CancellationToken cancellationToken = new CancellationToken())
    {
        throw new NotImplementedException();
    }
    
    
    // ----------------------------------------------
    // Private Methods
    // ----------------------------------------------

    //
    // TITAN REQUEST
    //
    private class TitanApiRequest
    {
        public string inputText { get; set; }
        public TitanTextGenerationConfig textGenerationConfig { get; set; }
    }

    private class TitanTextGenerationConfig
    {
        public Int32 maxTokenCount { get; set; }
        public List<string> stopSequences { get; set; }
        public float temperature { get; set; }
        public float topP { get; set; }
    }

    //
    // Claude REQUEST
    //
    private class ClaudeApiRequest
    {
        public string prompt { get; set; }
        public int max_tokens_to_sample { get; set; }
        public float temperature { get; set; }
        public int top_k { get; set; }
        public float top_p { get; set; }
        public List<string> stop_sequences { get; set; }
    }

    //
    // AI21 REQUEST
    //

    private class Ai21ApiRequest
    {
        public string prompt { get; set; }
        public int maxTokens { get; set; }
        public float temperature { get; set; }
        public float topP { get; set; }

        // AWS docs are wrong
        // https://us-east-1.console.aws.amazon.com/bedrock/home?region=us-east-1#/providers?model=j2-ultra
        //public List<string> stop_sequences { get; set; }
        public List<string> stopSequences { get; set; }

        // The AWS Boto3 Python library did not set these (by default anyway)
        public Ai21CountPenalty countPenalty { get; set; }
        public Ai21PresencePenalty presencePenalty { get; set; }
        public Ai21FrequencyPenalty frequencyPenalty { get; set; }
    }

    private class Ai21CountPenalty
    {
        public int scale { get; set; }
    }

    private class Ai21PresencePenalty
    {
        public int scale { get; set; }
    }

    private class Ai21FrequencyPenalty
    {
        public int scale { get; set; }
    }

    // ----------------------------------------------


    // Get the last prompt/message from the user
    string GetPrompt(ChatHistory chat)
    {
        // TODO: this should prob be AuthorRole.User but I think with streaming implemented something got f'ed up and now it's either System or User
        var roleToSearchFor =
            chat.Messages.Any(msg => msg.Role == AuthorRole.User) ? AuthorRole.User : AuthorRole.System;
        var prompt = chat.Messages
            .Last(m => m.Role == roleToSearchFor)  
            .Content;
        if (String.IsNullOrEmpty(prompt))
        {
            throw new Exception("Prompt is empty");
        }

        return prompt;
    }

    // Get the REST API Endpoint
    string GetEndpoint(AvailableModel model)
    {
        var bedrockModel = model.ModelVersion; //e.g. "amazon.titan-tg1-large";
        if (String.IsNullOrEmpty(bedrockModel))
            throw new Exception("bedrockModel is empty");

        var endpoint = $"https://bedrock.{Region}.amazonaws.com/model/{bedrockModel}/invoke";
        return endpoint;
    }

    // Get the response from the REST API
    // This will be a JSON-formatted string
    async Task<string> GetResponseString(string payload, string endpoint, string? modelId)
    {
        // Prepare Unsigned Request
        var content = new StringContent(payload);
        content.Headers.Remove("Content-Type");
        content.Headers.Add("Content-Type", "application/json");

        if (!String.IsNullOrEmpty(modelId))
            content.Headers.Add("modelId", modelId);

        var request = new HttpRequestMessage
        {
            Method = HttpMethod.Post,
            RequestUri = new Uri(endpoint),
            Content = content
        };
        request.Headers.Add("x-amzn-bedrock-save", "true");
        // request.Headers.Add("X-Amz-Security-Token", _sessionToken); // optional: FOR MFA

        // Make Signed Request
        var client = new HttpClient();
        request = await Signer.Sign(request, "bedrock", Region);
        var response = await client.SendAsync(request);
        var json = await response.Content.ReadAsStringAsync();
        var responseString = json;

        return responseString;
    }

    // Amazon Titan Bedrock API Call
    ChatResponse GetTitanChatResponse(string prompt,
        AvailableModel model)
    {
        var endpoint = GetEndpoint(model);

            var titanTextGenerationConfig = new TitanTextGenerationConfig
            {
                maxTokenCount = 512,
                temperature = 0,
                stopSequences = new List<string>(),
                topP = 0.9f
            };

            var titanApiRequest = new TitanApiRequest()
            {
                inputText = prompt,
                textGenerationConfig = titanTextGenerationConfig
            };

            var payload = JsonSerializer.Serialize<TitanApiRequest>(titanApiRequest);

            var modelId = model.ModelVersion;
            var json = GetResponseString(payload, endpoint, modelId).Result;

            try
            {
                var outputText = "";
                var tokenCount = 0;
                var options = new JsonDocumentOptions { AllowTrailingCommas = true };
                using JsonDocument doc = JsonDocument.Parse(json, options);
                var inputTokenCount = doc.RootElement.GetProperty("inputTextTokenCount").GetInt32();
                JsonElement results = doc.RootElement.GetProperty("results");
                foreach (JsonElement result in results.EnumerateArray())
                {
                    tokenCount = result.GetProperty("tokenCount").GetInt32();
                    outputText = result.GetProperty("outputText").GetString() ?? "";
                }

                return new ChatResponse
                {
                    Message = outputText,
                    InputTokens = inputTokenCount,
                    OutputTokens = tokenCount
                };

            }
            catch (Exception e)
            {
                var message = $"Error parsing response from Amazon Bedrock AI: {e.Message}";
                Console.WriteLine(message);
                throw new Exception(message);
            }
    }

    ChatResponse GetClaudeChatResponse(string prompt,
        AvailableModel model)
    {
        var endpoint = GetEndpoint(model);

        var claudeApiRequest = new ClaudeApiRequest()
        {
            prompt = prompt,
            max_tokens_to_sample = 512,
            temperature = 0,
            top_k = 1,
            top_p = 0.9f,
            stop_sequences = new List<string>()
        };

        var payload = JsonSerializer.Serialize<ClaudeApiRequest>(claudeApiRequest);

        var modelId = model.ModelVersion; // e.g. "ai21.j2-ultra"
        var json = GetResponseString(payload, endpoint, modelId).Result;

        try
        {
            var options = new JsonDocumentOptions { AllowTrailingCommas = true };
            using JsonDocument doc = JsonDocument.Parse(json, options);
            var outputText = doc.RootElement.GetProperty("completion").GetString();

            // TODO: waiting for feedback from Amazon on if/how we can get the exact token count
            // For now, just count words.
            var words = prompt.Split(new[] { ' ', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            var estimatedInputTokenCount = words.Length;
            var words2 = outputText.Split(new[] { ' ', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            var estimatedOutputTokenCount = words2.Length;

            return new ChatResponse
            {
                Message = outputText,
                InputTokens = estimatedInputTokenCount,
                OutputTokens = estimatedOutputTokenCount
            };
        }
        catch (Exception e)
        {
            string message = $"Error parsing response from Amazon Bedrock AI: {e.Message}";
            Console.WriteLine(message);
            throw new Exception(message);
        }
    }

    ChatResponse GetAi21ChatResponse(string prompt,
        AvailableModel model)
    {
            var endpoint = GetEndpoint(model);

            var countPenalty = new Ai21CountPenalty()
            {
                scale = 0
            };

            var frequencyPenalty = new Ai21FrequencyPenalty()
            {
                scale = 0
            };

            var presencePenalty = new Ai21PresencePenalty()
            {
                scale = 0
            };

            var ai21ApiRequest = new Ai21ApiRequest()
            {
                prompt = prompt,
                maxTokens = 200,
                temperature = 0,
                topP = 0.9f,
                stopSequences = new List<string>(),
                countPenalty = countPenalty,
                frequencyPenalty = frequencyPenalty,
                presencePenalty = presencePenalty
            };

            var payload = JsonSerializer.Serialize(ai21ApiRequest);

            var modelId = model.ModelVersion;
            var json = GetResponseString(payload, endpoint, modelId).Result;

            try
            {
                var options = new JsonDocumentOptions { AllowTrailingCommas = true };
                using JsonDocument doc = JsonDocument.Parse(json, options);

                var inputTokenCount = doc.RootElement.GetProperty("prompt").GetProperty("tokens").GetArrayLength();
                var data = doc.RootElement.GetProperty("completions")[0].GetProperty("data");
                var outputText = data.GetProperty("text").GetString() ?? "";
                var outputTokenCount = data.GetProperty("tokens").GetArrayLength();

                return new ChatResponse
                {
                    Message = outputText,
                    InputTokens = inputTokenCount,
                    OutputTokens = outputTokenCount
                };
            }
            catch (Exception e)
            {
                var message = $"Error parsing response from Amazon Bedrock AI: {e.Message}";
                Console.WriteLine(message);
                throw new Exception(message);
            }

    }

}