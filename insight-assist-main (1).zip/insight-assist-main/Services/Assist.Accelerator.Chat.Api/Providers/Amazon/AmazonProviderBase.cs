using Aws4RequestSigner;
using Insight.Assist.Api.Models;
using Newtonsoft.Json;

namespace Assist.Accelerator.Chat.Api.Providers.Amazon;

public class AmazonProviderBase
{
    protected AmazonProviderBase(AvailableModel model, IConfiguration configuration)
    {
        AccessKey = configuration["accessKey"]!;
        SecretKey = configuration["secretKey"]!;
        Region = configuration["region"]!;
        Signer = new AWS4RequestSigner(AccessKey, SecretKey);
        Model = model;
    }

    public AvailableModel Model { get; set; }

    public AWS4RequestSigner Signer { get; set; }

    public string Region { get; set; }

    public string SecretKey { get; set; }

    public string AccessKey { get; set; }
}