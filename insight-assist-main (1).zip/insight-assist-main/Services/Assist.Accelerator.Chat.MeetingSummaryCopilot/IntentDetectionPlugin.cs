﻿using Assist.Accelerator.Chat.CopilotSupport.DataAccess;
using Assist.Accelerator.Chat.MeetingSummaryCopilot.LocalModels;
using Azure.AI.OpenAI;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Orchestration;
using Microsoft.SemanticKernel.SkillDefinition;
using System.ComponentModel;
using System.Text;
using System.Text.Json;

namespace Assist.Accelerator.Chat.MeetingSummaryCopilot
{
    /// <summary>
    /// Provides the ability to select a plugin based off a user's prompt.
    /// </summary>
    public class IntentDetectionPlugin
    {
        private readonly ISKFunction _getIntentFunction;

        private readonly IKernel _kernel;
        private readonly IChatStateAccess? _chatStateAccess;
        // A dictionary of PluginName and PluginDescription
        private IDictionary<string, IDictionary<string, ISKFunction>> _pluginDictionary;
        private ISKFunction _defaultFunction;

        public IntentDetectionPlugin(IKernel kernel, IChatStateAccess? stateAccess)
        {
            _chatStateAccess = stateAccess;
            _pluginDictionary = new Dictionary<string, IDictionary<string, ISKFunction>>();
            _kernel = kernel;

            _getIntentFunction = kernel.CreateSemanticFunction(
                _detectIntentPromptTemplate,
                skillName: nameof(IntentDetectionPlugin),
                description: "Evaluate the intent of the user prompt and return the name of the plugin that will best satisfy the request.",
                maxTokens: _maxTokensInReply,
                temperature: 0.1,
                topP: 0.9
                );

        }

        public void AddPlugin(string pluginName, IDictionary<string, ISKFunction> pluginFunctions)
        {
            if (_pluginDictionary.ContainsKey(pluginName))
            {
                // Update that plugin's functions
                _pluginDictionary[pluginName] = pluginFunctions;
            }
            else
            {
                // Add a new Entry.
                _pluginDictionary.Add(pluginName, pluginFunctions);
            }
        }

        public void SetDefaultProcessor(ISKFunction defaultFunction)
        {
            _defaultFunction = defaultFunction;
        }

        /// <summary>
        /// Uses the plugins that were added to the to build a list of plugins that might be appropriate to process the user's prompt.
        /// The functions and their descriptions are provided to the LLM, along with the user's prompt, and the LLM will select the most appropriate plugin.
        /// If no plugin is selected, the default plugin is used.
        /// The selected plugin is then executed and its result is mapped to the provided SKContext instance.
        /// </summary>
        /// <param name="userInput"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        [SKFunction, Description("Evaluate the intent of the user prompt and select the plugin that best matches that intent.")]
        public async Task<SKContext> ExecuteDerivedIntentAsync(
            [Description("The user's prompt.")] string userInput,
            SKContext context)
        {
            string pluginsList = BuildPluginsList();

            if (string.IsNullOrWhiteSpace(userInput))
            {
                userInput = context.Variables["userInput"];
            }

            SKContext localContext = await LoadChatState(context.Clone());
            localContext.Variables.Set("userInput", userInput);
            localContext.Variables.Set("USER_PROMPT", userInput);
            localContext.Variables.Set("PLUGIN_LIST", pluginsList);

            ISKFunction selectedFunction = _defaultFunction;

            SKContext result = await _getIntentFunction.InvokeAsync(localContext);
            if (result.LastException == null)
            {
                string selectedFunctionName = result.Result;
                selectedFunction = GetFunction(selectedFunctionName);

            }

            if(selectedFunction.Name == _defaultFunction.Name)
            {
                // If the default (chat) function was selected, we need to redact the chat history to make sure it fits within the prompt's context window.
                localContext = PruneChatHistory(localContext);
            }

            SKContext processed = await selectedFunction.InvokeAsync(localContext);

            if (processed.LastException == null)
            {
                string processedResult = processed.Result;
                string processedLlmOutput = processed.Variables["llmOutput"];

                string finalResult = string.IsNullOrWhiteSpace(processedResult) ? processedLlmOutput : processedResult;
                if(processed.Variables.TryGetValue("meetingData", out string meetingData))
                {
                    context.Variables.Set("meetingData", meetingData);
                }
                context.Variables.Set("llmOutput", finalResult);
                context.Variables.Update(finalResult);
            }

            await SaveChatState(context);
            return context;
        }

        private async Task<SKContext> LoadChatState(SKContext context)
        {
            string chatId = context.Variables["chatId"];
            string stateJson = await _chatStateAccess?.GetCopilotChatStateAsync(chatId) ?? string.Empty;
            if(string.IsNullOrWhiteSpace(stateJson) == false)
            {
                MeetingChatState chatState = new MeetingChatState(context);
                chatState.RehydrateState(stateJson);

                context = chatState.Context;
            }
            
            return context;
        }

        private async Task SaveChatState(SKContext context)
        {
            MeetingChatState chatState = new MeetingChatState(context);
            string stateJson = chatState.GetState();
            string chatId = context.Variables["chatId"];

            await _chatStateAccess?.SaveCopilotChatAsync(chatId, stateJson);
        }

        private SKContext PruneChatHistory(SKContext context)
        {
            // pull the chat history from teh context variable called "chatJson" and deserialize it into a collection of objects.
            string chatJson = context.Variables["chatJson"];
            var chat = JsonSerializer.Deserialize<ChatModel>(chatJson);
            int maxHistoryLength = 2048 * 4;
            string chatHistory = string.Empty;

            ChatMessage[] messages = chat?.Messages.ToArray()??Array.Empty<ChatMessage>();

            for(int msgIndex = messages.Length - 1; msgIndex > 0; msgIndex--)
            {
                ChatMessage m = messages[msgIndex];
                string msgToAdd = $"{m.Role.ToString()?.ToUpper()??"ASSISTANT" }:  {m.Content}";
                if(chatHistory.Length + msgToAdd.Length < maxHistoryLength)
                {
                    chatHistory = msgToAdd + "\n" + chatHistory;
                }
                else
                {
                    break;
                }
            }

            context.Variables.Set("chatHistory", chatHistory);

            return context;
        }

        private ISKFunction? GetFunction(string functionName)
        {
            functionName = functionName.Replace("'", "");
            string plugin = functionName.Split('.')[0];
            string function = functionName.Split('.')[1];

            ISKFunction? result = null;

            if (_pluginDictionary.ContainsKey(plugin))
            {
                if (_pluginDictionary[plugin].ContainsKey(function))
                {
                    result = _pluginDictionary[plugin][function];
                }
            }

            return result ?? _defaultFunction;
        }

        private string BuildPluginsList()
        {

            StringBuilder stringBuilder = new StringBuilder();

            string defaultEntry = $"'{_defaultFunction.SkillName}.{_defaultFunction.Name}' || 'Use this plugin if none of the more specialized descriptions will work.'";
            stringBuilder.AppendLine(defaultEntry);
            foreach (string key in _pluginDictionary.Keys)
            {
                foreach (var item in _pluginDictionary[key])
                {
                    string functionName = $"{key}.{item.Key}";
                    string functionDescription = item.Value.Description;
                    string listItem = $"'{functionName}' || '{functionDescription}'";
                    stringBuilder.AppendLine(listItem);
                }
            }


            return stringBuilder.ToString();
        }

        #region Plugin Constants
        private const int _maxTokensInReply = 1024;

        private const string _detectIntentPromptTemplate =
@"Analyze the user's prompt against the provided list of Plugins and choose the most appropriate plugin to fulfil the user's intent.
If none of the plugins are appropriate, return the name of the ChatCompletion plugin.

Never Return the ChatCompletion plugin when the User prompt is empty.
If the user prompt seems conversational or references other messages in the chat, return the ChatCompletion plugin.

Each plugin that is available will be described in the following format:

PluginName || PluginDescription

YOU SHOULD RESPOND ONLY WITH THE EXACT NAME OF THE SELECTED PLUGIN AND NO OTHER TEXT.

User Prompt:  Reference the items in our conversation and tell me about the meeting
Example Good Response:  _GLOBAL_FUNCTIONS_.GetChatCompletion
Example Bad Response: The most appropriate plugin to use, given the input is _GLOBAL_FUNCTIONS_.GetChatCompletion

User Prompt: [empty string]
Example Good Response: TranscriptSummarizer.SummarizeTranscript
Example Bad Response: _GLOBAL_FUNCTIONS_.GetChatCompletion

Plugin List:
----------------
{{$PLUGIN_LIST}}
----------------

User Prompt:
----------------
{{$USER_PROMPT}}
----------------
";
        #endregion
    }

}
