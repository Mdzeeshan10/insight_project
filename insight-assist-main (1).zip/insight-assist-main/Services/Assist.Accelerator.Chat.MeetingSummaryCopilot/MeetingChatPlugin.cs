﻿using Assist.Accelerator.Chat.MeetingSummaryCopilot.LocalModels;
using Assist.Accelerator.Core.Events;
using Azure.AI.OpenAI;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.AI.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.AI.OpenAI.Tokenizers;
using Microsoft.SemanticKernel.Orchestration;
using Microsoft.SemanticKernel.SemanticFunctions;
using Microsoft.SemanticKernel.SkillDefinition;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.MeetingSummaryCopilot
{
    /// <summary>
    /// A version of the chat completion behavior that is customized to chatting about a summarized meeting.
    /// </summary>
    internal class MeetingChatPlugin
    {
        private readonly PromptTemplateConfig _promptConfig = new()
        {
            Completion =
            {
                MaxTokens = 2048,
                Temperature = 0.9,
                TopP = 0.0,
                PresencePenalty = 0.0,
                FrequencyPenalty = 0.0
            }
        };

        private readonly IKernel _kernel;
        private readonly IEventSink? _eventSink;
        private readonly ISKFunction _chatCompletionFunction;
        private readonly string _componentId;

        public MeetingChatPlugin(IKernel kernel, IEventSink? eventSink)
        {
            _componentId = $"{nameof(MeetingChatPlugin)}_{Guid.NewGuid()}";
            _kernel = kernel;
            _eventSink = eventSink;
            _chatCompletionFunction = kernel.CreateSemanticFunction(
                _completionPrompt,
                skillName: nameof(MeetingChatPlugin),
                description: "Chat about a meeting that has been summarized.",
                maxTokens: _promptConfig.Completion.MaxTokens,
                temperature: _promptConfig.Completion.Temperature,
                topP: _promptConfig.Completion.TopP,
                presencePenalty: _promptConfig.Completion.PresencePenalty,
                frequencyPenalty: _promptConfig.Completion.FrequencyPenalty
                );
        }

        [SKFunction, Description("Chat with the LLM about the summarized meeting content.")]
        public async Task<SKContext> ChatWithMeetingAsync(
            [Description("The unique identifier of this chat")]string chatId,
            [Description("The user's input")]string userInput,
            SKContext context)
        {
            EventMetadata llmCallMetadata = CreateMetadata(context);
            LlmCallCompletedEvent llmCallData = new LlmCallCompletedEvent(llmCallMetadata);
            llmCallData.MethodName = nameof(ChatWithMeetingAsync);
            if(context.Variables.TryGetValue("modelId", out string modelIdString))
            {
                llmCallData.ModelId = int.TryParse(modelIdString, out int modelId)?modelId:0;
            }
            llmCallData.IsSystemAction = false;
            llmCallData.MaxTokens = _promptConfig.Completion.MaxTokens;
            llmCallData.Temperature = _promptConfig.Completion.Temperature;
            llmCallData.TopP = _promptConfig.Completion.TopP;
            llmCallData.PresencePenalty = _promptConfig.Completion.PresencePenalty;
            llmCallData.FrequencyPenalty = _promptConfig.Completion.FrequencyPenalty;


            SKContext localContext = PruneChatHistory(context.Clone());

            localContext.Variables.Set("prompt", userInput);
            localContext.Variables.TryGetValue("userEmail", out string userEmail);
            localContext.Variables.TryGetValue("meetingData", out string meetingData);
            localContext.Variables.TryGetValue("chatHistory", out string prunedChatHistory);

            string chatPrompt = _completionPrompt
                .Replace("{{$prompt}}", userInput)
                .Replace("{{$chatHistory}}", prunedChatHistory)
                .Replace("{{$meetingData}}", meetingData);

            OnProcessStarted(localContext);
            OnProgressChanged(localContext, ProgressEventKind.Status,"Generating Response");

            // Try to set up Streamed chat response.
            IChatCompletion completionBot = _kernel.GetService<IChatCompletion>();
            ChatRequestSettings requestSettings = CreateChatRequestSettings();
            ChatHistory history = completionBot.CreateNewChat(chatPrompt);
            
            llmCallData.PromptTokenCount = GPT3Tokenizer.Encode(chatPrompt).Count;
            llmCallData.RequestTime = DateTime.UtcNow;
            IAsyncEnumerable<string> responseStream = completionBot.GenerateMessageStreamAsync(history, requestSettings);
            
            string fullResponse = string.Empty;

            bool haveSetProgressToReceiving = false;
            await foreach (string contentPiece in responseStream)
            {
                if (haveSetProgressToReceiving == false)
                {
                    OnProgressChanged(localContext, ProgressEventKind.Status, "Receiving Response");
                    haveSetProgressToReceiving = true;
                }

                fullResponse += contentPiece;
                OnProgressChanged(localContext, ProgressEventKind.Incremental, fullResponse);
            }

            llmCallData.ResponseRole = "assistant";
            llmCallData.ResponseContent = fullResponse;
            llmCallData.ResponseTime = DateTime.UtcNow;
            llmCallData.CompletionTokenCount = GPT3Tokenizer.Encode(fullResponse).Count;
            
            TokenUsage usage = new TokenUsage(llmCallData.PromptTokenCount, llmCallData.CompletionTokenCount);

            OnProcessCompleted(localContext, usage, fullResponse);
            OnApiCallCompleted(llmCallData);

            //string chatResponse = chatResult.Result;
            context.Variables.Update(fullResponse);
            context.Variables.Set("llmOutput", fullResponse);

            return context;
        }

        private TokenUsage EstimateTokenUsage(string prompt, string response)
        {
            var promptTokens = GPT3Tokenizer.Encode(prompt).Count;
            var completionTokens = GPT3Tokenizer.Encode(response).Count;
            TokenUsage usage = new TokenUsage(promptTokens, completionTokens);

            return usage;
        }

        private ChatRequestSettings CreateChatRequestSettings()
        {
            return new ChatRequestSettings
            {
                MaxTokens = _promptConfig.Completion.MaxTokens,
                Temperature = (float)_promptConfig.Completion.Temperature,
                PresencePenalty = (float)_promptConfig.Completion.PresencePenalty,
                FrequencyPenalty = (float)_promptConfig.Completion.FrequencyPenalty,
            };
        }

        private SKContext PruneChatHistory(SKContext context)
        {
            // pull the chat history from teh context variable called "chatJson" and deserialize it into a collection of objects.
            string chatJson = context.Variables["chatJson"];
            var chat = JsonSerializer.Deserialize<ChatModel>(chatJson);
            int maxHistoryLength = 2048 * 4;
            string chatHistory = string.Empty;

            ChatMessage[] messages = chat?.Messages.ToArray() ?? Array.Empty<ChatMessage>();

            for (int msgIndex = messages.Length - 1; msgIndex > 0; msgIndex--)
            {
                ChatMessage m = messages[msgIndex];
                string msgToAdd = $"{m.Role.ToString()?.ToUpper() ?? "ASSISTANT"}:  {m.Content}";
                if (chatHistory.Length + msgToAdd.Length < maxHistoryLength)
                {
                    chatHistory = msgToAdd + "\n" + chatHistory;
                }
                else
                {
                    break;
                }
            }

            context.Variables.Set("chatHistory", chatHistory);

            return context;
        }

        #region Event Publication Methods

        private EventMetadata CreateMetadata(SKContext context)
        {
            context.Variables.TryGetValue("chatId", out string? chatId);
            context.Variables.TryGetValue("userEmail", out string? userEmail);
            context.Variables.TryGetValue("userId", out string? userIdString);
            int.TryParse(userIdString, out int userId);

            EventMetadata metadata = new EventMetadata(chatId, userId, userEmail, nameof(TranscriptSummarizerCopilot));
            return metadata;

        }

        private void OnApiCallCompleted(LlmCallCompletedEvent eventData)
        {
            ApplicationSignal apiCallSignal = new ApplicationSignal(_componentId, eventData);
            _eventSink?.PublishSignal(apiCallSignal);
        }

        private void OnProcessStarted(SKContext context)
        {
            EventMetadata metadata = CreateMetadata(context);

            OperationStartingEvent eventArgs = new OperationStartingEvent(metadata,
                nameof(TranscriptSummarizerCopilot),
                nameof(ChatWithMeetingAsync),
                "Chat with the LLM about the summarized meeting content.");

            ApplicationSignal signal = new ApplicationSignal(_componentId, eventArgs);
            _eventSink?.PublishSignal(signal);

        }

        private void OnProgressChanged(SKContext context, ProgressEventKind progressKind,string? progressText)
        {
            EventMetadata metadata = CreateMetadata(context);

            OperationProgressedEvent eventArgs = new OperationProgressedEvent(metadata,
                null,
                progressKind,
                progressText ?? "Still working");

            ApplicationSignal signal = new ApplicationSignal(_componentId, eventArgs);
            _eventSink?.PublishSignal(signal);

        }

        private void OnProcessCompleted(SKContext context, TokenUsage usage, string? result)
        {
            EventMetadata metadata = CreateMetadata(context);

            OperationCompletedEvent eventArgs = new OperationCompletedEvent(metadata,
               result ?? context.Result,
               usage);

            ApplicationSignal signal = new ApplicationSignal(_componentId, eventArgs);
            _eventSink?.PublishSignal(signal);

        }

        private void OnProcessFailed(SKContext context, string? errorMessage)
        {
            EventMetadata metadata = CreateMetadata(context);

            OperationFailedEvent eventArgs = new OperationFailedEvent(metadata,
                errorMessage ?? context.LastErrorDescription,
                new TokenUsage(0, 0));

            ApplicationSignal signal = new ApplicationSignal(_componentId, eventArgs);
            _eventSink?.PublishSignal(signal);

        }

        #endregion


        private const string _completionPrompt = @"
You are a friendly and helpful assistant. 
Respond to the user's inquiry with a useful answer.
Use information from the chat history and meeting information where appropriate.
If there is nothing in the chat history or meeting information, respond normally.

HISTORY
+++++
{{$chatHistory}}
+++++

MEETING INFORMATION
+++++
{{$meetingData}}
+++++

USER: {{$prompt}}
ASSISTANT: 
";
    }
}
