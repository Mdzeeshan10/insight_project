﻿using Microsoft.SemanticKernel.Orchestration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.MeetingSummaryCopilot
{
    internal class MeetingChatState 
    {
        private readonly SKContext _context;

        public MeetingChatState(SKContext context)
        {
            _context = context.Clone();
        }

        public SKContext Context => _context;

        public string Prompt
        {
            get => _context.Variables["prompt"];
            set => _context.Variables.Set("prompt", value);
        }

        public string MeetingData
        {
            get => _context.Variables["meetingData"];
            set => _context.Variables.Set("meetingData", value);
        }

        public string GetState()
        {
            string state = JsonSerializer.Serialize(_context.Variables);
            return state;
        }

        public void RehydrateState(string stateJson)
        {
            var variables = JsonSerializer.Deserialize<Dictionary<string, string>>(stateJson);
            foreach (var entry in variables)
            {
                if(_context.Variables.ContainsKey(entry.Key))
                {
                    _context.Variables[entry.Key] = entry.Value;
                }
                else
                {
                    _context.Variables.Set(entry.Key, entry.Value);
                }
            }
        }
    }
}
