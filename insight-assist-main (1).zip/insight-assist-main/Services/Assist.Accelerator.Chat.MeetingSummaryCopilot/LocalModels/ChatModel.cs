﻿using Azure.AI.OpenAI;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Chat.MeetingSummaryCopilot.LocalModels
{
    internal class ChatModel
    {
        [Key]
        public Guid Id { get; set; }
        public IEnumerable<ChatMessage> Messages { get; set; }
        public IEnumerable<ChatMessage> SQLChat { get; set; }
        public string Title { get; set; }
        public int UserId { get; set; }
        public int TokenCount { get; set; }
        public int? CopilotId { get; set; }
        public int IndexId { get; set; }
        public DateTime? CreatedAt { get; set; }

        
    }
}
