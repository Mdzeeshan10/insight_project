﻿using Microsoft.SemanticKernel.Orchestration;
using Microsoft.SemanticKernel.SkillDefinition;
using Microsoft.SemanticKernel.Text;
using Microsoft.SemanticKernel;
using System.ComponentModel;
using System.Diagnostics;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Assist.Accelerator.Chat.CopilotSupport;
using Assist.Accelerator.Chat.CopilotSupport.DataAccess;
using Microsoft.Extensions.Configuration;
using Assist.Accelerator.Core.Events;

namespace Assist.Accelerator.Chat.MeetingSummaryCopilot
{
    /// <summary>
    /// Provides methods by which a meeting transcript can be summarized.
    /// </summary>
    public class TranscriptSummarizerCopilot : ICopilot
    {
        public const string SystemName = "Meeting Summarizer";
        private const string defaultDisplayName = "Meeting Summarizer";
        private const string defaultDescription = "Provides methods by which a meeting transcript can be summarized.";
        private const string defaultIntroMessage = "I can summarize a meeting transcript for you.";
        // This is the default pipeline that will be used until the database entry is updated.
        private const string defaultPipeline = "/{'ContextVariables':{},'Plugins':['ChatHistoryPlugin.GetChatHistory','FilePlugin.GetFileContents','IntentDetection.ExecuteDerivedIntent','ChatPlugin.GetChatTitle','ChatHistoryPlugin.UpdateChatHistory']}";
        private const string defaultEndpoint = "";
        private const string defaultCredentialData = "";
        private const int defaultAuthProviderId = 0;
        private const string supportedFileTypes = ".docx,.txt,.vtt";
        
        // Have to do it this way because the CopilotSettings doesn't contain the "Name" property.
        public string Name => SystemName;

        // These private constants help us make sure we don't fall afoul of any rate limiting or LLM constraints.
        // These can vary, depending on which Model is being used, as well as other constraints imposed by the Provider.
        // We may wish to make these configurable in the future, storing these limits in the AvailableModels table so that
        // They can be provided to other CoPilots that might need to use them.
        private const int MaxTokensPerRequest = 4096;
        private const int CharactersPerToken = 3;
        private const int TokenRateLimitPerMinute = 120000;
        private const int MaxConcurrentRequests = 5;

        private readonly IKernel _kernel;

        // These next two are "private" functions used by this coPilot specifically.
        // We're holding them privately so that they can't be used in other Pipelines.
        private ISKFunction _summarizeToJsonFunction;
        private ISKFunction _condenseSummaryFunction;

        private IDictionary<string, ISKFunction> _publishedFunctions;
        private IntentDetectionPlugin _intentDetector;
        private IDictionary<string, ISKFunction> _intentFunctions;

        private IChatStateAccess? _stateStorage;
        private IEventSink? _eventSink;
        private readonly string _componentId;
        private TokenUsage _workloadAggregator;

        public TranscriptSummarizerCopilot(IKernel kernel, IConfiguration? configuration = null, IEventSink? eventSink = null)
        {
            _workloadAggregator = new TokenUsage();
            _componentId = $"{nameof(TranscriptSummarizerCopilot)}_{Guid.NewGuid()}";
            _kernel = kernel;
            _eventSink = eventSink;

            if (configuration != null && configuration.GetConnectionString("ControlDb") != null)
            {
                string? cnString = configuration.GetConnectionString("ControlDb");
                if(string.IsNullOrWhiteSpace(cnString) == false)
                {
                    _stateStorage = new ChatStateAccess(configuration.GetConnectionString("ControlDb"));
                }
                else
                {
                    _stateStorage = null;
                }
                
            }

            var meetingChatPlugin = new MeetingChatPlugin(kernel, eventSink);
            kernel.ImportSkill(meetingChatPlugin, nameof(MeetingChatPlugin));

            _intentDetector = new IntentDetectionPlugin(kernel, _stateStorage);
            var meetingChatFunction = kernel.Skills.GetFunction(nameof(MeetingChatPlugin), "ChatWithMeeting");
            _intentDetector.SetDefaultProcessor(meetingChatFunction);

            CreatePrivateFunctions();

            _publishedFunctions = _kernel.ImportSkill(this, nameof(TranscriptSummarizerCopilot));
            _intentFunctions = _kernel.ImportSkill(_intentDetector, nameof(IntentDetectionPlugin));
            _intentDetector.AddPlugin(nameof(TranscriptSummarizerCopilot), _publishedFunctions);
        }

        /// <summary>
        /// Imports the plugin functions that are specific to the operation of this plugin that should not be used in a more general use-case.
        /// </summary>
        /// <param name="globalPlugins"></param>
        /// <returns></returns>
        public Dictionary<string, IDictionary<string, ISKFunction>> AddCopilotSpecificPlugins(Dictionary<string, IDictionary<string, ISKFunction>> globalPlugins)
        {
            globalPlugins.Add("TranscriptSummarizer", _publishedFunctions);
            globalPlugins.Add("IntentDetection", _intentFunctions);
            return globalPlugins;
        }

        private const string CopilotDescription = "Accepts the text of a meeting transcript and returns a summary of the meeting.";

        [SKFunction, Description(CopilotDescription)]
        public async Task<SKContext> SummarizeTranscriptAsync(
            [Description("The text content of the meeting transcription to be summarized")] string fileText
            , SKContext context)
        {
            OnProcessStarted(context);

            // If we've gotten to this method, and there is no file attached to the chat, we need to bail.
            if (string.IsNullOrWhiteSpace(fileText))
            {
                context.Variables.Set("llmOutput", "Please attach a meeting transcript to this chat and try your request again.");
                return context;
            }

            try
            {
                OnProgressChanged(context, "Normalizing Transcript Text.");
                fileText = PreprocessTranscript(fileText);

                OnProgressChanged(context, "Analyzing Transcript.");
                // Run the first private semantic function.
                // We'll update our aggregator inside the SummarizeMeetingToJsonAsync method.
                // Reason:  It's making multiple (perhaps many) calls to the LLM,
                // and the ModelResults on the context gets overwritten on each call.
                context = await SummarizeMeetingToJsonAsync(fileText, context);
                if (context.ErrorOccurred && context.LastException != null)
                {
                    throw context.LastException;
                }
                


                string chunkedJson = context.Result;
                string consolidatedSummary = ConsolidateJsonResults(chunkedJson);

                context.Variables.Set("meetingData", consolidatedSummary);
                // No need to roll up usage here. Consolidate doesn't call the LLM, so our usage hasn't changed.

                OnProgressChanged(context, "Formatting the summary");
                context = await CondenseSummaryAsync(consolidatedSummary, context);
                if (context.ErrorOccurred && context.LastException != null)
                {
                    throw context.LastException;
                }
                TokenUsage condenserCost = ExtractUsageFromContext(context);
                _workloadAggregator = _workloadAggregator.AddUsage(condenserCost);

                // We must assign the output of our coPilot to the "llmOutput" variable in order to use it later in the pipeline.
                string condensedSummary = context.Result;
                context.Variables.Set("llmOutput", condensedSummary);
                OnProcessCompleted(context, _workloadAggregator, condensedSummary);
            }
            catch (Exception e)
            {
                // We'll pass null as the errorMessage here, and let the Method extract the lastExceptionDescription for output.
                OnProcessFailed(context, _workloadAggregator, null);
                context.Variables.Set("llmOutput", "I'm sorry, I ran into some trouble when processing that transcript.");
                throw;
            }
             return context;
        }

        private string PreprocessTranscript(string transcript)
        {
            // Not crazy about having to do this, but .vtt and .txt files have different formats than .docx files.
            // This means we need to do different things to enforce consistency of pre-propcessed text.
            // we want:
            // hh:mm:ss
            // Speaker's Name (as First Last): Text of what they said.
            bool isVtt = transcript.StartsWith("WEBVTT") || transcript.Contains("</v>");

            // Normalize the line endings.
            transcript = transcript.Replace("\\r", Environment.NewLine);

            // Now run some pre-processing on those fileContents to get rid of some muck.
            transcript = Regex.Replace(transcript, "WEBVTT", "");

            // normalize our timecodes to a consistent format.  This ensures every timecode has a 2-digit hour, 2-digit minute, 2-digit second, and 3-digit millisecond value.
            transcript = Regex.Replace(transcript, @"\s([0-1]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9]\.\d{0,3})\s", delegate (Match match)
            {
                string hour = match.Groups[1].Value.PadLeft(2, '0');
                string minute = match.Groups[2].Value.PadLeft(2, '0');
                string seconds = match.Groups[3].Value.Split('.')[0].PadLeft(2, '0');
                return $"{hour}:{minute}:{seconds}";
            });

            if (isVtt)
            {
                // Reduce the timecode ranges to a single timecode representing the beginning of a speaker's statement.
                transcript = Regex.Replace(transcript, @"(\d\d?:\d\d?:\d\d?)(\.\d{0,3})?-->(\d\d:\d\d:\d\d)(\.\d{0,3})?", Environment.NewLine + @"$1");
                //  replace a specific format of a 'v' tag in a transcript with the correct format for the parsing function. Specifically, it replaces <v name, participantID>text with "participantID name: text"
                transcript = Regex.Replace(transcript, @"<v (.*)\,\s(.*)>(.*)<\/v>", Environment.NewLine + @"$2 $1: $3");
                //replacing a different format of 'v' tag with another parsing format. The text format gets replaced with "participantID: text"
                transcript = Regex.Replace(transcript, @"<v (.*)>(.*)<\/v>", Environment.NewLine + @"$1: $2");
                // compress multiple linebreaks into a single linebreak
                transcript = Regex.Replace(transcript, @"[\r\n]+", "\n");
            }
            else
            {
                // Some transcript file formats (docx) have "0:0:0.0 --> " as the timecode for the first line and it doesn't get caught in our Regex operation.
                // This replaces that with the format we need.
                transcript = transcript.Replace("0:0:0.0 -->", "00:00:00.0-->");
                transcript = Regex.Replace(transcript, @"(\d\d?:\d\d?:\d\d?)(\.\d{0,3})?-->(\d\d:\d\d:\d\d)(\.\d{0,3})?", Environment.NewLine + @"$1");

                // Change this:
                // LastName, FirstName
                // Text of what they said.
                //
                // to this:
                // FirstName LastName: Text of what they said.
                transcript = Regex.Replace(transcript, @"(.*)\,\s(.*)\n?\r?(.*)", delegate (Match match)
                {
                    string lastName = match.Groups[1].Value.Trim();
                    string firstName = match.Groups[2].Value.Trim();
                    string text = match.Groups[3].Value.Trim();

                    string reorganized = $"{firstName} {lastName}: {text}";
                    return reorganized;
                });
            }

            return transcript;
        }


        public Task<SKContext> SummarizeMeetingToJsonAsync(
            [Description("A meeting transcript.")] string fileText,
            SKContext context)
        {
            // Get the length of the prompt template so that we can account for that in our chunk size calculation.
            int promptTemplateLength = SummarizeToJsonPrompt.Length;

            // This raw chunk size can be calculated based on how much we intend to send in, plus how much we expect to get back.
            // Using 1.2 as our divisor here, as we expect the response to be about a fifth the size of the input.
            int rawChunkSize = (int)Math.Floor((double)(MaxTokensPerRequest * CharactersPerToken));

            //Next, we'll adjust that rawChunkSize to account for the length of the prompt template.
            int maxChunkSizeBytes = (int)Math.Floor((rawChunkSize - promptTemplateLength) * 0.5);
            // There are usually approximately 4 characters / token, so we'll divide by 4 to get the max number of tokens per chunk.
            int maxChunkSizeTokens = (int)(maxChunkSizeBytes / CharactersPerToken);

            // Use the SemanticKernel text chunker for now.  Might want to explore something more robust later.
            List<string> lines = TextChunker.SplitPlainTextLines(fileText, maxChunkSizeTokens);
            List<string> paragraphs = TextChunker.SplitPlainTextParagraphs(lines, maxChunkSizeTokens);

            // Calculate optimal batch size based on the number of average number of tokens in / chunk + the prompt size and the rate limit.
            // Pad the chunk size by 1.5 to account for tokens consumed in the response.  (Expect sumarization response to be half the size of the input)
            var averageChunkSize = paragraphs.Average(p => (p.Length + promptTemplateLength) / CharactersPerToken);
            var estimatedTokensPerChunk = (int)(averageChunkSize * 1.5);
            var optimalBatchSize = (int)(TokenRateLimitPerMinute / estimatedTokensPerChunk);

            // Microsoft recommends no more than 10 requests / second, so we'll hard-cap our batch size to that.
            if (optimalBatchSize > MaxConcurrentRequests) optimalBatchSize = MaxConcurrentRequests;

            // To that we don't overwhelm the API and violate our RateLimits, we'll break the paragraphs list into batches, running each batch
            // one at a time, processing of the chunks in each batch in parallel.
            var batches = paragraphs.Select((p, i) => new { Paragraph = p, Index = i })
                     .GroupBy(x => x.Index / optimalBatchSize)
                     .Select(g => g.Select(x => x.Paragraph).ToList())
                     .ToList();



            // Factored the looping and the API calling and the stuff into a separate function for readability.
            Task<SKContext> task = ProcessBatchedInput(context, promptTemplateLength, batches);

            return task;
        }

        private string[] batchProgressPhrases = new string[] { 
            "Reading your transcript", 
            "Digesting the information", 
            "Reading each line carefully", 
            "Oof!  This is a long meeting!", 
            "He said WHAT?!? Just kidding ;)", 
            "Almost done..." };
       

        /// <summary>
        /// Private method, loops the batches and the batched paragraphs, calling the API and processing the results.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="promptTemplateLength"></param>
        /// <param name="batches"></param>
        /// <returns></returns>
        private async Task<SKContext> ProcessBatchedInput(SKContext context, int promptTemplateLength, List<List<string>> batches)
        {
            EventMetadata stepMetadata = CreateMetadata(context);

            // Use this to accumulate the results of the API calls.
            List<string> processedChunks = new List<string>();

            // Calculate the number of tokens we can spend per second.  Used to calculate the delay between batches.
            int budgettedTokensPerSecond = (int)(TokenRateLimitPerMinute / 60);

            Stopwatch callTimer = new Stopwatch();
            callTimer.Start();

            object? lockObj = null;

            foreach (var batch in batches)
            {
                int batchNumber = batches.IndexOf(batch);
                if (batchNumber > 5) batchNumber = batchNumber % 5;
                OnProgressChanged(context, batchProgressPhrases[batchNumber]);
                // Calculate the approximate number of tokens we will SEND in this batch.
                int totalBatchRequestTokens = (int)(batch.Sum(b => b.Length + promptTemplateLength) / 4);

                var batchTimer = new Stopwatch();
                batchTimer.Start();
                var tasks = batch.Select(async (chunk) =>
                {
                    LlmCallCompletedEvent llmCallEvent = new LlmCallCompletedEvent(stepMetadata);
                    llmCallEvent.MethodName = nameof(SummarizeMeetingToJsonAsync);
                    if (context.Variables.TryGetValue("modelId", out string modelIdString))
                    {
                        llmCallEvent.ModelId = int.TryParse(modelIdString, out int modelId) ? modelId : 0;
                    }
                    llmCallEvent.IsSystemAction = false;
                    llmCallEvent.RequestTime = DateTime.UtcNow;
                    llmCallEvent.MaxTokens = _summarizeToJsonFunction.RequestSettings.MaxTokens;
                    llmCallEvent.Temperature = _summarizeToJsonFunction.RequestSettings.Temperature;
                    llmCallEvent.TopP = _summarizeToJsonFunction.RequestSettings.TopP;
                    llmCallEvent.PresencePenalty = _summarizeToJsonFunction.RequestSettings.PresencePenalty;
                    llmCallEvent.FrequencyPenalty = _summarizeToJsonFunction.RequestSettings.FrequencyPenalty;

                    Stopwatch chunkTimer = new Stopwatch();
                    chunkTimer.Start();
                    SKContext result = await this._summarizeToJsonFunction.InvokeAsync(chunk, context);
                    string summarizedChunk = result.Variables.ToString();
                    chunkTimer.Stop();

                    llmCallEvent.ResponseTime = DateTime.UtcNow;
                    TokenUsage extractJsonUsage = ExtractUsageFromContext(result);
                    llmCallEvent.PromptTokenCount = extractJsonUsage.RequestTokens;
                    llmCallEvent.CompletionTokenCount = extractJsonUsage.TotalTokens;
                    llmCallEvent.ResponseRole = "assistant";
                    llmCallEvent.ResponseContent = summarizedChunk;

                    OnApiCallCompleted(llmCallEvent);

                    while (lockObj != null)
                    {
                        Task.Delay(50).Wait();
                    }

                    lockObj = new object();
                    _workloadAggregator = _workloadAggregator.AddUsage(extractJsonUsage);
                    lockObj = null;

                    // Calculate stats for THIS chunk.
                    int chunkTokensSent = (int)((chunk.Length + promptTemplateLength) / CharactersPerToken);
                    int chunkTokensReceived = (int)(summarizedChunk.Length / CharactersPerToken);
                    int chunkTimeMs = (int)chunkTimer.ElapsedMilliseconds;


                    return summarizedChunk;
                });
                var returnedChunks = await Task.WhenAll(tasks);
                processedChunks.AddRange(returnedChunks);
                batchTimer.Stop();

                // Calculate some stats for the current batch.  Eventually we'll emit these in a Metrics Event.
                int totalTokensReceived = (int)(returnedChunks.Sum(c => c.Length) / CharactersPerToken);
                int tokensSpent = totalBatchRequestTokens + totalTokensReceived;
                int batchSeconds = (int)(batchTimer.ElapsedMilliseconds / 1000);
                // Calculate how many tokens we spent / second.
                int actualTokensPerSecond = (int)(tokensSpent / batchSeconds);



                await DelayForRateLimit(batches, budgettedTokensPerSecond, batch, batchSeconds, actualTokensPerSecond);
            }

            callTimer.Stop();


            string rawResults = string.Join("||\n", processedChunks);
            context.Variables.Update(rawResults);

            return context;

        }

        /// <summary>
        /// Calculates the amount of time we should wait before processing the next batch of paragraphs, and then Delays for that amount of time.
        /// </summary>
        /// <param name="batches">The collection of batched paragraphs</param>
        /// <param name="budgettedTokensPerSecond">How many tokens / second we can consume before we hit the rate limit.</param>
        /// <param name="batch">The batch that just completed processing.</param>
        /// <param name="batchSeconds">The number of seconds the current batch took to process</param>
        /// <param name="actualTokensPerSecond">How many tokens / second we ACTUALLY consumed in the last batch</param>
        /// <returns></returns>
        private async Task DelayForRateLimit(List<List<string>> batches, int budgettedTokensPerSecond, List<string> batch, int batchSeconds, int actualTokensPerSecond)
        {
            // If there's more batches to process, delay for a bit to allow for quota replenishment
            // and avoid the dreaded HTTP 429 (Too many requests).
            if (batches.IndexOf(batch) < batches.Count - 1)
            {
                // Figure out the ratio of actual tokens spent vs. our quota
                double burnRateRatio = (double)actualTokensPerSecond / (double)budgettedTokensPerSecond;

                // Calculate how many seconds are left in the current minute, adjust for our burn rate ratio, and delay for that many seconds.
                // We adjust for the "burn rate ratio" to pad the amount of wait time and hopefully level out our RateLimit consumption
                // across the entire summarization process.
                // Later, we'll collect these statistics and try to tune our Chunk Sizes and Batch delays to optimize the process without
                // increasing the number of HTTP 429 errors we receive.
                int delaySeconds = (int)((60 - batchSeconds) * burnRateRatio);
                // No need to delay longer than 60 seconds for our quota's sake.
                if (delaySeconds > 60) delaySeconds = 60;

                await Task.Delay(delaySeconds * 1000);
            }
        }

        private string ConsolidateJsonResults(string chunkedJson)
        {
            var summaryItems = new List<(string speakers, string timestamp, string statement)>();
            var actionItems = new List<(string owner, string task, string timestamp)>();

            List<string> chunks = chunkedJson.Split("||\n").ToList();

            try
            {
                List<JsonObject?> jsonChunks = chunks.Where(c => c.Length > 0).Select(c => JsonObject.Parse(c)?.AsObject()).ToList();
                foreach (var jsonChunk in jsonChunks)
                {
                    if (jsonChunk == null)
                    {
                        continue;
                    }

                    if (jsonChunk.TryGetPropertyValue("SummaryItem", out var summaryItemsNode))
                    {
                        foreach (var node in summaryItemsNode?.AsArray() ?? new JsonArray())
                        {
                            var obj = node?.AsObject();
                            if (obj == null) continue;

                            (string speakers, string timestamp, string statement) item = new()
                            {
                                speakers = obj?["Speakers"]?.ToString() ?? string.Empty,
                                timestamp = obj?["Timestamp"]?.ToString() ?? "",
                                statement = obj?["Statement"]?.ToString() ?? ""
                            };

                            summaryItems.Add(item);
                        }

                    }

                    if (jsonChunk.TryGetPropertyValue("ActionItem", out var actionItemsNode))
                    {
                        foreach (var node in actionItemsNode?.AsArray() ?? new JsonArray())
                        {
                            var obj = node?.AsObject();
                            if (obj == null) continue;

                            (string owner, string task, string timestamp) item = new()
                            {
                                owner = obj?["Owner"]?.ToString() ?? string.Empty,
                                timestamp = obj?["Timestamp"]?.ToString() ?? "",
                                task = obj?["Task"]?.ToString() ?? ""
                            };
                            actionItems.Add(item);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            //de-dupe the lists, then order by timestamp.
            var orderedSummaryItems = summaryItems
                .DistinctBy(s => s.speakers + s.timestamp)
                .OrderBy(s => s.timestamp)
                .Select(s => $" - {s.statement} ({s.speakers} @ {s.timestamp})")
                .ToList();
            var orderedActionItems = actionItems
                .DistinctBy(a => a.owner + a.timestamp)
                .OrderBy(a => a.timestamp)
                .Select(a => $" - {a.owner}: {a.task} ({a.timestamp})")
                .ToList();



            string summarizedMeeting = $"Meeting Summary:\r\n{string.Join(Environment.NewLine, orderedSummaryItems)}\r\n\r\nActionItems:\r\n{string.Join(Environment.NewLine, orderedActionItems)}";
            return summarizedMeeting;
        }

        private async Task<SKContext> CondenseSummaryAsync(
            [Description("The summarized meeting transcript that needs further condensing.")] string summary,
            SKContext context)
        {
            EventMetadata callMetadata = CreateMetadata(context);
            LlmCallCompletedEvent llmCallEvent = new LlmCallCompletedEvent(callMetadata);
            llmCallEvent.MethodName = nameof(CondenseSummaryAsync);
            if (context.Variables.TryGetValue("modelId", out string modelIdString))
            {
                llmCallEvent.ModelId = int.TryParse(modelIdString, out int modelId) ? modelId : 0;
            }
            llmCallEvent.IsSystemAction = false;
            llmCallEvent.RequestTime = DateTime.UtcNow;
            llmCallEvent.MaxTokens = _condenseSummaryFunction.RequestSettings.MaxTokens;
            llmCallEvent.Temperature = _condenseSummaryFunction.RequestSettings.Temperature;
            llmCallEvent.TopP = _condenseSummaryFunction.RequestSettings.TopP;
            llmCallEvent.PresencePenalty = _condenseSummaryFunction.RequestSettings.PresencePenalty;
            llmCallEvent.FrequencyPenalty = _condenseSummaryFunction.RequestSettings.FrequencyPenalty;

            SKContext functionCtx = context.Clone();

            functionCtx = await _condenseSummaryFunction.InvokeAsync(summary, functionCtx);

            string condensedSummary = functionCtx.Result;

            TokenUsage callUsage = ExtractUsageFromContext(functionCtx);
            llmCallEvent.ResponseTime = DateTime.UtcNow;
            llmCallEvent.ResponseRole = "assistant";
            llmCallEvent.ResponseContent = condensedSummary;
            llmCallEvent.PromptTokenCount = callUsage.RequestTokens;
            llmCallEvent.CompletionTokenCount = callUsage.ResponseTokens;


            OnApiCallCompleted(llmCallEvent);

            context.Variables.Update(condensedSummary);

            return context;
        }

        #region Event Publication Methods

        private void OnProcessStarted(SKContext context)
        {
            EventMetadata metadata = CreateMetadata(context);

            OperationStartingEvent eventArgs = new OperationStartingEvent(
                metadata,
                nameof(TranscriptSummarizerCopilot), 
                nameof(SummarizeTranscriptAsync), 
                CopilotDescription
                );
            ApplicationSignal signal = new ApplicationSignal(_componentId, eventArgs);
            _eventSink?.PublishSignal(signal);

            
        }

        private void OnProgressChanged(SKContext context, string? progressMessage)
        {
            EventMetadata metadata = CreateMetadata(context);
            TokenUsage usage = ExtractUsageFromContext(context);

            OperationProgressedEvent eventArgs = new OperationProgressedEvent(
                metadata,
                usage,
                ProgressEventKind.Status,
                progressMessage??"Still working"                
                );
            ApplicationSignal signal = new ApplicationSignal(_componentId, eventArgs);
            _eventSink?.PublishSignal(signal);
            
        }

        private void OnProcessCompleted(SKContext context, TokenUsage usage, string? result)
        {
            EventMetadata metadata = CreateMetadata(context);

            OperationCompletedEvent eventArgs = new OperationCompletedEvent(
                metadata,
                result ?? context.Result,
                usage);
            ApplicationSignal signal = new ApplicationSignal(_componentId, eventArgs);
            _eventSink?.PublishSignal(signal);
        }

        private void OnProcessFailed(SKContext context, TokenUsage usage, string? errorMessage)
        {
            EventMetadata metadata = CreateMetadata(context);
            

            OperationFailedEvent eventArgs = new OperationFailedEvent(
                metadata,
                errorMessage ?? context.LastErrorDescription,
                usage);
            ApplicationSignal signal = new ApplicationSignal(_componentId, eventArgs);
            _eventSink?.PublishSignal(signal);
        }

        /// <summary>
        /// Publishes a signal that carries the data about the API Call made to the LLM.
        /// This signal should not be intercepted and used for any other purpose than logging
        /// and quota tracking.
        /// </summary>
        /// <param name="eventData"></param>
        private void OnApiCallCompleted(LlmCallCompletedEvent eventData)
        {
            ApplicationSignal apiCallSignal = new ApplicationSignal(_componentId, eventData);
            _eventSink?.PublishSignal(apiCallSignal);
        }

        private EventMetadata CreateMetadata(SKContext context)
        {
            context.Variables.TryGetValue("chatId", out string? chatId);
            context.Variables.TryGetValue("userEmail", out string? userEmail);
            context.Variables.TryGetValue("userId", out string? userIdString);
            int.TryParse(userIdString, out int userId);

            EventMetadata metadata = new EventMetadata(chatId, userId, userEmail, nameof(TranscriptSummarizerCopilot));
            return metadata;

        }

        private TokenUsage ExtractUsageFromContext(SKContext context)
        {
            TokenUsage usage = new TokenUsage(0, 0);
            var modelResults = context.ModelResults.FirstOrDefault();
            if (modelResults!=null)
            {
                int request = modelResults.GetOpenAIChatResult()?.Usage?.PromptTokens 
                    ?? modelResults.GetOpenAITextResult()?.Usage?.PromptTokens
                    ?? 0;
                int response = modelResults.GetOpenAIChatResult()?.Usage?.CompletionTokens 
                    ?? modelResults.GetOpenAITextResult()?.Usage?.CompletionTokens
                    ?? 0;
                usage = new TokenUsage(request, response);
            }

            return usage;
        }

        #endregion

        #region Private Semantic Functions and Prompt definitions

        private void CreatePrivateFunctions()
        {
            this._summarizeToJsonFunction = _kernel.CreateSemanticFunction(
                SummarizeToJsonPrompt,
                skillName: nameof(TranscriptSummarizerCopilot),
                description: "Given a meeting transcript, summarize the important points made and any action items.",
                maxTokens: (int)(MaxTokensPerRequest * 0.25),
                temperature: 0.1,
                topP: 0.5
                );


            this._condenseSummaryFunction = _kernel.CreateSemanticFunction(
                CondenseSummaryPrompt,
                skillName: nameof(TranscriptSummarizerCopilot),
                description: "Given a summarized meeting transcript, condense and refine the summary to be as concise as possible without losing meaning or context.",
                maxTokens: (int)(MaxTokensPerRequest * 0.25),
                temperature: 0.1,
                topP: 0.5
                );
        }

        /// <summary>
        /// Creates an instance of the CopilotRegistration class and passes it to the provided registrationVisitor.
        /// This is only called when a Copilot implementation is not currently registered with the CopilotSupportService.
        /// 
        /// When a copilot self registers, it should provide an initial value for its registration properties.  These property values
        /// may be updated in the database, and those updated database values should be used when the copilot is invoked.
        /// 
        /// </summary>
        /// <param name="registrationVisitor"></param>
        public static CopilotRegistration RegisterSelf(Func<CopilotRegistration, int> registrationVisitor)
        {
            string pipeline = defaultPipeline;
            // Had to escape the { at the start of the defaultPipeline constant to avoid a compiler error.
            // that escape character cannot be sent to the database, or the pipeline won't be deserializable, so let's remove it now.
            if (pipeline.StartsWith("/")) 
            { 
                pipeline = pipeline.Substring(1);
            }

            CopilotRegistration registration = new CopilotRegistration
            {
                AuthProviderId = defaultAuthProviderId,
                SystemName = SystemName,
                DisplayName = defaultDisplayName,
                Description = defaultDescription,
                IntroMessage = defaultIntroMessage,
                Endpoint = defaultEndpoint,
                CredentialData = defaultCredentialData,
                Pipeline = pipeline,
                IsActive = true,
                Implementation = typeof(TranscriptSummarizerCopilot),
                FileTypes = supportedFileTypes,
                SubTitle = defaultDisplayName             
            };

            int copilotId = registrationVisitor( registration );

            registration.Id = copilotId;

            return registration;
        }



        private const string SummarizeToJsonPrompt =
@"Please summarize the following transcript into a JSON object with the structure:
{
	""SummaryItem"": [{""Speakers"":""SpeakerNames"", ""Timestamp"":""timestamp"", ""Statement"": ""bullet text here.""}],
	""ActionItem"" : [{""Owner"", ""Task"", ""Timestamp""}]
}
Abbreviate names in both lists to just the first name unless there are is another person in the meeting with the same first name.
SummaryItems should be brief and contain just enough context to understand without reading the transcript, around 300 characters per bullet.
SpeakerNames should be a comma separated list of the speakers for that summaryItem, and the Timestamp will be when discussion about that SummaryItem started.
Ideally, our Summary should reduce the overall transcript to 10% of its original size.
ActionItems should hold a list of action items from the meeting.  Favor 'I need to...' or 'I will do...' statements when identifying these items, rather than 'I want to...' type statements.
Each ActionItem should represent a concrete task that was assigned to a person in the meeting.
Owner is the abbreviated Name of who is assigned the Task, and Timestamp is when the user was assigned the action item.

ONLY RETURN A VALID JSON OBJECT without any additional commentary or text.

Here is the text to summarize:
{{$INPUT}}
";

        private const string CondenseSummaryPrompt =
@"Condense and refine the provided summary as instructed here.  The result of your work should include 4 sections, each complying with the detailed instructions for building each section of the output.  Those sections are: Executive Summary, Meeting Summary, Action Items, and Tone of Meeting.
Use markdown syntax to make the section headings bold. The bullet points should be plain text.

###*Executive Summary:*
The Executive Summary should be a short, two or three sentence paragraph that describes the high-level topics discussed during the meeting.

For the Meeting Summary section, the format of the original should be retained. Considering all bullet points in the summary, Condense them further, targeting a 40 to 60 percent reduction in the amount of text in that section. For example, if the input includes 25 bullet points, try to reduce that count to between 10 and 15 bullets in the output.  Do not sacrifice context or important details when consolidating those bullet points.

The Summary section must retain this format:
 - [Condensed statements] - ([List of speaker first names]: [Time at beginning of statements])

The Action Items section must retain the level of detail in the input but remove redundant or unrelated tasks from the list.
Each action item should include exactly one task but may have multiple people assigned. A person may have multiple action items assigned.
The condensed action items section must retain this format:
 - [Assignees (First Name only)]: [Action item] ([Time action item was first mentioned])

###*Tone of Meeting:*
The Tone of Meeting section should be a one or two sentence statement describing the overall mood and tone of the conversation and its participants.

The summary to condense is:
{{$INPUT}}
";


        private const string CondenseSummaryPrompt_old =
@"Condense and refine the following summary.  The format should be retained, but where possible, consolidate multiple statements into a single bullet point.
The result should still contain Meeting Summary and Action Items sections, each containing a list of bullet points, but we want to be
as concise as possible, without losing meaning or context.
The condensed meeting summary bullet points must include the speaker name and earliest timestamp from the original summary.
The condensed action items must include the assignee name and earliest timestamp from the original action item.


The summary to condense is:
{{$INPUT}}
";

        #endregion
    }
}