﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    /// <summary>
    /// Implement this interface on any class or service that needs to receive and handle events coming from any of the 
    /// other system components that may publish those events.
    /// 
    /// Note that the methods must be implemented as async operations, so that the handlers can be called in a non-blocking
    /// manner.
    /// </summary>
    public interface IOperationHandler
    {
        void RegisterHandlers(IEventSink eventSink);

        Task OnOperationStarting(OperationStartingEvent eventArgs);

        Task OnOperationCompleted(OperationCompletedEvent eventArgs);

        Task OnOperationFailed(OperationFailedEvent eventArgs);

        Task OnOperationProgressed(OperationProgressedEvent eventArgs);

        Task OnSignalReceived(ApplicationSignal signal);
    }
}
