﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    /// <summary>
    /// The OperationProgressed Event can be raised during a "Streamed Completion" scenario to send incremental "parts" of a chat completion,
    /// or to send a "Status" update if we are executing a long running, multi-step process that the User may care about tracking.
    /// 
    /// See the comments on the ProgressEventKind enum for more information on the two contexts in which this event should be used.
    /// </summary>
    public class OperationProgressedEvent : EventBase
    {
        [JsonConstructor]
        public OperationProgressedEvent():base()
        {
        }

        public OperationProgressedEvent(EventMetadata metadata,
            TokenUsage? usage,
            ProgressEventKind progressKind,
            string? progressText):base(metadata)
        {
            Usage = usage;
            ProgressKind = progressKind;
            ProgressText = progressText;
        }

        //public OperationProgressedEvent(string chatId,
        //    int userId,
        //    string userEmail,
        //    string? copilotName,
        //    TokenUsage? usage,
        //    ProgressEventKind progressKind,
        //    string? progressText) : base(chatId, userId, userEmail, copilotName)
        //{
        //    Usage = usage;
        //    ProgressKind = progressKind;
        //    ProgressText = progressText;
        //}

        /// <summary>
        /// Carries the usage information for the operation being reported on.
        /// </summary>
        public TokenUsage? Usage { get; init; }

        /// <summary>
        /// Clarifies the context under which the ProgressEvent is being raised.
        /// </summary>
        public ProgressEventKind ProgressKind { get; init; }

        /// <summary>
        /// Contains the information to be sent to the UI.
        /// 
        /// On a status update, we need to send this out as the payload of the "UpdateResponseStatus" call.
        /// On an incremental update, we send this value as the payload of the "SendPartialResponse" call.
        /// </summary>
        public string? ProgressText { get; init; }
    }

    /// <summary>
    /// Progress Events can be used two "Update" contexts while a process is executing.
    /// This enum defines and constrains those contexts so that purposed handlers can more easily determine whether to perform
    /// some activity with the received event or to ignore it.
    /// </summary>
    public enum ProgressEventKind {
        /// <summary>
        /// Allows us to send progress notifications out of an executing process
        /// Use Cases for this context:
        ///   Progress Notifications to a UI
        ///   Potential use with orchestration
        ///   Opportunities to improve system Observability
        ///   
        /// Note:  When a Status Update is sent, it is usually because an atomic LLM operation has either completed or made significant progress.
        /// Any "Status" update that is sent upon Model Activity completion should include any Usage Statistics that can be harvested from that
        /// function's execution.
        /// </summary>
        Status,
        
        /// <summary>
        /// Allows us to send a partially formed response from an executing process, as it is being built.
        /// Use Cases for this context:
        ///   Forwarding streamed chat completions from the model to the UI
        ///   Observability
        ///   
        /// Note:  We may include usage on streamed responses, but we need to determine if the model's usage stats are being aggregated
        /// and "rolled up" into the final response or not.  If that happens to be the case, then we should not persist usage stats on
        /// incremental ProgressEvents.
        /// </summary>
        Incremental
    }
}
