﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    public class InProcEventSink : IEventSink
    {
        
        // Dictionary<eventTypeName, Dictionary<componentId, handler>>
        private readonly Dictionary<string, Dictionary<string, Func<ApplicationSignal, Task>>> _signalHandlers;
        

        //Having a discrete dictionary of handlers fo reach event type is stupid.
        // We need a better solution to this, but I want to prove the concept first.
        // we can make this more generic later.
        //private readonly Dictionary<string, Func<OperationStartingEvent, Task>> _opStartHandlers;
        //private readonly Dictionary<string, Func<OperationCompletedEvent, Task>> _opCompleteHandlers;
        //private readonly Dictionary<string, Func<OperationProgressedEvent, Task>> _opProgressHandlers;
        //private readonly Dictionary<string, Func<OperationFailedEvent, Task>> _opFailedHandlers;

        private object? _lockObject;

        public InProcEventSink()
        {
            
            _signalHandlers = new Dictionary<string, Dictionary<string, Func<ApplicationSignal, Task>>>();

            //_opStartHandlers = new Dictionary<string, Func<OperationStartingEvent, Task>>();
            //_opCompleteHandlers = new Dictionary<string, Func<OperationCompletedEvent, Task>>();
            //_opProgressHandlers = new Dictionary<string, Func<OperationProgressedEvent, Task>>();
            //_opFailedHandlers = new Dictionary<string, Func<OperationFailedEvent, Task>>();
        }


        public Task PublishSignal(ApplicationSignal signal)
        {
            string eventType = signal.PayloadType;
            if(_signalHandlers.ContainsKey(eventType))
            {
                Dictionary<string, Func<ApplicationSignal, Task>> handlers = _signalHandlers[eventType];
                List<Func<ApplicationSignal, Task>> handlerList = handlers.Values.ToList();
                return Task.WhenAll(handlerList.Select(h => h?.Invoke(signal)??Task.CompletedTask));
            }
            else
            {
                return Task.CompletedTask;
            }
        }

        /// <summary>
        /// Registers the delegate as the handler for the specified event type, registered to
        /// the identified component instance.
        /// </summary>
        /// <param name="componentId">THe unique name for the component instance registering its handlers.</param>
        /// <param name="eventTypes">an array of event types that the component can handle</param>
        /// <param name="signalHandler">the Method to be called when one of those event types is published</param>
        public void RegisterHandler(string componentId, string[] eventTypes, Func<ApplicationSignal, Task> signalHandler)
        {
            while(_lockObject != null)
            {
                Task.Delay(50).Wait();
            }

            _lockObject = new object();
            foreach(string evtType in eventTypes)
            {
                // We don't have any handlers for that event type yet, so we'll create an entry in the outer dictionary.
                if (_signalHandlers.ContainsKey(evtType) == false)
                {
                    _signalHandlers.Add(evtType, new Dictionary<string, Func<ApplicationSignal, Task>>());
                }

                Dictionary<string, Func<ApplicationSignal, Task>> handlers = _signalHandlers[evtType];
                if (handlers.ContainsKey(componentId) == false)
                {
                    handlers.Add(componentId, signalHandler);
                }
                else
                {
                    handlers[componentId] = signalHandler;
                }
            }
            _lockObject = null;
        }


        /// <summary>
        /// To push operational events out to all subscribers, call this method, passing the appropriate event type.
        /// </summary>
        /// <param name="pluginEvent"></param>
        /// <returns></returns>
        //public async Task PublishEvent<T>(T pluginEvent) where T : EventBase
        //{
        //    Type eventType = typeof(T);

        //    //TODO:  This is really gross and needs a far better implementation.
        //    // For POC, this sledgeHammer approach will have to do.
        //    switch (eventType.Name)
        //    {
        //        case nameof(OperationStartingEvent):
        //            OperationStartingEvent startEvt = pluginEvent as OperationStartingEvent;
        //            if (startEvt == null)
        //            {
        //                throw new ArgumentException("The provided event cannot be published.");
        //            }
        //            List<Func<OperationStartingEvent, Task>> startSubs = _opStartHandlers.Values.ToList();

        //            await Task.WhenAll(startSubs.Select(s => s?.Invoke(startEvt)));
        //            break;

        //        case nameof(OperationProgressedEvent):
        //            OperationProgressedEvent progEvt = pluginEvent as OperationProgressedEvent;
        //            if (progEvt == null)
        //            {
        //                throw new ArgumentException("The provided event cannot be published.");
        //            }
        //            List<Func<OperationProgressedEvent, Task>> progSubs = _opProgressHandlers.Values.ToList();

        //            await Task.WhenAll(progSubs.Select(s => s?.Invoke(progEvt)));
        //            break;

        //        case nameof(OperationCompletedEvent):
        //            OperationCompletedEvent completeEvt = pluginEvent as OperationCompletedEvent;
        //            if(completeEvt == null)
        //            {
        //                throw new ArgumentException("The provided event cannot be published.");
        //            }
        //            List<Func<OperationCompletedEvent, Task>> completeSubs = _opCompleteHandlers.Values.ToList();
                    
        //            await Task.WhenAll(completeSubs.Select(s => s?.Invoke(completeEvt)));
        //            break;

        //        case nameof(OperationFailedEvent):
        //            OperationFailedEvent failEvt = pluginEvent as OperationFailedEvent;
        //            if (failEvt == null)
        //            {
        //                throw new ArgumentException("The provided event cannot be published.");
        //            }
        //            List<Func<OperationFailedEvent, Task>> failSubs = _opFailedHandlers.Values.ToList();
                    
        //            await Task.WhenAll(failSubs.Select(s => s?.Invoke(failEvt)));
        //            break;

        //        default:
        //            throw new InvalidOperationException("Cannot publish an event of type " + eventType.Name);
        //    }
            
            
                
            
        //}

        

        //public void Subscribe<T>(string componentId, Func<T, Task> eventHandler) where T:EventBase
        //{
        //    while(_lockObject != null)
        //    {
        //        Task.Delay(50).Wait();
        //    }

        //    _lockObject = new object();

        //    Type handlerType = typeof(T);
        //    switch (handlerType.Name)
        //    {
        //        case nameof(OperationStartingEvent):
        //            if(_opStartHandlers.ContainsKey(componentId) == false)
        //            {
        //                _opStartHandlers.Add(componentId, eventHandler as Func<OperationStartingEvent, Task>);
        //            }
        //            else
        //            {
        //                _opStartHandlers[componentId] = eventHandler as Func<OperationStartingEvent, Task>;
        //            }
        //            break;

        //        case nameof(OperationProgressedEvent):
        //            if(_opProgressHandlers.ContainsKey(componentId) == false)
        //            {
        //                _opProgressHandlers.Add(componentId, eventHandler as Func<OperationProgressedEvent, Task>);
        //            }
        //            else
        //            {
        //                _opProgressHandlers[componentId] = eventHandler as Func<OperationProgressedEvent, Task>;
        //            }
        //            break;

        //        case nameof(OperationCompletedEvent):
        //            if(_opCompleteHandlers.ContainsKey(componentId) == false)
        //            {
        //                _opCompleteHandlers.Add(componentId, eventHandler as Func<OperationCompletedEvent, Task>);
        //            }
        //            else
        //            {
        //                _opCompleteHandlers[componentId] = eventHandler as Func<OperationCompletedEvent, Task>;
        //            }
        //            break;

        //        case nameof(OperationFailedEvent):
        //            if(_opFailedHandlers.ContainsKey(componentId) == false)
        //            {
        //                _opFailedHandlers.Add(componentId, eventHandler as Func<OperationFailedEvent, Task>);
        //            }
        //            else
        //            {
        //                _opFailedHandlers[componentId] = eventHandler as Func<OperationFailedEvent, Task>;
        //            }
        //            break;

        //        default:
        //            _lockObject = null;
        //            throw new InvalidOperationException("Cannot subscribe to an event of type " + handlerType.Name);
        //    }

        //    _lockObject = null;

        //}

        public void UnsubscribeAll(string componentId)
        {
            while(_lockObject != null)
            {
                Task.Delay(50).Wait();
            }

            _lockObject = new object();
            foreach(var handlerRegistry in _signalHandlers.Values)
            {
                if(handlerRegistry?.ContainsKey(componentId)??false)
                {
                    handlerRegistry?.Remove(componentId);
                }
            }

            // Clean up the registry to get rid of null entries.  This is kinda icky,
            // not sure if I like this yet.
            Dictionary<string, Dictionary<string, Func<ApplicationSignal, Task>>> newReg =
                new Dictionary<string, Dictionary<string, Func<ApplicationSignal, Task>>>();
            
            foreach(string evtKey in _signalHandlers.Keys.Where(k=> k!=null).ToList())
            {
                var evtHandlers = _signalHandlers[evtKey];
                if (evtHandlers != null)
                {
                    var newHandlers = new Dictionary<string, Func<ApplicationSignal, Task>>();
                    foreach(string handlerKey in evtHandlers.Keys.Where(k=>k!=null).ToList())
                    {
                        if(evtHandlers.ContainsKey(handlerKey))
                        {
                            newHandlers.Add(handlerKey, evtHandlers[handlerKey]);
                        }
                    }
                    newReg.Add(evtKey, newHandlers);
                }
            }

            _signalHandlers.Clear();
            foreach(string evtKey in newReg.Keys)
            {
                _signalHandlers.Add(evtKey, newReg[evtKey]);
            }

            _lockObject = null;

            //if(_lockObject != null)
            //{
            //    Thread.Sleep(50);
            //}

            //_lockObject = new object();

            //if(_opStartHandlers.ContainsKey(componentId))
            //{
            //    _opStartHandlers.Remove(componentId);
            //}

            //if(_opProgressHandlers.ContainsKey(componentId))
            //{
            //    _opProgressHandlers.Remove(componentId);
            //}

            //if(_opCompleteHandlers.ContainsKey(componentId))
            //{
            //    _opCompleteHandlers.Remove(componentId);
            //}

            //if(_opFailedHandlers.ContainsKey(componentId))
            //{
            //    _opFailedHandlers.Remove(componentId);
            //}

            //_lockObject = null;
        }
    }
}
