﻿using Assist.Accelerator.Core.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    /// <summary>
    /// The Base Class that all events passed around the system will inherit from.
    /// Inclides properties for common metadata that must be included with all published events.
    /// </summary>
    public abstract class EventBase
    {
        [JsonConstructor]
        public EventBase()
        {
            ChatId = string.Empty;
            UserId = 0;
            UserEmail = string.Empty;
            CopilotName = string.Empty;
            TimestampUTC = DateTimeOffset.UtcNow.Ticks;
        }

        public EventBase(EventMetadata metadata)
        {
            ChatId = metadata.ChatId;
            UserId = metadata.UserId;
            UserEmail = metadata.UserEmail;
            CopilotName = metadata.CopilotName;
            TimestampUTC = DateTimeOffset.UtcNow.Ticks;
        }

        public EventBase(string chatId, int userId, string userEmail, string? copilotName = "")
        {
            ChatId = chatId;
            UserId = userId;
            UserEmail = userEmail;
            CopilotName = copilotName;
            TimestampUTC = DateTimeOffset.UtcNow.Ticks;
        }

        public string ChatId { get; init; }

        public int UserId { get; init; }

        public string UserEmail { get; init; }

        public string? CopilotName { get; init; }

        public long TimestampUTC { get; init; } 

        public DateTime UTCEventTime => new DateTime(TimestampUTC, DateTimeKind.Utc);

        public DateTime LocalEventTime => new DateTime(TimestampUTC, DateTimeKind.Utc).ToLocalTime();

        public EventMetadata GetMetadata()
        {
            EventMetadata metaData = new EventMetadata(ChatId, UserId, UserEmail, CopilotName);

            return metaData;
        }

        public virtual string ToJson()
        {
            var typeResolver = new PolymorphicEventResolver();
            var options = new JsonSerializerOptions
            {
                TypeInfoResolver = typeResolver
            };

            string json = JsonSerializer.Serialize(this, options);

            return json;
        }

        public static T? FromJson<T>(string json) where T:EventBase
        {
            var typeResolver = new PolymorphicEventResolver();
            var options = new JsonSerializerOptions
            {
                TypeInfoResolver = typeResolver
            };

            T? evtArgs = JsonSerializer.Deserialize<T>(json, options);
            return evtArgs;
        }

    }
}
