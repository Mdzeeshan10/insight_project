﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    /// <summary>
    /// Application Signal is the class used to transport Events from one compontent to another.
    /// Each signal includes a unique identifier, the name of the component that published the event,
    /// the Type Name of the event, and a serialized version of the eventData.
    /// 
    /// Components that process signals will be responsible for deserializing the event data that they
    /// are interested in.
    /// </summary>
    public class ApplicationSignal
    {
        [JsonConstructor]
        public ApplicationSignal():this(string.Empty, null)
        {
        }

        public ApplicationSignal(string componentId, EventBase? payload)
        {
            Id = Guid.NewGuid();
            PublisherCOmponentId = componentId;
            PayloadType = payload?.GetType().Name??nameof(Object);
            SerializedPayload = payload?.ToJson()??string.Empty;
        }

        public Guid Id { get; init; }

        public string PublisherCOmponentId { get; init; }

        public string PayloadType { get; init; }

        public string SerializedPayload { get; init; }

    }
}
