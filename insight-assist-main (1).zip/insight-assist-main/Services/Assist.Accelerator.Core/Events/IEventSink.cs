﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    public interface IEventSink
    {
        Task PublishSignal(ApplicationSignal signal);

        void RegisterHandler(string componentId, string[] eventTypeName, Func<ApplicationSignal, Task> signalHandler);

        void UnsubscribeAll(string componentId);
    }
}
