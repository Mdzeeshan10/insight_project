﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    /// <summary>
    /// Consider instantiating this at the beginning of a Pipeline run so that we're not constantly
    /// interrogating COntext properties for the same stuff every time we raise an event.
    /// </summary>
    public class EventMetadata
    {

        public EventMetadata(string chatId, int userId, string userEmail, string? copilotName = "")
        {
            ChatId = chatId;
            UserId = userId;
            UserEmail = userEmail;
            CopilotName = copilotName;
        }

        public string ChatId { get; init; }

        public int UserId { get; init; }

        public string UserEmail { get; init; }

        public string? CopilotName { get; init; }
    }
}
