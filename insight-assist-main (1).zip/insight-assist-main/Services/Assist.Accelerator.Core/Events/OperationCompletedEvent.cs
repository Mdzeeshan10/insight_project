﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    public class OperationCompletedEvent : EventBase
    {
        [JsonConstructor]
        public OperationCompletedEvent()
        {
            
        }

        public OperationCompletedEvent(EventMetadata metadata,
            string responseContent,
            TokenUsage usage)
        {
            ResponseContent = responseContent;
            Usage = usage;
        }

        //public OperationCompletedEvent(string chatId,
        //    int userId,
        //    string userEmail,
        //    string? copilotName,
        //    string responseContent,
        //    TokenUsage usage):base(chatId, userId, userEmail, copilotName)
        //{
        //    ResponseContent = responseContent;
        //    Usage = usage;
        //}

        /// <summary>
        /// The complete response from the process execution.
        /// </summary>
        public string ResponseContent { get; set; }

        public TokenUsage Usage { get; set; }
    }
}
