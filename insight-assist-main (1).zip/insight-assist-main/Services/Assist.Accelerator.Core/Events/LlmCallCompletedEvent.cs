﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    public class LlmCallCompletedEvent : EventBase
    {
        [JsonConstructor]
        public LlmCallCompletedEvent()
        {
        }

        public LlmCallCompletedEvent(EventMetadata metadata):base(metadata)
        {
            
        }

        public string MethodName { get; set; }

        public DateTime RequestTime { get; set; }

        public DateTime ResponseTime { get; set; }

        public int ModelId { get; set; }

        public bool? IsSystemAction { get; set; }

        public  int PromptTokenCount { get; set; }

        public int CompletionTokenCount { get; set; }

        public string? ResponseRole { get; set; }

        public string? ResponseContent { get; set; }

        public string? ErrorContent { get; set; }

        public int? MaxTokens { get; set; }

        public double? FrequencyPenalty { get; set; }

        public double? PresencePenalty { get; set; }

        public double? Temperature { get; set; }

        public double? TopP { get; set; }

    }
}
