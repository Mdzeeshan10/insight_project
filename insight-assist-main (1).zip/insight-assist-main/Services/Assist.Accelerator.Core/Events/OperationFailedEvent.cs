﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    public class OperationFailedEvent : EventBase
    {
        [JsonConstructor]
        public OperationFailedEvent()
        {
            
        }

        public OperationFailedEvent(EventMetadata metadata,
            string errorText,
            TokenUsage usage)
        {
            ErrorText = errorText;
            Usage = usage;
        }

        //public OperationFailedEvent(string chatId, 
        //    int userId, 
        //    string userEmail, 
        //    string? copilotName,
        //    string errorText,
        //    TokenUsage usage):base(chatId, userId, userEmail, copilotName)
        //{
        //    ErrorText = errorText;
        //    Usage = usage;
        //}

        public string ErrorText { get; set; }

        public TokenUsage Usage { get; set; }
    }
}
