﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    public class TokenUsage
    {
        [JsonConstructor]
        public TokenUsage()
        {
            
        }

        public TokenUsage(int requestTokens, int responseTokens)
        {
            RequestTokens = requestTokens;
            ResponseTokens = responseTokens;
        }

        public int RequestTokens { get; init; }

        public int ResponseTokens { get; init; }

        public int TotalTokens => RequestTokens + ResponseTokens;

        /// <summary>
        /// Use this method when we are using the TokenUsage instance as an aggregator to
        /// collect and roll up all usage from a multi-function call.
        /// Do Not include usage stats harvested from running Native Functions.
        /// </summary>
        /// <param name="usageToAdd"></param>
        /// <returns></returns>
        public TokenUsage AddUsage(TokenUsage usageToAdd)
        {
            return new TokenUsage(RequestTokens + usageToAdd.RequestTokens, ResponseTokens + usageToAdd.ResponseTokens);
        }
    }
}
