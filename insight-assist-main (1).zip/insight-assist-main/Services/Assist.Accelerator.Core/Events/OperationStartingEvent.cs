﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Events
{
    /// <summary>
    /// Provides notice that a particular Operation is starting.  May or may not need to be surfaced to the UI, but is most
    /// useful for observability.
    /// 
    /// Usage:
    /// </summary>
    public class OperationStartingEvent : EventBase
    {
        [JsonConstructor]
        public OperationStartingEvent():base()
        {
            
        }

        public OperationStartingEvent(EventMetadata metadata,
            string? pluginName,
            string? functionName,
            string? description):base(metadata)
        {
            PluginName = pluginName;
            FunctionName = functionName;
            Description = description;
        }

        //public OperationStartingEvent(
        //    string chatId, 
        //    int userId, 
        //    string userEmail, 
        //    string? copilotName, 
        //    string? pluginName, 
        //    string? functionName, 
        //    string? description):base(chatId, userId, userEmail, copilotName)
        //{
        //    PluginName = pluginName;
        //    FunctionName = functionName;
        //    Description = description;
        //}

        public string? PluginName { get; init; }

        public string? FunctionName { get; init; }

        public string? Description { get; init; }

        public string LogMessage => BuildLogMessage();

        private string BuildLogMessage()
        {
            string copilotPart = string.IsNullOrWhiteSpace(CopilotName) ? $"{CopilotName}" : string.Empty;
            string pluginPart = string.IsNullOrWhiteSpace(PluginName) ? $".{PluginName}" : string.Empty;
            string functionPart = string.IsNullOrWhiteSpace(FunctionName) ? $".{FunctionName}" : string.Empty;
            
            string logMessage = $"Operation: {copilotPart}{pluginPart}{functionPart} for chatId {ChatId} {Environment.NewLine} Started at: {LocalEventTime}. {Environment.NewLine} {Description}";

            return logMessage;
        }
    }
}
