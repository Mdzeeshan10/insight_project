﻿using Assist.Accelerator.Core.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Json.Serialization.Metadata;
using System.Threading.Tasks;

namespace Assist.Accelerator.Core.Utility
{
    internal class PolymorphicEventResolver : DefaultJsonTypeInfoResolver
    {
        public override JsonTypeInfo GetTypeInfo(Type type, JsonSerializerOptions options)
        {
            JsonTypeInfo jsonTypeInfo = base.GetTypeInfo(type, options);

            Type basePointType = typeof(EventBase);
            if (jsonTypeInfo.Type == basePointType)
            {
                var eventTypes = GetDerivedEvents();

                jsonTypeInfo.PolymorphismOptions = new JsonPolymorphismOptions
                {
                    TypeDiscriminatorPropertyName = "$point-type",
                    IgnoreUnrecognizedTypeDiscriminators = true,
                    UnknownDerivedTypeHandling = JsonUnknownDerivedTypeHandling.FailSerialization,
                //    DerivedTypes =
                //{
                //    new JsonDerivedType(typeof(ThreeDimensionalPoint), "3d"),
                //    new JsonDerivedType(typeof(FourDimensionalPoint), "4d")
                //}
                };

                foreach(var eventtype in eventTypes)
                    jsonTypeInfo.PolymorphismOptions.DerivedTypes.Add(eventtype);
            }

            return jsonTypeInfo;
        }

        private IList<JsonDerivedType> GetDerivedEvents()
        {
            List<JsonDerivedType> eventTypes = new List<JsonDerivedType>();

            var eventBaseType = typeof(EventBase);
            var eventTypesList = AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(s => s.GetTypes())
                .Where(p => eventBaseType.IsAssignableFrom(p) && p.IsClass && !p.IsAbstract);

            foreach (var eventType in eventTypesList)
                eventTypes.Add(new JsonDerivedType(eventType, eventType.Name));

            return eventTypes;
        }
    }
}
